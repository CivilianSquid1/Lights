/*    */ package com.fiskmods.ui;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Vector;
/*    */ import javax.swing.JList;
/*    */ 
/*    */ public class DynamicJList<E>
/*    */   extends JList<E>
/*    */ {
/* 10 */   private Vector<E> v = new Vector<>();
/*    */   
/*    */   private boolean hasChanged;
/*    */   
/*    */   public void add(E e) {
/* 15 */     this.v.add(e);
/* 16 */     this.hasChanged = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addAll(Collection<? extends E> e) {
/* 21 */     this.v.addAll(e);
/* 22 */     this.hasChanged = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 27 */     this.v.clear();
/* 28 */     this.hasChanged = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sync() {
/* 33 */     if (this.hasChanged) {
/*    */       
/* 35 */       this.hasChanged = false;
/* 36 */       setListData(this.v);
/* 37 */       setSelectedIndex(Math.max(this.v.size() - 1, 0));
/* 38 */       updateUI();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmod\\ui\DynamicJList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */