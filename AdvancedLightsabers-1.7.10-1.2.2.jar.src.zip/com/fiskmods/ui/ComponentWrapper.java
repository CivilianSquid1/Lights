/*    */ package com.fiskmods.ui;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ public class ComponentWrapper
/*    */ {
/*    */   private final UIWindow window;
/*    */   private final Component component;
/*    */   
/*    */   public ComponentWrapper(UIWindow ui, Component c) {
/* 13 */     this.window = ui;
/* 14 */     this.component = c;
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentWrapper map(String id) {
/* 19 */     this.window.components.put(id, this.component);
/* 20 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentWrapper setEnabled(Predicate<Component> p) {
/* 25 */     this.window.enabled.put(this.component, this.window.enabled.containsKey(this.component) ? p.and(this.window.enabled.get(this.component)) : p);
/* 26 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public UIWindow window() {
/* 31 */     return this.window;
/*    */   }
/*    */ 
/*    */   
/*    */   public Component get() {
/* 36 */     return this.component;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmod\\ui\ComponentWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */