/*    */ package com.fiskmods.ui;
/*    */ 
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ public class UIButton
/*    */   extends JButton
/*    */ {
/*    */   public UIButton(String text, int x, int y, int width, int height) {
/*  9 */     super(text);
/* 10 */     setBounds(x, y, width, height);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmod\\ui\UIButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */