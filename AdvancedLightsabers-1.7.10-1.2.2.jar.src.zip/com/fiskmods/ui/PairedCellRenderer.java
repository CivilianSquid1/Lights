/*    */ package com.fiskmods.ui;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.LayoutManager;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.ListCellRenderer;
/*    */ 
/*    */ public class PairedCellRenderer
/*    */   implements ListCellRenderer<String>
/*    */ {
/*    */   private final ListCellRenderer<? super String> renderer;
/*    */   
/*    */   public PairedCellRenderer(JList<String> list) {
/* 17 */     this.renderer = list.getCellRenderer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getListCellRendererComponent(JList<? extends String> parent, String e, int index, boolean selected, boolean hasFocus) {
/* 23 */     String[] astring = e.split(",");
/* 24 */     JPanel panel = new JPanel();
/* 25 */     JLabel label = new JLabel(astring[1]);
/* 26 */     Component c = this.renderer.getListCellRendererComponent(parent, astring[0], index, selected, hasFocus);
/*    */     
/* 28 */     c.setBounds(2, 2, 200, 18);
/* 29 */     panel.setLayout((LayoutManager)null);
/* 30 */     panel.setPreferredSize(new Dimension(0, 22));
/* 31 */     panel.add(c);
/* 32 */     label.setBounds(210, 2, 300, 18);
/* 33 */     panel.setBackground(c.getBackground());
/* 34 */     panel.add(label);
/*    */     
/* 36 */     return panel;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmod\\ui\PairedCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */