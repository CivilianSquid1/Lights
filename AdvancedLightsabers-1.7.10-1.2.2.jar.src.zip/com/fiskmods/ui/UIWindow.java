/*    */ package com.fiskmods.ui;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.LayoutManager;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Predicate;
/*    */ import javax.swing.AbstractButton;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class UIWindow
/*    */   extends JFrame {
/* 17 */   public final Map<String, Component> components = new HashMap<>();
/* 18 */   public final Map<Component, Predicate<Component>> enabled = new HashMap<>();
/* 19 */   public final JPanel panel = new JPanel();
/*    */   
/*    */   private Thread updateThread;
/*    */ 
/*    */   
/*    */   public UIWindow(String title, int width, int height) {
/* 25 */     this.panel.setLayout((LayoutManager)null);
/* 26 */     this.panel.setPreferredSize(new Dimension(width, height));
/* 27 */     this.updateThread = new Thread(() -> {
/*    */           try {
/*    */             while (true) {
/*    */               update();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */               
/*    */               updateUI();
/*    */             } 
/* 38 */           } catch (ThreadDeath threadDeath) {
/*    */             return;
/*    */           } 
/*    */         });
/*    */     
/* 43 */     setTitle(title);
/* 44 */     setContentPane(this.panel);
/* 45 */     setLocationRelativeTo((Component)null);
/* 46 */     setLocation(getX() - width / 2, getY() - height / 2);
/* 47 */     setDefaultCloseOperation(3);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void update() {}
/*    */ 
/*    */   
/*    */   public void updateUI() {
/* 56 */     this.enabled.forEach((key, value) -> key.setEnabled(value.test(key)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ComponentWrapper add(Component component, int x, int y, int width, int height) {
/* 64 */     add(component);
/* 65 */     component.setBounds(x, y, width, height);
/* 66 */     return new ComponentWrapper(this, component);
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentWrapper add(AbstractButton button, int x, int y, int width, int height, ActionListener listener) {
/* 71 */     button.addActionListener(listener);
/* 72 */     return add(button, x, y, width, height);
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentWrapper add(String text, int x, int y, int width, int height) {
/* 77 */     return add(new JLabel(text), x, y, width, height);
/*    */   }
/*    */ 
/*    */   
/*    */   public void open() {
/* 82 */     pack();
/* 83 */     setVisible(true);
/* 84 */     setResizable(false);
/* 85 */     this.updateThread.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 90 */     dispose();
/* 91 */     this.updateThread.stop();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmod\\ui\UIWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */