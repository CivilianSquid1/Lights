package com.fiskmods.lightsabers;

public interface ALConstants {
  public static final String BATTLEGEAR = "battlegear2";
  
  public static final String DYNAMIC_LIGHTS = "DynamicLights";
  
  public static final String TAG_PART = "Type";
  
  public static final String TAG_POUCH_UUID = "PouchID";
  
  public static final String TAG_LIGHTSABER = "Lightsaber";
  
  public static final String TAG_LIGHTSABER_SPECIAL = "Special";
  
  public static final int FORCE_POWER_COOLDOWN = 20;
}


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\ALConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */