/*    */ package com.fiskmods.lightsabers.client.particle;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityALFX
/*    */   extends EntityFX
/*    */ {
/*    */   protected EntityALFX(World world, double x, double y, double z) {
/* 10 */     super(world, x, y, z);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityALFX(World world, double x, double y, double z, double motionX, double motionY, double motionZ) {
/* 15 */     super(world, x, y, z, motionX, motionY, motionZ);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_70537_b() {
/* 21 */     return 9;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70536_a(int index) {
/* 27 */     this.field_94054_b = index % 16;
/* 28 */     this.field_94055_c = index / 16;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\particle\EntityALFX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */