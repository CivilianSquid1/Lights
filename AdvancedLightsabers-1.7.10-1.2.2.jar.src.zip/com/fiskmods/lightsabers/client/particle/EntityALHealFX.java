/*    */ package com.fiskmods.lightsabers.client.particle;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityALHealFX
/*    */   extends EntityALFX
/*    */ {
/*    */   private float flameScale;
/*    */   
/*    */   public EntityALHealFX(World world, double x, double y, double z, double motionX, double motionY, double motionZ) {
/* 13 */     super(world, x, y, z, motionX, motionY, motionZ);
/* 14 */     this.field_70159_w = motionX;
/* 15 */     this.field_70181_x = motionY;
/* 16 */     this.field_70179_y = motionZ;
/* 17 */     this.flameScale = this.field_70544_f;
/* 18 */     this.field_70552_h = this.field_70553_i = this.field_70551_j = 1.0F;
/* 19 */     this.field_70547_e = (int)(10.0D / (Math.random() * 0.25D + 0.75D)) + 10;
/* 20 */     this.field_70145_X = false;
/* 21 */     func_70536_a(0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70539_a(Tessellator tesselator, float partialTicks, float f, float f1, float f2, float f3, float f4) {
/* 27 */     float f5 = (this.field_70546_d + partialTicks) / this.field_70547_e;
/* 28 */     this.field_70544_f = this.flameScale * (1.0F - f5 * f5 * 0.5F);
/* 29 */     super.func_70539_a(tesselator, partialTicks, f, f1, f2, f3, f4);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityFX func_70541_f(float scale) {
/* 35 */     this.flameScale *= scale;
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_70070_b(float partialTicks) {
/* 42 */     return 15728880;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public float func_70013_c(float partialTicks) {
/* 48 */     return 1.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 54 */     this.field_70169_q = this.field_70165_t;
/* 55 */     this.field_70167_r = this.field_70163_u;
/* 56 */     this.field_70166_s = this.field_70161_v;
/* 57 */     this.field_70181_x += 0.0010000000474974513D;
/*    */     
/* 59 */     if (this.field_70546_d++ >= this.field_70547_e)
/*    */     {
/* 61 */       func_70106_y();
/*    */     }
/*    */     
/* 64 */     func_70091_d(this.field_70159_w, this.field_70181_x, this.field_70179_y);
/* 65 */     this.field_70159_w *= 0.9599999785423279D;
/* 66 */     this.field_70181_x *= 0.9599999785423279D;
/* 67 */     this.field_70179_y *= 0.9599999785423279D;
/*    */     
/* 69 */     if (this.field_70122_E) {
/*    */       
/* 71 */       this.field_70159_w *= 0.699999988079071D;
/* 72 */       this.field_70179_y *= 0.699999988079071D;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\particle\EntityALHealFX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */