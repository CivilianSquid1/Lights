/*    */ package com.fiskmods.lightsabers.client.particle;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ 
/*    */ public enum ALParticleType
/*    */ {
/*  7 */   FORCE_HEAL((Class)EntityALHealFX.class);
/*    */   
/*    */   public Class<? extends EntityFX> particleClass;
/*    */ 
/*    */   
/*    */   ALParticleType(Class<? extends EntityFX> clazz) {
/* 13 */     this.particleClass = clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\particle\ALParticleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */