/*    */ package com.fiskmods.lightsabers.client.particle;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALParticles
/*    */ {
/* 15 */   private static final ResourceLocation texture = new ResourceLocation("lightsabers", "textures/particle/particles.png");
/* 16 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   public static final int fxLayersSize = 16;
/*    */ 
/*    */   
/*    */   public static EntityFX spawnParticle(ALParticleType particleType, double x, double y, double z, double motionX, double motionY, double motionZ) {
/* 22 */     if (mc != null && mc.field_71451_h != null && mc.field_71452_i != null && mc.field_71441_e != null)
/*    */     {
/* 24 */       if (mc.field_71441_e.field_72995_K) {
/*    */         
/* 26 */         int particleSetting = mc.field_71474_y.field_74362_aa;
/*    */         
/* 28 */         if (particleSetting == 1 && mc.field_71441_e.field_73012_v.nextInt(3) == 0)
/*    */         {
/* 30 */           particleSetting = 2;
/*    */         }
/*    */         
/* 33 */         double diffX = mc.field_71451_h.field_70165_t - x;
/* 34 */         double diffY = mc.field_71451_h.field_70163_u - y;
/* 35 */         double diffZ = mc.field_71451_h.field_70161_v - z;
/*    */         
/* 37 */         EntityFX particle = null;
/* 38 */         double maxRenderDistance = 16.0D;
/* 39 */         boolean flag = false;
/*    */         
/* 41 */         if (diffX * diffX + diffY * diffY + diffZ * diffZ > maxRenderDistance * maxRenderDistance && flag)
/*    */         {
/* 43 */           return null;
/*    */         }
/* 45 */         if (particleSetting > 1)
/*    */         {
/* 47 */           return null;
/*    */         }
/*    */ 
/*    */ 
/*    */         
/*    */         try {
/* 53 */           Constructor<? extends EntityFX> c = particleType.particleClass.getConstructor(new Class[] { World.class, double.class, double.class, double.class, double.class, double.class, double.class });
/* 54 */           particle = c.newInstance(new Object[] { mc.field_71441_e, Double.valueOf(x), Double.valueOf(y), Double.valueOf(z), Double.valueOf(motionX), Double.valueOf(motionY), Double.valueOf(motionZ) });
/*    */           
/* 56 */           mc.field_71452_i.func_78873_a(particle);
/*    */           
/* 58 */           return particle;
/*    */         }
/* 60 */         catch (Exception e) {
/*    */           
/* 62 */           e.printStackTrace();
/*    */ 
/*    */           
/* 65 */           return null;
/*    */         } 
/*    */       } 
/*    */     }
/*    */     
/* 70 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getParticlesInWorld(List[] list) {
/* 75 */     int i = 0;
/*    */     
/* 77 */     for (int j = 0; j < list.length - 1; j++)
/*    */     {
/* 79 */       i += list[j].size();
/*    */     }
/*    */     
/* 82 */     return i;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void bindParticleTextures(int layer) {
/* 87 */     if (layer == 9)
/*    */     {
/* 89 */       mc.func_110434_K().func_110577_a(texture);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\particle\ALParticles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */