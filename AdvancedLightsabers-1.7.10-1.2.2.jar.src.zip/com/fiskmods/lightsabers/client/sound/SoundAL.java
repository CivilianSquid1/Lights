/*    */ package com.fiskmods.lightsabers.client.sound;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.client.audio.PositionedSound;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class SoundAL
/*    */   extends PositionedSound {
/* 12 */   public static SoundAL mediumHum = makeSound(new ResourceLocation(ALSounds.ambient_lightsaber_hum_medium), true, 1.0F, 0.5F);
/*    */ 
/*    */   
/*    */   public static SoundAL makeSound(ResourceLocation resourceLocation, boolean loop) {
/* 16 */     SoundAL sound = new SoundAL(resourceLocation, 1.0F, 1.0F, false, 0, ISound.AttenuationType.NONE, 0.0F, 0.0F, 0.0F);
/* 17 */     sound.field_147659_g = loop;
/* 18 */     return sound;
/*    */   }
/*    */ 
/*    */   
/*    */   public static SoundAL makeSound(ResourceLocation resourceLocation, boolean loop, float volume, float pitch) {
/* 23 */     SoundAL sound = new SoundAL(resourceLocation, volume, pitch, loop, 0, ISound.AttenuationType.NONE, 0.0F, 0.0F, 0.0F);
/* 24 */     return sound;
/*    */   }
/*    */ 
/*    */   
/*    */   public static SoundAL makeSound(ResourceLocation resourceLocation, boolean loop, float x, float y, float z) {
/* 29 */     SoundAL sound = new SoundAL(resourceLocation, 1.0F, 1.0F, loop, 0, ISound.AttenuationType.LINEAR, x, y, z);
/* 30 */     return sound;
/*    */   }
/*    */ 
/*    */   
/*    */   public static SoundAL makeSound(ResourceLocation resourceLocation, boolean loop, float x, float y, float z, float volume, float pitch, ISound.AttenuationType attenuationType) {
/* 35 */     SoundAL sound = new SoundAL(resourceLocation, volume, pitch, loop, 0, attenuationType, x, y, z);
/* 36 */     return sound;
/*    */   }
/*    */ 
/*    */   
/*    */   public SoundAL(ResourceLocation location, float volume, float pitch, boolean repeat, int p_i45108_5_, ISound.AttenuationType p_i45108_6_, float x, float y, float z) {
/* 41 */     super(location);
/* 42 */     this.field_147662_b = volume;
/* 43 */     this.field_147663_c = pitch;
/* 44 */     this.field_147660_d = x;
/* 45 */     this.field_147661_e = y;
/* 46 */     this.field_147658_f = z;
/* 47 */     this.field_147659_g = repeat;
/* 48 */     this.field_147665_h = p_i45108_5_;
/* 49 */     this.field_147666_i = p_i45108_6_;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\sound\SoundAL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */