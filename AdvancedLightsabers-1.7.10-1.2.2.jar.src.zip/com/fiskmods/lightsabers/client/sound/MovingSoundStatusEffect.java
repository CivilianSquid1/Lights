/*    */ package com.fiskmods.lightsabers.client.sound;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.audio.MovingSound;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class MovingSoundStatusEffect
/*    */   extends MovingSound
/*    */ {
/*    */   public final EntityLivingBase theEntity;
/*    */   public final Effect theEffect;
/*    */   
/*    */   public MovingSoundStatusEffect(EntityLivingBase entity, Effect effect, String name) {
/* 20 */     super(new ResourceLocation(name));
/* 21 */     this.theEntity = entity;
/* 22 */     this.theEffect = effect;
/* 23 */     this.field_147659_g = true;
/* 24 */     this.field_147665_h = 0;
/* 25 */     this.field_147662_b = 1.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_73660_a() {
/* 31 */     if (this.theEntity.field_70128_L || StatusEffect.get(this.theEntity, this.theEffect) == null) {
/*    */       
/* 33 */       this.field_147668_j = true;
/*    */     }
/*    */     else {
/*    */       
/* 37 */       this.field_147660_d = (float)this.theEntity.field_70165_t;
/* 38 */       this.field_147661_e = (float)this.theEntity.field_70163_u;
/* 39 */       this.field_147658_f = (float)this.theEntity.field_70161_v;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\sound\MovingSoundStatusEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */