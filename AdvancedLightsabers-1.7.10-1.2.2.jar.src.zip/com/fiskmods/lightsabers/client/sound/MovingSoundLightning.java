/*    */ package com.fiskmods.lightsabers.client.sound;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.helper.ALHelper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.audio.MovingSound;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class MovingSoundLightning
/*    */   extends MovingSound
/*    */ {
/*    */   public final EntityLivingBase caster;
/*    */   
/*    */   public MovingSoundLightning(EntityLivingBase entity) {
/* 20 */     super(new ResourceLocation(ALSounds.player_force_lightning));
/* 21 */     this.caster = entity;
/* 22 */     this.field_147659_g = true;
/* 23 */     this.field_147665_h = 0;
/* 24 */     this.field_147662_b = 1.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_73660_a() {
/* 30 */     float f = ((Float)ALData.RIGHT_ARM_TIMER.interpolate((Entity)this.caster)).floatValue();
/*    */     
/* 32 */     if (this.caster.field_70128_L || f <= 0.0F) {
/*    */       
/* 34 */       this.field_147668_j = true;
/*    */     }
/*    */     else {
/*    */       
/* 38 */       EntityLivingBase target = ALHelper.getForceLightningTarget(this.caster);
/*    */       
/* 40 */       if ((Minecraft.func_71410_x()).field_71439_g == target) {
/*    */         
/* 42 */         this.field_147660_d = (float)target.field_70165_t;
/* 43 */         this.field_147661_e = (float)target.field_70163_u;
/* 44 */         this.field_147658_f = (float)target.field_70161_v;
/*    */       }
/*    */       else {
/*    */         
/* 48 */         this.field_147660_d = (float)this.caster.field_70165_t;
/* 49 */         this.field_147661_e = (float)this.caster.field_70163_u;
/* 50 */         this.field_147658_f = (float)this.caster.field_70161_v;
/*    */       } 
/*    */       
/* 53 */       this.field_147662_b = f;
/* 54 */       this.field_147663_c = 0.75F + (float)Math.random() * 0.25F;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\sound\MovingSoundLightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */