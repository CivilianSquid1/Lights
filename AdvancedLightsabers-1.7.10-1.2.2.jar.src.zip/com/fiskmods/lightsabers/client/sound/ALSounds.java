/*    */ package com.fiskmods.lightsabers.client.sound;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALSounds
/*    */ {
/*  7 */   public static final String ambient_fortify = create("ambient.fortify");
/*  8 */   public static final String ambient_stealth = create("ambient.stealth");
/*  9 */   public static final String ambient_lightsaber_hum_heavy = create("ambient.lightsaber.hum_heavy");
/* 10 */   public static final String ambient_lightsaber_hum_light = create("ambient.lightsaber.hum_light");
/* 11 */   public static final String ambient_lightsaber_hum_medium = create("ambient.lightsaber.hum_medium");
/* 12 */   public static final String block_holocron_invest = create("block.holocron.invest");
/* 13 */   public static final String block_holocron_unlock = create("block.holocron.unlock");
/* 14 */   public static final String block_sith_sarcophagus_close = create("block.sith_sarcophagus.close");
/* 15 */   public static final String block_sith_sarcophagus_open = create("block.sith_sarcophagus.open");
/* 16 */   public static final String mob_lightsaber_hit = create("mob.lightsaber.hit");
/* 17 */   public static final String mob_lightsaber_off = create("mob.lightsaber.off");
/* 18 */   public static final String mob_lightsaber_on = create("mob.lightsaber.on");
/* 19 */   public static final String mob_lightsaber_swing = create("mob.lightsaber.swing");
/* 20 */   public static final String mob_sith_ghost_death = create("mob.sith_ghost.death");
/* 21 */   public static final String mob_sith_ghost_idle = create("mob.sith_ghost.idle");
/* 22 */   public static final String player_force_cast = create("player.force.cast");
/* 23 */   public static final String player_force_dark = create("player.force.dark");
/* 24 */   public static final String player_force_fail = create("player.force.fail");
/* 25 */   public static final String player_force_heal = create("player.force.heal");
/* 26 */   public static final String player_force_lightning = create("player.force.lightning");
/* 27 */   public static final String player_force_stealth_off = create("player.force.stealth.off");
/* 28 */   public static final String player_force_stealth_on = create("player.force.stealth.on");
/* 29 */   public static final String player_lightsaber_hit = create("player.lightsaber.hit");
/* 30 */   public static final String player_lightsaber_off = create("player.lightsaber.off");
/* 31 */   public static final String player_lightsaber_on = create("player.lightsaber.on");
/* 32 */   public static final String player_lightsaber_sweet_dreams = create("player.lightsaber.sweet_dreams");
/* 33 */   public static final String player_lightsaber_swing = create("player.lightsaber.swing");
/*    */ 
/*    */   
/*    */   private static String create(String s) {
/* 37 */     return "lightsabers:" + s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\sound\ALSounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */