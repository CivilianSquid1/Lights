/*    */ package com.fiskmods.lightsabers.client.sound;
/*    */ 
/*    */ import com.fiskmods.lightsabers.asm.ASMHooksClient;
/*    */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.audio.MovingSound;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class MovingSoundHum
/*    */   extends MovingSound
/*    */ {
/*    */   public final Entity theEntity;
/*    */   
/*    */   public MovingSoundHum(Entity entity, String type) {
/* 23 */     super(new ResourceLocation("lightsabers", "hum_" + type));
/* 24 */     this.theEntity = entity;
/* 25 */     this.field_147659_g = true;
/* 26 */     this.field_147665_h = 0;
/* 27 */     this.field_147662_b = 0.25F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_73660_a() {
/* 33 */     boolean flag = false;
/*    */     
/* 35 */     if (this.theEntity instanceof EntityLivingBase) {
/*    */       
/* 37 */       EntityLivingBase entity = (EntityLivingBase)this.theEntity;
/* 38 */       ItemStack itemstack = entity.func_70694_bm();
/* 39 */       flag = (itemstack == null || !(itemstack.func_77973_b() instanceof ItemLightsaberBase) || !ItemLightsaberBase.isActive(itemstack));
/*    */     }
/* 41 */     else if (this.theEntity instanceof com.fiskmods.lightsabers.common.entity.EntityLightsaber) {
/*    */     
/*    */     } 
/*    */ 
/*    */     
/* 46 */     if (this.theEntity.field_70128_L || flag) {
/*    */       
/* 48 */       this.field_147668_j = true;
/* 49 */       ASMHooksClient.humSounds.remove(this.theEntity.func_110124_au().toString());
/*    */     }
/*    */     else {
/*    */       
/* 53 */       this.field_147660_d = (float)this.theEntity.field_70165_t;
/* 54 */       this.field_147661_e = (float)this.theEntity.field_70163_u;
/* 55 */       this.field_147658_f = (float)this.theEntity.field_70161_v;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\sound\MovingSoundHum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */