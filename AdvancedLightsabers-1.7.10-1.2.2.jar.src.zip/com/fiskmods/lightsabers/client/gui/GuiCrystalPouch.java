/*    */ package com.fiskmods.lightsabers.client.gui;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.container.ContainerCrystalPouch;
/*    */ import com.fiskmods.lightsabers.common.container.InventoryCrystalPouch;
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiCrystalPouch
/*    */   extends GuiContainer
/*    */ {
/* 22 */   private static final ResourceLocation TEXTURES = new ResourceLocation("lightsabers", "textures/gui/container/crystal_pouch.png");
/*    */ 
/*    */   
/*    */   public GuiCrystalPouch(InventoryPlayer inventoryPlayer, InventoryCrystalPouch inventory) {
/* 26 */     super((Container)new ContainerCrystalPouch(inventoryPlayer, inventory));
/* 27 */     this.field_147000_g = 150;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146979_b(int mouseX, int mouseY) {
/* 33 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("gui.crystal_pouch", new Object[0]), 8, 6, 4210752);
/* 34 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("container.inventory", new Object[0]), 8, this.field_147000_g - 93, 4210752);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/* 40 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 41 */     this.field_146297_k.func_110434_K().func_110577_a(TEXTURES);
/* 42 */     func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
/*    */     
/* 44 */     ALRenderHelper.setupRenderItemIntoGUI();
/* 45 */     GL11.glColor4f(0.6F, 0.6F, 0.6F, 0.125F);
/* 46 */     boolean prevColor = field_146296_j.field_77024_a;
/* 47 */     field_146296_j.field_77024_a = false;
/*    */     
/* 49 */     ContainerCrystalPouch container = (ContainerCrystalPouch)this.field_147002_h;
/* 50 */     InventoryCrystalPouch inventory = container.inventory;
/*    */     
/* 52 */     for (int i = 0; i < (CrystalColor.values()).length; i++) {
/*    */       
/* 54 */       if (inventory.func_70301_a(i) == null) {
/*    */         
/* 56 */         int[] pos = { 8 + i % 9 * 18, 18 + i / 9 * 18 };
/*    */         
/* 58 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.25F);
/* 59 */         field_146296_j.func_82406_b(this.field_146297_k.field_71466_p, this.field_146297_k.func_110434_K(), ItemCrystal.create(CrystalColor.values()[i]), this.field_147003_i + pos[0], this.field_147009_r + pos[1]);
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     field_146296_j.field_77024_a = prevColor;
/* 64 */     ALRenderHelper.finishRenderItemIntoGUI();
/* 65 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiCrystalPouch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */