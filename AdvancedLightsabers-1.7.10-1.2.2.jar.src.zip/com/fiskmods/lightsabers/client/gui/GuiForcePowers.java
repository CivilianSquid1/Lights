/*     */ package com.fiskmods.lightsabers.client.gui;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*     */ import com.fiskmods.lightsabers.common.force.PowerStats;
/*     */ import com.fiskmods.lightsabers.common.force.PowerType;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.PacketTileAction;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiOptionButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.stats.AchievementList;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiForcePowers
/*     */   extends GuiScreen
/*     */ {
/*  46 */   private static final int field_146572_y = AchievementList.field_76010_a * 24 - 112;
/*  47 */   private static final int field_146571_z = AchievementList.field_76008_b * 24 - 112;
/*  48 */   private static final int field_146559_A = AchievementList.field_76009_c * 24 - 77;
/*  49 */   private static final int field_146560_B = AchievementList.field_76006_d * 24 - 77;
/*  50 */   private static final ResourceLocation GUI_TEXTURES = new ResourceLocation("textures/gui/achievement/achievement_background.png");
/*     */   protected GuiScreen prevScreen;
/*  52 */   protected int xSize = 256;
/*  53 */   protected int ySize = 202;
/*     */   protected int prevMouseX;
/*     */   protected int prevMouseY;
/*  56 */   protected float zoom = 1.0F;
/*     */   
/*     */   protected double field_146569_s;
/*     */   protected double field_146568_t;
/*     */   protected double field_146567_u;
/*     */   protected double field_146566_v;
/*     */   protected double field_146565_w;
/*     */   protected double field_146573_x;
/*     */   private int field_146554_D;
/*     */   private PowerManager powerManager;
/*  66 */   private LinkedList<Power> powers = new LinkedList<>();
/*     */   
/*     */   public final TileEntityHolocron tile;
/*     */ 
/*     */   
/*     */   public GuiForcePowers(GuiScreen gui, EntityPlayer player, TileEntityHolocron tileentity) {
/*  72 */     this.prevScreen = gui;
/*  73 */     this.tile = tileentity;
/*  74 */     this.powerManager = new PowerManager(player);
/*  75 */     short short1 = 141;
/*  76 */     short short2 = 141;
/*  77 */     this.field_146569_s = this.field_146567_u = this.field_146565_w = (AchievementList.field_76004_f.field_75993_a * 24 - short1 / 2 - 12);
/*  78 */     this.field_146568_t = this.field_146566_v = this.field_146573_x = (AchievementList.field_76004_f.field_75991_b * 24 - short2 / 2);
/*  79 */     this.powers.clear();
/*     */     
/*  81 */     for (Power power : Power.POWERS)
/*     */     {
/*  83 */       this.powers.add(power);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  90 */     this.field_146292_n.add(new GuiOptionButton(0, this.field_146294_l / 2 + 24, this.field_146295_m / 2 + 74, 80, 20, I18n.func_135052_a("gui.done", new Object[0])));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146281_b() {
/*  96 */     if (this.tile != null)
/*     */     {
/*  98 */       ALNetworkManager.wrapper.sendToServer((IMessage)new PacketTileAction((Entity)this.field_146297_k.field_71439_g, this.tile.field_145851_c, this.tile.field_145848_d, this.tile.field_145849_e, 1));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146284_a(GuiButton button) {
/* 105 */     if (button.field_146127_k == 0)
/*     */     {
/* 107 */       this.field_146297_k.func_147108_a(this.prevScreen);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char c, int key) {
/* 114 */     if (key == this.field_146297_k.field_71474_y.field_151445_Q.func_151463_i()) {
/*     */       
/* 116 */       this.field_146297_k.func_147108_a((GuiScreen)null);
/* 117 */       this.field_146297_k.func_71381_h();
/*     */     }
/*     */     else {
/*     */       
/* 121 */       super.func_73869_a(c, key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 128 */     if (Mouse.isButtonDown(0)) {
/*     */       
/* 130 */       int x = (this.field_146294_l - this.xSize) / 2;
/* 131 */       int y = (this.field_146295_m - this.ySize) / 2;
/* 132 */       int i1 = x + 8;
/* 133 */       int j1 = y + 17;
/*     */       
/* 135 */       if ((this.field_146554_D == 0 || this.field_146554_D == 1) && mouseX >= i1 && mouseX < i1 + 224 && mouseY >= j1 && mouseY < j1 + 155)
/*     */       {
/* 137 */         if (this.field_146554_D == 0) {
/*     */           
/* 139 */           this.field_146554_D = 1;
/*     */         }
/*     */         else {
/*     */           
/* 143 */           this.field_146567_u -= ((mouseX - this.prevMouseX) * this.zoom);
/* 144 */           this.field_146566_v -= ((mouseY - this.prevMouseY) * this.zoom);
/* 145 */           this.field_146565_w = this.field_146569_s = this.field_146567_u;
/* 146 */           this.field_146573_x = this.field_146568_t = this.field_146566_v;
/*     */         } 
/*     */         
/* 149 */         this.prevMouseX = mouseX;
/* 150 */         this.prevMouseY = mouseY;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 155 */       this.field_146554_D = 0;
/*     */     } 
/*     */     
/* 158 */     int i = Mouse.getDWheel();
/* 159 */     float prevZoom = this.zoom;
/*     */     
/* 161 */     if (i < 0) {
/*     */       
/* 163 */       this.zoom += 0.25F;
/*     */     }
/* 165 */     else if (i > 0) {
/*     */       
/* 167 */       this.zoom -= 0.25F;
/*     */     } 
/*     */     
/* 170 */     this.zoom = MathHelper.func_76131_a(this.zoom, 1.0F, 2.0F);
/*     */     
/* 172 */     if (this.zoom != prevZoom) {
/*     */       
/* 174 */       float f6 = prevZoom - this.zoom;
/* 175 */       float f5 = prevZoom * this.xSize;
/* 176 */       float f1 = prevZoom * this.ySize;
/* 177 */       float f2 = this.zoom * this.xSize;
/* 178 */       float f3 = this.zoom * this.ySize;
/* 179 */       this.field_146567_u -= ((f2 - f5) * 0.5F);
/* 180 */       this.field_146566_v -= ((f3 - f1) * 0.5F);
/* 181 */       this.field_146565_w = this.field_146569_s = this.field_146567_u;
/* 182 */       this.field_146573_x = this.field_146568_t = this.field_146566_v;
/*     */     } 
/*     */     
/* 185 */     if (this.field_146565_w < field_146572_y)
/*     */     {
/* 187 */       this.field_146565_w = field_146572_y;
/*     */     }
/*     */     
/* 190 */     if (this.field_146573_x < field_146571_z)
/*     */     {
/* 192 */       this.field_146573_x = field_146571_z;
/*     */     }
/*     */     
/* 195 */     if (this.field_146565_w >= field_146559_A)
/*     */     {
/* 197 */       this.field_146565_w = (field_146559_A - 1);
/*     */     }
/*     */     
/* 200 */     if (this.field_146573_x >= field_146560_B)
/*     */     {
/* 202 */       this.field_146573_x = (field_146560_B - 1);
/*     */     }
/*     */     
/* 205 */     func_146276_q_();
/* 206 */     drawBackground(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73876_c() {
/* 212 */     this.field_146569_s = this.field_146567_u;
/* 213 */     this.field_146568_t = this.field_146566_v;
/* 214 */     double d0 = this.field_146565_w - this.field_146567_u;
/* 215 */     double d1 = this.field_146573_x - this.field_146566_v;
/*     */     
/* 217 */     if (d0 * d0 + d1 * d1 < 4.0D) {
/*     */       
/* 219 */       this.field_146567_u += d0;
/* 220 */       this.field_146566_v += d1;
/*     */     }
/*     */     else {
/*     */       
/* 224 */       this.field_146567_u += d0 * 0.85D;
/* 225 */       this.field_146566_v += d1 * 0.85D;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawForeground() {
/* 231 */     int x = (this.field_146294_l - this.xSize) / 2;
/* 232 */     int y = (this.field_146295_m - this.ySize) / 2;
/* 233 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("gui.forcePowers", new Object[0]), x + 15, y + 5, 4210752);
/*     */     
/* 235 */     x += 15;
/* 236 */     y += this.ySize - 25;
/* 237 */     drawOutlinedString(StatCollector.func_74837_a("gui.forcePowers.xp", new Object[] { Integer.valueOf(MathHelper.func_76141_d(((Float)ALData.FORCE_XP.get((Entity)this.field_146297_k.field_71439_g)).floatValue())) }), x, y, (MathHelper.func_76141_d(((Float)ALData.FORCE_XP.get((Entity)this.field_146297_k.field_71439_g)).floatValue()) > 0) ? 8453920 : 14108744);
/* 238 */     drawOutlinedString(StatCollector.func_74837_a("gui.forcePowers.basePower", new Object[] { ALData.BASE_POWER.get((Entity)this.field_146297_k.field_71439_g) }), x, y + 10, (((Byte)ALData.BASE_POWER.get((Entity)this.field_146297_k.field_71439_g)).byteValue() > 0) ? 8453920 : 14108744);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawOutlinedString(String s, int x, int y, int color) {
/* 243 */     this.field_146289_q.func_78276_b(s, x + 1, y, 0);
/* 244 */     this.field_146289_q.func_78276_b(s, x - 1, y, 0);
/* 245 */     this.field_146289_q.func_78276_b(s, x, y + 1, 0);
/* 246 */     this.field_146289_q.func_78276_b(s, x, y - 1, 0);
/* 247 */     this.field_146289_q.func_78276_b(s, x, y, color);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawBackground(int mouseX, int mouseY, float partialTicks) {
/* 252 */     int k = MathHelper.func_76128_c(this.field_146569_s + (this.field_146567_u - this.field_146569_s) * partialTicks);
/* 253 */     int l = MathHelper.func_76128_c(this.field_146568_t + (this.field_146566_v - this.field_146568_t) * partialTicks);
/*     */     
/* 255 */     if (k < field_146572_y)
/*     */     {
/* 257 */       k = field_146572_y;
/*     */     }
/*     */     
/* 260 */     if (l < field_146571_z)
/*     */     {
/* 262 */       l = field_146571_z;
/*     */     }
/*     */     
/* 265 */     if (k >= field_146559_A)
/*     */     {
/* 267 */       k = field_146559_A - 1;
/*     */     }
/*     */     
/* 270 */     if (l >= field_146560_B)
/*     */     {
/* 272 */       l = field_146560_B - 1;
/*     */     }
/*     */     
/* 275 */     int x = (this.field_146294_l - this.xSize) / 2;
/* 276 */     int y = (this.field_146295_m - this.ySize) / 2;
/* 277 */     int k1 = x + 16;
/* 278 */     int l1 = y + 17;
/* 279 */     this.field_73735_i = 0.0F;
/* 280 */     GL11.glDepthFunc(518);
/* 281 */     GL11.glPushMatrix();
/* 282 */     GL11.glTranslatef(k1, l1, -200.0F);
/*     */ 
/*     */     
/* 285 */     GL11.glScalef(1.0F / this.zoom, 1.0F / this.zoom, 1.0F);
/* 286 */     GL11.glEnable(3553);
/* 287 */     GL11.glDisable(2896);
/* 288 */     GL11.glEnable(32826);
/* 289 */     GL11.glEnable(2903);
/* 290 */     int i2 = k + 288 >> 4;
/* 291 */     int j2 = l + 288 >> 4;
/* 292 */     int k2 = (k + 288) % 16;
/* 293 */     int l2 = (l + 288) % 16;
/* 294 */     boolean flag = true;
/* 295 */     boolean flag1 = true;
/* 296 */     boolean flag2 = true;
/* 297 */     boolean flag3 = true;
/* 298 */     boolean flag4 = true;
/* 299 */     Random random = new Random();
/* 300 */     float f1 = 16.0F / this.zoom;
/* 301 */     float f2 = 16.0F / this.zoom;
/*     */ 
/*     */     
/*     */     int i3;
/*     */     
/* 306 */     for (i3 = 0; i3 * f1 - l2 < 155.0F; i3++) {
/*     */       
/* 308 */       float f3 = 0.6F - (j2 + i3) / 25.0F * 0.3F;
/* 309 */       GL11.glColor4f(f3, f3, f3, 1.0F);
/*     */       
/* 311 */       for (int j3 = 0; j3 * f2 - k2 < 224.0F; j3++) {
/*     */         
/* 313 */         Block block = ModBlocks.lightForcestone;
/* 314 */         random.setSeed((this.field_146297_k.func_110432_I().func_148255_b().hashCode() + i2 + j3 + (j2 + i3) * 16));
/* 315 */         int k3 = random.nextInt(Math.max(1 + (i2 + j3 + 10) / 6, 0)) + (i2 + j3 + 10) / 1 - 11;
/*     */         
/* 317 */         if (k3 < 20)
/*     */         {
/* 319 */           block = ModBlocks.darkForcestone;
/*     */         }
/*     */         
/* 322 */         k3 = random.nextInt(50);
/* 323 */         IIcon iicon = block.func_149691_a(random.nextInt(6), (k3 > 32) ? ((k3 > 40) ? 2 : 1) : 0);
/*     */         
/* 325 */         this.field_146297_k.func_110434_K().func_110577_a(TextureMap.field_110575_b);
/* 326 */         func_94065_a(j3 * 16 - k2, i3 * 16 - l2, iicon, 16, 16);
/*     */       } 
/*     */     } 
/*     */     
/* 330 */     GL11.glEnable(2929);
/* 331 */     GL11.glDepthFunc(515);
/* 332 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 337 */     for (i3 = 0; i3 < this.powers.size(); i3++) {
/*     */       
/* 339 */       Power power1 = this.powers.get(i3);
/*     */       
/* 341 */       if (power1.parent != null && this.powers.contains(power1.parent)) {
/*     */         
/* 343 */         int j3 = power1.getXOffset() * 24 - k + 11;
/* 344 */         int k3 = power1.getYOffset() * 24 - l + 11;
/* 345 */         int i = power1.parent.getXOffset() * 24 - k + 11;
/* 346 */         int l3 = power1.parent.getYOffset() * 24 - l + 11;
/* 347 */         boolean flag5 = this.powerManager.hasPowerUnlocked(power1);
/* 348 */         boolean flag6 = this.powerManager.canUnlockPower(power1);
/* 349 */         int hierarchy = this.powerManager.getHierarchy(power1);
/*     */         
/* 351 */         if (hierarchy <= 4) {
/*     */           
/* 353 */           int maxWidth = -16777216;
/*     */           
/* 355 */           if (flag5) {
/*     */             
/* 357 */             maxWidth = -6250336;
/*     */           }
/* 359 */           else if (flag6) {
/*     */             
/* 361 */             maxWidth = -16711936;
/*     */           } 
/*     */           
/* 364 */           Tessellator tessellator = Tessellator.field_78398_a;
/* 365 */           float prevLineWidth = GL11.glGetFloat(2849);
/* 366 */           GL11.glLineWidth(2.0F / this.zoom);
/* 367 */           GL11.glEnable(3042);
/* 368 */           GL11.glDisable(3553);
/* 369 */           OpenGlHelper.func_148821_a(770, 771, 1, 0);
/* 370 */           float f6 = (maxWidth >> 24 & 0xFF) / 255.0F;
/* 371 */           float f = (maxWidth >> 16 & 0xFF) / 255.0F;
/* 372 */           float f3 = (maxWidth >> 8 & 0xFF) / 255.0F;
/* 373 */           float f7 = (maxWidth & 0xFF) / 255.0F;
/* 374 */           GL11.glColor4f(f, f3, f7, f6);
/* 375 */           tessellator.func_78371_b(3);
/* 376 */           tessellator.func_78377_a(j3, k3, 0.0D);
/* 377 */           tessellator.func_78377_a(i, l3, 0.0D);
/* 378 */           tessellator.func_78381_a();
/* 379 */           GL11.glEnable(3553);
/* 380 */           GL11.glDisable(3042);
/* 381 */           GL11.glLineWidth(prevLineWidth);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 386 */     Power power = null;
/* 387 */     float f4 = (mouseX - k1) * this.zoom;
/* 388 */     float f5 = (mouseY - l1) * this.zoom;
/* 389 */     RenderHelper.func_74520_c();
/* 390 */     GL11.glDisable(2896);
/* 391 */     GL11.glEnable(32826);
/* 392 */     GL11.glEnable(2903);
/*     */ 
/*     */ 
/*     */     
/* 396 */     for (int l4 = 0; l4 < this.powers.size(); l4++) {
/*     */       
/* 398 */       Power power1 = this.powers.get(l4);
/* 399 */       int hoverX = power1.getXOffset() * 24 - k;
/* 400 */       int hoverY = power1.getYOffset() * 24 - l;
/*     */       
/* 402 */       if (hoverX >= -24 && hoverY >= -24 && hoverX <= 224.0F * this.zoom && hoverY <= 155.0F * this.zoom) {
/*     */         
/* 404 */         int hierarchy = this.powerManager.getHierarchy(power1);
/*     */ 
/*     */         
/* 407 */         if (this.powerManager.hasPowerUnlocked(power1)) {
/*     */           
/* 409 */           float f6 = 0.75F;
/* 410 */           GL11.glColor4f(f6, f6, f6, 1.0F);
/*     */         }
/* 412 */         else if (this.powerManager.canUnlockPower(power1)) {
/*     */           
/* 414 */           float f6 = 1.0F;
/* 415 */           GL11.glColor4f(f6, f6, f6, 1.0F);
/*     */         }
/* 417 */         else if (hierarchy < 3) {
/*     */           
/* 419 */           float f6 = 0.3F;
/* 420 */           GL11.glColor4f(f6, f6, f6, 1.0F);
/*     */         }
/* 422 */         else if (hierarchy == 3) {
/*     */           
/* 424 */           float f6 = 0.2F;
/* 425 */           GL11.glColor4f(f6, f6, f6, 1.0F);
/*     */         }
/*     */         else {
/*     */           
/* 429 */           if (hierarchy != 4) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 434 */           float f6 = 0.1F;
/* 435 */           GL11.glColor4f(f6, f6, f6, 1.0F);
/*     */         } 
/*     */         
/* 438 */         this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/*     */         
/* 440 */         GL11.glEnable(3042);
/* 441 */         func_73729_b(hoverX - 2, hoverY - 2, 0, 202, 26, 26);
/*     */         
/* 443 */         if (!this.powerManager.canUnlockPower(power1)) {
/*     */           
/* 445 */           float f = 0.1F;
/* 446 */           GL11.glColor4f(f, f, f, 1.0F);
/*     */         } 
/*     */         
/* 449 */         GL11.glDisable(2896);
/* 450 */         GL11.glEnable(2884);
/*     */         
/* 452 */         if (power1.hasIcon()) {
/*     */           
/* 454 */           this.field_146297_k.func_110434_K().func_110577_a(GuiOverlay.ICONS);
/* 455 */           func_73729_b(hoverX + 3, hoverY + 3, power1.getIconX() * 16, power1.getIconY() * 16, 16, 16);
/*     */         } 
/*     */         
/* 458 */         GL11.glBlendFunc(770, 771);
/* 459 */         GL11.glDisable(2896);
/* 460 */         GL11.glDisable(3042);
/* 461 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */         
/* 463 */         if (f4 >= hoverX && f4 <= (hoverX + 22) && f5 >= hoverY && f5 <= (hoverY + 22))
/*     */         {
/* 465 */           power = power1;
/*     */         }
/*     */       } 
/*     */       continue;
/*     */     } 
/* 470 */     GL11.glDisable(2929);
/* 471 */     GL11.glEnable(3042);
/* 472 */     GL11.glPopMatrix();
/* 473 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 474 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/* 475 */     func_73729_b(x, y, 0, 0, this.xSize, this.ySize);
/* 476 */     this.field_73735_i = 0.0F;
/* 477 */     GL11.glDepthFunc(515);
/* 478 */     GL11.glDisable(2929);
/* 479 */     GL11.glEnable(3553);
/* 480 */     super.func_73863_a(mouseX, mouseY, partialTicks);
/*     */     
/* 482 */     GL11.glDisable(2896);
/* 483 */     GL11.glDisable(2929);
/* 484 */     drawForeground();
/* 485 */     GL11.glEnable(2929);
/*     */ 
/*     */     
/* 488 */     if (power != null) {
/*     */       
/* 490 */       String title = power.getLocalizedName();
/* 491 */       int hoverX = mouseX + 12;
/* 492 */       int hoverY = mouseY - 4;
/* 493 */       int hierarchy = this.powerManager.getHierarchy(power);
/*     */       
/* 495 */       if (!this.powerManager.canUnlockPower(power)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 500 */         if (hierarchy == 3)
/*     */         {
/* 502 */           title = I18n.func_135052_a("achievement.unknown", new Object[0]);
/* 503 */           int maxWidth = Math.max(this.field_146289_q.func_78256_a(title), 120);
/* 504 */           String s = (new ChatComponentTranslation("achievement.requires", new Object[] { power.parent.getLocalizedName() })).func_150260_c();
/* 505 */           int k4 = this.field_146289_q.func_78267_b(s, maxWidth);
/* 506 */           func_73733_a(hoverX - 3, hoverY - 3, hoverX + maxWidth + 3, hoverY + k4 + 12 + 3, -1073741824, -1073741824);
/* 507 */           this.field_146289_q.func_78279_b(s, hoverX, hoverY + 12, maxWidth, -9416624);
/*     */         }
/* 509 */         else if (hierarchy < 3)
/*     */         {
/* 511 */           int maxWidth = Math.max(this.field_146289_q.func_78256_a(title), 120);
/* 512 */           String s = (new ChatComponentTranslation("achievement.requires", new Object[] { power.parent.getLocalizedName() })).func_150260_c();
/* 513 */           int k4 = this.field_146289_q.func_78267_b(s, maxWidth);
/* 514 */           func_73733_a(hoverX - 3, hoverY - 3, hoverX + maxWidth + 3, hoverY + k4 + 12 + 3, -1073741824, -1073741824);
/* 515 */           this.field_146289_q.func_78279_b(s, hoverX, hoverY + 12, maxWidth, -9416624);
/*     */         }
/*     */         else
/*     */         {
/* 519 */           title = null;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 524 */         int maxWidth = Math.max(this.field_146289_q.func_78256_a(title), 120);
/*     */         
/* 526 */         List<String> desc = new ArrayList<>();
/* 527 */         PowerStats stats = power.powerStats;
/*     */         
/* 529 */         if (power.getActualXpCost((EntityPlayer)this.field_146297_k.field_71439_g) != 0)
/*     */         {
/* 531 */           desc.add((!this.powerManager.hasPowerUnlocked(power) ? (String)EnumChatFormatting.RED : "") + I18n.func_135052_a("forcepower.cost", new Object[] { Integer.valueOf(power.getActualXpCost((EntityPlayer)this.field_146297_k.field_71439_g)) }));
/*     */         }
/*     */         
/* 534 */         if (stats.baseRequirement != 0)
/*     */         {
/* 536 */           desc.add(((!this.powerManager.hasPowerUnlocked(power) && ((Byte)ALData.BASE_POWER.get((Entity)this.field_146297_k.field_71439_g)).byteValue() < stats.baseRequirement) ? (String)EnumChatFormatting.RED : "") + I18n.func_135052_a("forcepower.basePowerReq", new Object[] { Integer.valueOf(stats.baseRequirement) }));
/*     */         }
/*     */         
/* 539 */         if (stats.useCost != 0.0F)
/*     */         {
/* 541 */           desc.add(I18n.func_135052_a((stats.powerType == PowerType.PER_USE) ? "forcepower.perUse" : ((stats.powerType == PowerType.PER_SECOND) ? "forcepower.perSecond" : "forcepower.passive"), new Object[] { ItemStack.field_111284_a.format(stats.useCost) }));
/*     */         }
/*     */         
/* 544 */         if (stats.baseBonus != 0)
/*     */         {
/* 546 */           desc.add(I18n.func_135052_a("forcepower.basePower", new Object[] { ((stats.baseBonus < 0) ? "-" : "+") + stats.baseBonus }));
/*     */         }
/*     */         
/* 549 */         if (stats.forceBonus != 0)
/*     */         {
/* 551 */           desc.add(I18n.func_135052_a("forcepower.forcePower", new Object[] { ((stats.forceBonus < 0) ? "-" : "+") + stats.forceBonus }));
/*     */         }
/*     */         
/* 554 */         if (stats.regen != 0)
/*     */         {
/* 556 */           desc.add(I18n.func_135052_a("forcepower.forceRegen", new Object[] { ((stats.regen < 0) ? "-" : "+") + stats.regen + ((stats.regenOperation == 1) ? "%" : "") }));
/*     */         }
/*     */         
/* 559 */         if (power.powerEffect != null) {
/*     */           
/* 561 */           String[] astring = power.powerEffect.getDesc();
/*     */           
/* 563 */           if (astring.length > 0) {
/*     */             
/* 565 */             desc.add("");
/* 566 */             desc.addAll(Arrays.asList(astring));
/*     */           } 
/*     */         } 
/*     */         
/* 570 */         for (String s : desc)
/*     */         {
/* 572 */           maxWidth = Math.max(this.field_146289_q.func_78256_a(s), maxWidth);
/*     */         }
/*     */         
/* 575 */         PowerData data = PowerManager.getPowerData((EntityPlayer)this.field_146297_k.field_71439_g, power);
/* 576 */         String xpLeft = I18n.func_135052_a("forcepower.xpLeft", new Object[] { Integer.valueOf(power.getActualXpCost((EntityPlayer)this.field_146297_k.field_71439_g) - data.xpInvested) });
/* 577 */         maxWidth = Math.max(this.field_146289_q.func_78256_a(xpLeft), maxWidth);
/*     */         
/* 579 */         func_73733_a(hoverX - 3, hoverY - 3, hoverX + maxWidth + 3, hoverY + 6 + (2 + this.field_146289_q.field_78288_b) * (desc.size() + 1) + 12, -1073741824, -1073741824);
/* 580 */         int height = hoverY + this.field_146289_q.field_78288_b + 4;
/*     */         
/* 582 */         for (String s2 : desc) {
/*     */           
/* 584 */           this.field_146289_q.func_78261_a(s2, hoverX, height, 10790052);
/* 585 */           height += 2 + this.field_146289_q.field_78288_b;
/*     */         } 
/*     */         
/* 588 */         if (this.powerManager.hasPowerUnlocked(power)) {
/*     */           
/* 590 */           this.field_146289_q.func_78261_a(I18n.func_135052_a("forcepower.unlocked", new Object[0]), hoverX, height + 3, -7302913);
/*     */         }
/*     */         else {
/*     */           
/* 594 */           this.field_146289_q.func_78261_a(xpLeft, hoverX, height + 3, -7302913);
/*     */         } 
/*     */       } 
/*     */       
/* 598 */       if (title != null)
/*     */       {
/* 600 */         this.field_146289_q.func_78261_a(title, hoverX, hoverY, this.powerManager.canUnlockPower(power) ? -1 : -8355712);
/*     */       }
/*     */       
/* 603 */       if (Mouse.isButtonDown(0) && !this.powerManager.hasPowerUnlocked(power) && this.powerManager.canUnlockPower(power) && (MathHelper.func_76128_c(((Float)ALData.FORCE_XP.get((Entity)this.field_146297_k.field_71439_g)).floatValue()) > 0 || power.getActualXpCost((EntityPlayer)this.field_146297_k.field_71439_g) == 0) && (((Byte)ALData.BASE_POWER.get((Entity)this.field_146297_k.field_71439_g)).byteValue() >= power.powerStats.baseRequirement || power.powerStats.baseRequirement == 0))
/*     */       {
/* 605 */         ALData.DRAINING_XP_TO.set((EntityPlayer)this.field_146297_k.field_71439_g, power.getName());
/*     */       }
/*     */       else
/*     */       {
/* 609 */         ALData.DRAINING_XP_TO.set((EntityPlayer)this.field_146297_k.field_71439_g, "");
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 614 */       ALData.DRAINING_XP_TO.set((EntityPlayer)this.field_146297_k.field_71439_g, "");
/*     */     } 
/*     */     
/* 617 */     GL11.glEnable(2929);
/* 618 */     GL11.glEnable(2896);
/* 619 */     RenderHelper.func_74518_a();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_73868_f() {
/* 625 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiForcePowers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */