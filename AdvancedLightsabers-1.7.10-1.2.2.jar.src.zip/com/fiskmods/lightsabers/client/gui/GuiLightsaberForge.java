/*     */ package com.fiskmods.lightsabers.client.gui;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.container.ContainerLightsaberForge;
/*     */ import com.fiskmods.lightsabers.common.container.InventoryLightsaberForge;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.google.common.collect.Iterables;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiLightsaberForge
/*     */   extends GuiContainer
/*     */ {
/*  31 */   private static final ResourceLocation GUI_TEXTURES = new ResourceLocation("lightsabers", "textures/gui/container/lightsaber_forge.png");
/*     */ 
/*     */   
/*     */   public GuiLightsaberForge(InventoryPlayer inventoryPlayer, TileEntityLightsaberForge tile) {
/*  35 */     super((Container)new ContainerLightsaberForge(inventoryPlayer, tile));
/*  36 */     this.field_147000_g = 196;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146979_b(int mouseX, int mouseY) {
/*  42 */     String s = I18n.func_135052_a("gui.lightsaber_forge", new Object[0]);
/*  43 */     this.field_146289_q.func_78276_b(s, this.field_146999_f / 2 - this.field_146289_q.func_78256_a(s) / 2, 6, 4210752);
/*  44 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("container.inventory", new Object[0]), 8, this.field_147000_g - 94, 4210752);
/*     */     
/*  46 */     ContainerLightsaberForge container = (ContainerLightsaberForge)this.field_147002_h;
/*  47 */     InventoryLightsaberForge inventory = container.craftMatrix;
/*  48 */     LightsaberData data = inventory.result;
/*     */     
/*  50 */     if (data != null) {
/*     */       
/*  52 */       if (data.isTooShort()) {
/*     */         
/*  54 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  55 */         this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/*  56 */         func_73729_b(131, 65, 176, 0, 26, 17);
/*     */         
/*  58 */         GL11.glTranslatef(0.0F, 0.0F, 300.0F);
/*  59 */         func_73731_b(this.field_146289_q, I18n.func_135052_a("gui.lightsaber_forge.too_short", new Object[0]), 45, 64 - this.field_146289_q.field_78288_b, 14108744);
/*     */       }
/*     */       else {
/*     */         
/*  63 */         GL11.glTranslatef(0.0F, 0.0F, 300.0F);
/*  64 */         func_73731_b(this.field_146289_q, I18n.func_135052_a("%s cm", new Object[] { ItemStack.field_111284_a.format(data.getHeightCm()) }), 45, 64 - this.field_146289_q.field_78288_b, -1);
/*     */       } 
/*     */       
/*  67 */       GL11.glTranslatef(0.0F, 0.0F, -300.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/*  74 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  75 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/*  76 */     func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
/*     */     
/*  78 */     ContainerLightsaberForge container = (ContainerLightsaberForge)this.field_147002_h;
/*  79 */     InventoryLightsaberForge inventory = container.craftMatrix;
/*  80 */     LightsaberData data = inventory.result;
/*     */     
/*  82 */     if (data != null) {
/*     */       
/*  84 */       float spin = this.field_146297_k.field_71439_g.field_70173_aa + partialTicks;
/*     */       
/*  86 */       GL11.glEnable(32826);
/*  87 */       OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0F, 240.0F);
/*  88 */       GL11.glEnable(2903);
/*  89 */       GL11.glPushMatrix();
/*  90 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  91 */       GL11.glTranslatef((this.field_147003_i + 110), (this.field_147009_r + 40), 20.0F);
/*  92 */       GL11.glRotatef((float)Math.sin((spin / 20.0F)) * 2.5F, 0.0F, 1.0F, 0.0F);
/*  93 */       GL11.glRotatef((float)Math.sin((spin / 20.0F + 2.0F)) * 2.5F, 0.0F, 0.0F, 1.0F);
/*  94 */       GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/*  95 */       GL11.glRotatef(90.0F + spin, 0.0F, 1.0F, 0.0F);
/*  96 */       GL11.glScalef(-20.0F, 20.0F, 20.0F);
/*  97 */       RenderHelper.func_74520_c();
/*  98 */       ALRenderHelper.startGlScissor(this.field_147003_i + 43, this.field_147009_r + 17, 113, 47);
/*  99 */       ALRenderHelper.renderLightsaber(data, container.craftResult.func_70301_a(0), false);
/* 100 */       ALRenderHelper.endGlScissor();
/* 101 */       RenderHelper.func_74518_a();
/* 102 */       GL11.glPopMatrix();
/* 103 */       RenderHelper.func_74518_a();
/*     */     }
/*     */     else {
/*     */       
/* 107 */       Hilt hilt = null;
/*     */       
/* 109 */       for (int slot = 0; slot < 4; slot++) {
/*     */         
/* 111 */         ItemStack stack = inventory.func_70301_a(slot);
/*     */         
/* 113 */         if (stack != null)
/*     */         {
/* 115 */           if (hilt == null || hilt == ItemLightsaberPart.get(stack)) {
/*     */             
/* 117 */             hilt = ItemLightsaberPart.get(stack);
/*     */           }
/*     */           else {
/*     */             
/* 121 */             hilt = null;
/*     */             
/*     */             break;
/*     */           } 
/*     */         }
/*     */       } 
/* 127 */       if (hilt == null)
/*     */       {
/* 129 */         hilt = (Hilt)Iterables.get((Iterable)Hilt.REGISTRY, this.field_146297_k.field_71439_g.field_70173_aa / 20 % Hilt.REGISTRY.func_148742_b().size());
/*     */       }
/*     */       
/* 132 */       ALRenderHelper.setupRenderItemIntoGUI();
/* 133 */       GL11.glColor4f(0.6F, 0.6F, 0.6F, 0.125F);
/* 134 */       boolean prevColor = field_146296_j.field_77024_a;
/* 135 */       field_146296_j.field_77024_a = false;
/*     */       
/* 137 */       if (hilt != null) {
/*     */         
/* 139 */         for (int i = 0; i < 4; i++) {
/*     */           
/* 141 */           if (inventory.func_70301_a(i) == null) {
/*     */             
/* 143 */             int[] pos = ContainerLightsaberForge.SLOTS[i];
/* 144 */             field_146296_j.func_82406_b(this.field_146297_k.field_71466_p, this.field_146297_k.func_110434_K(), ItemLightsaberPart.create(PartType.values()[i], hilt), this.field_147003_i + pos[0], this.field_147009_r + pos[1]);
/*     */           } 
/*     */         } 
/*     */         
/* 148 */         if (inventory.func_70301_a(5) == null) {
/*     */           
/* 150 */           int[] pos = ContainerLightsaberForge.SLOTS[5];
/*     */           
/* 152 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.25F);
/* 153 */           field_146296_j.func_82406_b(this.field_146297_k.field_71466_p, this.field_146297_k.func_110434_K(), ItemCrystal.create(hilt.getColor()), this.field_147003_i + pos[0], this.field_147009_r + pos[1]);
/*     */         } 
/*     */       } 
/*     */       
/* 157 */       field_146296_j.field_77024_a = prevColor;
/* 158 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 159 */       ALRenderHelper.finishRenderItemIntoGUI();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */