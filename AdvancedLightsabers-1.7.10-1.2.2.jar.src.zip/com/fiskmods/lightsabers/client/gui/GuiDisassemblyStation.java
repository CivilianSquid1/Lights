/*    */ package com.fiskmods.lightsabers.client.gui;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.container.ContainerDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiDisassemblyStation
/*    */   extends GuiContainer
/*    */ {
/* 19 */   private static final ResourceLocation GUI_TEXTURES = new ResourceLocation("lightsabers", "textures/gui/container/disassembly_station.png");
/*    */   
/*    */   private TileEntityDisassemblyStation tileentity;
/*    */ 
/*    */   
/*    */   public GuiDisassemblyStation(InventoryPlayer inventoryPlayer, TileEntityDisassemblyStation tile) {
/* 25 */     super((Container)new ContainerDisassemblyStation(inventoryPlayer, tile));
/* 26 */     this.tileentity = tile;
/* 27 */     this.field_147000_g = 168;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146979_b(int mouseX, int mouseY) {
/* 33 */     String s = I18n.func_135052_a(this.tileentity.func_145825_b(), new Object[0]);
/* 34 */     this.field_146289_q.func_78276_b(s, this.field_146999_f / 2 - this.field_146289_q.func_78256_a(s) / 2, 6, 4210752);
/* 35 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("container.inventory", new Object[0]), 8, this.field_147000_g - 94, 4210752);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/* 41 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 42 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/* 43 */     func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
/*    */     
/* 45 */     if (this.tileentity.isBurning()) {
/*    */       
/* 47 */       int i = this.tileentity.getBurnTimeRemainingScaled(13);
/* 48 */       func_73729_b(this.field_147003_i + 56 - 39, this.field_147009_r + 37 + 12 - i, 176, 12 - i, 14, i + 2);
/*    */       
/* 50 */       i = this.tileentity.getCookProgressScaled(24);
/* 51 */       func_73729_b(this.field_147003_i + 79 - 40, this.field_147009_r + 36, 176, 14, i + 1, 16);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */