/*     */ package com.fiskmods.lightsabers.client.gui;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*     */ import com.fiskmods.lightsabers.common.data.ALPlayerData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffect;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectActive;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.List;
/*     */ import mods.battlegear2.utils.BattlegearConfig;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraftforge.client.GuiIngameForge;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiOverlay
/*     */   extends Gui
/*     */ {
/*  35 */   private Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  37 */   public static final ResourceLocation ICONS = new ResourceLocation("lightsabers", "textures/gui/icons.png");
/*  38 */   public static final ResourceLocation WIDGETS = new ResourceLocation("lightsabers", "textures/gui/widgets.png");
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderGameOverlayPre(RenderGameOverlayEvent.Pre event) {
/*  43 */     ScaledResolution res = event.resolution;
/*  44 */     EntityClientPlayerMP entityClientPlayerMP = this.mc.field_71439_g;
/*  45 */     int width = res.func_78326_a();
/*  46 */     int height = res.func_78328_b();
/*     */     
/*  48 */     if (event.type == RenderGameOverlayEvent.ElementType.EXPERIENCE || event.type == RenderGameOverlayEvent.ElementType.JUMPBAR) {
/*     */       
/*  50 */       if (ALHelper.getForcePowerMax((EntityPlayer)entityClientPlayerMP) > 0)
/*     */       {
/*  52 */         GL11.glPushMatrix();
/*  53 */         GL11.glTranslatef(0.0F, -6.0F, 0.0F);
/*     */       }
/*     */     
/*  56 */     } else if (event.type == RenderGameOverlayEvent.ElementType.ALL) {
/*     */       
/*  58 */       if (this.mc.field_71474_y.field_74320_O == 0) {
/*     */         
/*  60 */         GL11.glPushMatrix();
/*  61 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  62 */         GL11.glTranslatef(0.0F, 0.0F, -0.5F);
/*  63 */         GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*  64 */         GL11.glRotatef(0.0F, 1.0F, 0.0F, 0.0F);
/*  65 */         GL11.glRotatef(0.0F, 0.0F, 1.0F, 0.0F);
/*     */         
/*  67 */         for (StatusEffect status : (ALEntityData.getData((EntityLivingBase)entityClientPlayerMP)).activeEffects) {
/*     */           
/*  69 */           Power power = status.effect.getPower(status.amplifier);
/*  70 */           PowerEffect powerEffect = power.powerEffect;
/*     */           
/*  72 */           if (powerEffect instanceof PowerEffectActive)
/*     */           {
/*  74 */             ((PowerEffectActive)powerEffect).render((EntityPlayer)entityClientPlayerMP, event.partialTicks);
/*     */           }
/*     */         } 
/*     */         
/*  78 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/*  81 */       if (ALHelper.getForcePowerMax((EntityPlayer)entityClientPlayerMP) > 0 && GuiIngameForge.renderExperiance) {
/*     */         
/*  83 */         GuiIngameForge.left_height += 6;
/*  84 */         GuiIngameForge.right_height += 6;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderGameOverlayPost(RenderGameOverlayEvent.Post event) {
/*  92 */     ScaledResolution res = event.resolution;
/*  93 */     EntityClientPlayerMP entityClientPlayerMP = this.mc.field_71439_g;
/*  94 */     int width = res.func_78326_a();
/*  95 */     int height = res.func_78328_b();
/*     */     
/*  97 */     if (event.type == RenderGameOverlayEvent.ElementType.EXPERIENCE || event.type == RenderGameOverlayEvent.ElementType.JUMPBAR) {
/*     */       
/*  99 */       if (ALHelper.getForcePowerMax((EntityPlayer)entityClientPlayerMP) > 0)
/*     */       {
/* 101 */         GL11.glPopMatrix();
/*     */       }
/*     */     }
/* 104 */     else if (event.type == RenderGameOverlayEvent.ElementType.HOTBAR) {
/*     */       
/* 106 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 107 */       renderForceBar(event, width, height, (EntityPlayer)entityClientPlayerMP);
/* 108 */       renderPowerSelector(event, width, height, (EntityPlayer)entityClientPlayerMP);
/* 109 */       renderStatusEffects(event, width, height, (EntityPlayer)entityClientPlayerMP);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderForceBar(RenderGameOverlayEvent.Post event, int width, int height, EntityPlayer player) {
/* 115 */     this.mc.func_110434_K().func_110577_a(ICONS);
/* 116 */     int cap = ALHelper.getForcePowerMax(player);
/* 117 */     int left = width / 2 - 91;
/* 118 */     int top = height - 32 + 3;
/*     */     
/* 120 */     if (cap > 0) {
/*     */       
/* 122 */       short barWidth = 182;
/* 123 */       int filled = (int)(((Float)ALData.FORCE_POWER.interpolate((Entity)player)).floatValue() / cap * barWidth);
/* 124 */       int filledDiff = (int)(((Float)ALData.FORCE_POWER_DIFF.interpolate((Entity)player)).floatValue() / cap * barWidth);
/*     */       
/* 126 */       GL11.glEnable(3042);
/* 127 */       func_73729_b(left, top, 0, 74, barWidth, 5);
/*     */       
/* 129 */       if (filledDiff > filled && filledDiff > 0)
/*     */       {
/* 131 */         func_73729_b(left, top, 0, 79, filledDiff, 5);
/*     */       }
/*     */       
/* 134 */       if (filled > 0)
/*     */       {
/* 136 */         func_73729_b(left, top, 0, 84, filled, 5);
/*     */       }
/*     */       
/* 139 */       String s = MathHelper.func_76141_d(((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue()) + "/" + cap;
/*     */       
/* 141 */       boolean prevUnicode = this.mc.field_71466_p.func_82883_a();
/* 142 */       this.mc.field_71466_p.func_78264_a(true);
/* 143 */       GL11.glPushMatrix();
/* 144 */       GL11.glTranslatef((left + barWidth / 2 - this.mc.field_71466_p.func_78256_a(s) / 2), (top - 2), 0.0F);
/*     */       
/* 146 */       this.mc.field_71466_p.func_78276_b(s, 1, 0, 0);
/* 147 */       this.mc.field_71466_p.func_78276_b(s, -1, 0, 0);
/* 148 */       this.mc.field_71466_p.func_78276_b(s, 0, 1, 0);
/* 149 */       this.mc.field_71466_p.func_78276_b(s, 0, -1, 0);
/*     */       
/* 151 */       for (int i = 0; i < 4; i++) {
/*     */         
/* 153 */         GL11.glPushMatrix();
/* 154 */         GL11.glTranslatef((i == 0) ? 0.5F : ((i == 1) ? -0.5F : 0.0F), (i == 2) ? 0.5F : ((i == 3) ? -0.5F : 0.0F), 0.0F);
/* 155 */         this.mc.field_71466_p.func_78276_b(s, 0, 0, 4210752);
/* 156 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/* 159 */       this.mc.field_71466_p.func_78276_b(s, 0, 0, -1);
/* 160 */       this.mc.field_71466_p.func_78264_a(prevUnicode);
/* 161 */       GL11.glDisable(3042);
/* 162 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderPowerSelector(RenderGameOverlayEvent.Post event, int width, int height, EntityPlayer player) {
/* 168 */     this.mc.func_110434_K().func_110577_a(WIDGETS);
/* 169 */     int left = width / 2 - 184;
/* 170 */     int top = height - 22;
/*     */     
/* 172 */     if (ALHelper.getForcePowerMax(player) > 0) {
/*     */       
/* 174 */       ALPlayerData data = ALPlayerData.getData(player);
/* 175 */       int selected = ((Byte)ALData.SELECTED_POWER.get((Entity)player)).byteValue();
/*     */       
/* 177 */       if (Lightsabers.isBattlegearLoaded) {
/*     */         
/* 179 */         BattlegearConfig config = new BattlegearConfig();
/*     */         
/* 181 */         if ((new Rectangle(left + BattlegearConfig.battleBarOffset[0], top + BattlegearConfig.battleBarOffset[1], 62, 22)).intersects(left, top, 62.0D, 22.0D)) {
/*     */           
/* 183 */           left += BattlegearConfig.battleBarOffset[0];
/* 184 */           top += BattlegearConfig.battleBarOffset[1] - 25;
/*     */         } 
/*     */       } 
/*     */       
/* 188 */       GL11.glEnable(3042);
/* 189 */       func_73729_b(left, top, 0, 0, 62, 22);
/* 190 */       this.mc.func_110434_K().func_110577_a(ICONS);
/*     */       
/* 192 */       List<Power> selectedPowers = (List<Power>)ALData.SELECTED_POWERS.get((Entity)player);
/*     */       
/* 194 */       for (int i = 0; i < selectedPowers.size(); i++) {
/*     */         
/* 196 */         if (i <= 2) {
/*     */           
/* 198 */           Power power = selectedPowers.get(i);
/*     */           
/* 200 */           if (power != null && power.hasIcon())
/*     */           {
/* 202 */             func_73729_b(left + 3 + i * 20, top + 3, power.getIconX() * 16, power.getIconY() * 16, 16, 16);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 207 */       this.mc.func_110434_K().func_110577_a(WIDGETS);
/* 208 */       func_73729_b(left - 1 + selected * 20, top - 1, 0, 22, 24, 24);
/* 209 */       GL11.glDisable(3042);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderStatusEffects(RenderGameOverlayEvent.Post event, int width, int height, EntityPlayer player) {
/* 215 */     GL11.glEnable(3042);
/* 216 */     ALEntityData data = ALEntityData.getData((EntityLivingBase)player);
/* 217 */     int left = width - 3;
/* 218 */     int top = height - 28;
/*     */     
/* 220 */     boolean prevUnicodeFlag = this.mc.field_71466_p.func_82883_a();
/* 221 */     this.mc.field_71466_p.func_78264_a(true);
/*     */     
/* 223 */     for (int i = 0; i < data.activeEffects.size(); i++) {
/*     */       
/* 225 */       StatusEffect status = data.activeEffects.get(i);
/* 226 */       Effect e = status.effect;
/*     */       
/* 228 */       if (status.duration >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 233 */         this.mc.func_110434_K().func_110577_a(ICONS);
/* 234 */         func_73729_b(left - 26, top - 26 - 28 * i, 0, 48, 26, 26);
/*     */         
/* 236 */         if (e != null) {
/*     */           
/* 238 */           Power power = e.getPower(status.amplifier);
/*     */           
/* 240 */           if (power != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 245 */             if (power.hasIcon())
/*     */             {
/* 247 */               func_73729_b(left - 21, top - 21 - 28 * i, power.getIconX() * 16, power.getIconY() * 16, 16, 16);
/*     */             }
/*     */             
/* 250 */             String s = e.getLocalizedName();
/* 251 */             String s1 = StringUtils.func_76337_a(status.duration);
/*     */             
/* 253 */             if (status.amplifier > 0 && status.amplifier < 10)
/*     */             {
/* 255 */               s = s + " " + StatCollector.func_74838_a("enchantment.level." + (status.amplifier + 1));
/*     */             }
/*     */             
/* 258 */             func_73731_b(this.mc.field_71466_p, s, left - 30 - this.mc.field_71466_p.func_78256_a(s), top - 22 - 28 * i, -1);
/* 259 */             func_73731_b(this.mc.field_71466_p, s1, left - 30 - this.mc.field_71466_p.func_78256_a(s1), top - 13 - 28 * i, -1);
/*     */           } 
/*     */         } 
/*     */       } 
/* 263 */     }  this.mc.field_71466_p.func_78264_a(prevUnicodeFlag);
/* 264 */     GL11.glDisable(3042);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */