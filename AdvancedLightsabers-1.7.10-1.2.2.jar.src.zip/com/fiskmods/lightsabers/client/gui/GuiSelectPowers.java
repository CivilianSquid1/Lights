/*     */ package com.fiskmods.lightsabers.client.gui;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.fiskmods.lightsabers.common.force.PowerStats;
/*     */ import com.fiskmods.lightsabers.common.force.PowerType;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.ItemRenderer;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureUtil;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiSelectPowers
/*     */   extends GuiScreen
/*     */ {
/*  33 */   public static final ResourceLocation GUI_TEXTURES = new ResourceLocation("lightsabers", "textures/gui/container/force_power_selector.png");
/*  34 */   protected int xSize = 176;
/*  35 */   protected int ySize = 166;
/*     */   
/*  37 */   public int grabbedId = -1;
/*     */   
/*     */   public int grabbedOffsetX;
/*     */   public int grabbedOffsetY;
/*  41 */   public List<PowerSlot> slots = new ArrayList<>();
/*  42 */   public Power[] selectedPowers = new Power[3];
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  47 */     super.func_73866_w_();
/*  48 */     this.slots.clear();
/*  49 */     this.selectedPowers = (Power[])((List)ALData.SELECTED_POWERS.get((Entity)this.field_146297_k.field_71439_g)).toArray((Object[])this.selectedPowers);
/*  50 */     List<PowerData> list = ALHelper.getRelevantPowers((EntityPlayer)this.field_146297_k.field_71439_g);
/*  51 */     Collections.sort(list);
/*     */     
/*  53 */     PowerData[] powers = list.<PowerData>toArray(new PowerData[16]);
/*     */     
/*  55 */     for (int x = 0; x < 4; x++) {
/*     */       
/*  57 */       for (int y = 0; y < 4; y++) {
/*     */         
/*  59 */         PowerData data = powers[y + x * 4];
/*  60 */         this.slots.add(new PowerSlot((data != null) ? data.power : null, y + x * 4, 8 + y * 18, 8 + x * 18));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char c, int key) {
/*  68 */     super.func_73869_a(c, key);
/*     */     
/*  70 */     if (key == this.field_146297_k.field_71474_y.field_151445_Q.func_151463_i()) {
/*     */       
/*  72 */       this.field_146297_k.func_147108_a((GuiScreen)null);
/*  73 */       this.field_146297_k.func_71381_h();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int mouseX, int mouseY, int button) {
/*  80 */     super.func_73864_a(mouseX, mouseY, button);
/*  81 */     int x = (this.field_146294_l - this.xSize) / 2;
/*  82 */     int y = (this.field_146295_m - this.ySize) / 2;
/*  83 */     boolean flag = false;
/*     */     
/*  85 */     if (button == 0 && func_146272_n()) {
/*     */       
/*  87 */       List<Integer> indexes = Lists.newArrayList();
/*     */       int i;
/*  89 */       for (i = 0; i < this.selectedPowers.length; i++) {
/*     */         
/*  91 */         if (this.selectedPowers[i] == null)
/*     */         {
/*  93 */           indexes.add(Integer.valueOf(i));
/*     */         }
/*     */       } 
/*     */       
/*  97 */       if (!indexes.isEmpty() && this.grabbedId < 0)
/*     */       {
/*  99 */         for (PowerSlot slot : this.slots) {
/*     */           
/* 101 */           int x1 = x + slot.x;
/* 102 */           int y1 = y + slot.y;
/*     */           
/* 104 */           if (slot.power != null && (new Rectangle(x1 - 1, y1 - 1, 18, 18)).contains(mouseX, mouseY)) {
/*     */             
/* 106 */             this.selectedPowers[((Integer)indexes.get(0)).intValue()] = slot.power;
/* 107 */             flag = true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 112 */       if (this.grabbedId < 0)
/*     */       {
/* 114 */         for (i = 0; i < 3; i++) {
/*     */           
/* 116 */           if (this.selectedPowers[i] != null && (new Rectangle(x + 62 + i * 18, y + 142, 16, 16)).contains(mouseX, mouseY)) {
/*     */             
/* 118 */             this.selectedPowers[i] = null;
/* 119 */             flag = true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 125 */     if (flag)
/*     */     {
/* 127 */       ALData.SELECTED_POWERS.setWithoutNotify((Entity)this.field_146297_k.field_71439_g, Lists.newArrayList((Object[])this.selectedPowers));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146273_a(int mouseX, int mouseY, int button, long time) {
/* 134 */     super.func_146273_a(mouseX, mouseY, button, time);
/* 135 */     int x = (this.field_146294_l - this.xSize) / 2;
/* 136 */     int y = (this.field_146295_m - this.ySize) / 2;
/*     */     
/* 138 */     if (button == 0)
/*     */     {
/* 140 */       if (this.grabbedId < 0)
/*     */       {
/* 142 */         for (PowerSlot slot : this.slots) {
/*     */           
/* 144 */           int x1 = x + slot.x;
/* 145 */           int y1 = y + slot.y;
/*     */           
/* 147 */           if (slot.power != null && (new Rectangle(x1 - 1, y1 - 1, 18, 18)).contains(mouseX, mouseY)) {
/*     */             
/* 149 */             this.grabbedId = slot.id;
/* 150 */             this.grabbedOffsetX = x1 - mouseX;
/* 151 */             this.grabbedOffsetY = y1 - mouseY;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146286_b(int mouseX, int mouseY, int signature) {
/* 161 */     super.func_146286_b(mouseX, mouseY, signature);
/* 162 */     int x = (this.field_146294_l - this.xSize) / 2;
/* 163 */     int y = (this.field_146295_m - this.ySize) / 2;
/*     */     
/* 165 */     if (signature == 0) {
/*     */       
/* 167 */       if (this.grabbedId >= 0)
/*     */       {
/* 169 */         for (int i = 0; i < 3; i++) {
/*     */           
/* 171 */           if ((new Rectangle(x + 62 + i * 18, y + 142, 16, 16)).contains(mouseX, mouseY)) {
/*     */             
/* 173 */             PowerSlot slot = this.slots.get(this.grabbedId);
/*     */             
/* 175 */             if (slot != null) {
/*     */               
/* 177 */               this.selectedPowers[i] = slot.power;
/* 178 */               ALData.SELECTED_POWERS.setWithoutNotify((Entity)this.field_146297_k.field_71439_g, Lists.newArrayList((Object[])this.selectedPowers));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 184 */       this.grabbedId = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PowerSlot getSlotFor(Power power) {
/* 190 */     for (PowerSlot slot : this.slots) {
/*     */       
/* 192 */       if (slot.power == power)
/*     */       {
/* 194 */         return slot;
/*     */       }
/*     */     } 
/*     */     
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 204 */     func_146276_q_();
/* 205 */     GL11.glEnable(3042);
/* 206 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 207 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/* 208 */     int x = (this.field_146294_l - this.xSize) / 2;
/* 209 */     int y = (this.field_146295_m - this.ySize) / 2;
/* 210 */     func_73729_b(x, y, 0, 0, this.xSize, this.ySize);
/*     */     
/* 212 */     this.field_146297_k.func_110434_K().func_110577_a(GuiOverlay.ICONS);
/* 213 */     Power grabPower = null;
/* 214 */     Power hoverPower = null;
/*     */     
/* 216 */     for (PowerSlot slot : this.slots) {
/*     */       
/* 218 */       Power power = slot.power;
/* 219 */       int x1 = x + slot.x;
/* 220 */       int y1 = y + slot.y;
/*     */       
/* 222 */       if (power != null) {
/*     */         
/* 224 */         if (power.hasIcon())
/*     */         {
/* 226 */           func_73729_b(x1, y1, power.getIconX() * 16, power.getIconY() * 16, 16, 16);
/*     */         }
/*     */         
/* 229 */         if (this.grabbedId == slot.id)
/*     */         {
/* 231 */           grabPower = power;
/*     */         }
/*     */       } 
/*     */       
/* 235 */       if ((new Rectangle(x1 - 1, y1 - 1, 18, 18)).contains(mouseX, mouseY)) {
/*     */         
/* 237 */         GL11.glDisable(2929);
/* 238 */         GL11.glColorMask(true, true, true, false);
/* 239 */         func_73733_a(x1, y1, x1 + 16, y1 + 16, -2130706433, -2130706433);
/* 240 */         GL11.glColorMask(true, true, true, true);
/* 241 */         GL11.glEnable(2929);
/* 242 */         GL11.glEnable(3042);
/*     */         
/* 244 */         hoverPower = power;
/*     */       } 
/*     */     } 
/*     */     
/* 248 */     int grabX = mouseX + this.grabbedOffsetX;
/* 249 */     int grabY = mouseY + this.grabbedOffsetY;
/*     */     
/* 251 */     for (int i = 0; i < this.selectedPowers.length; i++) {
/*     */       
/* 253 */       Power power = this.selectedPowers[i];
/*     */       
/* 255 */       int x1 = x + 62 + i * 18;
/* 256 */       int y1 = y + 142;
/* 257 */       boolean flag = (new Rectangle(x1 - 1, y1 - 1, 18, 18)).contains(mouseX, mouseY);
/*     */       
/* 259 */       if (flag) {
/*     */         
/* 261 */         grabX = x1;
/* 262 */         grabY = y1;
/*     */       } 
/*     */       
/* 265 */       if (power != null && power.hasIcon() && (grabX != x1 || grabY != y1 || grabPower == null))
/*     */       {
/* 267 */         func_73729_b(x1, y1, power.getIconX() * 16, power.getIconY() * 16, 16, 16);
/*     */       }
/*     */       
/* 270 */       if (flag) {
/*     */         
/* 272 */         GL11.glDisable(2929);
/* 273 */         GL11.glColorMask(true, true, true, false);
/* 274 */         func_73733_a(x1, y1, x1 + 16, y1 + 16, -2130706433, -2130706433);
/* 275 */         GL11.glColorMask(true, true, true, true);
/* 276 */         GL11.glEnable(2929);
/* 277 */         GL11.glEnable(3042);
/*     */         
/* 279 */         hoverPower = power;
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     if (hoverPower != null) {
/*     */       
/* 285 */       Tessellator tessellator = Tessellator.field_78398_a;
/* 286 */       float f = 0.00390625F;
/* 287 */       float scale = 70.0F;
/*     */       
/* 289 */       if (hoverPower.hasIcon()) {
/*     */         
/* 291 */         TextureUtil.func_152777_a(false, false, 1.0F);
/* 292 */         GL11.glPushMatrix();
/* 293 */         GL11.glEnable(32826);
/* 294 */         GL11.glTranslatef((x + 126), y + 60.5F, this.field_73735_i + 20.0F);
/* 295 */         GL11.glScalef(scale, -scale, -scale);
/* 296 */         GL11.glTranslatef(-0.5F, -0.25F, -0.0421875F);
/* 297 */         GL11.glTranslatef(0.0F, 0.0F, 0.084375F);
/* 298 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 299 */         ItemRenderer.func_78439_a(tessellator, (hoverPower.getIconX() * 16) * f, (hoverPower.getIconY() * 16) * f, (hoverPower.getIconX() * 16 + 16) * f, (hoverPower.getIconY() * 16 + 16) * f, 16, 16, 0.0F);
/* 300 */         GL11.glDisable(32826);
/* 301 */         GL11.glPopMatrix();
/* 302 */         TextureUtil.func_147945_b();
/*     */       } 
/*     */       
/* 305 */       String name = hoverPower.getLocalizedName();
/* 306 */       int x1 = x + 8;
/* 307 */       int y1 = y + 84;
/* 308 */       int fieldWidth = Math.max(this.field_146289_q.func_78256_a(name), 160);
/*     */       
/* 310 */       List<String> list = Lists.newArrayList();
/* 311 */       PowerStats stats = hoverPower.powerStats;
/*     */       
/* 313 */       if (hoverPower.powerEffect != null) {
/*     */         
/* 315 */         String[] astring = hoverPower.powerEffect.getDesc();
/*     */         
/* 317 */         for (String s : astring)
/*     */         {
/* 319 */           list.add(s);
/*     */         }
/*     */       } 
/*     */       
/* 323 */       for (String desc : list)
/*     */       {
/* 325 */         fieldWidth = Math.max(this.field_146289_q.func_78256_a(desc), fieldWidth);
/*     */       }
/*     */       
/* 328 */       func_73733_a(x1, y1, x1 + fieldWidth, y1 + Math.max((this.field_146289_q.field_78288_b + 2) * list.size() + this.field_146289_q.field_78288_b * 2 + 12, 52), -1524489694, -1524489694);
/* 329 */       int height = y1 + this.field_146289_q.field_78288_b + 4;
/*     */       
/* 331 */       if (name != null)
/*     */       {
/* 333 */         this.field_146289_q.func_78261_a(name, x1 + 3, y1 + 3, -1);
/*     */       }
/*     */       
/* 336 */       if (stats.useCost > 0.0F) {
/*     */         
/* 338 */         this.field_146289_q.func_78261_a(I18n.func_135052_a((stats.powerType == PowerType.PER_USE) ? "forcepower.perUse" : "forcepower.perSecond", new Object[] { ItemStack.field_111284_a.format(stats.useCost) }), x1 + 3, height + 3, 10790052);
/* 339 */         height += 5 + this.field_146289_q.field_78288_b;
/*     */       } 
/*     */       
/* 342 */       for (String desc : list) {
/*     */         
/* 344 */         this.field_146289_q.func_78261_a(desc, x1 + 3, height + 3, 10790052);
/* 345 */         height += 2 + this.field_146289_q.field_78288_b;
/*     */       } 
/*     */       
/* 348 */       GL11.glEnable(3042);
/* 349 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     
/* 352 */     if (grabPower != null && grabPower.hasIcon()) {
/*     */       
/* 354 */       this.field_146297_k.func_110434_K().func_110577_a(GuiOverlay.ICONS);
/* 355 */       func_73729_b(grabX, grabY, grabPower.getIconX() * 16, grabPower.getIconY() * 16, 16, 16);
/*     */     } 
/*     */     
/* 358 */     GL11.glDisable(3042);
/* 359 */     super.func_73863_a(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_73868_f() {
/* 365 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146281_b() {
/* 371 */     ALData.SELECTED_POWERS.sync((EntityPlayer)this.field_146297_k.field_71439_g);
/*     */   }
/*     */ 
/*     */   
/*     */   private class PowerSlot
/*     */   {
/*     */     public Power power;
/*     */     public int id;
/*     */     public int x;
/*     */     public int y;
/*     */     
/*     */     public PowerSlot(Power power, int id, int x, int y) {
/* 383 */       this.power = power;
/* 384 */       this.id = id;
/* 385 */       this.x = x;
/* 386 */       this.y = y;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiSelectPowers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */