/*    */ package com.fiskmods.lightsabers.client.gui;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*    */ import cpw.mods.fml.client.config.DummyConfigElement;
/*    */ import cpw.mods.fml.client.config.GuiConfig;
/*    */ import cpw.mods.fml.client.config.IConfigElement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraftforge.common.config.ConfigElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiALModConfig
/*    */   extends GuiConfig
/*    */ {
/*    */   public GuiALModConfig(GuiScreen parent) {
/* 20 */     super(parent, getConfigElements(), "lightsabers", false, false, "Advanced Lightsabers Configuration");
/*    */   }
/*    */ 
/*    */   
/*    */   private static List<IConfigElement> getConfigElements() {
/* 25 */     List<IConfigElement> elements = new ArrayList<>();
/* 26 */     elements.add(categoryElement("Dynamic Lights", new IConfigElement[0]));
/* 27 */     elements.add(categoryElement("Rendering", new IConfigElement[0]));
/* 28 */     return elements;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String getConventionalName(String s) {
/* 33 */     return s.toLowerCase(Locale.ROOT).replace(" ", "");
/*    */   }
/*    */ 
/*    */   
/*    */   private static IConfigElement categoryElement(String category, String name, String tooltip_key, IConfigElement... configElements) {
/* 38 */     List<IConfigElement> list = (new ConfigElement(ModConfig.configFile.getCategory(category.toLowerCase(Locale.ROOT)))).getChildElements();
/*    */     
/* 40 */     for (IConfigElement configElement : configElements)
/*    */     {
/* 42 */       list.add(configElement);
/*    */     }
/*    */     
/* 45 */     return (IConfigElement)new DummyConfigElement.DummyCategoryElement(name, tooltip_key, list);
/*    */   }
/*    */ 
/*    */   
/*    */   private static IConfigElement categoryElement(String category, IConfigElement... configElements) {
/* 50 */     return categoryElement(category, category, getConventionalName(category), configElements);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiALModConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */