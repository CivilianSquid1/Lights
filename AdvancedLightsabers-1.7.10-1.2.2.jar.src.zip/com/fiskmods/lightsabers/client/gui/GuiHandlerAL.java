/*    */ package com.fiskmods.lightsabers.client.gui;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*    */ import com.fiskmods.lightsabers.common.container.ContainerCrystalPouch;
/*    */ import com.fiskmods.lightsabers.common.container.ContainerDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.container.ContainerLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.container.ContainerSithCoffin;
/*    */ import com.fiskmods.lightsabers.common.container.InventoryCrystalPouch;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import cpw.mods.fml.common.network.IGuiHandler;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiHandlerAL
/*    */   implements IGuiHandler
/*    */ {
/*    */   public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
/* 25 */     TileEntity tile = world.func_147438_o(x, y, z);
/*    */     
/* 27 */     switch (id) {
/*    */       
/*    */       case 0:
/* 30 */         return (world.func_147439_a(x, y, z) instanceof com.fiskmods.lightsabers.common.block.BlockLightsaberForge) ? new ContainerLightsaberForge(player.field_71071_by, (TileEntityLightsaberForge)tile) : null;
/*    */       case 1:
/* 32 */         return (world.func_147439_a(x, y, z) == ModBlocks.sithCoffin) ? new ContainerSithCoffin(player.field_71071_by, (TileEntitySithCoffin)tile) : null;
/*    */       case 3:
/* 34 */         return new ContainerCrystalPouch(player.field_71071_by, new InventoryCrystalPouch(player, x));
/*    */       case 4:
/* 36 */         return (tile instanceof TileEntityDisassemblyStation) ? new ContainerDisassemblyStation(player.field_71071_by, (TileEntityDisassemblyStation)tile) : null;
/*    */     } 
/*    */     
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
/* 45 */     TileEntity tile = world.func_147438_o(x, y, z);
/*    */     
/* 47 */     switch (id) {
/*    */       
/*    */       case 0:
/* 50 */         return (world.func_147439_a(x, y, z) instanceof com.fiskmods.lightsabers.common.block.BlockLightsaberForge) ? new GuiLightsaberForge(player.field_71071_by, (TileEntityLightsaberForge)tile) : null;
/*    */       case 1:
/* 52 */         return (world.func_147439_a(x, y, z) == ModBlocks.sithCoffin) ? new GuiSithCoffin(player.field_71071_by, (TileEntitySithCoffin)tile) : null;
/*    */       case 2:
/* 54 */         return (world.func_147439_a(x, y, z) == ModBlocks.holocron) ? new GuiForcePowers(null, player, (TileEntityHolocron)tile) : null;
/*    */       case 3:
/* 56 */         return new GuiCrystalPouch(player.field_71071_by, new InventoryCrystalPouch(player, x));
/*    */       case 4:
/* 58 */         return (tile instanceof TileEntityDisassemblyStation) ? new GuiDisassemblyStation(player.field_71071_by, (TileEntityDisassemblyStation)tile) : null;
/*    */     } 
/*    */     
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiHandlerAL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */