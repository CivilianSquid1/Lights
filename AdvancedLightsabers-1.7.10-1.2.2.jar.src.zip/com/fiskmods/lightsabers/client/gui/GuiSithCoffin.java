/*    */ package com.fiskmods.lightsabers.client.gui;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.container.ContainerSithCoffin;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiSithCoffin
/*    */   extends GuiContainer
/*    */ {
/* 18 */   private static final ResourceLocation GUI_TEXTURES = new ResourceLocation("textures/gui/container/generic_54.png");
/*    */   
/*    */   private TileEntitySithCoffin tileentity;
/*    */   
/*    */   public GuiSithCoffin(InventoryPlayer inventoryPlayer, TileEntitySithCoffin tile) {
/* 23 */     super((Container)new ContainerSithCoffin(inventoryPlayer, tile));
/* 24 */     this.tileentity = tile;
/* 25 */     this.field_147000_g = 168;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146979_b(int mouseX, int mouseY) {
/* 31 */     String s = this.tileentity.func_145818_k_() ? this.tileentity.func_145825_b() : I18n.func_135052_a(this.tileentity.func_145825_b(), new Object[0]);
/* 32 */     this.field_146289_q.func_78276_b(s, 8, 6, 4210752);
/* 33 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("container.inventory", new Object[0]), 8, this.field_147000_g - 94, 4210752);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/* 39 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 40 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURES);
/* 41 */     int k = (this.field_146294_l - this.field_146999_f) / 2;
/* 42 */     int l = (this.field_146295_m - this.field_147000_g) / 2;
/* 43 */     func_73729_b(k, l, 0, 0, this.field_146999_f, 17);
/* 44 */     func_73729_b(k, l + 17, 0, 71, this.field_146999_f, this.field_147000_g - 17);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\gui\GuiSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */