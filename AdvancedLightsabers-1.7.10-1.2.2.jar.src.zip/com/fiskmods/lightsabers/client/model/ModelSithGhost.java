/*    */ package com.fiskmods.lightsabers.client.model;
/*    */ 
/*    */ import com.fiskmods.lightsabers.helper.ModelHelper;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class ModelSithGhost
/*    */   extends ModelBiped
/*    */ {
/*    */   public ModelRenderer hood;
/*    */   
/*    */   public ModelSithGhost() {
/* 15 */     this.field_78090_t = 64;
/* 16 */     this.field_78089_u = 64;
/* 17 */     this.field_78115_e = new ModelRenderer((ModelBase)this, 22, 10);
/* 18 */     this.field_78115_e.field_78809_i = true;
/* 19 */     this.field_78115_e.func_78793_a(0.0F, 0.0F, 0.0F);
/* 20 */     this.field_78115_e.func_78790_a(-4.0F, 0.0F, -2.5F, 8, 12, 5, 0.0F);
/* 21 */     this.field_78123_h = new ModelRenderer((ModelBase)this, 0, 10);
/* 22 */     this.field_78123_h.func_78793_a(-2.0F, 12.0F, 0.0F);
/* 23 */     this.field_78123_h.func_78790_a(-2.3F, 0.0F, -2.5F, 6, 12, 5, 0.0F);
/* 24 */     setRotateAngle(this.field_78123_h, 0.0F, 0.0F, 0.05235988F);
/* 25 */     this.field_78116_c = new ModelRenderer((ModelBase)this, 0, 0);
/* 26 */     this.field_78116_c.field_78809_i = true;
/* 27 */     this.field_78116_c.func_78793_a(0.0F, 0.0F, 0.0F);
/* 28 */     this.field_78116_c.func_78790_a(-4.5F, -8.0F, -4.5F, 9, 9, 1, 0.0F);
/* 29 */     this.field_78112_f = new ModelRenderer((ModelBase)this, 48, 10);
/* 30 */     this.field_78112_f.func_78793_a(-4.0F, 2.0F, 0.0F);
/* 31 */     this.field_78112_f.func_78790_a(-4.0F, -2.0F, -1.9F, 4, 12, 4, 0.0F);
/* 32 */     this.hood = new ModelRenderer((ModelBase)this, 0, 27);
/* 33 */     this.hood.field_78809_i = true;
/* 34 */     this.hood.func_78793_a(0.0F, 0.0F, 0.0F);
/* 35 */     this.hood.func_78790_a(-5.5F, -9.4F, -3.6F, 11, 11, 9, 0.0F);
/* 36 */     setRotateAngle(this.hood, 0.0842994F, 0.0F, 0.0F);
/* 37 */     this.field_78113_g = new ModelRenderer((ModelBase)this, 48, 10);
/* 38 */     this.field_78113_g.field_78809_i = true;
/* 39 */     this.field_78113_g.func_78793_a(4.0F, 2.0F, 0.0F);
/* 40 */     this.field_78113_g.func_78790_a(0.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
/* 41 */     this.field_78124_i = new ModelRenderer((ModelBase)this, 0, 10);
/* 42 */     this.field_78124_i.field_78809_i = true;
/* 43 */     this.field_78124_i.func_78793_a(2.0F, 12.0F, 0.0F);
/* 44 */     this.field_78124_i.func_78790_a(-3.7F, 0.0F, -2.5F, 6, 12, 5, 0.0F);
/* 45 */     setRotateAngle(this.field_78124_i, 0.0F, 0.0F, -0.05235988F);
/* 46 */     this.field_78116_c.func_78792_a(this.hood);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 52 */     func_78087_a(f, f1, f2, f3, f4, f5, entity);
/* 53 */     ModelHelper.renderBipedPre(this, entity, f, f1, f2, f3, f4, f5);
/* 54 */     this.field_78115_e.func_78785_a(f5);
/* 55 */     this.field_78123_h.func_78785_a(f5);
/* 56 */     this.field_78116_c.func_78785_a(f5);
/* 57 */     this.field_78112_f.func_78785_a(f5);
/* 58 */     this.field_78113_g.func_78785_a(f5);
/* 59 */     this.field_78124_i.func_78785_a(f5);
/* 60 */     ModelHelper.renderBipedPost(this, entity, f, f1, f2, f3, f4, f5);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 65 */     modelRenderer.field_78795_f = x;
/* 66 */     modelRenderer.field_78796_g = y;
/* 67 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
/* 73 */     super.func_78087_a(f, f1, f2, f3, f4, f5, entity);
/* 74 */     this.field_78112_f.func_78793_a(-4.0F, 2.0F, 0.0F);
/* 75 */     this.field_78113_g.func_78793_a(4.0F, 2.0F, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\ModelSithGhost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */