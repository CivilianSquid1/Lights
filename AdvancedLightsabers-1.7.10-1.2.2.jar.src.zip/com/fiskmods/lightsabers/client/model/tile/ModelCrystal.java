/*    */ package com.fiskmods.lightsabers.client.model.tile;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ 
/*    */ public class ModelCrystal
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer shape1;
/*    */   public ModelRenderer shape2;
/*    */   public ModelRenderer shape3;
/*    */   public ModelRenderer shape4;
/*    */   public ModelRenderer shape5;
/*    */   public ModelRenderer shape6;
/*    */   
/*    */   public ModelCrystal() {
/* 17 */     this.field_78090_t = 64;
/* 18 */     this.field_78089_u = 32;
/*    */     
/* 20 */     this.shape2 = new ModelRenderer(this, 0, 0);
/* 21 */     this.shape2.func_78793_a(-0.8F, 24.3F, -0.9F);
/* 22 */     this.shape2.func_78789_a(-0.5F, -3.0F, -0.5F, 1, 3, 1);
/* 23 */     setRotateAngle(this.shape2, 0.34906584F, 0.33161256F, -0.06981317F);
/* 24 */     this.shape6 = new ModelRenderer(this, 0, 0);
/* 25 */     this.shape6.func_78793_a(0.5F, 24.0F, -1.5F);
/* 26 */     this.shape6.func_78789_a(-0.5F, -3.0F, -0.5F, 2, 3, 2);
/* 27 */     setRotateAngle(this.shape6, 0.20943952F, -0.82030475F, 0.12217305F);
/* 28 */     this.shape4 = new ModelRenderer(this, 0, 0);
/* 29 */     this.shape4.func_78793_a(-8.326673E-17F, 24.3F, 1.0F);
/* 30 */     this.shape4.func_78789_a(-0.5F, -4.0F, -1.0F, 1, 4, 2);
/* 31 */     setRotateAngle(this.shape4, -0.2443461F, 1.1693707F, 0.34906584F);
/* 32 */     this.shape1 = new ModelRenderer(this, 0, 0);
/* 33 */     this.shape1.func_78793_a(-1.0F, 24.3F, 2.7755576E-17F);
/* 34 */     this.shape1.func_78789_a(-1.0F, -4.0F, -1.0F, 2, 4, 2);
/* 35 */     setRotateAngle(this.shape1, -0.17453292F, 0.0F, -0.17453292F);
/* 36 */     this.shape5 = new ModelRenderer(this, 0, 0);
/* 37 */     this.shape5.func_78793_a(-8.326673E-17F, 24.3F, 0.5F);
/* 38 */     this.shape5.func_78789_a(-0.5F, -3.0F, -0.5F, 1, 3, 1);
/* 39 */     setRotateAngle(this.shape5, -0.5235988F, -0.40142572F, 0.12217305F);
/* 40 */     this.shape3 = new ModelRenderer(this, 0, 0);
/* 41 */     this.shape3.func_78793_a(-8.326673E-17F, 24.3F, 2.7755576E-17F);
/* 42 */     this.shape3.func_78789_a(-1.0F, -6.0F, -1.0F, 2, 6, 2);
/* 43 */     setRotateAngle(this.shape3, 0.08726646F, 0.0F, 0.10471976F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render() {
/* 48 */     this.shape2.func_78785_a(0.0625F);
/* 49 */     this.shape6.func_78785_a(0.0625F);
/* 50 */     this.shape4.func_78785_a(0.0625F);
/* 51 */     this.shape1.func_78785_a(0.0625F);
/* 52 */     this.shape5.func_78785_a(0.0625F);
/* 53 */     this.shape3.func_78785_a(0.0625F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 58 */     modelRenderer.field_78795_f = x;
/* 59 */     modelRenderer.field_78796_g = y;
/* 60 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\tile\ModelCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */