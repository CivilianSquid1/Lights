/*     */ package com.fiskmods.lightsabers.client.model.tile;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelDisassemblyStation
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer tabletopThing;
/*     */   public ModelRenderer back;
/*     */   public ModelRenderer base;
/*     */   public ModelRenderer ring1;
/*     */   public ModelRenderer theClawwwww;
/*     */   public ModelRenderer tabletopThingSlant;
/*     */   public ModelRenderer innerSlant;
/*     */   public ModelRenderer frontTop;
/*     */   public ModelRenderer outerSlant;
/*     */   public ModelRenderer ring2;
/*     */   public ModelRenderer ring3;
/*     */   public ModelRenderer ring4;
/*     */   public ModelRenderer ring5;
/*     */   public ModelRenderer ring6;
/*     */   public ModelRenderer ring7;
/*     */   public ModelRenderer ring8;
/*     */   public ModelRenderer clawArm2;
/*     */   public ModelRenderer clawArm3;
/*     */   public ModelRenderer clawArm3Left;
/*     */   public ModelRenderer clawArm3Right;
/*     */   public ModelRenderer clawArm4Left;
/*     */   public ModelRenderer clawArm4Right;
/*     */   
/*     */   public ModelDisassemblyStation() {
/*  35 */     this.field_78090_t = 128;
/*  36 */     this.field_78089_u = 128;
/*  37 */     this.base = new ModelRenderer(this, 0, 0);
/*  38 */     this.base.func_78793_a(0.0F, 0.0F, 0.0F);
/*  39 */     this.base.func_78790_a(-16.0F, 10.0F, -8.0F, 32, 14, 16, 0.0F);
/*  40 */     this.ring6 = new ModelRenderer(this, 81, 10);
/*  41 */     this.ring6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.ring6.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  43 */     setRotateAngle(this.ring6, 0.0F, -2.3561945F, 0.0F);
/*  44 */     this.ring4 = new ModelRenderer(this, 81, 10);
/*  45 */     this.ring4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.ring4.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  47 */     setRotateAngle(this.ring4, 0.0F, 2.3561945F, 0.0F);
/*  48 */     this.clawArm2 = new ModelRenderer(this, 81, 0);
/*  49 */     this.clawArm2.func_78793_a(-0.4F, 9.6F, 0.0F);
/*  50 */     this.clawArm2.func_78790_a(0.0F, 0.6F, -0.01F, 2, 6, 2, 0.0F);
/*  51 */     setRotateAngle(this.clawArm2, 0.0F, 0.0F, -0.87266463F);
/*  52 */     this.ring2 = new ModelRenderer(this, 81, 10);
/*  53 */     this.ring2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  54 */     this.ring2.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  55 */     setRotateAngle(this.ring2, 0.0F, 0.7853982F, 0.0F);
/*  56 */     this.ring5 = new ModelRenderer(this, 81, 10);
/*  57 */     this.ring5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  58 */     this.ring5.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  59 */     setRotateAngle(this.ring5, 0.0F, 3.1415927F, 0.0F);
/*  60 */     this.clawArm3 = new ModelRenderer(this, 81, 0);
/*  61 */     this.clawArm3.func_78793_a(4.5F, 6.6F, 0.0F);
/*  62 */     this.clawArm3.func_78790_a(0.0F, 0.6F, -0.01F, 0, 4, 0, 0.0F);
/*  63 */     setRotateAngle(this.clawArm3, 0.0F, 0.0F, 1.5707964F);
/*  64 */     this.ring8 = new ModelRenderer(this, 81, 10);
/*  65 */     this.ring8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  66 */     this.ring8.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  67 */     setRotateAngle(this.ring8, 0.0F, -0.7853982F, 0.0F);
/*  68 */     this.clawArm4Left = new ModelRenderer(this, 103, 11);
/*  69 */     this.clawArm4Left.func_78793_a(-3.4F, 0.1F, -0.02F);
/*  70 */     this.clawArm4Left.func_78790_a(0.0F, 0.0F, 0.0F, 2, 5, 2, 0.0F);
/*  71 */     setRotateAngle(this.clawArm4Left, 0.0F, 0.0F, -1.0995574F);
/*  72 */     this.tabletopThing = new ModelRenderer(this, 90, 0);
/*  73 */     this.tabletopThing.func_78793_a(22.0F, -3.0F, 4.0F);
/*  74 */     this.tabletopThing.func_78790_a(-19.0F, 10.0F, -8.0F, 12, 3, 7, 0.0F);
/*  75 */     this.theClawwwww = new ModelRenderer(this, 0, 0);
/*  76 */     this.theClawwwww.func_78793_a(-18.0F, -2.0F, 4.0F);
/*  77 */     this.theClawwwww.func_78790_a(0.0F, 0.0F, 0.0F, 2, 10, 2, 0.0F);
/*  78 */     setRotateAngle(this.theClawwwww, -0.9075712F, 0.13962634F, 0.0F);
/*  79 */     this.clawArm3Left = new ModelRenderer(this, 94, 10);
/*  80 */     this.clawArm3Left.func_78793_a(1.84F, 5.61F, 0.0F);
/*  81 */     this.clawArm3Left.func_78790_a(0.0F, 0.6F, -0.01F, 2, 3, 2, 0.0F);
/*  82 */     setRotateAngle(this.clawArm3Left, 0.0F, 0.0F, 2.3561945F);
/*  83 */     this.clawArm4Right = new ModelRenderer(this, 103, 11);
/*  84 */     this.clawArm4Right.func_78793_a(3.71F, 0.86F, -0.02F);
/*  85 */     this.clawArm4Right.func_78790_a(0.0F, 0.0F, 0.0F, 2, 4, 2, 0.0F);
/*  86 */     setRotateAngle(this.clawArm4Right, 0.0F, 0.0F, 0.7330383F);
/*  87 */     this.ring1 = new ModelRenderer(this, 81, 10);
/*  88 */     this.ring1.func_78793_a(-15.0F, -1.1F, 4.0F);
/*  89 */     this.ring1.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/*  90 */     setRotateAngle(this.ring1, 1.5707964F, 1.5707964F, 0.0F);
/*  91 */     this.tabletopThingSlant = new ModelRenderer(this, 94, 26);
/*  92 */     this.tabletopThingSlant.func_78793_a(-19.0F, 13.54F, -11.54F);
/*  93 */     this.tabletopThingSlant.func_78790_a(0.0F, 0.0F, 0.0F, 12, 3, 5, 0.0F);
/*  94 */     setRotateAngle(this.tabletopThingSlant, 0.7853982F, 0.0F, 0.0F);
/*  95 */     this.back = new ModelRenderer(this, 0, 30);
/*  96 */     this.back.func_78793_a(0.0F, -7.0F, 11.0F);
/*  97 */     this.back.func_78790_a(-16.0F, 2.0F, -8.0F, 32, 15, 5, 0.0F);
/*  98 */     this.ring3 = new ModelRenderer(this, 81, 10);
/*  99 */     this.ring3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 100 */     this.ring3.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/* 101 */     setRotateAngle(this.ring3, 0.0F, 1.5707964F, 0.0F);
/* 102 */     this.outerSlant = new ModelRenderer(this, 0, 72);
/* 103 */     this.outerSlant.func_78793_a(0.0F, -2.0F, -13.47F);
/* 104 */     this.outerSlant.func_78790_a(-15.99F, 10.0F, -8.0F, 32, 8, 4, 0.0F);
/* 105 */     setRotateAngle(this.outerSlant, 1.0821041F, 0.0F, 0.0F);
/* 106 */     this.ring7 = new ModelRenderer(this, 81, 10);
/* 107 */     this.ring7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 108 */     this.ring7.func_78790_a(-1.5F, -2.0F, 0.62F, 3, 2, 3, 0.0F);
/* 109 */     setRotateAngle(this.ring7, 0.0F, -1.5810938F, 0.0F);
/* 110 */     this.innerSlant = new ModelRenderer(this, 0, 50);
/* 111 */     this.innerSlant.func_78793_a(0.0F, -4.0F, -16.0F);
/* 112 */     this.innerSlant.func_78790_a(-16.01F, 10.0F, -8.0F, 32, 8, 6, 0.0F);
/* 113 */     setRotateAngle(this.innerSlant, 0.87266463F, 0.0F, 0.0F);
/* 114 */     this.frontTop = new ModelRenderer(this, 0, 64);
/* 115 */     this.frontTop.func_78793_a(-16.0F, 6.22F, -6.52F);
/* 116 */     this.frontTop.func_78790_a(0.0F, 0.0F, 0.0F, 32, 4, 4, 0.0F);
/* 117 */     setRotateAngle(this.frontTop, -0.87266463F, 0.0F, 0.0F);
/* 118 */     this.clawArm3Right = new ModelRenderer(this, 94, 10);
/* 119 */     this.clawArm3Right.field_78809_i = true;
/* 120 */     this.clawArm3Right.func_78793_a(1.84F, 5.61F, 0.0F);
/* 121 */     this.clawArm3Right.func_78790_a(3.2F, -0.8F, -0.01F, 2, 3, 2, 0.0F);
/* 122 */     setRotateAngle(this.clawArm3Right, 0.0F, 0.0F, -2.3561945F);
/* 123 */     this.ring1.func_78792_a(this.ring6);
/* 124 */     this.ring1.func_78792_a(this.ring4);
/* 125 */     this.theClawwwww.func_78792_a(this.clawArm2);
/* 126 */     this.ring1.func_78792_a(this.ring2);
/* 127 */     this.ring1.func_78792_a(this.ring5);
/* 128 */     this.clawArm2.func_78792_a(this.clawArm3);
/* 129 */     this.ring1.func_78792_a(this.ring8);
/* 130 */     this.clawArm3Left.func_78792_a(this.clawArm4Left);
/* 131 */     this.clawArm3.func_78792_a(this.clawArm3Left);
/* 132 */     this.clawArm3Right.func_78792_a(this.clawArm4Right);
/* 133 */     this.tabletopThing.func_78792_a(this.tabletopThingSlant);
/* 134 */     this.ring1.func_78792_a(this.ring3);
/* 135 */     this.innerSlant.func_78792_a(this.outerSlant);
/* 136 */     this.ring1.func_78792_a(this.ring7);
/* 137 */     this.back.func_78792_a(this.innerSlant);
/* 138 */     this.innerSlant.func_78792_a(this.frontTop);
/* 139 */     this.clawArm3.func_78792_a(this.clawArm3Right);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(float scale) {
/* 144 */     this.base.func_78785_a(scale);
/* 145 */     this.tabletopThing.func_78785_a(scale);
/* 146 */     this.theClawwwww.func_78785_a(scale);
/* 147 */     GL11.glPushMatrix();
/* 148 */     GL11.glTranslatef(this.ring1.field_82906_o, this.ring1.field_82908_p, this.ring1.field_82907_q);
/* 149 */     GL11.glTranslatef(this.ring1.field_78800_c * scale, this.ring1.field_78797_d * scale, this.ring1.field_78798_e * scale);
/* 150 */     GL11.glScaled(1.0D, 0.8D, 0.8D);
/* 151 */     GL11.glTranslatef(-this.ring1.field_82906_o, -this.ring1.field_82908_p, -this.ring1.field_82907_q);
/* 152 */     GL11.glTranslatef(-this.ring1.field_78800_c * scale, -this.ring1.field_78797_d * scale, -this.ring1.field_78798_e * scale);
/* 153 */     this.ring1.func_78785_a(scale);
/* 154 */     GL11.glPopMatrix();
/* 155 */     this.back.func_78785_a(scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 160 */     modelRenderer.field_78795_f = x;
/* 161 */     modelRenderer.field_78796_g = y;
/* 162 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\tile\ModelDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */