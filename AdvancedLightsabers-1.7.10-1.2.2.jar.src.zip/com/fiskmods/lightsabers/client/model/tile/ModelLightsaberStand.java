/*    */ package com.fiskmods.lightsabers.client.model.tile;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class ModelLightsaberStand
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer base1;
/*    */   public ModelRenderer lStandAngle;
/*    */   public ModelRenderer lStandTip;
/*    */   public ModelRenderer rStandAngle;
/*    */   public ModelRenderer rStandTip;
/*    */   public ModelRenderer trimBtm;
/*    */   public ModelRenderer trimL;
/*    */   public ModelRenderer trimR;
/*    */   public ModelRenderer trimTop;
/*    */   
/*    */   public ModelLightsaberStand() {
/* 22 */     this.field_78090_t = 64;
/* 23 */     this.field_78089_u = 32;
/* 24 */     this.trimBtm = (new ModelRenderer(this, "trimBtm")).func_78784_a(10, 9);
/* 25 */     this.trimBtm.func_78793_a(0.0F, 0.0F, 0.0F);
/* 26 */     this.trimBtm.func_78790_a(0.0F, 0.0F, 0.0F, 15, 3, 1, 0.0F);
/* 27 */     this.rStandAngle = (new ModelRenderer(this, "rStandAngle")).func_78784_a(0, 0);
/* 28 */     this.rStandAngle.func_78793_a(0.3F, 0.7F, 0.0F);
/* 29 */     this.rStandAngle.func_78790_a(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
/* 30 */     setRotateAngle(this.rStandAngle, 0.0F, 0.0F, -0.7853982F);
/* 31 */     this.trimL = (new ModelRenderer(this, "trimL")).func_78784_a(0, 9);
/* 32 */     this.trimL.func_78793_a(-5.2F, 22.8F, -2.8F);
/* 33 */     this.trimL.func_78790_a(0.0F, 0.0F, 0.0F, 1, 3, 8, 0.0F);
/* 34 */     this.rStandTip = (new ModelRenderer(this, "rStandTip")).func_78784_a(0, 0);
/* 35 */     this.rStandTip.func_78793_a(2.5F, 22.3F, -0.5F);
/* 36 */     this.rStandTip.func_78790_a(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
/* 37 */     this.lStandTip = (new ModelRenderer(this, "lStandTip")).func_78784_a(0, 0);
/* 38 */     this.lStandTip.func_78793_a(-3.5F, 22.3F, -0.5F);
/* 39 */     this.lStandTip.func_78790_a(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
/* 40 */     this.trimTop = (new ModelRenderer(this, "trimTop")).func_78784_a(10, 9);
/* 41 */     this.trimTop.func_78793_a(0.0F, 0.0F, 7.0F);
/* 42 */     this.trimTop.func_78790_a(0.0F, 0.0F, 0.0F, 15, 3, 1, 0.0F);
/* 43 */     this.lStandAngle = (new ModelRenderer(this, "lStandAngle")).func_78784_a(0, 0);
/* 44 */     this.lStandAngle.func_78793_a(0.0F, 0.0F, 0.0F);
/* 45 */     this.lStandAngle.func_78790_a(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
/* 46 */     setRotateAngle(this.lStandAngle, 0.0F, 0.0F, 0.7853982F);
/* 47 */     this.base1 = (new ModelRenderer(this, "base1")).func_78784_a(0, 0);
/* 48 */     this.base1.func_78793_a(-4.8F, 23.0F, -2.3F);
/* 49 */     this.base1.func_78790_a(0.0F, 0.0F, 0.0F, 14, 1, 8, 0.0F);
/* 50 */     this.trimR = (new ModelRenderer(this, "trimR")).func_78784_a(0, 9);
/* 51 */     this.trimR.func_78793_a(14.0F, 0.0F, 0.0F);
/* 52 */     this.trimR.func_78790_a(0.0F, 0.0F, 0.0F, 1, 3, 8, 0.0F);
/* 53 */     this.trimL.func_78792_a(this.trimBtm);
/* 54 */     this.rStandTip.func_78792_a(this.rStandAngle);
/* 55 */     this.trimL.func_78792_a(this.trimTop);
/* 56 */     this.lStandTip.func_78792_a(this.lStandAngle);
/* 57 */     this.trimL.func_78792_a(this.trimR);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render() {
/* 62 */     GL11.glPushMatrix();
/* 63 */     GL11.glTranslatef(this.trimL.field_82906_o, this.trimL.field_82908_p, this.trimL.field_82907_q);
/* 64 */     GL11.glTranslatef(this.trimL.field_78800_c * 0.0625F, this.trimL.field_78797_d * 0.0625F, this.trimL.field_78798_e * 0.0625F);
/* 65 */     GL11.glScaled(0.7D, 0.4D, 0.7D);
/* 66 */     GL11.glTranslatef(-this.trimL.field_82906_o, -this.trimL.field_82908_p, -this.trimL.field_82907_q);
/* 67 */     GL11.glTranslatef(-this.trimL.field_78800_c * 0.0625F, -this.trimL.field_78797_d * 0.0625F, -this.trimL.field_78798_e * 0.0625F);
/* 68 */     this.trimL.func_78785_a(0.0625F);
/* 69 */     GL11.glPopMatrix();
/* 70 */     this.rStandTip.func_78785_a(0.0625F);
/* 71 */     this.lStandTip.func_78785_a(0.0625F);
/* 72 */     GL11.glPushMatrix();
/* 73 */     GL11.glTranslatef(this.base1.field_82906_o, this.base1.field_82908_p, this.base1.field_82907_q);
/* 74 */     GL11.glTranslatef(this.base1.field_78800_c * 0.0625F, this.base1.field_78797_d * 0.0625F, this.base1.field_78798_e * 0.0625F);
/* 75 */     GL11.glScaled(0.7D, 1.0D, 0.6D);
/* 76 */     GL11.glTranslatef(-this.base1.field_82906_o, -this.base1.field_82908_p, -this.base1.field_82907_q);
/* 77 */     GL11.glTranslatef(-this.base1.field_78800_c * 0.0625F, -this.base1.field_78797_d * 0.0625F, -this.base1.field_78798_e * 0.0625F);
/* 78 */     this.base1.func_78785_a(0.0625F);
/* 79 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 84 */     modelRenderer.field_78795_f = x;
/* 85 */     modelRenderer.field_78796_g = y;
/* 86 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\tile\ModelLightsaberStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */