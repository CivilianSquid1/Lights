/*     */ package com.fiskmods.lightsabers.client.model.tile;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ 
/*     */ 
/*     */ public class ModelSithCoffin
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer base1;
/*     */   public ModelRenderer lid1;
/*     */   public ModelRenderer base2;
/*     */   public ModelRenderer base3;
/*     */   public ModelRenderer base4;
/*     */   public ModelRenderer base7;
/*     */   public ModelRenderer base10;
/*     */   public ModelRenderer base15;
/*     */   public ModelRenderer base5;
/*     */   public ModelRenderer base6;
/*     */   public ModelRenderer base8;
/*     */   public ModelRenderer base9;
/*     */   public ModelRenderer base11;
/*     */   public ModelRenderer base12;
/*     */   public ModelRenderer base13;
/*     */   public ModelRenderer base14;
/*     */   public ModelRenderer lid2;
/*     */   public ModelRenderer lid3;
/*     */   public ModelRenderer lid4;
/*     */   public ModelRenderer lid5;
/*     */   
/*     */   public ModelSithCoffin() {
/*  34 */     this.field_78090_t = 256;
/*  35 */     this.field_78089_u = 128;
/*  36 */     this.base10 = new ModelRenderer(this, 107, 0);
/*  37 */     this.base10.func_78793_a(0.0F, -2.0F, -13.5F);
/*  38 */     this.base10.func_78790_a(-6.0F, -7.0F, -0.5F, 12, 7, 1, 0.0F);
/*  39 */     this.base15 = new ModelRenderer(this, 107, 0);
/*  40 */     this.base15.func_78793_a(0.0F, -2.0F, 13.5F);
/*  41 */     this.base15.func_78790_a(-6.0F, -7.0F, -0.5F, 12, 7, 1, 0.0F);
/*  42 */     setRotateAngle(this.base15, 0.0F, 3.1415927F, 0.0F);
/*  43 */     this.lid3 = new ModelRenderer(this, 64, 28);
/*  44 */     this.lid3.func_78793_a(1.5F, -2.3F, 0.0F);
/*  45 */     this.lid3.func_78790_a(0.0F, 0.0F, -13.0F, 1, 3, 26, 0.0F);
/*  46 */     setRotateAngle(this.lid3, 0.0F, 0.0F, 0.6981317F);
/*  47 */     this.base3 = new ModelRenderer(this, 0, 90);
/*  48 */     this.base3.func_78793_a(0.0F, -2.0F, 0.0F);
/*  49 */     this.base3.func_78790_a(-5.5F, -6.0F, -12.0F, 11, 6, 24, 0.0F);
/*  50 */     this.base2 = new ModelRenderer(this, 110, 0);
/*  51 */     this.base2.func_78793_a(0.0F, -3.0F, 8.0F);
/*  52 */     this.base2.func_78790_a(-6.0F, -2.0F, -14.0F, 12, 2, 28, 0.0F);
/*  53 */     this.base8 = new ModelRenderer(this, 172, 0);
/*  54 */     this.base8.field_78809_i = true;
/*  55 */     this.base8.func_78793_a(3.0F, -1.0F, -13.98F);
/*  56 */     this.base8.func_78790_a(0.0F, -2.0F, 0.0F, 3, 5, 1, 0.0F);
/*  57 */     setRotateAngle(this.base8, 0.0F, 0.0F, -1.5707964F);
/*  58 */     this.base11 = new ModelRenderer(this, 58, 0);
/*  59 */     this.base11.func_78793_a(0.0F, -5.5F, 0.0F);
/*  60 */     this.base11.func_78790_a(-10.0F, -2.0F, -1.0F, 20, 2, 2, 0.0F);
/*  61 */     this.base6 = new ModelRenderer(this, 172, 0);
/*  62 */     this.base6.func_78793_a(-3.0F, -1.0F, 13.98F);
/*  63 */     this.base6.func_78790_a(-3.0F, -2.0F, -1.0F, 3, 5, 1, 0.0F);
/*  64 */     setRotateAngle(this.base6, 0.0F, 0.0F, 1.5707964F);
/*  65 */     this.lid1 = new ModelRenderer(this, 0, 60);
/*  66 */     this.lid1.func_78793_a(-9.0F, 11.5F, 8.0F);
/*  67 */     this.lid1.func_78790_a(1.5F, -2.3F, -13.0F, 15, 1, 26, 0.0F);
/*  68 */     this.base1 = new ModelRenderer(this, 160, 0);
/*  69 */     this.base1.func_78793_a(0.0F, 24.0F, 0.0F);
/*  70 */     this.base1.func_78790_a(-8.0F, -3.0F, -8.0F, 16, 3, 32, 0.0F);
/*  71 */     this.base12 = new ModelRenderer(this, 0, 30);
/*  72 */     this.base12.field_78809_i = true;
/*  73 */     this.base12.func_78793_a(9.0F, -1.0F, 1.0F);
/*  74 */     this.base12.func_78790_a(-1.0F, -1.0F, 0.0F, 2, 2, 25, 0.0F);
/*  75 */     this.lid4 = new ModelRenderer(this, 0, 0);
/*  76 */     this.lid4.func_78793_a(9.0F, -1.3F, -12.5F);
/*  77 */     this.lid4.func_78790_a(-8.0F, 0.0F, -0.5F, 16, 2, 1, 0.0F);
/*  78 */     this.base4 = new ModelRenderer(this, 183, 36);
/*  79 */     this.base4.func_78793_a(-6.0F, -2.0F, 0.0F);
/*  80 */     this.base4.func_78790_a(-8.0F, -1.0F, -14.0F, 8, 1, 28, 0.0F);
/*  81 */     setRotateAngle(this.base4, 0.0F, 0.0F, 1.0471976F);
/*  82 */     this.base7 = new ModelRenderer(this, 183, 36);
/*  83 */     this.base7.field_78809_i = true;
/*  84 */     this.base7.func_78793_a(6.0F, -2.0F, 0.0F);
/*  85 */     this.base7.func_78790_a(0.0F, -1.0F, -14.0F, 8, 1, 28, 0.0F);
/*  86 */     setRotateAngle(this.base7, 0.0F, 0.0F, -1.0471976F);
/*  87 */     this.lid5 = new ModelRenderer(this, 0, 0);
/*  88 */     this.lid5.func_78793_a(9.0F, -1.3F, 12.5F);
/*  89 */     this.lid5.func_78790_a(-8.0F, 0.0F, -0.5F, 16, 2, 1, 0.0F);
/*  90 */     setRotateAngle(this.lid5, 0.0F, 3.1415927F, 0.0F);
/*  91 */     this.base13 = new ModelRenderer(this, 0, 30);
/*  92 */     this.base13.func_78793_a(-9.0F, -1.0F, 1.0F);
/*  93 */     this.base13.func_78790_a(-1.0F, -1.0F, 0.0F, 2, 2, 25, 0.0F);
/*  94 */     this.base5 = new ModelRenderer(this, 172, 0);
/*  95 */     this.base5.func_78793_a(-3.0F, -1.0F, -13.98F);
/*  96 */     this.base5.func_78790_a(-3.0F, -2.0F, 0.0F, 3, 5, 1, 0.0F);
/*  97 */     setRotateAngle(this.base5, 0.0F, 0.0F, 1.5707964F);
/*  98 */     this.lid2 = new ModelRenderer(this, 64, 28);
/*  99 */     this.lid2.field_78809_i = true;
/* 100 */     this.lid2.func_78793_a(16.5F, -2.3F, 0.0F);
/* 101 */     this.lid2.func_78790_a(-1.0F, 0.0F, -13.0F, 1, 3, 26, 0.0F);
/* 102 */     setRotateAngle(this.lid2, 0.0F, 0.0F, -0.6981317F);
/* 103 */     this.base9 = new ModelRenderer(this, 172, 0);
/* 104 */     this.base9.field_78809_i = true;
/* 105 */     this.base9.func_78793_a(3.0F, -1.0F, 13.98F);
/* 106 */     this.base9.func_78790_a(0.0F, -2.0F, -1.0F, 3, 5, 1, 0.0F);
/* 107 */     setRotateAngle(this.base9, 0.0F, 0.0F, -1.5707964F);
/* 108 */     this.base14 = new ModelRenderer(this, 58, 0);
/* 109 */     this.base14.func_78793_a(0.0F, 0.0F, 27.0F);
/* 110 */     this.base14.func_78790_a(-10.0F, -2.0F, -1.0F, 20, 2, 2, 0.0F);
/* 111 */     setRotateAngle(this.base14, 0.0F, 3.1415927F, 0.0F);
/* 112 */     this.base2.func_78792_a(this.base10);
/* 113 */     this.base2.func_78792_a(this.base15);
/* 114 */     this.lid1.func_78792_a(this.lid3);
/* 115 */     this.base2.func_78792_a(this.base3);
/* 116 */     this.base1.func_78792_a(this.base2);
/* 117 */     this.base7.func_78792_a(this.base8);
/* 118 */     this.base10.func_78792_a(this.base11);
/* 119 */     this.base4.func_78792_a(this.base6);
/* 120 */     this.base11.func_78792_a(this.base12);
/* 121 */     this.lid1.func_78792_a(this.lid4);
/* 122 */     this.base2.func_78792_a(this.base4);
/* 123 */     this.base2.func_78792_a(this.base7);
/* 124 */     this.lid1.func_78792_a(this.lid5);
/* 125 */     this.base11.func_78792_a(this.base13);
/* 126 */     this.base4.func_78792_a(this.base5);
/* 127 */     this.lid1.func_78792_a(this.lid2);
/* 128 */     this.base7.func_78792_a(this.base9);
/* 129 */     this.base11.func_78792_a(this.base14);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(TileEntitySithCoffin tile) {
/* 134 */     float f = tile.getLidOpenTimer(ClientEventHandler.renderTick);
/* 135 */     float f1 = (f > 0.5F) ? ((1.0F - f) * 2.0F) : 1.0F;
/* 136 */     float f2 = 1.0F - f1;
/* 137 */     this.lid1.func_78793_a(-9.0F + 16.0F * f, 11.5F - 3.0F * f2, 8.0F);
/* 138 */     this.lid1.field_78808_h = f2;
/*     */     
/* 140 */     this.lid1.func_78785_a(0.0625F);
/* 141 */     this.base1.func_78785_a(0.0625F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 146 */     modelRenderer.field_78795_f = x;
/* 147 */     modelRenderer.field_78796_g = y;
/* 148 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\tile\ModelSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */