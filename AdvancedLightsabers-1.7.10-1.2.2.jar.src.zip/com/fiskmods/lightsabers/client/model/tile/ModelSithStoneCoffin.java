/*    */ package com.fiskmods.lightsabers.client.model.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ 
/*    */ 
/*    */ public class ModelSithStoneCoffin
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer base;
/*    */   public ModelRenderer coffin;
/*    */   
/*    */   public ModelSithStoneCoffin() {
/* 15 */     this.field_78090_t = 128;
/* 16 */     this.field_78089_u = 128;
/* 17 */     this.base = new ModelRenderer(this, 0, 0);
/* 18 */     this.base.func_78793_a(0.0F, 24.0F, 0.0F);
/* 19 */     this.base.func_78790_a(-8.0F, -3.0F, -8.0F, 16, 3, 16, 0.0F);
/* 20 */     this.coffin = new ModelRenderer(this, 0, 20);
/* 21 */     this.coffin.func_78793_a(0.0F, -3.0F, 2.0F);
/* 22 */     this.coffin.func_78790_a(-6.5F, -4.5F, 0.0F, 13, 9, 28, 0.0F);
/* 23 */     setRotateAngle(this.coffin, 1.5707964F, 0.0F, 0.0F);
/* 24 */     this.base.func_78792_a(this.coffin);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(TileEntitySithStoneCoffin tile) {
/* 29 */     this.coffin.field_78807_k = tile.baseplateOnly;
/* 30 */     this.base.func_78785_a(0.0625F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 35 */     modelRenderer.field_78795_f = x;
/* 36 */     modelRenderer.field_78796_g = y;
/* 37 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\tile\ModelSithStoneCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */