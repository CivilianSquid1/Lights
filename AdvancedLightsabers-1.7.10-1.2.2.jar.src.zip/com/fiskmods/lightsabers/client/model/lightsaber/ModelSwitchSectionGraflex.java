/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelSwitchSectionGraflex
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer switch1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer switch2;
/*     */   
/*     */   public ModelSwitchSectionGraflex() {
/*  25 */     this.field_78090_t = 64;
/*  26 */     this.field_78089_u = 32;
/*  27 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  28 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  29 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  30 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  31 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  32 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  33 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  34 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  35 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  36 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  37 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  38 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  39 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  40 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  41 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  42 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  43 */     this.switch2 = new ModelRenderer(this, 8, 3);
/*  44 */     this.switch2.func_78793_a(0.0F, 0.0F, -0.8F);
/*  45 */     this.switch2.func_78790_a(-1.0F, -1.5F, -1.0F, 2, 9, 1, 0.0F);
/*  46 */     setRotateAngle(this.switch2, 0.10471976F, 0.0F, 0.0F);
/*  47 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  48 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  50 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  51 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  52 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  53 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  54 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  55 */     this.body8 = new ModelRenderer(this, 0, 11);
/*  56 */     this.body8.func_78793_a(0.0F, -4.0F, 3.0F);
/*  57 */     this.body8.func_78790_a(-1.5F, -4.0F, 0.0F, 3, 8, 2, 0.0F);
/*  58 */     this.switch1 = new ModelRenderer(this, 8, 0);
/*  59 */     this.switch1.func_78793_a(-4.7F, -6.0F, -1.4F);
/*  60 */     this.switch1.func_78790_a(-1.0F, -1.0F, -1.0F, 2, 2, 1, 0.0F);
/*  61 */     this.body9 = new ModelRenderer(this, 0, 0);
/*  62 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/*  63 */     this.body9.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  64 */     setRotateAngle(this.body9, 0.0F, -0.7853982F, 0.0F);
/*  65 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  66 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  67 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  68 */     this.body1.func_78792_a(this.body5);
/*  69 */     this.body1.func_78792_a(this.body2);
/*  70 */     this.body1.func_78792_a(this.body6);
/*  71 */     this.body1.func_78792_a(this.body4);
/*  72 */     this.switch1.func_78792_a(this.switch2);
/*  73 */     this.body1.func_78792_a(this.body3);
/*  74 */     this.body1.func_78792_a(this.body7);
/*  75 */     this.body7.func_78792_a(this.body8);
/*  76 */     this.body1.func_78792_a(this.body9);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  82 */     GL11.glPushMatrix();
/*  83 */     GL11.glTranslatef(this.switch1.field_82906_o, this.switch1.field_82908_p, this.switch1.field_82907_q);
/*  84 */     GL11.glTranslatef(this.switch1.field_78800_c * f5, this.switch1.field_78797_d * f5, this.switch1.field_78798_e * f5);
/*  85 */     GL11.glScaled(0.6D, 0.6D, 0.6D);
/*  86 */     GL11.glTranslatef(-this.switch1.field_82906_o, -this.switch1.field_82908_p, -this.switch1.field_82907_q);
/*  87 */     GL11.glTranslatef(-this.switch1.field_78800_c * f5, -this.switch1.field_78797_d * f5, -this.switch1.field_78798_e * f5);
/*  88 */     this.switch1.func_78785_a(f5);
/*  89 */     GL11.glPopMatrix();
/*  90 */     GL11.glPushMatrix();
/*  91 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/*  92 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/*  93 */     GL11.glScaled(1.1D, 1.1D, 1.1D);
/*  94 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/*  95 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/*  96 */     this.body1.func_78785_a(f5);
/*  97 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 102 */     modelRenderer.field_78795_f = x;
/* 103 */     modelRenderer.field_78796_g = y;
/* 104 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionGraflex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */