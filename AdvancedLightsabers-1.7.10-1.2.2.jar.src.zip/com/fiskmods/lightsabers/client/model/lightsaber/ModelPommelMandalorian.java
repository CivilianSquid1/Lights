/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class ModelPommelMandalorian
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body25;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body21;
/*     */   public ModelRenderer body23;
/*     */   public ModelRenderer body22;
/*     */   public ModelRenderer body24;
/*     */   public ModelRenderer body26;
/*     */   
/*     */   public ModelPommelMandalorian() {
/*  38 */     this.field_78090_t = 64;
/*  39 */     this.field_78089_u = 32;
/*  40 */     this.body18 = new ModelRenderer(this, 0, 14);
/*  41 */     this.body18.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.body18.func_78790_a(-2.98F, 0.0F, -2.5F, 3, 1, 5, 0.0F);
/*  43 */     this.body19 = new ModelRenderer(this, 0, 14);
/*  44 */     this.body19.field_78809_i = true;
/*  45 */     this.body19.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body19.func_78790_a(-0.02F, 0.0F, -2.5F, 3, 1, 5, 0.0F);
/*  47 */     this.body1 = new ModelRenderer(this, 0, 9);
/*  48 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.76F, 3, 4, 1, 0.0F);
/*  50 */     this.body13 = new ModelRenderer(this, 0, 20);
/*  51 */     this.body13.func_78793_a(0.0F, 4.0F, 0.0F);
/*  52 */     this.body13.func_78790_a(-1.5F, 0.0F, 1.76F, 3, 1, 2, 0.0F);
/*  53 */     this.body20 = new ModelRenderer(this, 0, 20);
/*  54 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/*  55 */     this.body20.func_78790_a(-1.5F, 0.0F, 1.76F, 3, 1, 2, 0.0F);
/*  56 */     setRotateAngle(this.body20, 0.0F, 3.1415927F, 0.0F);
/*  57 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  58 */     this.body3.func_78793_a(-1.0F, 0.0F, 0.0F);
/*  59 */     this.body3.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/*  60 */     setRotateAngle(this.body3, 0.0F, -0.47211155F, 0.0F);
/*  61 */     this.body9 = new ModelRenderer(this, 0, 0);
/*  62 */     this.body9.func_78793_a(-1.5F, 0.0F, 3.76F);
/*  63 */     this.body9.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/*  64 */     setRotateAngle(this.body9, 0.0F, -0.46949357F, 0.0F);
/*  65 */     this.body17 = new ModelRenderer(this, 11, 12);
/*  66 */     this.body17.field_78809_i = true;
/*  67 */     this.body17.func_78793_a(1.0F, 0.0F, 0.0F);
/*  68 */     this.body17.func_78790_a(0.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/*  69 */     setRotateAngle(this.body17, 0.0F, 0.47211155F, 0.0F);
/*  70 */     this.body12 = new ModelRenderer(this, 0, 0);
/*  71 */     this.body12.field_78809_i = true;
/*  72 */     this.body12.func_78793_a(1.0F, 0.0F, 0.0F);
/*  73 */     this.body12.func_78790_a(0.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/*  74 */     setRotateAngle(this.body12, 0.0F, 0.47211155F, 0.0F);
/*  75 */     this.body23 = new ModelRenderer(this, 11, 12);
/*  76 */     this.body23.field_78809_i = true;
/*  77 */     this.body23.func_78793_a(1.5F, 0.5F, 3.76F);
/*  78 */     this.body23.func_78790_a(0.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/*  79 */     setRotateAngle(this.body23, 0.0F, 0.46949357F, 0.0F);
/*  80 */     this.body10 = new ModelRenderer(this, 0, 0);
/*  81 */     this.body10.func_78793_a(-1.0F, 0.0F, 0.0F);
/*  82 */     this.body10.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/*  83 */     setRotateAngle(this.body10, 0.0F, -0.47211155F, 0.0F);
/*  84 */     this.body22 = new ModelRenderer(this, 11, 12);
/*  85 */     this.body22.func_78793_a(-1.0F, 0.0F, 0.0F);
/*  86 */     this.body22.func_78790_a(-1.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/*  87 */     setRotateAngle(this.body22, 0.0F, -0.47211155F, 0.0F);
/*  88 */     this.body8 = new ModelRenderer(this, 0, 9);
/*  89 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  90 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.76F, 3, 4, 1, 0.0F);
/*  91 */     setRotateAngle(this.body8, 0.0F, 3.1415927F, 0.0F);
/*  92 */     this.body11 = new ModelRenderer(this, 0, 0);
/*  93 */     this.body11.field_78809_i = true;
/*  94 */     this.body11.func_78793_a(1.5F, 0.0F, 3.76F);
/*  95 */     this.body11.func_78790_a(0.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/*  96 */     setRotateAngle(this.body11, 0.0F, 0.46949357F, 0.0F);
/*  97 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  98 */     this.body7.field_78809_i = true;
/*  99 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 100 */     this.body7.func_78790_a(1.98F, 0.0F, -2.5F, 1, 4, 5, 0.0F);
/* 101 */     this.body14 = new ModelRenderer(this, 11, 12);
/* 102 */     this.body14.func_78793_a(-1.5F, 0.5F, 3.76F);
/* 103 */     this.body14.func_78790_a(-1.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/* 104 */     setRotateAngle(this.body14, 0.0F, -0.46949357F, 0.0F);
/* 105 */     this.body25 = new ModelRenderer(this, 8, 5);
/* 106 */     this.body25.func_78793_a(0.0F, 0.45F, -0.75F);
/* 107 */     this.body25.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 4, 0.0F);
/* 108 */     this.body26 = new ModelRenderer(this, 7, 0);
/* 109 */     this.body26.func_78793_a(0.0F, 3.0F, 2.0F);
/* 110 */     this.body26.func_78790_a(-1.5F, -2.0F, 0.0F, 3, 2, 3, 0.0F);
/* 111 */     setRotateAngle(this.body26, 0.9599311F, 0.0F, 0.0F);
/* 112 */     this.body4 = new ModelRenderer(this, 0, 0);
/* 113 */     this.body4.field_78809_i = true;
/* 114 */     this.body4.func_78793_a(1.5F, 0.0F, 3.76F);
/* 115 */     this.body4.func_78790_a(0.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/* 116 */     setRotateAngle(this.body4, 0.0F, 0.46949357F, 0.0F);
/* 117 */     this.body15 = new ModelRenderer(this, 11, 12);
/* 118 */     this.body15.func_78793_a(-1.0F, 0.0F, 0.0F);
/* 119 */     this.body15.func_78790_a(-1.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/* 120 */     setRotateAngle(this.body15, 0.0F, -0.47211155F, 0.0F);
/* 121 */     this.body2 = new ModelRenderer(this, 0, 0);
/* 122 */     this.body2.func_78793_a(-1.5F, 0.0F, 3.76F);
/* 123 */     this.body2.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/* 124 */     setRotateAngle(this.body2, 0.0F, -0.46949357F, 0.0F);
/* 125 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 126 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 127 */     this.body6.func_78790_a(-2.98F, 0.0F, -2.5F, 1, 4, 5, 0.0F);
/* 128 */     this.body5 = new ModelRenderer(this, 0, 0);
/* 129 */     this.body5.field_78809_i = true;
/* 130 */     this.body5.func_78793_a(1.0F, 0.0F, 0.0F);
/* 131 */     this.body5.func_78790_a(0.0F, 0.0F, -1.0F, 1, 4, 1, 0.0F);
/* 132 */     setRotateAngle(this.body5, 0.0F, 0.47211155F, 0.0F);
/* 133 */     this.body21 = new ModelRenderer(this, 11, 12);
/* 134 */     this.body21.func_78793_a(-1.5F, 0.5F, 3.76F);
/* 135 */     this.body21.func_78790_a(-1.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/* 136 */     setRotateAngle(this.body21, 0.0F, -0.46949357F, 0.0F);
/* 137 */     this.body24 = new ModelRenderer(this, 11, 12);
/* 138 */     this.body24.field_78809_i = true;
/* 139 */     this.body24.func_78793_a(1.0F, 0.0F, 0.0F);
/* 140 */     this.body24.func_78790_a(0.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/* 141 */     setRotateAngle(this.body24, 0.0F, 0.47211155F, 0.0F);
/* 142 */     this.body16 = new ModelRenderer(this, 11, 12);
/* 143 */     this.body16.field_78809_i = true;
/* 144 */     this.body16.func_78793_a(1.5F, 0.5F, 3.76F);
/* 145 */     this.body16.func_78790_a(0.0F, -0.5F, -2.0F, 1, 1, 2, 0.0F);
/* 146 */     setRotateAngle(this.body16, 0.0F, 0.46949357F, 0.0F);
/* 147 */     this.body13.func_78792_a(this.body18);
/* 148 */     this.body13.func_78792_a(this.body19);
/* 149 */     this.body1.func_78792_a(this.body13);
/* 150 */     this.body13.func_78792_a(this.body20);
/* 151 */     this.body2.func_78792_a(this.body3);
/* 152 */     this.body8.func_78792_a(this.body9);
/* 153 */     this.body16.func_78792_a(this.body17);
/* 154 */     this.body11.func_78792_a(this.body12);
/* 155 */     this.body20.func_78792_a(this.body23);
/* 156 */     this.body9.func_78792_a(this.body10);
/* 157 */     this.body21.func_78792_a(this.body22);
/* 158 */     this.body1.func_78792_a(this.body8);
/* 159 */     this.body8.func_78792_a(this.body11);
/* 160 */     this.body1.func_78792_a(this.body7);
/* 161 */     this.body13.func_78792_a(this.body14);
/* 162 */     this.body13.func_78792_a(this.body25);
/* 163 */     this.body25.func_78792_a(this.body26);
/* 164 */     this.body1.func_78792_a(this.body4);
/* 165 */     this.body14.func_78792_a(this.body15);
/* 166 */     this.body1.func_78792_a(this.body2);
/* 167 */     this.body1.func_78792_a(this.body6);
/* 168 */     this.body4.func_78792_a(this.body5);
/* 169 */     this.body20.func_78792_a(this.body21);
/* 170 */     this.body23.func_78792_a(this.body24);
/* 171 */     this.body13.func_78792_a(this.body16);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 177 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 182 */     modelRenderer.field_78795_f = x;
/* 183 */     modelRenderer.field_78796_g = y;
/* 184 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelMandalorian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */