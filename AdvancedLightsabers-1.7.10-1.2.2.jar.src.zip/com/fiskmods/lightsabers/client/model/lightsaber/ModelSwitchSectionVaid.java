/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelSwitchSectionVaid
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer upperButton1;
/*     */   public ModelRenderer lowerButton1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer upperButton2;
/*     */   public ModelRenderer upperButton3;
/*     */   public ModelRenderer upperButton4;
/*     */   public ModelRenderer upperButton5;
/*     */   public ModelRenderer upperButton6;
/*     */   public ModelRenderer upperButton7;
/*     */   public ModelRenderer upperButton8;
/*     */   public ModelRenderer lowerButton2;
/*     */   public ModelRenderer lowerButton3;
/*     */   public ModelRenderer lowerButton4;
/*     */   public ModelRenderer lowerButton5;
/*     */   public ModelRenderer lowerButton6;
/*     */   public ModelRenderer lowerButton7;
/*     */   public ModelRenderer lowerButton8;
/*     */   
/*     */   public ModelSwitchSectionVaid() {
/*  38 */     this.field_78090_t = 64;
/*  39 */     this.field_78089_u = 32;
/*  40 */     this.upperButton6 = new ModelRenderer(this, 8, 0);
/*  41 */     this.upperButton6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.upperButton6.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  43 */     setRotateAngle(this.upperButton6, 0.0F, -2.3561945F, 0.0F);
/*  44 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  45 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  47 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  48 */     this.lowerButton5 = new ModelRenderer(this, 0, 9);
/*  49 */     this.lowerButton5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  50 */     this.lowerButton5.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  51 */     setRotateAngle(this.lowerButton5, 0.0F, 3.1415927F, 0.0F);
/*  52 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  53 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  54 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  55 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  56 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  57 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  58 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  59 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  60 */     this.upperButton8 = new ModelRenderer(this, 8, 0);
/*  61 */     this.upperButton8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  62 */     this.upperButton8.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  63 */     setRotateAngle(this.upperButton8, 0.0F, -0.7853982F, 0.0F);
/*  64 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  65 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  66 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  67 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  68 */     this.upperButton2 = new ModelRenderer(this, 8, 0);
/*  69 */     this.upperButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  70 */     this.upperButton2.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  71 */     setRotateAngle(this.upperButton2, 0.0F, 0.7853982F, 0.0F);
/*  72 */     this.upperButton3 = new ModelRenderer(this, 8, 0);
/*  73 */     this.upperButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  74 */     this.upperButton3.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  75 */     setRotateAngle(this.upperButton3, 0.0F, 1.5707964F, 0.0F);
/*  76 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  77 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  78 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  79 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  80 */     this.upperButton7 = new ModelRenderer(this, 8, 0);
/*  81 */     this.upperButton7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  82 */     this.upperButton7.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  83 */     setRotateAngle(this.upperButton7, 0.0F, -1.5707964F, 0.0F);
/*  84 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  85 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  86 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  87 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  88 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.body8.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  90 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  91 */     this.lowerButton7 = new ModelRenderer(this, 0, 9);
/*  92 */     this.lowerButton7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  93 */     this.lowerButton7.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  94 */     setRotateAngle(this.lowerButton7, 0.0F, -1.5707964F, 0.0F);
/*  95 */     this.lowerButton6 = new ModelRenderer(this, 0, 9);
/*  96 */     this.lowerButton6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  97 */     this.lowerButton6.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  98 */     setRotateAngle(this.lowerButton6, 0.0F, -2.3561945F, 0.0F);
/*  99 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 100 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 101 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 102 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/* 103 */     this.upperButton4 = new ModelRenderer(this, 8, 0);
/* 104 */     this.upperButton4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 105 */     this.upperButton4.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 106 */     setRotateAngle(this.upperButton4, 0.0F, 2.3561945F, 0.0F);
/* 107 */     this.lowerButton8 = new ModelRenderer(this, 0, 9);
/* 108 */     this.lowerButton8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 109 */     this.lowerButton8.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 110 */     setRotateAngle(this.lowerButton8, 0.0F, -0.7853982F, 0.0F);
/* 111 */     this.lowerButton3 = new ModelRenderer(this, 0, 9);
/* 112 */     this.lowerButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 113 */     this.lowerButton3.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 114 */     setRotateAngle(this.lowerButton3, 0.0F, 1.5707964F, 0.0F);
/* 115 */     this.upperButton5 = new ModelRenderer(this, 8, 0);
/* 116 */     this.upperButton5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 117 */     this.upperButton5.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 118 */     setRotateAngle(this.upperButton5, 0.0F, 3.1415927F, 0.0F);
/* 119 */     this.lowerButton2 = new ModelRenderer(this, 0, 9);
/* 120 */     this.lowerButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 121 */     this.lowerButton2.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 122 */     setRotateAngle(this.lowerButton2, 0.0F, 0.7853982F, 0.0F);
/* 123 */     this.upperButton1 = new ModelRenderer(this, 8, 0);
/* 124 */     this.upperButton1.func_78793_a(-3.8F, -6.2F, 0.0F);
/* 125 */     this.upperButton1.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 126 */     setRotateAngle(this.upperButton1, 0.0F, 0.0F, -1.5707964F);
/* 127 */     this.lowerButton4 = new ModelRenderer(this, 0, 9);
/* 128 */     this.lowerButton4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 129 */     this.lowerButton4.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 130 */     setRotateAngle(this.lowerButton4, 0.0F, 2.3561945F, 0.0F);
/* 131 */     this.lowerButton1 = new ModelRenderer(this, 0, 9);
/* 132 */     this.lowerButton1.func_78793_a(-3.8F, -3.0F, 0.0F);
/* 133 */     this.lowerButton1.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 134 */     setRotateAngle(this.lowerButton1, 0.0F, 0.0F, -1.5707964F);
/* 135 */     this.upperButton1.func_78792_a(this.upperButton6);
/* 136 */     this.body1.func_78792_a(this.body4);
/* 137 */     this.lowerButton1.func_78792_a(this.lowerButton5);
/* 138 */     this.body1.func_78792_a(this.body7);
/* 139 */     this.body1.func_78792_a(this.body2);
/* 140 */     this.upperButton1.func_78792_a(this.upperButton8);
/* 141 */     this.body1.func_78792_a(this.body3);
/* 142 */     this.upperButton1.func_78792_a(this.upperButton2);
/* 143 */     this.upperButton1.func_78792_a(this.upperButton3);
/* 144 */     this.body1.func_78792_a(this.body5);
/* 145 */     this.upperButton1.func_78792_a(this.upperButton7);
/* 146 */     this.body1.func_78792_a(this.body8);
/* 147 */     this.lowerButton1.func_78792_a(this.lowerButton7);
/* 148 */     this.lowerButton1.func_78792_a(this.lowerButton6);
/* 149 */     this.body1.func_78792_a(this.body6);
/* 150 */     this.upperButton1.func_78792_a(this.upperButton4);
/* 151 */     this.lowerButton1.func_78792_a(this.lowerButton8);
/* 152 */     this.lowerButton1.func_78792_a(this.lowerButton3);
/* 153 */     this.upperButton1.func_78792_a(this.upperButton5);
/* 154 */     this.lowerButton1.func_78792_a(this.lowerButton2);
/* 155 */     this.lowerButton1.func_78792_a(this.lowerButton4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 161 */     GL11.glPushMatrix();
/* 162 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 163 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 164 */     GL11.glScaled(1.15D, 1.15D, 1.15D);
/* 165 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 166 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 167 */     this.body1.func_78785_a(f5);
/* 168 */     GL11.glPopMatrix();
/* 169 */     GL11.glPushMatrix();
/* 170 */     GL11.glTranslatef(this.upperButton1.field_82906_o, this.upperButton1.field_82908_p, this.upperButton1.field_82907_q);
/* 171 */     GL11.glTranslatef(this.upperButton1.field_78800_c * f5, this.upperButton1.field_78797_d * f5, this.upperButton1.field_78798_e * f5);
/* 172 */     GL11.glScaled(0.3D, 0.3D, 0.3D);
/* 173 */     GL11.glTranslatef(-this.upperButton1.field_82906_o, -this.upperButton1.field_82908_p, -this.upperButton1.field_82907_q);
/* 174 */     GL11.glTranslatef(-this.upperButton1.field_78800_c * f5, -this.upperButton1.field_78797_d * f5, -this.upperButton1.field_78798_e * f5);
/* 175 */     this.upperButton1.func_78785_a(f5);
/* 176 */     GL11.glPopMatrix();
/* 177 */     GL11.glPushMatrix();
/* 178 */     GL11.glTranslatef(this.lowerButton1.field_82906_o, this.lowerButton1.field_82908_p, this.lowerButton1.field_82907_q);
/* 179 */     GL11.glTranslatef(this.lowerButton1.field_78800_c * f5, this.lowerButton1.field_78797_d * f5, this.lowerButton1.field_78798_e * f5);
/* 180 */     GL11.glScaled(0.3D, 0.3D, 0.3D);
/* 181 */     GL11.glTranslatef(-this.lowerButton1.field_82906_o, -this.lowerButton1.field_82908_p, -this.lowerButton1.field_82907_q);
/* 182 */     GL11.glTranslatef(-this.lowerButton1.field_78800_c * f5, -this.lowerButton1.field_78797_d * f5, -this.lowerButton1.field_78798_e * f5);
/* 183 */     this.lowerButton1.func_78785_a(f5);
/* 184 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 189 */     modelRenderer.field_78795_f = x;
/* 190 */     modelRenderer.field_78796_g = y;
/* 191 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionVaid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */