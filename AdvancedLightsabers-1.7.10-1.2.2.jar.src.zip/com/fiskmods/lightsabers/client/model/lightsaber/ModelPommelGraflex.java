/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelPommelGraflex
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer top1;
/*     */   public ModelRenderer bottom1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer top2;
/*     */   public ModelRenderer top3;
/*     */   public ModelRenderer top4;
/*     */   public ModelRenderer top5;
/*     */   public ModelRenderer top6;
/*     */   public ModelRenderer top7;
/*     */   public ModelRenderer top8;
/*     */   public ModelRenderer bottom2;
/*     */   public ModelRenderer bottom3;
/*     */   public ModelRenderer bottom6;
/*     */   public ModelRenderer bottom9;
/*     */   public ModelRenderer bottom4;
/*     */   public ModelRenderer bottom5;
/*     */   public ModelRenderer bottom7;
/*     */   public ModelRenderer bottom8;
/*     */   
/*     */   public ModelPommelGraflex() {
/*  40 */     this.field_78090_t = 64;
/*  41 */     this.field_78089_u = 32;
/*  42 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  43 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  44 */     this.body1.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  45 */     this.bottom3 = new ModelRenderer(this, 10, 2);
/*  46 */     this.bottom3.field_78809_i = true;
/*  47 */     this.bottom3.func_78793_a(0.5F, 0.0F, -4.0F);
/*  48 */     this.bottom3.func_78790_a(0.0F, -0.5F, -0.5F, 4, 1, 1, 0.0F);
/*  49 */     this.bottom1 = new ModelRenderer(this, 0, 8);
/*  50 */     this.bottom1.func_78793_a(2.3F, 0.8F, 0.0F);
/*  51 */     this.bottom1.func_78790_a(0.0F, -1.0F, -3.0F, 2, 2, 6, 0.0F);
/*  52 */     this.bottom2 = new ModelRenderer(this, 7, 7);
/*  53 */     this.bottom2.field_78809_i = true;
/*  54 */     this.bottom2.func_78793_a(1.0F, 0.0F, 0.0F);
/*  55 */     this.bottom2.func_78790_a(-0.5F, -0.5F, -4.5F, 1, 1, 9, 0.0F);
/*  56 */     setRotateAngle(this.bottom2, 0.0F, 0.0F, 0.4712389F);
/*  57 */     this.top7 = new ModelRenderer(this, 10, 0);
/*  58 */     this.top7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  59 */     this.top7.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  60 */     setRotateAngle(this.top7, 0.0F, -1.5707964F, 0.0F);
/*  61 */     this.bottom6 = new ModelRenderer(this, 10, 2);
/*  62 */     this.bottom6.field_78809_i = true;
/*  63 */     this.bottom6.func_78793_a(0.5F, 0.0F, 4.0F);
/*  64 */     this.bottom6.func_78790_a(0.0F, -0.5F, -0.5F, 4, 1, 1, 0.0F);
/*  65 */     this.top8 = new ModelRenderer(this, 10, 0);
/*  66 */     this.top8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  67 */     this.top8.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  68 */     setRotateAngle(this.top8, 0.0F, -0.7853982F, 0.0F);
/*  69 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  70 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  71 */     this.body7.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  72 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  73 */     this.body9 = new ModelRenderer(this, 0, 5);
/*  74 */     this.body9.func_78793_a(-0.2F, 1.0F, 0.0F);
/*  75 */     this.body9.func_78790_a(-2.5F, 0.0F, -1.0F, 5, 1, 2, 0.0F);
/*  76 */     setRotateAngle(this.body9, 0.0F, 0.0F, 0.0017453292F);
/*  77 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  78 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  79 */     this.body6.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  80 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  81 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  82 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  83 */     this.body8.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  84 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  85 */     this.bottom7 = new ModelRenderer(this, 0, 8);
/*  86 */     this.bottom7.field_78809_i = true;
/*  87 */     this.bottom7.func_78793_a(3.68F, 0.0F, 0.12F);
/*  88 */     this.bottom7.func_78790_a(0.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/*  89 */     setRotateAngle(this.bottom7, 0.0F, 0.6981317F, 0.0F);
/*  90 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  91 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.body5.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  93 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  94 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  95 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  96 */     this.body3.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  97 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  98 */     this.top6 = new ModelRenderer(this, 10, 0);
/*  99 */     this.top6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 100 */     this.top6.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 101 */     setRotateAngle(this.top6, 0.0F, -2.3561945F, 0.0F);
/* 102 */     this.top4 = new ModelRenderer(this, 10, 0);
/* 103 */     this.top4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 104 */     this.top4.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 105 */     setRotateAngle(this.top4, 0.0F, 2.3561945F, 0.0F);
/* 106 */     this.bottom9 = new ModelRenderer(this, 17, 1);
/* 107 */     this.bottom9.field_78809_i = true;
/* 108 */     this.bottom9.func_78793_a(6.35F, 0.0F, 0.0F);
/* 109 */     this.bottom9.func_78790_a(-0.5F, -0.5F, -1.5F, 1, 1, 3, 0.0F);
/* 110 */     this.top3 = new ModelRenderer(this, 10, 0);
/* 111 */     this.top3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 112 */     this.top3.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 113 */     setRotateAngle(this.top3, 0.0F, 1.5707964F, 0.0F);
/* 114 */     this.bottom4 = new ModelRenderer(this, 0, 8);
/* 115 */     this.bottom4.field_78809_i = true;
/* 116 */     this.bottom4.func_78793_a(3.68F, 0.0F, -0.12F);
/* 117 */     this.bottom4.func_78790_a(0.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/* 118 */     setRotateAngle(this.bottom4, 0.0F, -0.6981317F, 0.0F);
/* 119 */     this.top5 = new ModelRenderer(this, 10, 0);
/* 120 */     this.top5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 121 */     this.top5.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 122 */     setRotateAngle(this.top5, 0.0F, 3.1415927F, 0.0F);
/* 123 */     this.body4 = new ModelRenderer(this, 0, 0);
/* 124 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 125 */     this.body4.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/* 126 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/* 127 */     this.bottom5 = new ModelRenderer(this, 0, 10);
/* 128 */     this.bottom5.field_78809_i = true;
/* 129 */     this.bottom5.func_78793_a(1.78F, 0.0F, -0.05F);
/* 130 */     this.bottom5.func_78790_a(0.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/* 131 */     setRotateAngle(this.bottom5, 0.0F, -0.4537856F, 0.0F);
/* 132 */     this.top1 = new ModelRenderer(this, 10, 0);
/* 133 */     this.top1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 134 */     this.top1.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 135 */     this.top2 = new ModelRenderer(this, 10, 0);
/* 136 */     this.top2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 137 */     this.top2.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 138 */     setRotateAngle(this.top2, 0.0F, 0.7853982F, 0.0F);
/* 139 */     this.body2 = new ModelRenderer(this, 0, 0);
/* 140 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 141 */     this.body2.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/* 142 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/* 143 */     this.bottom8 = new ModelRenderer(this, 0, 10);
/* 144 */     this.bottom8.field_78809_i = true;
/* 145 */     this.bottom8.func_78793_a(1.78F, 0.0F, 0.05F);
/* 146 */     this.bottom8.func_78790_a(0.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/* 147 */     setRotateAngle(this.bottom8, 0.0F, 0.4537856F, 0.0F);
/* 148 */     this.bottom2.func_78792_a(this.bottom3);
/* 149 */     this.bottom1.func_78792_a(this.bottom2);
/* 150 */     this.top1.func_78792_a(this.top7);
/* 151 */     this.bottom2.func_78792_a(this.bottom6);
/* 152 */     this.top1.func_78792_a(this.top8);
/* 153 */     this.body1.func_78792_a(this.body7);
/* 154 */     this.body1.func_78792_a(this.body9);
/* 155 */     this.body1.func_78792_a(this.body6);
/* 156 */     this.body1.func_78792_a(this.body8);
/* 157 */     this.bottom6.func_78792_a(this.bottom7);
/* 158 */     this.body1.func_78792_a(this.body5);
/* 159 */     this.body1.func_78792_a(this.body3);
/* 160 */     this.top1.func_78792_a(this.top6);
/* 161 */     this.top1.func_78792_a(this.top4);
/* 162 */     this.bottom2.func_78792_a(this.bottom9);
/* 163 */     this.top1.func_78792_a(this.top3);
/* 164 */     this.bottom3.func_78792_a(this.bottom4);
/* 165 */     this.top1.func_78792_a(this.top5);
/* 166 */     this.body1.func_78792_a(this.body4);
/* 167 */     this.bottom4.func_78792_a(this.bottom5);
/* 168 */     this.top1.func_78792_a(this.top2);
/* 169 */     this.body1.func_78792_a(this.body2);
/* 170 */     this.bottom7.func_78792_a(this.bottom8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 176 */     GL11.glPushMatrix();
/* 177 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 178 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 179 */     GL11.glScaled(1.0D, 0.5D, 1.0D);
/* 180 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 181 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 182 */     this.body1.func_78785_a(f5);
/* 183 */     GL11.glPopMatrix();
/* 184 */     GL11.glPushMatrix();
/* 185 */     GL11.glTranslatef(this.bottom1.field_82906_o, this.bottom1.field_82908_p, this.bottom1.field_82907_q);
/* 186 */     GL11.glTranslatef(this.bottom1.field_78800_c * f5, this.bottom1.field_78797_d * f5, this.bottom1.field_78798_e * f5);
/* 187 */     GL11.glScaled(0.4D, 0.4D, 0.4D);
/* 188 */     GL11.glTranslatef(-this.bottom1.field_82906_o, -this.bottom1.field_82908_p, -this.bottom1.field_82907_q);
/* 189 */     GL11.glTranslatef(-this.bottom1.field_78800_c * f5, -this.bottom1.field_78797_d * f5, -this.bottom1.field_78798_e * f5);
/* 190 */     this.bottom1.func_78785_a(f5);
/* 191 */     GL11.glPopMatrix();
/* 192 */     GL11.glPushMatrix();
/* 193 */     GL11.glTranslatef(this.top1.field_82906_o, this.top1.field_82908_p, this.top1.field_82907_q);
/* 194 */     GL11.glTranslatef(this.top1.field_78800_c * f5, this.top1.field_78797_d * f5, this.top1.field_78798_e * f5);
/* 195 */     GL11.glScaled(0.8D, 1.0D, 0.8D);
/* 196 */     GL11.glTranslatef(-this.top1.field_82906_o, -this.top1.field_82908_p, -this.top1.field_82907_q);
/* 197 */     GL11.glTranslatef(-this.top1.field_78800_c * f5, -this.top1.field_78797_d * f5, -this.top1.field_78798_e * f5);
/* 198 */     this.top1.func_78785_a(f5);
/* 199 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 204 */     modelRenderer.field_78795_f = x;
/* 205 */     modelRenderer.field_78796_g = y;
/* 206 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelGraflex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */