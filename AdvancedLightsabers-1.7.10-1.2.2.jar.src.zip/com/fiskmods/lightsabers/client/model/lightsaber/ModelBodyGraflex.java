/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class ModelBodyGraflex
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body23;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer body21;
/*     */   public ModelRenderer body22;
/*     */   public ModelRenderer body24;
/*     */   
/*     */   public ModelBodyGraflex() {
/*  36 */     this.field_78090_t = 64;
/*  37 */     this.field_78089_u = 32;
/*  38 */     this.body14 = new ModelRenderer(this, 0, 0);
/*  39 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/*  40 */     this.body14.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  41 */     setRotateAngle(this.body14, 0.0F, -2.3561945F, 0.0F);
/*  42 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  43 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  44 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  45 */     setRotateAngle(this.body8, 0.0F, 2.3561945F, 0.0F);
/*  46 */     this.body18 = new ModelRenderer(this, 8, 0);
/*  47 */     this.body18.func_78793_a(0.0F, 8.3F, 2.6F);
/*  48 */     this.body18.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  49 */     this.body3 = new ModelRenderer(this, 8, 0);
/*  50 */     this.body3.func_78793_a(0.0F, 8.3F, 2.6F);
/*  51 */     this.body3.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  52 */     this.body7 = new ModelRenderer(this, 14, 0);
/*  53 */     this.body7.func_78793_a(0.0F, 0.0F, 0.6F);
/*  54 */     this.body7.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/*  55 */     this.body16 = new ModelRenderer(this, 14, 0);
/*  56 */     this.body16.func_78793_a(0.0F, 0.0F, 0.6F);
/*  57 */     this.body16.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/*  58 */     this.body12 = new ModelRenderer(this, 8, 0);
/*  59 */     this.body12.func_78793_a(0.0F, 8.3F, 2.6F);
/*  60 */     this.body12.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  61 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  62 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  63 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  64 */     this.body22 = new ModelRenderer(this, 14, 0);
/*  65 */     this.body22.func_78793_a(0.0F, 0.0F, 0.6F);
/*  66 */     this.body22.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/*  67 */     this.body20 = new ModelRenderer(this, 0, 0);
/*  68 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body20.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  70 */     setRotateAngle(this.body20, 0.0F, -0.7853982F, 0.0F);
/*  71 */     this.body19 = new ModelRenderer(this, 14, 0);
/*  72 */     this.body19.func_78793_a(0.0F, 0.0F, 0.6F);
/*  73 */     this.body19.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/*  74 */     this.body9 = new ModelRenderer(this, 8, 0);
/*  75 */     this.body9.func_78793_a(0.0F, 8.3F, 2.6F);
/*  76 */     this.body9.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  77 */     this.body10 = new ModelRenderer(this, 14, 0);
/*  78 */     this.body10.func_78793_a(0.0F, 0.0F, 0.6F);
/*  79 */     this.body10.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/*  80 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  81 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  82 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  83 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  84 */     this.body23 = new ModelRenderer(this, 8, 0);
/*  85 */     this.body23.func_78793_a(0.0F, 8.3F, 2.6F);
/*  86 */     this.body23.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  87 */     this.body15 = new ModelRenderer(this, 8, 0);
/*  88 */     this.body15.func_78793_a(0.0F, 8.3F, 2.6F);
/*  89 */     this.body15.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  90 */     this.body11 = new ModelRenderer(this, 0, 0);
/*  91 */     this.body11.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.body11.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  93 */     setRotateAngle(this.body11, 0.0F, 3.1415927F, 0.0F);
/*  94 */     this.body21 = new ModelRenderer(this, 8, 0);
/*  95 */     this.body21.func_78793_a(0.0F, 8.3F, 2.6F);
/*  96 */     this.body21.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/*  97 */     this.body17 = new ModelRenderer(this, 0, 0);
/*  98 */     this.body17.func_78793_a(0.0F, 0.0F, 0.0F);
/*  99 */     this.body17.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/* 100 */     setRotateAngle(this.body17, 0.0F, -1.5707964F, 0.0F);
/* 101 */     this.body13 = new ModelRenderer(this, 14, 0);
/* 102 */     this.body13.func_78793_a(0.0F, 0.0F, 0.6F);
/* 103 */     this.body13.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/* 104 */     this.body5 = new ModelRenderer(this, 0, 0);
/* 105 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 106 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/* 107 */     setRotateAngle(this.body5, 0.0F, 1.5707964F, 0.0F);
/* 108 */     this.body6 = new ModelRenderer(this, 8, 0);
/* 109 */     this.body6.func_78793_a(0.0F, 8.3F, 2.6F);
/* 110 */     this.body6.func_78790_a(-1.0F, -7.5F, 0.5F, 2, 15, 1, 0.0F);
/* 111 */     this.body24 = new ModelRenderer(this, 14, 0);
/* 112 */     this.body24.func_78793_a(0.0F, 0.0F, 0.6F);
/* 113 */     this.body24.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/* 114 */     this.body4 = new ModelRenderer(this, 14, 0);
/* 115 */     this.body4.func_78793_a(0.0F, 0.0F, 0.6F);
/* 116 */     this.body4.func_78790_a(-0.5F, -7.5F, 0.5F, 1, 15, 1, 0.0F);
/* 117 */     this.body1.func_78792_a(this.body14);
/* 118 */     this.body1.func_78792_a(this.body8);
/* 119 */     this.body17.func_78792_a(this.body18);
/* 120 */     this.body2.func_78792_a(this.body3);
/* 121 */     this.body6.func_78792_a(this.body7);
/* 122 */     this.body15.func_78792_a(this.body16);
/* 123 */     this.body11.func_78792_a(this.body12);
/* 124 */     this.body21.func_78792_a(this.body22);
/* 125 */     this.body1.func_78792_a(this.body20);
/* 126 */     this.body18.func_78792_a(this.body19);
/* 127 */     this.body8.func_78792_a(this.body9);
/* 128 */     this.body9.func_78792_a(this.body10);
/* 129 */     this.body1.func_78792_a(this.body2);
/* 130 */     this.body1.func_78792_a(this.body23);
/* 131 */     this.body14.func_78792_a(this.body15);
/* 132 */     this.body1.func_78792_a(this.body11);
/* 133 */     this.body20.func_78792_a(this.body21);
/* 134 */     this.body1.func_78792_a(this.body17);
/* 135 */     this.body12.func_78792_a(this.body13);
/* 136 */     this.body1.func_78792_a(this.body5);
/* 137 */     this.body5.func_78792_a(this.body6);
/* 138 */     this.body23.func_78792_a(this.body24);
/* 139 */     this.body3.func_78792_a(this.body4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 145 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 150 */     modelRenderer.field_78795_f = x;
/* 151 */     modelRenderer.field_78796_g = y;
/* 152 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyGraflex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */