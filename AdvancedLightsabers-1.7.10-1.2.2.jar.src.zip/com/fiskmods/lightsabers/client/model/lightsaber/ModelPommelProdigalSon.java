/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelPommelProdigalSon
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer top1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer top2;
/*     */   public ModelRenderer top3;
/*     */   public ModelRenderer top4;
/*     */   public ModelRenderer top5;
/*     */   public ModelRenderer top6;
/*     */   public ModelRenderer top7;
/*     */   public ModelRenderer top8;
/*     */   
/*     */   public ModelPommelProdigalSon() {
/*  30 */     this.field_78090_t = 64;
/*  31 */     this.field_78089_u = 32;
/*  32 */     this.top6 = new ModelRenderer(this, 10, 0);
/*  33 */     this.top6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  34 */     this.top6.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  35 */     setRotateAngle(this.top6, 0.0F, -2.3561945F, 0.0F);
/*  36 */     this.top5 = new ModelRenderer(this, 10, 0);
/*  37 */     this.top5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  38 */     this.top5.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  39 */     setRotateAngle(this.top5, 0.0F, 3.1415927F, 0.0F);
/*  40 */     this.top2 = new ModelRenderer(this, 10, 0);
/*  41 */     this.top2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.top2.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  43 */     setRotateAngle(this.top2, 0.0F, 0.7853982F, 0.0F);
/*  44 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  45 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body4.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  47 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  48 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  49 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  50 */     this.body7.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  51 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  52 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  53 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  54 */     this.body6.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  55 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  56 */     this.top3 = new ModelRenderer(this, 10, 0);
/*  57 */     this.top3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  58 */     this.top3.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  59 */     setRotateAngle(this.top3, 0.0F, 1.5707964F, 0.0F);
/*  60 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  61 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  62 */     this.body2.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  63 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  64 */     this.top1 = new ModelRenderer(this, 10, 0);
/*  65 */     this.top1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  66 */     this.top1.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  67 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  68 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body8.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  70 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  71 */     this.top7 = new ModelRenderer(this, 10, 0);
/*  72 */     this.top7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.top7.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  74 */     setRotateAngle(this.top7, 0.0F, -1.5707964F, 0.0F);
/*  75 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  76 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  77 */     this.body3.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  78 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  79 */     this.top4 = new ModelRenderer(this, 10, 0);
/*  80 */     this.top4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  81 */     this.top4.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  82 */     setRotateAngle(this.top4, 0.0F, 2.3561945F, 0.0F);
/*  83 */     this.top8 = new ModelRenderer(this, 10, 0);
/*  84 */     this.top8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  85 */     this.top8.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  86 */     setRotateAngle(this.top8, 0.0F, -0.7853982F, 0.0F);
/*  87 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  88 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.body1.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  90 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  91 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.body5.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 2, 4, 0.0F);
/*  93 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  94 */     this.top1.func_78792_a(this.top6);
/*  95 */     this.top1.func_78792_a(this.top5);
/*  96 */     this.top1.func_78792_a(this.top2);
/*  97 */     this.body1.func_78792_a(this.body4);
/*  98 */     this.body1.func_78792_a(this.body7);
/*  99 */     this.body1.func_78792_a(this.body6);
/* 100 */     this.top1.func_78792_a(this.top3);
/* 101 */     this.body1.func_78792_a(this.body2);
/* 102 */     this.body1.func_78792_a(this.body8);
/* 103 */     this.top1.func_78792_a(this.top7);
/* 104 */     this.body1.func_78792_a(this.body3);
/* 105 */     this.top1.func_78792_a(this.top4);
/* 106 */     this.top1.func_78792_a(this.top8);
/* 107 */     this.body1.func_78792_a(this.body5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 113 */     GL11.glPushMatrix();
/* 114 */     GL11.glTranslatef(this.top1.field_82906_o, this.top1.field_82908_p, this.top1.field_82907_q);
/* 115 */     GL11.glTranslatef(this.top1.field_78800_c * f5, this.top1.field_78797_d * f5, this.top1.field_78798_e * f5);
/* 116 */     GL11.glScaled(0.8D, 1.0D, 0.8D);
/* 117 */     GL11.glTranslatef(-this.top1.field_82906_o, -this.top1.field_82908_p, -this.top1.field_82907_q);
/* 118 */     GL11.glTranslatef(-this.top1.field_78800_c * f5, -this.top1.field_78797_d * f5, -this.top1.field_78798_e * f5);
/* 119 */     this.top1.func_78785_a(f5);
/* 120 */     GL11.glPopMatrix();
/* 121 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 126 */     modelRenderer.field_78795_f = x;
/* 127 */     modelRenderer.field_78796_g = y;
/* 128 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelProdigalSon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */