/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ModelSwitchSectionRebel
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer lowerSideButton1;
/*     */   public ModelRenderer innerBody1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer lowerSideButton2;
/*     */   public ModelRenderer lowerSideButton3;
/*     */   public ModelRenderer lowerSideButton4;
/*     */   public ModelRenderer lowerSideButton5;
/*     */   public ModelRenderer lowerSideButton6;
/*     */   public ModelRenderer lowerSideButton7;
/*     */   public ModelRenderer lowerSideButton8;
/*     */   public ModelRenderer body2_1;
/*     */   public ModelRenderer body3_1;
/*     */   public ModelRenderer body4_1;
/*     */   public ModelRenderer body5_1;
/*     */   public ModelRenderer body6_1;
/*     */   public ModelRenderer body7_1;
/*     */   public ModelRenderer body9_1;
/*     */   
/*     */   public ModelSwitchSectionRebel() {
/*  37 */     this.field_78090_t = 64;
/*  38 */     this.field_78089_u = 32;
/*  39 */     this.innerBody1 = new ModelRenderer(this, 0, 0);
/*  40 */     this.innerBody1.func_78793_a(0.0F, -2.2F, 0.0F);
/*  41 */     this.innerBody1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/*  42 */     setRotateAngle(this.innerBody1, 0.0F, -1.5707964F, 0.0F);
/*  43 */     this.lowerSideButton5 = new ModelRenderer(this, 10, 9);
/*  44 */     this.lowerSideButton5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  45 */     this.lowerSideButton5.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  46 */     setRotateAngle(this.lowerSideButton5, 0.0F, 3.1415927F, 0.0F);
/*  47 */     this.body4 = new ModelRenderer(this, 0, 9);
/*  48 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  50 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  51 */     this.body1 = new ModelRenderer(this, 0, 9);
/*  52 */     this.body1.func_78793_a(0.0F, 4.0F, 0.0F);
/*  53 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  54 */     setRotateAngle(this.body1, 0.0F, -1.5707964F, 0.0F);
/*  55 */     this.body7 = new ModelRenderer(this, 0, 15);
/*  56 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  58 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  59 */     this.body5 = new ModelRenderer(this, 0, 9);
/*  60 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  61 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  62 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  63 */     this.body2_1 = new ModelRenderer(this, 0, 0);
/*  64 */     this.body2_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body2_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/*  66 */     setRotateAngle(this.body2_1, 0.0F, 0.7853982F, 0.0F);
/*  67 */     this.lowerSideButton1 = new ModelRenderer(this, 10, 9);
/*  68 */     this.lowerSideButton1.func_78793_a(-3.62F, -2.1F, 0.0F);
/*  69 */     this.lowerSideButton1.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  70 */     setRotateAngle(this.lowerSideButton1, 1.5707964F, 1.5707964F, 0.0F);
/*  71 */     this.body9 = new ModelRenderer(this, 0, 9);
/*  72 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.body9.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  74 */     setRotateAngle(this.body9, 0.0F, -0.7853982F, 0.0F);
/*  75 */     this.body2 = new ModelRenderer(this, 0, 9);
/*  76 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  77 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  78 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  79 */     this.lowerSideButton7 = new ModelRenderer(this, 10, 9);
/*  80 */     this.lowerSideButton7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  81 */     this.lowerSideButton7.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  82 */     setRotateAngle(this.lowerSideButton7, 0.0F, -1.5707964F, 0.0F);
/*  83 */     this.body5_1 = new ModelRenderer(this, 0, 0);
/*  84 */     this.body5_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  85 */     this.body5_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/*  86 */     setRotateAngle(this.body5_1, 0.0F, 3.1415927F, 0.0F);
/*  87 */     this.lowerSideButton3 = new ModelRenderer(this, 10, 9);
/*  88 */     this.lowerSideButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.lowerSideButton3.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  90 */     setRotateAngle(this.lowerSideButton3, 0.0F, 1.5707964F, 0.0F);
/*  91 */     this.body6_1 = new ModelRenderer(this, 0, 0);
/*  92 */     this.body6_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  93 */     this.body6_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/*  94 */     setRotateAngle(this.body6_1, 0.0F, -2.3561945F, 0.0F);
/*  95 */     this.body3 = new ModelRenderer(this, 0, 9);
/*  96 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  97 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/*  98 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  99 */     this.lowerSideButton6 = new ModelRenderer(this, 10, 9);
/* 100 */     this.lowerSideButton6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 101 */     this.lowerSideButton6.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 102 */     setRotateAngle(this.lowerSideButton6, 0.0F, -2.3561945F, 0.0F);
/* 103 */     this.body7_1 = new ModelRenderer(this, 0, 0);
/* 104 */     this.body7_1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 105 */     this.body7_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/* 106 */     setRotateAngle(this.body7_1, 0.0F, -1.5707964F, 0.0F);
/* 107 */     this.body3_1 = new ModelRenderer(this, 0, 0);
/* 108 */     this.body3_1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 109 */     this.body3_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/* 110 */     setRotateAngle(this.body3_1, 0.0F, 1.5707964F, 0.0F);
/* 111 */     this.lowerSideButton2 = new ModelRenderer(this, 10, 9);
/* 112 */     this.lowerSideButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 113 */     this.lowerSideButton2.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 114 */     setRotateAngle(this.lowerSideButton2, 0.0F, 0.7853982F, 0.0F);
/* 115 */     this.lowerSideButton8 = new ModelRenderer(this, 10, 9);
/* 116 */     this.lowerSideButton8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 117 */     this.lowerSideButton8.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 118 */     setRotateAngle(this.lowerSideButton8, 0.0F, -0.7853982F, 0.0F);
/* 119 */     this.body6 = new ModelRenderer(this, 0, 9);
/* 120 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 121 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 4, 1, 0.0F);
/* 122 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/* 123 */     this.lowerSideButton4 = new ModelRenderer(this, 10, 9);
/* 124 */     this.lowerSideButton4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 125 */     this.lowerSideButton4.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 126 */     setRotateAngle(this.lowerSideButton4, 0.0F, 2.3561945F, 0.0F);
/* 127 */     this.body9_1 = new ModelRenderer(this, 0, 0);
/* 128 */     this.body9_1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 129 */     this.body9_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/* 130 */     setRotateAngle(this.body9_1, 0.0F, -0.7853982F, 0.0F);
/* 131 */     this.body4_1 = new ModelRenderer(this, 0, 0);
/* 132 */     this.body4_1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 133 */     this.body4_1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 5, 1, 0.0F);
/* 134 */     setRotateAngle(this.body4_1, 0.0F, 2.3561945F, 0.0F);
/* 135 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton5);
/* 136 */     this.body1.func_78792_a(this.body4);
/* 137 */     this.body1.func_78792_a(this.body7);
/* 138 */     this.body1.func_78792_a(this.body5);
/* 139 */     this.innerBody1.func_78792_a(this.body2_1);
/* 140 */     this.body1.func_78792_a(this.body9);
/* 141 */     this.body1.func_78792_a(this.body2);
/* 142 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton7);
/* 143 */     this.innerBody1.func_78792_a(this.body5_1);
/* 144 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton3);
/* 145 */     this.innerBody1.func_78792_a(this.body6_1);
/* 146 */     this.body1.func_78792_a(this.body3);
/* 147 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton6);
/* 148 */     this.innerBody1.func_78792_a(this.body7_1);
/* 149 */     this.innerBody1.func_78792_a(this.body3_1);
/* 150 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton2);
/* 151 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton8);
/* 152 */     this.body1.func_78792_a(this.body6);
/* 153 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton4);
/* 154 */     this.innerBody1.func_78792_a(this.body9_1);
/* 155 */     this.innerBody1.func_78792_a(this.body4_1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 161 */     GL11.glPushMatrix();
/* 162 */     GL11.glTranslatef(this.innerBody1.field_82906_o, this.innerBody1.field_82908_p, this.innerBody1.field_82907_q);
/* 163 */     GL11.glTranslatef(this.innerBody1.field_78800_c * f5, this.innerBody1.field_78797_d * f5, this.innerBody1.field_78798_e * f5);
/* 164 */     GL11.glScaled(0.8D, 0.6D, 0.8D);
/* 165 */     GL11.glTranslatef(-this.innerBody1.field_82906_o, -this.innerBody1.field_82908_p, -this.innerBody1.field_82907_q);
/* 166 */     GL11.glTranslatef(-this.innerBody1.field_78800_c * f5, -this.innerBody1.field_78797_d * f5, -this.innerBody1.field_78798_e * f5);
/* 167 */     this.innerBody1.func_78785_a(f5);
/* 168 */     GL11.glPopMatrix();
/* 169 */     this.body1.func_78785_a(f5);
/* 170 */     GL11.glPushMatrix();
/* 171 */     GL11.glTranslatef(this.lowerSideButton1.field_82906_o, this.lowerSideButton1.field_82908_p, this.lowerSideButton1.field_82907_q);
/* 172 */     GL11.glTranslatef(this.lowerSideButton1.field_78800_c * f5, this.lowerSideButton1.field_78797_d * f5, this.lowerSideButton1.field_78798_e * f5);
/* 173 */     GL11.glScaled(0.2D, 0.2D, 0.2D);
/* 174 */     GL11.glTranslatef(-this.lowerSideButton1.field_82906_o, -this.lowerSideButton1.field_82908_p, -this.lowerSideButton1.field_82907_q);
/* 175 */     GL11.glTranslatef(-this.lowerSideButton1.field_78800_c * f5, -this.lowerSideButton1.field_78797_d * f5, -this.lowerSideButton1.field_78798_e * f5);
/* 176 */     this.lowerSideButton1.func_78785_a(f5);
/* 177 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 182 */     modelRenderer.field_78795_f = x;
/* 183 */     modelRenderer.field_78796_g = y;
/* 184 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionRebel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */