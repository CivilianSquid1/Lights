/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelSwitchSectionMechanical
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer switch1;
/*     */   public ModelRenderer switch2;
/*     */   public ModelRenderer switchPanel;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body8;
/*     */   
/*     */   public ModelSwitchSectionMechanical() {
/*  26 */     this.field_78090_t = 64;
/*  27 */     this.field_78089_u = 32;
/*  28 */     this.switch1 = new ModelRenderer(this, 10, 3);
/*  29 */     this.switch1.func_78793_a(-4.7F, -6.0F, -1.1F);
/*  30 */     this.switch1.func_78790_a(0.1F, -0.52F, -1.87F, 2, 9, 2, 0.0F);
/*  31 */     setRotateAngle(this.switch1, 0.10471976F, 0.0F, 0.0F);
/*  32 */     this.switchPanel = new ModelRenderer(this, 8, 20);
/*  33 */     this.switchPanel.func_78793_a(-3.0F, -4.5F, -2.2F);
/*  34 */     this.switchPanel.func_78790_a(-2.0F, -3.9F, 0.0F, 2, 8, 3, 0.0F);
/*  35 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  36 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  37 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  38 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  39 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  40 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  41 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  42 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  43 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  44 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  45 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  46 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  47 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  48 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  49 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  50 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  51 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  52 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  53 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  54 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  55 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  56 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  57 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  58 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  59 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  60 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  61 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  62 */     this.switch2 = new ModelRenderer(this, 10, 3);
/*  63 */     this.switch2.func_78793_a(-4.7F, -5.7F, -1.1F);
/*  64 */     this.switch2.func_78790_a(0.1F, -1.55F, -2.02F, 2, 2, 2, 0.0F);
/*  65 */     setRotateAngle(this.switch2, -0.61086524F, 0.0F, 0.0F);
/*  66 */     this.body9 = new ModelRenderer(this, 0, 0);
/*  67 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/*  68 */     this.body9.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  69 */     setRotateAngle(this.body9, 0.0F, -0.7853982F, 0.0F);
/*  70 */     this.body8 = new ModelRenderer(this, 0, 11);
/*  71 */     this.body8.func_78793_a(0.0F, -4.0F, 3.0F);
/*  72 */     this.body8.func_78790_a(-1.5F, -4.0F, 0.0F, 3, 8, 2, 0.0F);
/*  73 */     this.body1.func_78792_a(this.body6);
/*  74 */     this.body1.func_78792_a(this.body2);
/*  75 */     this.body1.func_78792_a(this.body4);
/*  76 */     this.body1.func_78792_a(this.body5);
/*  77 */     this.body1.func_78792_a(this.body3);
/*  78 */     this.body1.func_78792_a(this.body7);
/*  79 */     this.body1.func_78792_a(this.body9);
/*  80 */     this.body7.func_78792_a(this.body8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  86 */     GL11.glPushMatrix();
/*  87 */     GL11.glTranslatef(this.switch1.field_82906_o, this.switch1.field_82908_p, this.switch1.field_82907_q);
/*  88 */     GL11.glTranslatef(this.switch1.field_78800_c * f5, this.switch1.field_78797_d * f5, this.switch1.field_78798_e * f5);
/*  89 */     GL11.glScaled(0.5D, 0.6D, 1.0D);
/*  90 */     GL11.glTranslatef(-this.switch1.field_82906_o, -this.switch1.field_82908_p, -this.switch1.field_82907_q);
/*  91 */     GL11.glTranslatef(-this.switch1.field_78800_c * f5, -this.switch1.field_78797_d * f5, -this.switch1.field_78798_e * f5);
/*  92 */     this.switch1.func_78785_a(f5);
/*  93 */     GL11.glPopMatrix();
/*  94 */     GL11.glPushMatrix();
/*  95 */     GL11.glTranslatef(this.switchPanel.field_82906_o, this.switchPanel.field_82908_p, this.switchPanel.field_82907_q);
/*  96 */     GL11.glTranslatef(this.switchPanel.field_78800_c * f5, this.switchPanel.field_78797_d * f5, this.switchPanel.field_78798_e * f5);
/*  97 */     GL11.glScaled(1.2D, 1.1D, 1.4D);
/*  98 */     GL11.glTranslatef(-this.switchPanel.field_82906_o, -this.switchPanel.field_82908_p, -this.switchPanel.field_82907_q);
/*  99 */     GL11.glTranslatef(-this.switchPanel.field_78800_c * f5, -this.switchPanel.field_78797_d * f5, -this.switchPanel.field_78798_e * f5);
/* 100 */     this.switchPanel.func_78785_a(f5);
/* 101 */     GL11.glPopMatrix();
/* 102 */     GL11.glPushMatrix();
/* 103 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 104 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 105 */     GL11.glScaled(1.1D, 1.1D, 1.1D);
/* 106 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 107 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 108 */     this.body1.func_78785_a(f5);
/* 109 */     GL11.glPopMatrix();
/* 110 */     GL11.glPushMatrix();
/* 111 */     GL11.glTranslatef(this.switch2.field_82906_o, this.switch2.field_82908_p, this.switch2.field_82907_q);
/* 112 */     GL11.glTranslatef(this.switch2.field_78800_c * f5, this.switch2.field_78797_d * f5, this.switch2.field_78798_e * f5);
/* 113 */     GL11.glScaled(0.5D, 0.6D, 1.0D);
/* 114 */     GL11.glTranslatef(-this.switch2.field_82906_o, -this.switch2.field_82908_p, -this.switch2.field_82907_q);
/* 115 */     GL11.glTranslatef(-this.switch2.field_78800_c * f5, -this.switch2.field_78797_d * f5, -this.switch2.field_78798_e * f5);
/* 116 */     this.switch2.func_78785_a(f5);
/* 117 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 122 */     modelRenderer.field_78795_f = x;
/* 123 */     modelRenderer.field_78796_g = y;
/* 124 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionMechanical.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */