/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelPommelRedeemer
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer top1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer top2;
/*     */   public ModelRenderer top3;
/*     */   public ModelRenderer top4;
/*     */   public ModelRenderer top5;
/*     */   public ModelRenderer top6;
/*     */   public ModelRenderer top7;
/*     */   public ModelRenderer top8;
/*     */   
/*     */   public ModelPommelRedeemer() {
/*  30 */     this.field_78090_t = 64;
/*  31 */     this.field_78089_u = 32;
/*  32 */     this.top1 = new ModelRenderer(this, 10, 0);
/*  33 */     this.top1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  34 */     this.top1.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  35 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  36 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  37 */     this.body2.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  38 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  39 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  40 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  41 */     this.body8.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  42 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  43 */     this.top5 = new ModelRenderer(this, 10, 0);
/*  44 */     this.top5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  45 */     this.top5.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  46 */     setRotateAngle(this.top5, 0.0F, 3.1415927F, 0.0F);
/*  47 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  48 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body1.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  50 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  51 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  52 */     this.body5.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  53 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  54 */     this.top2 = new ModelRenderer(this, 10, 0);
/*  55 */     this.top2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  56 */     this.top2.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  57 */     setRotateAngle(this.top2, 0.0F, 0.7853982F, 0.0F);
/*  58 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  59 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  60 */     this.body3.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  61 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  62 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  63 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  64 */     this.body6.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  65 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  66 */     this.top7 = new ModelRenderer(this, 10, 0);
/*  67 */     this.top7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  68 */     this.top7.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  69 */     setRotateAngle(this.top7, 0.0F, -1.5707964F, 0.0F);
/*  70 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  71 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  72 */     this.body4.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  73 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  74 */     this.top3 = new ModelRenderer(this, 10, 0);
/*  75 */     this.top3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  76 */     this.top3.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  77 */     setRotateAngle(this.top3, 0.0F, 1.5707964F, 0.0F);
/*  78 */     this.top4 = new ModelRenderer(this, 10, 0);
/*  79 */     this.top4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  80 */     this.top4.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  81 */     setRotateAngle(this.top4, 0.0F, 2.3561945F, 0.0F);
/*  82 */     this.top8 = new ModelRenderer(this, 10, 0);
/*  83 */     this.top8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  84 */     this.top8.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  85 */     setRotateAngle(this.top8, 0.0F, -0.7853982F, 0.0F);
/*  86 */     this.top6 = new ModelRenderer(this, 10, 0);
/*  87 */     this.top6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  88 */     this.top6.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  89 */     setRotateAngle(this.top6, 0.0F, -2.3561945F, 0.0F);
/*  90 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  91 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.body7.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 1, 4, 0.0F);
/*  93 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  94 */     this.body1.func_78792_a(this.body2);
/*  95 */     this.body1.func_78792_a(this.body8);
/*  96 */     this.top1.func_78792_a(this.top5);
/*  97 */     this.body1.func_78792_a(this.body5);
/*  98 */     this.top1.func_78792_a(this.top2);
/*  99 */     this.body1.func_78792_a(this.body3);
/* 100 */     this.body1.func_78792_a(this.body6);
/* 101 */     this.top1.func_78792_a(this.top7);
/* 102 */     this.body1.func_78792_a(this.body4);
/* 103 */     this.top1.func_78792_a(this.top3);
/* 104 */     this.top1.func_78792_a(this.top4);
/* 105 */     this.top1.func_78792_a(this.top8);
/* 106 */     this.top1.func_78792_a(this.top6);
/* 107 */     this.body1.func_78792_a(this.body7);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 113 */     GL11.glPushMatrix();
/* 114 */     GL11.glTranslatef(this.top1.field_82906_o, this.top1.field_82908_p, this.top1.field_82907_q);
/* 115 */     GL11.glTranslatef(this.top1.field_78800_c * f5, this.top1.field_78797_d * f5, this.top1.field_78798_e * f5);
/* 116 */     GL11.glScaled(0.8D, 1.0D, 0.8D);
/* 117 */     GL11.glTranslatef(-this.top1.field_82906_o, -this.top1.field_82908_p, -this.top1.field_82907_q);
/* 118 */     GL11.glTranslatef(-this.top1.field_78800_c * f5, -this.top1.field_78797_d * f5, -this.top1.field_78798_e * f5);
/* 119 */     this.top1.func_78785_a(f5);
/* 120 */     GL11.glPopMatrix();
/* 121 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 126 */     modelRenderer.field_78795_f = x;
/* 127 */     modelRenderer.field_78796_g = y;
/* 128 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelRedeemer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */