/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class ModelBodyFury
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body10_1;
/*     */   public ModelRenderer body10_2;
/*     */   public ModelRenderer body10_3;
/*     */   public ModelRenderer body10_4;
/*     */   public ModelRenderer body10_5;
/*     */   public ModelRenderer body10_6;
/*     */   public ModelRenderer body10_7;
/*     */   public ModelRenderer body10_8;
/*     */   
/*     */   public ModelBodyFury() {
/*  30 */     this.field_78090_t = 64;
/*  31 */     this.field_78089_u = 32;
/*  32 */     this.body10_2 = new ModelRenderer(this, 8, 0);
/*  33 */     this.body10_2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  34 */     this.body10_2.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  35 */     setRotateAngle(this.body10_2, 0.0F, 0.62831855F, 0.0F);
/*  36 */     this.body10_6 = new ModelRenderer(this, 8, 0);
/*  37 */     this.body10_6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  38 */     this.body10_6.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  39 */     setRotateAngle(this.body10_6, 0.0F, 0.62831855F, 0.0F);
/*  40 */     this.body10_7 = new ModelRenderer(this, 8, 0);
/*  41 */     this.body10_7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.body10_7.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  43 */     setRotateAngle(this.body10_7, 0.0F, 0.62831855F, 0.0F);
/*  44 */     this.body14 = new ModelRenderer(this, 0, 0);
/*  45 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body14.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  47 */     setRotateAngle(this.body14, 0.0F, -2.3561945F, 0.0F);
/*  48 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  49 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  50 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  51 */     this.body10_1 = new ModelRenderer(this, 8, 0);
/*  52 */     this.body10_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  53 */     this.body10_1.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  54 */     setRotateAngle(this.body10_1, 0.0F, 0.62831855F, 0.0F);
/*  55 */     this.body17 = new ModelRenderer(this, 0, 0);
/*  56 */     this.body17.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.body17.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  58 */     setRotateAngle(this.body17, 0.0F, -1.5707964F, 0.0F);
/*  59 */     this.body10_8 = new ModelRenderer(this, 8, 0);
/*  60 */     this.body10_8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  61 */     this.body10_8.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  62 */     setRotateAngle(this.body10_8, 0.0F, 0.62831855F, 0.0F);
/*  63 */     this.body20 = new ModelRenderer(this, 0, 0);
/*  64 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body20.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  66 */     setRotateAngle(this.body20, 0.0F, -0.7853982F, 0.0F);
/*  67 */     this.body11 = new ModelRenderer(this, 0, 0);
/*  68 */     this.body11.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body11.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  70 */     setRotateAngle(this.body11, 0.0F, 3.1415927F, 0.0F);
/*  71 */     this.body10 = new ModelRenderer(this, 8, 0);
/*  72 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.body10.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  74 */     setRotateAngle(this.body10, 0.0F, 0.62831855F, 0.0F);
/*  75 */     this.body10_4 = new ModelRenderer(this, 8, 0);
/*  76 */     this.body10_4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  77 */     this.body10_4.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  78 */     setRotateAngle(this.body10_4, 0.0F, 0.62831855F, 0.0F);
/*  79 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  80 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  81 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  82 */     setRotateAngle(this.body5, 0.0F, 1.5707964F, 0.0F);
/*  83 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  84 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  85 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  86 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  87 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  88 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  90 */     setRotateAngle(this.body8, 0.0F, 2.3561945F, 0.0F);
/*  91 */     this.body9 = new ModelRenderer(this, 8, 0);
/*  92 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/*  93 */     this.body9.func_78790_a(-0.5F, 0.4F, 3.52F, 1, 15, 1, 0.0F);
/*  94 */     this.body10_3 = new ModelRenderer(this, 8, 0);
/*  95 */     this.body10_3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  96 */     this.body10_3.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  97 */     setRotateAngle(this.body10_3, 0.0F, 0.62831855F, 0.0F);
/*  98 */     this.body10_5 = new ModelRenderer(this, 8, 0);
/*  99 */     this.body10_5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 100 */     this.body10_5.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/* 101 */     setRotateAngle(this.body10_5, 0.0F, 0.62831855F, 0.0F);
/* 102 */     this.body10_1.func_78792_a(this.body10_2);
/* 103 */     this.body10_5.func_78792_a(this.body10_6);
/* 104 */     this.body10_6.func_78792_a(this.body10_7);
/* 105 */     this.body1.func_78792_a(this.body14);
/* 106 */     this.body10.func_78792_a(this.body10_1);
/* 107 */     this.body1.func_78792_a(this.body17);
/* 108 */     this.body10_7.func_78792_a(this.body10_8);
/* 109 */     this.body1.func_78792_a(this.body20);
/* 110 */     this.body1.func_78792_a(this.body11);
/* 111 */     this.body9.func_78792_a(this.body10);
/* 112 */     this.body10_3.func_78792_a(this.body10_4);
/* 113 */     this.body1.func_78792_a(this.body5);
/* 114 */     this.body1.func_78792_a(this.body2);
/* 115 */     this.body1.func_78792_a(this.body8);
/* 116 */     this.body1.func_78792_a(this.body9);
/* 117 */     this.body10_2.func_78792_a(this.body10_3);
/* 118 */     this.body10_4.func_78792_a(this.body10_5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 124 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 129 */     modelRenderer.field_78795_f = x;
/* 130 */     modelRenderer.field_78796_g = y;
/* 131 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyFury.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */