/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ModelBodyRebel
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer switchPart;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body10_1;
/*     */   public ModelRenderer body10_2;
/*     */   public ModelRenderer body10_3;
/*     */   
/*     */   public ModelBodyRebel() {
/*  27 */     this.field_78090_t = 64;
/*  28 */     this.field_78089_u = 32;
/*  29 */     this.body10_2 = new ModelRenderer(this, 8, 0);
/*  30 */     this.body10_2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  31 */     this.body10_2.func_78790_a(-0.5F, 0.5F, 3.22F, 1, 15, 1, 0.0F);
/*  32 */     setRotateAngle(this.body10_2, 0.0F, 0.62831855F, 0.0F);
/*  33 */     this.body11 = new ModelRenderer(this, 13, 0);
/*  34 */     this.body11.func_78793_a(0.0F, 0.0F, 0.0F);
/*  35 */     this.body11.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  36 */     setRotateAngle(this.body11, 0.0F, 3.1415927F, 0.0F);
/*  37 */     this.body17 = new ModelRenderer(this, 0, 0);
/*  38 */     this.body17.func_78793_a(0.0F, 0.0F, 0.0F);
/*  39 */     this.body17.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  40 */     setRotateAngle(this.body17, 0.0F, -1.5707964F, 0.0F);
/*  41 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  42 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  43 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  44 */     this.body14 = new ModelRenderer(this, 22, 0);
/*  45 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body14.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  47 */     setRotateAngle(this.body14, 0.0F, -2.3561945F, 0.0F);
/*  48 */     this.body20 = new ModelRenderer(this, 0, 0);
/*  49 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/*  50 */     this.body20.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  51 */     setRotateAngle(this.body20, 0.0F, -0.7853982F, 0.0F);
/*  52 */     this.body10 = new ModelRenderer(this, 8, 0);
/*  53 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  54 */     this.body10.func_78790_a(-0.5F, 0.5F, 3.22F, 1, 15, 1, 0.0F);
/*  55 */     setRotateAngle(this.body10, 0.0F, 0.62831855F, 0.0F);
/*  56 */     this.switchPart = new ModelRenderer(this, 0, 23);
/*  57 */     this.switchPart.func_78793_a(-1.0F, 3.3F, -4.5F);
/*  58 */     this.switchPart.func_78790_a(0.0F, 0.0F, 0.0F, 2, 6, 1, 0.0F);
/*  59 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  60 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  61 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  62 */     setRotateAngle(this.body5, 0.0F, 1.5707964F, 0.0F);
/*  63 */     this.body8 = new ModelRenderer(this, 31, 0);
/*  64 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  66 */     setRotateAngle(this.body8, 0.0F, 2.3561945F, 0.0F);
/*  67 */     this.body9 = new ModelRenderer(this, 8, 0);
/*  68 */     this.body9.func_78793_a(0.0F, -0.7F, 0.0F);
/*  69 */     this.body9.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  70 */     setRotateAngle(this.body9, 0.0F, -1.2217305F, 0.0F);
/*  71 */     this.body10_3 = new ModelRenderer(this, 8, 0);
/*  72 */     this.body10_3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.body10_3.func_78790_a(-0.5F, 0.5F, 3.52F, 1, 15, 1, 0.0F);
/*  74 */     setRotateAngle(this.body10_3, 0.0F, 0.62831855F, 0.0F);
/*  75 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  76 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  77 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  78 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  79 */     this.body10_1 = new ModelRenderer(this, 8, 0);
/*  80 */     this.body10_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  81 */     this.body10_1.func_78790_a(-0.5F, 0.5F, 2.82F, 1, 15, 1, 0.0F);
/*  82 */     setRotateAngle(this.body10_1, 0.0F, 0.62831855F, 0.0F);
/*  83 */     this.body10_1.func_78792_a(this.body10_2);
/*  84 */     this.body1.func_78792_a(this.body11);
/*  85 */     this.body1.func_78792_a(this.body17);
/*  86 */     this.body1.func_78792_a(this.body14);
/*  87 */     this.body1.func_78792_a(this.body20);
/*  88 */     this.body9.func_78792_a(this.body10);
/*  89 */     this.body1.func_78792_a(this.body5);
/*  90 */     this.body1.func_78792_a(this.body8);
/*  91 */     this.body10_2.func_78792_a(this.body10_3);
/*  92 */     this.body1.func_78792_a(this.body2);
/*  93 */     this.body10.func_78792_a(this.body10_1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  99 */     this.body1.func_78785_a(f5);
/* 100 */     this.switchPart.func_78785_a(f5);
/* 101 */     GL11.glPushMatrix();
/* 102 */     GL11.glTranslatef(this.body9.field_82906_o, this.body9.field_82908_p, this.body9.field_82907_q);
/* 103 */     GL11.glTranslatef(this.body9.field_78800_c * f5, this.body9.field_78797_d * f5, this.body9.field_78798_e * f5);
/* 104 */     GL11.glScaled(0.9D, 1.34D, 1.0D);
/* 105 */     GL11.glTranslatef(-this.body9.field_82906_o, -this.body9.field_82908_p, -this.body9.field_82907_q);
/* 106 */     GL11.glTranslatef(-this.body9.field_78800_c * f5, -this.body9.field_78797_d * f5, -this.body9.field_78798_e * f5);
/* 107 */     this.body9.func_78785_a(f5);
/* 108 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 113 */     modelRenderer.field_78795_f = x;
/* 114 */     modelRenderer.field_78796_g = y;
/* 115 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyRebel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */