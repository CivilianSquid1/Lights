/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelEmitterDroideka
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer ring1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer ring2;
/*     */   public ModelRenderer ring3;
/*     */   public ModelRenderer ring4;
/*     */   public ModelRenderer ring5;
/*     */   public ModelRenderer ring6;
/*     */   public ModelRenderer ring7;
/*     */   public ModelRenderer ring8;
/*     */   
/*     */   public ModelEmitterDroideka() {
/*  30 */     this.field_78090_t = 64;
/*  31 */     this.field_78089_u = 32;
/*  32 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  33 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  34 */     this.body6.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  35 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  36 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  37 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  38 */     this.body8.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  39 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  40 */     this.ring6 = new ModelRenderer(this, 0, 5);
/*  41 */     this.ring6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.ring6.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  43 */     setRotateAngle(this.ring6, 0.0F, -2.3561945F, 0.0F);
/*  44 */     this.ring3 = new ModelRenderer(this, 0, 5);
/*  45 */     this.ring3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.ring3.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  47 */     setRotateAngle(this.ring3, 0.0F, 1.5707964F, 0.0F);
/*  48 */     this.ring8 = new ModelRenderer(this, 0, 5);
/*  49 */     this.ring8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  50 */     this.ring8.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  51 */     setRotateAngle(this.ring8, 0.0F, -0.7853982F, 0.0F);
/*  52 */     this.ring7 = new ModelRenderer(this, 0, 5);
/*  53 */     this.ring7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  54 */     this.ring7.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  55 */     setRotateAngle(this.ring7, 0.0F, -1.5707964F, 0.0F);
/*  56 */     this.ring5 = new ModelRenderer(this, 0, 5);
/*  57 */     this.ring5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  58 */     this.ring5.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  59 */     setRotateAngle(this.ring5, 0.0F, 3.1415927F, 0.0F);
/*  60 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  61 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  62 */     this.body1.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  63 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  64 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body2.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  66 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  67 */     this.ring2 = new ModelRenderer(this, 0, 5);
/*  68 */     this.ring2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.ring2.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  70 */     setRotateAngle(this.ring2, 0.0F, 0.7853982F, 0.0F);
/*  71 */     this.ring1 = new ModelRenderer(this, 0, 5);
/*  72 */     this.ring1.func_78793_a(0.0F, -0.3F, 0.0F);
/*  73 */     this.ring1.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  74 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  75 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  76 */     this.body3.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  77 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  78 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  79 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  80 */     this.body7.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  81 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  82 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  83 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  84 */     this.body5.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  85 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  86 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  87 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  88 */     this.body4.func_78790_a(-1.5F, -3.0F, 1.62F, 3, 3, 2, 0.0F);
/*  89 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  90 */     this.ring4 = new ModelRenderer(this, 0, 5);
/*  91 */     this.ring4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.ring4.func_78790_a(-1.5F, -5.0F, 2.62F, 3, 5, 1, 0.0F);
/*  93 */     setRotateAngle(this.ring4, 0.0F, 2.3561945F, 0.0F);
/*  94 */     this.body1.func_78792_a(this.body6);
/*  95 */     this.body1.func_78792_a(this.body8);
/*  96 */     this.ring1.func_78792_a(this.ring6);
/*  97 */     this.ring1.func_78792_a(this.ring3);
/*  98 */     this.ring1.func_78792_a(this.ring8);
/*  99 */     this.ring1.func_78792_a(this.ring7);
/* 100 */     this.ring1.func_78792_a(this.ring5);
/* 101 */     this.body1.func_78792_a(this.body2);
/* 102 */     this.ring1.func_78792_a(this.ring2);
/* 103 */     this.body1.func_78792_a(this.body3);
/* 104 */     this.body1.func_78792_a(this.body7);
/* 105 */     this.body1.func_78792_a(this.body5);
/* 106 */     this.body1.func_78792_a(this.body4);
/* 107 */     this.ring1.func_78792_a(this.ring4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 113 */     this.body1.func_78785_a(f5);
/* 114 */     GL11.glPushMatrix();
/* 115 */     GL11.glTranslatef(this.ring1.field_82906_o, this.ring1.field_82908_p, this.ring1.field_82907_q);
/* 116 */     GL11.glTranslatef(this.ring1.field_78800_c * f5, this.ring1.field_78797_d * f5, this.ring1.field_78798_e * f5);
/* 117 */     GL11.glScaled(1.2D, 1.2D, 1.2D);
/* 118 */     GL11.glTranslatef(-this.ring1.field_82906_o, -this.ring1.field_82908_p, -this.ring1.field_82907_q);
/* 119 */     GL11.glTranslatef(-this.ring1.field_78800_c * f5, -this.ring1.field_78797_d * f5, -this.ring1.field_78798_e * f5);
/* 120 */     this.ring1.func_78785_a(f5);
/* 121 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 126 */     modelRenderer.field_78795_f = x;
/* 127 */     modelRenderer.field_78796_g = y;
/* 128 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelEmitterDroideka.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */