/*    */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class ModelSwitchSectionProdigalSon
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer body1;
/*    */   public ModelRenderer body2;
/*    */   public ModelRenderer body3;
/*    */   public ModelRenderer body4;
/*    */   public ModelRenderer body5;
/*    */   public ModelRenderer body6;
/*    */   public ModelRenderer body7;
/*    */   public ModelRenderer body10;
/*    */   public ModelRenderer body8;
/*    */   public ModelRenderer body9;
/*    */   
/*    */   public ModelSwitchSectionProdigalSon() {
/* 24 */     this.field_78090_t = 64;
/* 25 */     this.field_78089_u = 32;
/* 26 */     this.body3 = new ModelRenderer(this, 0, 0);
/* 27 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 28 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 29 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/* 30 */     this.body7 = new ModelRenderer(this, 0, 0);
/* 31 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 32 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 33 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/* 34 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 35 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 36 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 37 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/* 38 */     this.body9 = new ModelRenderer(this, 8, 0);
/* 39 */     this.body9.func_78793_a(-1.5F, 1.75F, 0.75F);
/* 40 */     this.body9.func_78790_a(-1.0F, -2.0F, -0.5F, 1, 4, 1, 0.0F);
/* 41 */     this.body10 = new ModelRenderer(this, 0, 0);
/* 42 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/* 43 */     this.body10.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 44 */     setRotateAngle(this.body10, 0.0F, -0.7853982F, 0.0F);
/* 45 */     this.body1 = new ModelRenderer(this, 0, 0);
/* 46 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 47 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 48 */     this.body4 = new ModelRenderer(this, 0, 0);
/* 49 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 50 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 51 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/* 52 */     this.body8 = new ModelRenderer(this, 0, 9);
/* 53 */     this.body8.func_78793_a(0.0F, -4.0F, 3.62F);
/* 54 */     this.body8.func_78790_a(-1.5F, -4.0F, 0.0F, 3, 8, 2, 0.0F);
/* 55 */     this.body2 = new ModelRenderer(this, 0, 0);
/* 56 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 57 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 58 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/* 59 */     this.body5 = new ModelRenderer(this, 0, 0);
/* 60 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 61 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 62 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/* 63 */     this.body1.func_78792_a(this.body3);
/* 64 */     this.body1.func_78792_a(this.body7);
/* 65 */     this.body1.func_78792_a(this.body6);
/* 66 */     this.body8.func_78792_a(this.body9);
/* 67 */     this.body1.func_78792_a(this.body10);
/* 68 */     this.body1.func_78792_a(this.body4);
/* 69 */     this.body7.func_78792_a(this.body8);
/* 70 */     this.body1.func_78792_a(this.body2);
/* 71 */     this.body1.func_78792_a(this.body5);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 77 */     GL11.glPushMatrix();
/* 78 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 79 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 80 */     GL11.glScaled(1.1D, 1.1D, 1.1D);
/* 81 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 82 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 83 */     this.body1.func_78785_a(f5);
/* 84 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 89 */     modelRenderer.field_78795_f = x;
/* 90 */     modelRenderer.field_78796_g = y;
/* 91 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionProdigalSon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */