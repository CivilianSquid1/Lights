/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelPommelJuggernaut
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer cap1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body22;
/*     */   public ModelRenderer body23;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer body21;
/*     */   public ModelRenderer body24;
/*     */   public ModelRenderer cap2;
/*     */   public ModelRenderer cap3;
/*     */   public ModelRenderer cap4;
/*     */   
/*     */   public ModelPommelJuggernaut() {
/*  42 */     this.field_78090_t = 64;
/*  43 */     this.field_78089_u = 32;
/*  44 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  45 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  46 */     this.body1.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/*  47 */     this.body16 = new ModelRenderer(this, 0, 0);
/*  48 */     this.body16.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body16.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/*  50 */     setRotateAngle(this.body16, 0.0F, -1.5707964F, 0.0F);
/*  51 */     this.body3 = new ModelRenderer(this, 0, 9);
/*  52 */     this.body3.func_78793_a(0.0F, 5.0F, 3.62F);
/*  53 */     this.body3.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/*  54 */     setRotateAngle(this.body3, -1.0471976F, 0.0F, 0.0F);
/*  55 */     this.cap2 = new ModelRenderer(this, 0, 18);
/*  56 */     this.cap2.func_78793_a(0.0F, 1.3F, 0.0F);
/*  57 */     this.cap2.func_78790_a(-4.0F, 0.0F, -0.5F, 8, 1, 1, 0.0F);
/*  58 */     this.body12 = new ModelRenderer(this, 14, 0);
/*  59 */     this.body12.func_78793_a(0.0F, 3.0F, 3.12F);
/*  60 */     this.body12.func_78790_a(-1.0F, -3.0F, 0.0F, 2, 6, 1, 0.0F);
/*  61 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  62 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  63 */     this.body4.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/*  64 */     setRotateAngle(this.body4, 0.0F, 1.5707964F, 0.0F);
/*  65 */     this.body22 = new ModelRenderer(this, 0, 9);
/*  66 */     this.body22.func_78793_a(0.0F, 5.0F, 3.62F);
/*  67 */     this.body22.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/*  68 */     setRotateAngle(this.body22, -1.0471976F, 0.0F, 0.0F);
/*  69 */     this.cap3 = new ModelRenderer(this, 0, 14);
/*  70 */     this.cap3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  71 */     this.cap3.func_78790_a(-3.5F, 0.0F, -1.0F, 7, 2, 2, 0.0F);
/*  72 */     setRotateAngle(this.cap3, 0.0F, 1.5707964F, 0.0F);
/*  73 */     this.body19 = new ModelRenderer(this, 14, 7);
/*  74 */     this.body19.func_78793_a(0.0F, 0.0F, 0.5F);
/*  75 */     this.body19.func_78790_a(-0.5F, -3.0F, 0.0F, 1, 6, 1, 0.0F);
/*  76 */     this.body9 = new ModelRenderer(this, 0, 9);
/*  77 */     this.body9.func_78793_a(0.0F, 5.0F, 3.62F);
/*  78 */     this.body9.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/*  79 */     setRotateAngle(this.body9, -1.0471976F, 0.0F, 0.0F);
/*  80 */     this.body6 = new ModelRenderer(this, 14, 0);
/*  81 */     this.body6.func_78793_a(0.0F, 3.0F, 3.12F);
/*  82 */     this.body6.func_78790_a(-1.0F, -3.0F, 0.0F, 2, 6, 1, 0.0F);
/*  83 */     this.body15 = new ModelRenderer(this, 0, 9);
/*  84 */     this.body15.func_78793_a(0.0F, 5.0F, 3.62F);
/*  85 */     this.body15.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/*  86 */     setRotateAngle(this.body15, -1.0471976F, 0.0F, 0.0F);
/*  87 */     this.body11 = new ModelRenderer(this, 0, 9);
/*  88 */     this.body11.func_78793_a(0.0F, 5.0F, 3.62F);
/*  89 */     this.body11.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/*  90 */     setRotateAngle(this.body11, -1.0471976F, 0.0F, 0.0F);
/*  91 */     this.body18 = new ModelRenderer(this, 14, 0);
/*  92 */     this.body18.func_78793_a(0.0F, 3.0F, 3.12F);
/*  93 */     this.body18.func_78790_a(-1.0F, -3.0F, 0.0F, 2, 6, 1, 0.0F);
/*  94 */     this.body14 = new ModelRenderer(this, 0, 0);
/*  95 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/*  96 */     this.body14.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/*  97 */     setRotateAngle(this.body14, 0.0F, -2.3561945F, 0.0F);
/*  98 */     this.body13 = new ModelRenderer(this, 14, 7);
/*  99 */     this.body13.func_78793_a(0.0F, 0.0F, 0.5F);
/* 100 */     this.body13.func_78790_a(-0.5F, -3.0F, 0.0F, 1, 6, 1, 0.0F);
/* 101 */     this.body23 = new ModelRenderer(this, 14, 0);
/* 102 */     this.body23.func_78793_a(0.0F, 3.0F, 3.12F);
/* 103 */     this.body23.func_78790_a(-1.0F, -3.0F, 0.0F, 2, 6, 1, 0.0F);
/* 104 */     this.cap4 = new ModelRenderer(this, 0, 18);
/* 105 */     this.cap4.func_78793_a(0.0F, 1.3F, 0.0F);
/* 106 */     this.cap4.func_78790_a(-4.0F, 0.0F, -0.5F, 8, 1, 1, 0.0F);
/* 107 */     this.body8 = new ModelRenderer(this, 0, 0);
/* 108 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 109 */     this.body8.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/* 110 */     setRotateAngle(this.body8, 0.0F, 2.3561945F, 0.0F);
/* 111 */     this.body2 = new ModelRenderer(this, 0, 0);
/* 112 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 113 */     this.body2.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/* 114 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/* 115 */     this.body17 = new ModelRenderer(this, 0, 9);
/* 116 */     this.body17.func_78793_a(0.0F, 5.0F, 3.62F);
/* 117 */     this.body17.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/* 118 */     setRotateAngle(this.body17, -1.0471976F, 0.0F, 0.0F);
/* 119 */     this.cap1 = new ModelRenderer(this, 0, 14);
/* 120 */     this.cap1.func_78793_a(0.0F, 4.7F, 0.0F);
/* 121 */     this.cap1.func_78790_a(-3.5F, 0.0F, -1.0F, 7, 2, 2, 0.0F);
/* 122 */     this.body7 = new ModelRenderer(this, 14, 7);
/* 123 */     this.body7.func_78793_a(0.0F, 0.0F, 0.5F);
/* 124 */     this.body7.func_78790_a(-0.5F, -3.0F, 0.0F, 1, 6, 1, 0.0F);
/* 125 */     this.body21 = new ModelRenderer(this, 0, 9);
/* 126 */     this.body21.func_78793_a(0.0F, 5.0F, 3.62F);
/* 127 */     this.body21.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/* 128 */     setRotateAngle(this.body21, -1.0471976F, 0.0F, 0.0F);
/* 129 */     this.body10 = new ModelRenderer(this, 0, 0);
/* 130 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/* 131 */     this.body10.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/* 132 */     setRotateAngle(this.body10, 0.0F, 3.1415927F, 0.0F);
/* 133 */     this.body24 = new ModelRenderer(this, 14, 7);
/* 134 */     this.body24.func_78793_a(0.0F, 0.0F, 0.5F);
/* 135 */     this.body24.func_78790_a(-0.5F, -3.0F, 0.0F, 1, 6, 1, 0.0F);
/* 136 */     this.body5 = new ModelRenderer(this, 0, 9);
/* 137 */     this.body5.func_78793_a(0.0F, 5.0F, 3.62F);
/* 138 */     this.body5.func_78790_a(-1.5F, 0.0F, -2.0F, 3, 3, 2, 0.0F);
/* 139 */     setRotateAngle(this.body5, -1.0471976F, 0.0F, 0.0F);
/* 140 */     this.body20 = new ModelRenderer(this, 0, 0);
/* 141 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/* 142 */     this.body20.func_78790_a(-1.5F, 0.0F, -0.38F, 3, 5, 4, 0.0F);
/* 143 */     setRotateAngle(this.body20, 0.0F, -0.7853982F, 0.0F);
/* 144 */     this.body1.func_78792_a(this.body16);
/* 145 */     this.body2.func_78792_a(this.body3);
/* 146 */     this.cap1.func_78792_a(this.cap2);
/* 147 */     this.body10.func_78792_a(this.body12);
/* 148 */     this.body1.func_78792_a(this.body4);
/* 149 */     this.body1.func_78792_a(this.body22);
/* 150 */     this.cap1.func_78792_a(this.cap3);
/* 151 */     this.body18.func_78792_a(this.body19);
/* 152 */     this.body8.func_78792_a(this.body9);
/* 153 */     this.body4.func_78792_a(this.body6);
/* 154 */     this.body14.func_78792_a(this.body15);
/* 155 */     this.body10.func_78792_a(this.body11);
/* 156 */     this.body16.func_78792_a(this.body18);
/* 157 */     this.body1.func_78792_a(this.body14);
/* 158 */     this.body12.func_78792_a(this.body13);
/* 159 */     this.body1.func_78792_a(this.body23);
/* 160 */     this.cap3.func_78792_a(this.cap4);
/* 161 */     this.body1.func_78792_a(this.body8);
/* 162 */     this.body1.func_78792_a(this.body2);
/* 163 */     this.body16.func_78792_a(this.body17);
/* 164 */     this.body6.func_78792_a(this.body7);
/* 165 */     this.body20.func_78792_a(this.body21);
/* 166 */     this.body1.func_78792_a(this.body10);
/* 167 */     this.body23.func_78792_a(this.body24);
/* 168 */     this.body4.func_78792_a(this.body5);
/* 169 */     this.body1.func_78792_a(this.body20);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 175 */     GL11.glPushMatrix();
/* 176 */     GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 177 */     this.body1.func_78785_a(f5);
/* 178 */     this.cap1.func_78785_a(f5);
/* 179 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 184 */     modelRenderer.field_78795_f = x;
/* 185 */     modelRenderer.field_78796_g = y;
/* 186 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelJuggernaut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */