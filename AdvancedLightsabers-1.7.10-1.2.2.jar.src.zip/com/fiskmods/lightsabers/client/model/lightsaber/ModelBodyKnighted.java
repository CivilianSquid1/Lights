/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class ModelBodyKnighted
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body21;
/*     */   public ModelRenderer body22;
/*     */   
/*     */   public ModelBodyKnighted() {
/*  34 */     this.field_78090_t = 64;
/*  35 */     this.field_78089_u = 32;
/*  36 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  37 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  38 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  39 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  40 */     this.body13 = new ModelRenderer(this, 8, 0);
/*  41 */     this.body13.func_78793_a(0.0F, 9.6F, 0.0F);
/*  42 */     this.body13.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  43 */     setRotateAngle(this.body13, 0.0F, 2.5132742F, 0.0F);
/*  44 */     this.body10 = new ModelRenderer(this, 8, 0);
/*  45 */     this.body10.func_78793_a(0.0F, 9.6F, 0.0F);
/*  46 */     this.body10.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  47 */     setRotateAngle(this.body10, 0.0F, 0.62831855F, 0.0F);
/*  48 */     this.body20 = new ModelRenderer(this, 0, 21);
/*  49 */     this.body20.func_78793_a(0.0F, 2.9F, 0.0F);
/*  50 */     this.body20.func_78790_a(-0.5F, -3.0F, 3.4F, 1, 6, 1, 0.0F);
/*  51 */     setRotateAngle(this.body20, 0.0F, 1.5707964F, 0.0F);
/*  52 */     this.body12 = new ModelRenderer(this, 8, 0);
/*  53 */     this.body12.func_78793_a(0.0F, 9.6F, 0.0F);
/*  54 */     this.body12.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  55 */     setRotateAngle(this.body12, 0.0F, 1.8849556F, 0.0F);
/*  56 */     this.body17 = new ModelRenderer(this, 8, 0);
/*  57 */     this.body17.func_78793_a(0.0F, 9.6F, 0.0F);
/*  58 */     this.body17.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  59 */     setRotateAngle(this.body17, 0.0F, -1.2566371F, 0.0F);
/*  60 */     this.body21 = new ModelRenderer(this, 0, 21);
/*  61 */     this.body21.func_78793_a(0.0F, 2.9F, 0.0F);
/*  62 */     this.body21.func_78790_a(-0.5F, -3.0F, 3.4F, 1, 6, 1, 0.0F);
/*  63 */     setRotateAngle(this.body21, 0.0F, 3.1415927F, 0.0F);
/*  64 */     this.body22 = new ModelRenderer(this, 0, 21);
/*  65 */     this.body22.func_78793_a(0.0F, 2.9F, 0.0F);
/*  66 */     this.body22.func_78790_a(-0.5F, -3.0F, 3.4F, 1, 6, 1, 0.0F);
/*  67 */     setRotateAngle(this.body22, 0.0F, -1.5707964F, 0.0F);
/*  68 */     this.body18 = new ModelRenderer(this, 8, 0);
/*  69 */     this.body18.func_78793_a(0.0F, 9.6F, 0.0F);
/*  70 */     this.body18.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  71 */     setRotateAngle(this.body18, 0.0F, -0.62831855F, 0.0F);
/*  72 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  73 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  74 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  75 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  76 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  77 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  78 */     this.body7.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  79 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  80 */     this.body14 = new ModelRenderer(this, 8, 0);
/*  81 */     this.body14.func_78793_a(0.0F, 9.6F, 0.0F);
/*  82 */     this.body14.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  83 */     setRotateAngle(this.body14, 0.0F, 3.1415927F, 0.0F);
/*  84 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  85 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  86 */     this.body3.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/*  87 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  88 */     this.body15 = new ModelRenderer(this, 8, 0);
/*  89 */     this.body15.func_78793_a(0.0F, 9.6F, 0.0F);
/*  90 */     this.body15.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  91 */     setRotateAngle(this.body15, 0.0F, -2.5132742F, 0.0F);
/*  92 */     this.body11 = new ModelRenderer(this, 8, 0);
/*  93 */     this.body11.func_78793_a(0.0F, 9.6F, 0.0F);
/*  94 */     this.body11.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/*  95 */     setRotateAngle(this.body11, 0.0F, 1.2566371F, 0.0F);
/*  96 */     this.body19 = new ModelRenderer(this, 0, 21);
/*  97 */     this.body19.func_78793_a(0.0F, 2.9F, 0.0F);
/*  98 */     this.body19.func_78790_a(-0.5F, -3.0F, 3.4F, 1, 6, 1, 0.0F);
/*  99 */     this.body16 = new ModelRenderer(this, 8, 0);
/* 100 */     this.body16.func_78793_a(0.0F, 9.6F, 0.0F);
/* 101 */     this.body16.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/* 102 */     setRotateAngle(this.body16, 0.0F, -1.8849556F, 0.0F);
/* 103 */     this.body5 = new ModelRenderer(this, 0, 0);
/* 104 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 105 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/* 106 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/* 107 */     this.body4 = new ModelRenderer(this, 0, 0);
/* 108 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 109 */     this.body4.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/* 110 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/* 111 */     this.body1 = new ModelRenderer(this, 0, 0);
/* 112 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 113 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/* 114 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 115 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 116 */     this.body6.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 20, 1, 0.0F);
/* 117 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/* 118 */     this.body9 = new ModelRenderer(this, 8, 0);
/* 119 */     this.body9.func_78793_a(0.0F, 9.6F, 0.0F);
/* 120 */     this.body9.func_78790_a(-1.0F, -9.5F, 2.95F, 2, 19, 1, 0.0F);
/* 121 */     this.body1.func_78792_a(this.body8);
/* 122 */     this.body1.func_78792_a(this.body13);
/* 123 */     this.body1.func_78792_a(this.body10);
/* 124 */     this.body1.func_78792_a(this.body20);
/* 125 */     this.body1.func_78792_a(this.body12);
/* 126 */     this.body1.func_78792_a(this.body17);
/* 127 */     this.body1.func_78792_a(this.body21);
/* 128 */     this.body1.func_78792_a(this.body22);
/* 129 */     this.body1.func_78792_a(this.body18);
/* 130 */     this.body1.func_78792_a(this.body2);
/* 131 */     this.body1.func_78792_a(this.body7);
/* 132 */     this.body1.func_78792_a(this.body14);
/* 133 */     this.body1.func_78792_a(this.body3);
/* 134 */     this.body1.func_78792_a(this.body15);
/* 135 */     this.body1.func_78792_a(this.body11);
/* 136 */     this.body1.func_78792_a(this.body19);
/* 137 */     this.body1.func_78792_a(this.body16);
/* 138 */     this.body1.func_78792_a(this.body5);
/* 139 */     this.body1.func_78792_a(this.body4);
/* 140 */     this.body1.func_78792_a(this.body6);
/* 141 */     this.body1.func_78792_a(this.body9);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 147 */     this.body1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 152 */     modelRenderer.field_78795_f = x;
/* 153 */     modelRenderer.field_78796_g = y;
/* 154 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyKnighted.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */