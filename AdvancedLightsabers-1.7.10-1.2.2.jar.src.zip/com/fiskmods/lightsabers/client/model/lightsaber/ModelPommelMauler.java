/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelPommelMauler
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer top1;
/*     */   public ModelRenderer outerRing1;
/*     */   public ModelRenderer innerRing1;
/*     */   public ModelRenderer top2;
/*     */   public ModelRenderer top3;
/*     */   public ModelRenderer top4;
/*     */   public ModelRenderer top5;
/*     */   public ModelRenderer top6;
/*     */   public ModelRenderer top7;
/*     */   public ModelRenderer top8;
/*     */   public ModelRenderer outerRing2;
/*     */   public ModelRenderer outerRing3;
/*     */   public ModelRenderer outerRing4;
/*     */   public ModelRenderer outerRing5;
/*     */   public ModelRenderer outerRing6;
/*     */   public ModelRenderer outerRing7;
/*     */   public ModelRenderer outerRing8;
/*     */   public ModelRenderer innerRing2;
/*     */   public ModelRenderer innerRing3;
/*     */   public ModelRenderer innerRing4;
/*     */   public ModelRenderer innerRing5;
/*     */   public ModelRenderer innerRing6;
/*     */   public ModelRenderer innerRing7;
/*     */   public ModelRenderer innerRing8;
/*     */   
/*     */   public ModelPommelMauler() {
/*  38 */     this.field_78090_t = 64;
/*  39 */     this.field_78089_u = 32;
/*  40 */     this.outerRing1 = new ModelRenderer(this, 0, 0);
/*  41 */     this.outerRing1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  42 */     this.outerRing1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  43 */     this.top7 = new ModelRenderer(this, 8, 0);
/*  44 */     this.top7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  45 */     this.top7.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  46 */     setRotateAngle(this.top7, 0.0F, -1.5707964F, 0.0F);
/*  47 */     this.outerRing3 = new ModelRenderer(this, 0, 0);
/*  48 */     this.outerRing3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.outerRing3.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  50 */     setRotateAngle(this.outerRing3, 0.0F, 1.5707964F, 0.0F);
/*  51 */     this.outerRing6 = new ModelRenderer(this, 0, 0);
/*  52 */     this.outerRing6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  53 */     this.outerRing6.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  54 */     setRotateAngle(this.outerRing6, 0.0F, -2.3561945F, 0.0F);
/*  55 */     this.innerRing8 = new ModelRenderer(this, 0, 2);
/*  56 */     this.innerRing8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.innerRing8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  58 */     setRotateAngle(this.innerRing8, 0.0F, -0.7853982F, 0.0F);
/*  59 */     this.innerRing3 = new ModelRenderer(this, 0, 2);
/*  60 */     this.innerRing3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  61 */     this.innerRing3.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  62 */     setRotateAngle(this.innerRing3, 0.0F, 1.5707964F, 0.0F);
/*  63 */     this.outerRing8 = new ModelRenderer(this, 0, 0);
/*  64 */     this.outerRing8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.outerRing8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  66 */     setRotateAngle(this.outerRing8, 0.0F, -0.7853982F, 0.0F);
/*  67 */     this.top1 = new ModelRenderer(this, 8, 0);
/*  68 */     this.top1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.top1.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  70 */     this.top3 = new ModelRenderer(this, 8, 0);
/*  71 */     this.top3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  72 */     this.top3.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  73 */     setRotateAngle(this.top3, 0.0F, 1.5707964F, 0.0F);
/*  74 */     this.outerRing2 = new ModelRenderer(this, 0, 0);
/*  75 */     this.outerRing2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  76 */     this.outerRing2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  77 */     setRotateAngle(this.outerRing2, 0.0F, 0.7853982F, 0.0F);
/*  78 */     this.top8 = new ModelRenderer(this, 8, 0);
/*  79 */     this.top8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  80 */     this.top8.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  81 */     setRotateAngle(this.top8, 0.0F, -0.7853982F, 0.0F);
/*  82 */     this.outerRing7 = new ModelRenderer(this, 0, 0);
/*  83 */     this.outerRing7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  84 */     this.outerRing7.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  85 */     setRotateAngle(this.outerRing7, 0.0F, -1.5707964F, 0.0F);
/*  86 */     this.innerRing5 = new ModelRenderer(this, 0, 2);
/*  87 */     this.innerRing5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  88 */     this.innerRing5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  89 */     setRotateAngle(this.innerRing5, 0.0F, 3.1415927F, 0.0F);
/*  90 */     this.innerRing2 = new ModelRenderer(this, 0, 2);
/*  91 */     this.innerRing2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.innerRing2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/*  93 */     setRotateAngle(this.innerRing2, 0.0F, 0.7853982F, 0.0F);
/*  94 */     this.top4 = new ModelRenderer(this, 8, 0);
/*  95 */     this.top4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  96 */     this.top4.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/*  97 */     setRotateAngle(this.top4, 0.0F, 2.3561945F, 0.0F);
/*  98 */     this.top2 = new ModelRenderer(this, 8, 0);
/*  99 */     this.top2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 100 */     this.top2.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 101 */     setRotateAngle(this.top2, 0.0F, 0.7853982F, 0.0F);
/* 102 */     this.top6 = new ModelRenderer(this, 8, 0);
/* 103 */     this.top6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 104 */     this.top6.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 105 */     setRotateAngle(this.top6, 0.0F, -2.3561945F, 0.0F);
/* 106 */     this.innerRing6 = new ModelRenderer(this, 0, 2);
/* 107 */     this.innerRing6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 108 */     this.innerRing6.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 109 */     setRotateAngle(this.innerRing6, 0.0F, -2.3561945F, 0.0F);
/* 110 */     this.innerRing4 = new ModelRenderer(this, 0, 2);
/* 111 */     this.innerRing4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 112 */     this.innerRing4.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 113 */     setRotateAngle(this.innerRing4, 0.0F, 2.3561945F, 0.0F);
/* 114 */     this.outerRing4 = new ModelRenderer(this, 0, 0);
/* 115 */     this.outerRing4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 116 */     this.outerRing4.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 117 */     setRotateAngle(this.outerRing4, 0.0F, 2.3561945F, 0.0F);
/* 118 */     this.innerRing1 = new ModelRenderer(this, 0, 2);
/* 119 */     this.innerRing1.func_78793_a(0.0F, -1.0F, 0.0F);
/* 120 */     this.innerRing1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 121 */     this.innerRing7 = new ModelRenderer(this, 0, 2);
/* 122 */     this.innerRing7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 123 */     this.innerRing7.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 124 */     setRotateAngle(this.innerRing7, 0.0F, -1.5707964F, 0.0F);
/* 125 */     this.outerRing5 = new ModelRenderer(this, 0, 0);
/* 126 */     this.outerRing5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 127 */     this.outerRing5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 1, 1, 0.0F);
/* 128 */     setRotateAngle(this.outerRing5, 0.0F, 3.1415927F, 0.0F);
/* 129 */     this.top5 = new ModelRenderer(this, 8, 0);
/* 130 */     this.top5.func_78793_a(0.0F, 0.0F, 0.0F);
/* 131 */     this.top5.func_78790_a(-1.5F, -1.0F, 2.62F, 3, 1, 1, 0.0F);
/* 132 */     setRotateAngle(this.top5, 0.0F, 3.1415927F, 0.0F);
/* 133 */     this.top1.func_78792_a(this.top7);
/* 134 */     this.outerRing1.func_78792_a(this.outerRing3);
/* 135 */     this.outerRing1.func_78792_a(this.outerRing6);
/* 136 */     this.innerRing1.func_78792_a(this.innerRing8);
/* 137 */     this.innerRing1.func_78792_a(this.innerRing3);
/* 138 */     this.outerRing1.func_78792_a(this.outerRing8);
/* 139 */     this.top1.func_78792_a(this.top3);
/* 140 */     this.outerRing1.func_78792_a(this.outerRing2);
/* 141 */     this.top1.func_78792_a(this.top8);
/* 142 */     this.outerRing1.func_78792_a(this.outerRing7);
/* 143 */     this.innerRing1.func_78792_a(this.innerRing5);
/* 144 */     this.innerRing1.func_78792_a(this.innerRing2);
/* 145 */     this.top1.func_78792_a(this.top4);
/* 146 */     this.top1.func_78792_a(this.top2);
/* 147 */     this.top1.func_78792_a(this.top6);
/* 148 */     this.innerRing1.func_78792_a(this.innerRing6);
/* 149 */     this.innerRing1.func_78792_a(this.innerRing4);
/* 150 */     this.outerRing1.func_78792_a(this.outerRing4);
/* 151 */     this.innerRing1.func_78792_a(this.innerRing7);
/* 152 */     this.outerRing1.func_78792_a(this.outerRing5);
/* 153 */     this.top1.func_78792_a(this.top5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 159 */     GL11.glPushMatrix();
/* 160 */     GL11.glTranslatef(this.outerRing1.field_82906_o, this.outerRing1.field_82908_p, this.outerRing1.field_82907_q);
/* 161 */     GL11.glTranslatef(this.outerRing1.field_78800_c * f5, this.outerRing1.field_78797_d * f5, this.outerRing1.field_78798_e * f5);
/* 162 */     GL11.glScaled(1.0D, 0.25D, 1.0D);
/* 163 */     GL11.glTranslatef(-this.outerRing1.field_82906_o, -this.outerRing1.field_82908_p, -this.outerRing1.field_82907_q);
/* 164 */     GL11.glTranslatef(-this.outerRing1.field_78800_c * f5, -this.outerRing1.field_78797_d * f5, -this.outerRing1.field_78798_e * f5);
/* 165 */     this.outerRing1.func_78785_a(f5);
/* 166 */     GL11.glPopMatrix();
/* 167 */     GL11.glPushMatrix();
/* 168 */     GL11.glTranslatef(this.top1.field_82906_o, this.top1.field_82908_p, this.top1.field_82907_q);
/* 169 */     GL11.glTranslatef(this.top1.field_78800_c * f5, this.top1.field_78797_d * f5, this.top1.field_78798_e * f5);
/* 170 */     GL11.glScaled(0.8D, 1.0D, 0.8D);
/* 171 */     GL11.glTranslatef(-this.top1.field_82906_o, -this.top1.field_82908_p, -this.top1.field_82907_q);
/* 172 */     GL11.glTranslatef(-this.top1.field_78800_c * f5, -this.top1.field_78797_d * f5, -this.top1.field_78798_e * f5);
/* 173 */     this.top1.func_78785_a(f5);
/* 174 */     GL11.glPopMatrix();
/* 175 */     GL11.glPushMatrix();
/* 176 */     GL11.glTranslatef(this.innerRing1.field_82906_o, this.innerRing1.field_82908_p, this.innerRing1.field_82907_q);
/* 177 */     GL11.glTranslatef(this.innerRing1.field_78800_c * f5, this.innerRing1.field_78797_d * f5, this.innerRing1.field_78798_e * f5);
/* 178 */     GL11.glScaled(0.65D, 1.3D, 0.65D);
/* 179 */     GL11.glTranslatef(-this.innerRing1.field_82906_o, -this.innerRing1.field_82908_p, -this.innerRing1.field_82907_q);
/* 180 */     GL11.glTranslatef(-this.innerRing1.field_78800_c * f5, -this.innerRing1.field_78797_d * f5, -this.innerRing1.field_78798_e * f5);
/* 181 */     this.innerRing1.func_78785_a(f5);
/* 182 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 187 */     modelRenderer.field_78795_f = x;
/* 188 */     modelRenderer.field_78796_g = y;
/* 189 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelPommelMauler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */