/*    */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class ModelBodyMandalorian
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer body1;
/*    */   public ModelRenderer body2;
/*    */   public ModelRenderer body4;
/*    */   public ModelRenderer body6;
/*    */   public ModelRenderer body7;
/*    */   public ModelRenderer body8;
/*    */   public ModelRenderer body3;
/*    */   public ModelRenderer body5;
/*    */   public ModelRenderer body9;
/*    */   public ModelRenderer body11;
/*    */   public ModelRenderer body10;
/*    */   public ModelRenderer body12;
/*    */   
/*    */   public ModelBodyMandalorian() {
/* 24 */     this.field_78090_t = 64;
/* 25 */     this.field_78089_u = 32;
/* 26 */     this.body7 = new ModelRenderer(this, 0, 0);
/* 27 */     this.body7.field_78809_i = true;
/* 28 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 29 */     this.body7.func_78790_a(1.98F, 0.0F, -2.5F, 1, 26, 5, 0.0F);
/* 30 */     this.body10 = new ModelRenderer(this, 20, 0);
/* 31 */     this.body10.func_78793_a(-1.0F, 0.0F, 0.0F);
/* 32 */     this.body10.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 33 */     setRotateAngle(this.body10, 0.0F, -0.47211155F, 0.0F);
/* 34 */     this.body3 = new ModelRenderer(this, 20, 0);
/* 35 */     this.body3.func_78793_a(-1.0F, 0.0F, 0.0F);
/* 36 */     this.body3.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 37 */     setRotateAngle(this.body3, 0.0F, -0.47211155F, 0.0F);
/* 38 */     this.body5 = new ModelRenderer(this, 20, 0);
/* 39 */     this.body5.field_78809_i = true;
/* 40 */     this.body5.func_78793_a(1.0F, 0.0F, 0.0F);
/* 41 */     this.body5.func_78790_a(0.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 42 */     setRotateAngle(this.body5, 0.0F, 0.47211155F, 0.0F);
/* 43 */     this.body11 = new ModelRenderer(this, 20, 0);
/* 44 */     this.body11.field_78809_i = true;
/* 45 */     this.body11.func_78793_a(1.5F, 0.0F, 3.76F);
/* 46 */     this.body11.func_78790_a(0.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 47 */     setRotateAngle(this.body11, 0.0F, 0.46949357F, 0.0F);
/* 48 */     this.body4 = new ModelRenderer(this, 20, 0);
/* 49 */     this.body4.field_78809_i = true;
/* 50 */     this.body4.func_78793_a(1.5F, 0.0F, 3.76F);
/* 51 */     this.body4.func_78790_a(0.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 52 */     setRotateAngle(this.body4, 0.0F, 0.46949357F, 0.0F);
/* 53 */     this.body2 = new ModelRenderer(this, 20, 0);
/* 54 */     this.body2.func_78793_a(-1.5F, 0.0F, 3.76F);
/* 55 */     this.body2.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 56 */     setRotateAngle(this.body2, 0.0F, -0.46949357F, 0.0F);
/* 57 */     this.body8 = new ModelRenderer(this, 12, 0);
/* 58 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 59 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.76F, 3, 26, 1, 0.0F);
/* 60 */     setRotateAngle(this.body8, 0.0F, 3.1415927F, 0.0F);
/* 61 */     this.body1 = new ModelRenderer(this, 12, 0);
/* 62 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 63 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.76F, 3, 26, 1, 0.0F);
/* 64 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 65 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 66 */     this.body6.func_78790_a(-2.98F, 0.0F, -2.5F, 1, 26, 5, 0.0F);
/* 67 */     this.body9 = new ModelRenderer(this, 20, 0);
/* 68 */     this.body9.func_78793_a(-1.5F, 0.0F, 3.76F);
/* 69 */     this.body9.func_78790_a(-1.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 70 */     setRotateAngle(this.body9, 0.0F, -0.46949357F, 0.0F);
/* 71 */     this.body12 = new ModelRenderer(this, 20, 0);
/* 72 */     this.body12.field_78809_i = true;
/* 73 */     this.body12.func_78793_a(1.0F, 0.0F, 0.0F);
/* 74 */     this.body12.func_78790_a(0.0F, 0.0F, -1.0F, 1, 26, 1, 0.0F);
/* 75 */     setRotateAngle(this.body12, 0.0F, 0.47211155F, 0.0F);
/* 76 */     this.body1.func_78792_a(this.body7);
/* 77 */     this.body9.func_78792_a(this.body10);
/* 78 */     this.body2.func_78792_a(this.body3);
/* 79 */     this.body4.func_78792_a(this.body5);
/* 80 */     this.body8.func_78792_a(this.body11);
/* 81 */     this.body1.func_78792_a(this.body4);
/* 82 */     this.body1.func_78792_a(this.body2);
/* 83 */     this.body1.func_78792_a(this.body8);
/* 84 */     this.body1.func_78792_a(this.body6);
/* 85 */     this.body8.func_78792_a(this.body9);
/* 86 */     this.body11.func_78792_a(this.body12);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 92 */     this.body1.func_78785_a(f5);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 97 */     modelRenderer.field_78795_f = x;
/* 98 */     modelRenderer.field_78796_g = y;
/* 99 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyMandalorian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */