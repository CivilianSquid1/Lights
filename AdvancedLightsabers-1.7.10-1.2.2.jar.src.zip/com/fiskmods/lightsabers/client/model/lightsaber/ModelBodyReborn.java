/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class ModelBodyReborn
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer sideBlade1point3;
/*     */   public ModelRenderer sideBlade1point2;
/*     */   public ModelRenderer sideBlade1point1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer sideBlade2;
/*     */   public ModelRenderer sideBlade3;
/*     */   public ModelRenderer sideBlade4;
/*     */   public ModelRenderer sideBlade5;
/*     */   public ModelRenderer sideBlade2_1;
/*     */   public ModelRenderer sideBlade3_1;
/*     */   public ModelRenderer sideBlade4_1;
/*     */   public ModelRenderer sideBlade5_1;
/*     */   public ModelRenderer sideBlade2_2;
/*     */   public ModelRenderer sideBlade3_2;
/*     */   public ModelRenderer sideBlade4_2;
/*     */   public ModelRenderer sideBlade5_2;
/*     */   
/*     */   public ModelBodyReborn() {
/*  35 */     this.field_78090_t = 32;
/*  36 */     this.field_78089_u = 32;
/*  37 */     this.sideBlade1point1 = new ModelRenderer(this, 0, 11);
/*  38 */     this.sideBlade1point1.func_78793_a(-2.8F, 0.0F, -2.2F);
/*  39 */     this.sideBlade1point1.func_78790_a(0.0F, 0.0F, 0.0F, 1, 17, 1, 0.0F);
/*  40 */     setRotateAngle(this.sideBlade1point1, 0.0F, 2.3561945F, 0.0F);
/*  41 */     this.sideBlade5 = new ModelRenderer(this, 0, 11);
/*  42 */     this.sideBlade5.func_78793_a(-1.34F, 17.1F, 0.0F);
/*  43 */     this.sideBlade5.func_78790_a(0.0F, 0.3F, 0.0F, 3, 1, 1, 0.0F);
/*  44 */     setRotateAngle(this.sideBlade5, 0.0F, 0.0F, -0.61086524F);
/*  45 */     this.sideBlade3_2 = new ModelRenderer(this, 0, 11);
/*  46 */     this.sideBlade3_2.func_78793_a(0.96F, 0.5F, 0.0F);
/*  47 */     this.sideBlade3_2.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/*  48 */     setRotateAngle(this.sideBlade3_2, 0.0F, 0.0F, 0.17453292F);
/*  49 */     this.body17 = new ModelRenderer(this, -7, 11);
/*  50 */     this.body17.func_78793_a(0.0F, 0.0F, 0.0F);
/*  51 */     this.body17.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/*  52 */     setRotateAngle(this.body17, 0.0F, -1.5707964F, 0.0F);
/*  53 */     this.sideBlade1point3 = new ModelRenderer(this, 0, 11);
/*  54 */     this.sideBlade1point3.func_78793_a(0.5F, 0.0F, 3.6F);
/*  55 */     this.sideBlade1point3.func_78790_a(0.0F, 0.0F, 0.0F, 1, 17, 1, 0.0F);
/*  56 */     setRotateAngle(this.sideBlade1point3, 0.0F, -1.5707964F, 0.0F);
/*  57 */     this.sideBlade2 = new ModelRenderer(this, 0, 11);
/*  58 */     this.sideBlade2.func_78793_a(0.9F, -5.0F, 0.0F);
/*  59 */     this.sideBlade2.func_78790_a(0.0F, 5.0F, 0.0F, 1, 1, 1, 0.0F);
/*  60 */     this.sideBlade2_2 = new ModelRenderer(this, 0, 11);
/*  61 */     this.sideBlade2_2.func_78793_a(0.9F, -5.0F, 0.0F);
/*  62 */     this.sideBlade2_2.func_78790_a(0.0F, 5.0F, 0.0F, 1, 1, 1, 0.0F);
/*  63 */     this.sideBlade3_1 = new ModelRenderer(this, 0, 11);
/*  64 */     this.sideBlade3_1.func_78793_a(0.96F, 0.5F, 0.0F);
/*  65 */     this.sideBlade3_1.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/*  66 */     setRotateAngle(this.sideBlade3_1, 0.0F, 0.0F, 0.17453292F);
/*  67 */     this.body20 = new ModelRenderer(this, 23, 11);
/*  68 */     this.body20.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body20.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/*  70 */     setRotateAngle(this.body20, 0.0F, -0.7853982F, 0.0F);
/*  71 */     this.sideBlade4 = new ModelRenderer(this, 0, 11);
/*  72 */     this.sideBlade4.func_78793_a(-0.04F, 11.4F, 0.0F);
/*  73 */     this.sideBlade4.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/*  74 */     setRotateAngle(this.sideBlade4, 0.0F, 0.0F, -0.17453292F);
/*  75 */     this.sideBlade2_1 = new ModelRenderer(this, 0, 11);
/*  76 */     this.sideBlade2_1.func_78793_a(0.9F, -5.0F, 0.0F);
/*  77 */     this.sideBlade2_1.func_78790_a(0.0F, 5.0F, 0.0F, 1, 1, 1, 0.0F);
/*  78 */     this.sideBlade4_2 = new ModelRenderer(this, 0, 11);
/*  79 */     this.sideBlade4_2.func_78793_a(-0.04F, 11.4F, 0.0F);
/*  80 */     this.sideBlade4_2.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/*  81 */     setRotateAngle(this.sideBlade4_2, 0.0F, 0.0F, -0.17453292F);
/*  82 */     this.body2 = new ModelRenderer(this, 25, 11);
/*  83 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  84 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/*  85 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  86 */     this.sideBlade3 = new ModelRenderer(this, 0, 11);
/*  87 */     this.sideBlade3.func_78793_a(0.96F, 0.5F, 0.0F);
/*  88 */     this.sideBlade3.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/*  89 */     setRotateAngle(this.sideBlade3, 0.0F, 0.0F, 0.17453292F);
/*  90 */     this.body5 = new ModelRenderer(this, -9, 11);
/*  91 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/*  93 */     setRotateAngle(this.body5, 0.0F, 1.5707964F, 0.0F);
/*  94 */     this.body1 = new ModelRenderer(this, -2, 11);
/*  95 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  96 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/*  97 */     this.body8 = new ModelRenderer(this, -2, 11);
/*  98 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  99 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/* 100 */     setRotateAngle(this.body8, 0.0F, 2.3561945F, 0.0F);
/* 101 */     this.sideBlade1point2 = new ModelRenderer(this, 0, 11);
/* 102 */     this.sideBlade1point2.func_78793_a(2.2F, 0.0F, -2.8F);
/* 103 */     this.sideBlade1point2.func_78790_a(0.0F, 0.0F, 0.0F, 1, 17, 1, 0.0F);
/* 104 */     setRotateAngle(this.sideBlade1point2, 0.0F, 0.7853982F, 0.0F);
/* 105 */     this.sideBlade5_2 = new ModelRenderer(this, 0, 11);
/* 106 */     this.sideBlade5_2.func_78793_a(-1.34F, 17.1F, 0.0F);
/* 107 */     this.sideBlade5_2.func_78790_a(0.0F, 0.3F, 0.0F, 3, 1, 1, 0.0F);
/* 108 */     setRotateAngle(this.sideBlade5_2, 0.0F, 0.0F, -0.61086524F);
/* 109 */     this.sideBlade5_1 = new ModelRenderer(this, 0, 11);
/* 110 */     this.sideBlade5_1.func_78793_a(-1.34F, 17.1F, 0.0F);
/* 111 */     this.sideBlade5_1.func_78790_a(0.0F, 0.3F, 0.0F, 3, 1, 1, 0.0F);
/* 112 */     setRotateAngle(this.sideBlade5_1, 0.0F, 0.0F, -0.61086524F);
/* 113 */     this.body14 = new ModelRenderer(this, -2, 11);
/* 114 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/* 115 */     this.body14.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/* 116 */     setRotateAngle(this.body14, 0.0F, -2.3561945F, 0.0F);
/* 117 */     this.sideBlade4_1 = new ModelRenderer(this, 0, 11);
/* 118 */     this.sideBlade4_1.func_78793_a(-0.04F, 11.4F, 0.0F);
/* 119 */     this.sideBlade4_1.func_78790_a(0.0F, 0.3F, 0.0F, 1, 5, 1, 0.0F);
/* 120 */     setRotateAngle(this.sideBlade4_1, 0.0F, 0.0F, -0.17453292F);
/* 121 */     this.body11 = new ModelRenderer(this, 24, 11);
/* 122 */     this.body11.func_78793_a(0.0F, 0.0F, 0.0F);
/* 123 */     this.body11.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 19, 1, 0.0F);
/* 124 */     setRotateAngle(this.body11, 0.0F, 3.1415927F, 0.0F);
/* 125 */     this.sideBlade1point3.func_78792_a(this.sideBlade5);
/* 126 */     this.sideBlade1point1.func_78792_a(this.sideBlade3_2);
/* 127 */     this.body1.func_78792_a(this.body17);
/* 128 */     this.sideBlade1point3.func_78792_a(this.sideBlade2);
/* 129 */     this.sideBlade1point1.func_78792_a(this.sideBlade2_2);
/* 130 */     this.sideBlade1point2.func_78792_a(this.sideBlade3_1);
/* 131 */     this.body1.func_78792_a(this.body20);
/* 132 */     this.sideBlade1point3.func_78792_a(this.sideBlade4);
/* 133 */     this.sideBlade1point2.func_78792_a(this.sideBlade2_1);
/* 134 */     this.sideBlade1point1.func_78792_a(this.sideBlade4_2);
/* 135 */     this.body1.func_78792_a(this.body2);
/* 136 */     this.sideBlade1point3.func_78792_a(this.sideBlade3);
/* 137 */     this.body1.func_78792_a(this.body5);
/* 138 */     this.body1.func_78792_a(this.body8);
/* 139 */     this.sideBlade1point1.func_78792_a(this.sideBlade5_2);
/* 140 */     this.sideBlade1point2.func_78792_a(this.sideBlade5_1);
/* 141 */     this.body1.func_78792_a(this.body14);
/* 142 */     this.sideBlade1point2.func_78792_a(this.sideBlade4_1);
/* 143 */     this.body1.func_78792_a(this.body11);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 149 */     this.sideBlade1point1.func_78785_a(f5);
/* 150 */     this.sideBlade1point3.func_78785_a(f5);
/* 151 */     this.body1.func_78785_a(f5);
/* 152 */     this.sideBlade1point2.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 157 */     modelRenderer.field_78795_f = x;
/* 158 */     modelRenderer.field_78796_g = y;
/* 159 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyReborn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */