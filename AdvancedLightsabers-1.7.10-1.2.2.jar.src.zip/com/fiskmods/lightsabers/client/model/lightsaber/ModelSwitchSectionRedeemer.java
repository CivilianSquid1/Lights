/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelSwitchSectionRedeemer
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer upperSideButton1;
/*     */   public ModelRenderer lowerSideButton1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer upperSideButton2;
/*     */   public ModelRenderer upperSideButton3;
/*     */   public ModelRenderer upperSideButton4;
/*     */   public ModelRenderer upperSideButton5;
/*     */   public ModelRenderer upperSideButton6;
/*     */   public ModelRenderer upperSideButton7;
/*     */   public ModelRenderer upperSideButton8;
/*     */   public ModelRenderer lowerSideButton2;
/*     */   public ModelRenderer lowerSideButton3;
/*     */   public ModelRenderer lowerSideButton4;
/*     */   public ModelRenderer lowerSideButton5;
/*     */   public ModelRenderer lowerSideButton6;
/*     */   public ModelRenderer lowerSideButton7;
/*     */   public ModelRenderer lowerSideButton8;
/*     */   public ModelRenderer lowerSideButton9;
/*     */   public ModelRenderer lowerSideButton10;
/*     */   public ModelRenderer lowerSideButton11;
/*     */   public ModelRenderer lowerSideButton12;
/*     */   public ModelRenderer lowerSideButton13;
/*     */   public ModelRenderer lowerSideButton14;
/*     */   
/*     */   public ModelSwitchSectionRedeemer() {
/*  45 */     this.field_78090_t = 64;
/*  46 */     this.field_78089_u = 32;
/*  47 */     this.lowerSideButton5 = new ModelRenderer(this, 10, 9);
/*  48 */     this.lowerSideButton5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.lowerSideButton5.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  50 */     setRotateAngle(this.lowerSideButton5, 0.0F, 3.1415927F, 0.0F);
/*  51 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  52 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  53 */     this.body3.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  54 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  55 */     this.lowerSideButton2 = new ModelRenderer(this, 10, 9);
/*  56 */     this.lowerSideButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.lowerSideButton2.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  58 */     setRotateAngle(this.lowerSideButton2, 0.0F, 0.7853982F, 0.0F);
/*  59 */     this.lowerSideButton13 = new ModelRenderer(this, 22, 0);
/*  60 */     this.lowerSideButton13.func_78793_a(0.0F, -2.0F, 0.0F);
/*  61 */     this.lowerSideButton13.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/*  62 */     setRotateAngle(this.lowerSideButton13, 0.0F, -1.0471976F, 0.0F);
/*  63 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  64 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body1.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  66 */     setRotateAngle(this.body1, 0.0F, -1.5707964F, 0.0F);
/*  67 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  68 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body5.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/*  70 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  71 */     this.lowerSideButton7 = new ModelRenderer(this, 10, 9);
/*  72 */     this.lowerSideButton7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.lowerSideButton7.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  74 */     setRotateAngle(this.lowerSideButton7, 0.0F, -1.5707964F, 0.0F);
/*  75 */     this.lowerSideButton12 = new ModelRenderer(this, 22, 0);
/*  76 */     this.lowerSideButton12.func_78793_a(0.0F, -2.0F, 0.0F);
/*  77 */     this.lowerSideButton12.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/*  78 */     setRotateAngle(this.lowerSideButton12, 0.0F, 2.0943952F, 0.0F);
/*  79 */     this.lowerSideButton11 = new ModelRenderer(this, 22, 0);
/*  80 */     this.lowerSideButton11.func_78793_a(0.0F, -2.0F, 0.0F);
/*  81 */     this.lowerSideButton11.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/*  82 */     setRotateAngle(this.lowerSideButton11, 0.0F, 1.0471976F, 0.0F);
/*  83 */     this.upperSideButton3 = new ModelRenderer(this, 8, 0);
/*  84 */     this.upperSideButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  85 */     this.upperSideButton3.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/*  86 */     setRotateAngle(this.upperSideButton3, 0.0F, 1.5707964F, 0.0F);
/*  87 */     this.upperSideButton2 = new ModelRenderer(this, 8, 0);
/*  88 */     this.upperSideButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.upperSideButton2.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/*  90 */     setRotateAngle(this.upperSideButton2, 0.0F, 0.7853982F, 0.0F);
/*  91 */     this.upperSideButton5 = new ModelRenderer(this, 8, 0);
/*  92 */     this.upperSideButton5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  93 */     this.upperSideButton5.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/*  94 */     setRotateAngle(this.upperSideButton5, 0.0F, 3.1415927F, 0.0F);
/*  95 */     this.lowerSideButton10 = new ModelRenderer(this, 22, 0);
/*  96 */     this.lowerSideButton10.func_78793_a(0.0F, -2.0F, 0.0F);
/*  97 */     this.lowerSideButton10.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/*  98 */     setRotateAngle(this.lowerSideButton10, 0.0F, 3.1415927F, 0.0F);
/*  99 */     this.lowerSideButton9 = new ModelRenderer(this, 22, 0);
/* 100 */     this.lowerSideButton9.func_78793_a(0.0F, -2.0F, 0.0F);
/* 101 */     this.lowerSideButton9.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/* 102 */     this.body8 = new ModelRenderer(this, 0, 9);
/* 103 */     this.body8.func_78793_a(0.0F, -4.0F, 3.62F);
/* 104 */     this.body8.func_78790_a(-1.5F, -4.0F, 0.0F, 3, 8, 2, 0.0F);
/* 105 */     this.lowerSideButton8 = new ModelRenderer(this, 10, 9);
/* 106 */     this.lowerSideButton8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 107 */     this.lowerSideButton8.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 108 */     setRotateAngle(this.lowerSideButton8, 0.0F, -0.7853982F, 0.0F);
/* 109 */     this.body7 = new ModelRenderer(this, 0, 0);
/* 110 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 111 */     this.body7.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 112 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/* 113 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 114 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 115 */     this.body6.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 116 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/* 117 */     this.lowerSideButton1 = new ModelRenderer(this, 10, 9);
/* 118 */     this.lowerSideButton1.func_78793_a(-3.62F, -2.1F, 0.0F);
/* 119 */     this.lowerSideButton1.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 120 */     setRotateAngle(this.lowerSideButton1, 1.5707964F, 1.5707964F, 0.0F);
/* 121 */     this.body2 = new ModelRenderer(this, 0, 0);
/* 122 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 123 */     this.body2.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 124 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/* 125 */     this.upperSideButton1 = new ModelRenderer(this, 8, 0);
/* 126 */     this.upperSideButton1.func_78793_a(-3.62F, -6.1F, 0.0F);
/* 127 */     this.upperSideButton1.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/* 128 */     setRotateAngle(this.upperSideButton1, 1.5707964F, 1.5707964F, 0.0F);
/* 129 */     this.body4 = new ModelRenderer(this, 0, 0);
/* 130 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 131 */     this.body4.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 132 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/* 133 */     this.body9 = new ModelRenderer(this, 0, 0);
/* 134 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/* 135 */     this.body9.func_78790_a(-1.5F, -8.0F, 2.62F, 3, 8, 1, 0.0F);
/* 136 */     setRotateAngle(this.body9, 0.0F, -0.7853982F, 0.0F);
/* 137 */     this.upperSideButton6 = new ModelRenderer(this, 8, 0);
/* 138 */     this.upperSideButton6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 139 */     this.upperSideButton6.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/* 140 */     setRotateAngle(this.upperSideButton6, 0.0F, -2.3561945F, 0.0F);
/* 141 */     this.upperSideButton7 = new ModelRenderer(this, 8, 0);
/* 142 */     this.upperSideButton7.func_78793_a(0.0F, 0.0F, 0.0F);
/* 143 */     this.upperSideButton7.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/* 144 */     setRotateAngle(this.upperSideButton7, 0.0F, -1.5707964F, 0.0F);
/* 145 */     this.lowerSideButton3 = new ModelRenderer(this, 10, 9);
/* 146 */     this.lowerSideButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 147 */     this.lowerSideButton3.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 148 */     setRotateAngle(this.lowerSideButton3, 0.0F, 1.5707964F, 0.0F);
/* 149 */     this.upperSideButton8 = new ModelRenderer(this, 8, 0);
/* 150 */     this.upperSideButton8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 151 */     this.upperSideButton8.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/* 152 */     setRotateAngle(this.upperSideButton8, 0.0F, -0.7853982F, 0.0F);
/* 153 */     this.upperSideButton4 = new ModelRenderer(this, 8, 0);
/* 154 */     this.upperSideButton4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 155 */     this.upperSideButton4.func_78790_a(-1.5F, -5.0F, -0.38F, 3, 5, 4, 0.0F);
/* 156 */     setRotateAngle(this.upperSideButton4, 0.0F, 2.3561945F, 0.0F);
/* 157 */     this.lowerSideButton4 = new ModelRenderer(this, 10, 9);
/* 158 */     this.lowerSideButton4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 159 */     this.lowerSideButton4.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 160 */     setRotateAngle(this.lowerSideButton4, 0.0F, 2.3561945F, 0.0F);
/* 161 */     this.lowerSideButton6 = new ModelRenderer(this, 10, 9);
/* 162 */     this.lowerSideButton6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 163 */     this.lowerSideButton6.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 164 */     setRotateAngle(this.lowerSideButton6, 0.0F, -2.3561945F, 0.0F);
/* 165 */     this.lowerSideButton14 = new ModelRenderer(this, 22, 0);
/* 166 */     this.lowerSideButton14.func_78793_a(0.0F, -2.0F, 0.0F);
/* 167 */     this.lowerSideButton14.func_78790_a(-1.5F, -1.5F, 2.7F, 3, 3, 2, 0.0F);
/* 168 */     setRotateAngle(this.lowerSideButton14, 0.0F, -2.0943952F, 0.0F);
/* 169 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton5);
/* 170 */     this.body1.func_78792_a(this.body3);
/* 171 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton2);
/* 172 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton13);
/* 173 */     this.body1.func_78792_a(this.body5);
/* 174 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton7);
/* 175 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton12);
/* 176 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton11);
/* 177 */     this.upperSideButton1.func_78792_a(this.upperSideButton3);
/* 178 */     this.upperSideButton1.func_78792_a(this.upperSideButton2);
/* 179 */     this.upperSideButton1.func_78792_a(this.upperSideButton5);
/* 180 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton10);
/* 181 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton9);
/* 182 */     this.body7.func_78792_a(this.body8);
/* 183 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton8);
/* 184 */     this.body1.func_78792_a(this.body7);
/* 185 */     this.body1.func_78792_a(this.body6);
/* 186 */     this.body1.func_78792_a(this.body2);
/* 187 */     this.body1.func_78792_a(this.body4);
/* 188 */     this.body1.func_78792_a(this.body9);
/* 189 */     this.upperSideButton1.func_78792_a(this.upperSideButton6);
/* 190 */     this.upperSideButton1.func_78792_a(this.upperSideButton7);
/* 191 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton3);
/* 192 */     this.upperSideButton1.func_78792_a(this.upperSideButton8);
/* 193 */     this.upperSideButton1.func_78792_a(this.upperSideButton4);
/* 194 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton4);
/* 195 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton6);
/* 196 */     this.lowerSideButton1.func_78792_a(this.lowerSideButton14);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 202 */     this.body1.func_78785_a(f5);
/* 203 */     GL11.glPushMatrix();
/* 204 */     GL11.glTranslatef(this.lowerSideButton1.field_82906_o, this.lowerSideButton1.field_82908_p, this.lowerSideButton1.field_82907_q);
/* 205 */     GL11.glTranslatef(this.lowerSideButton1.field_78800_c * f5, this.lowerSideButton1.field_78797_d * f5, this.lowerSideButton1.field_78798_e * f5);
/* 206 */     GL11.glScaled(0.2D, 0.2D, 0.2D);
/* 207 */     GL11.glTranslatef(-this.lowerSideButton1.field_82906_o, -this.lowerSideButton1.field_82908_p, -this.lowerSideButton1.field_82907_q);
/* 208 */     GL11.glTranslatef(-this.lowerSideButton1.field_78800_c * f5, -this.lowerSideButton1.field_78797_d * f5, -this.lowerSideButton1.field_78798_e * f5);
/* 209 */     this.lowerSideButton1.func_78785_a(f5);
/* 210 */     GL11.glPopMatrix();
/* 211 */     GL11.glPushMatrix();
/* 212 */     GL11.glTranslatef(this.upperSideButton1.field_82906_o, this.upperSideButton1.field_82908_p, this.upperSideButton1.field_82907_q);
/* 213 */     GL11.glTranslatef(this.upperSideButton1.field_78800_c * f5, this.upperSideButton1.field_78797_d * f5, this.upperSideButton1.field_78798_e * f5);
/* 214 */     GL11.glScaled(0.15D, 0.15D, 0.15D);
/* 215 */     GL11.glTranslatef(-this.upperSideButton1.field_82906_o, -this.upperSideButton1.field_82908_p, -this.upperSideButton1.field_82907_q);
/* 216 */     GL11.glTranslatef(-this.upperSideButton1.field_78800_c * f5, -this.upperSideButton1.field_78797_d * f5, -this.upperSideButton1.field_78798_e * f5);
/* 217 */     this.upperSideButton1.func_78785_a(f5);
/* 218 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 223 */     modelRenderer.field_78795_f = x;
/* 224 */     modelRenderer.field_78796_g = y;
/* 225 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionRedeemer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */