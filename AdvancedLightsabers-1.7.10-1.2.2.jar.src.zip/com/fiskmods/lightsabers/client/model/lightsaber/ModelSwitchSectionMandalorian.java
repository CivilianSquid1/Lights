/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelSwitchSectionMandalorian
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer top1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer top2;
/*     */   public ModelRenderer top3;
/*     */   public ModelRenderer top7;
/*     */   public ModelRenderer top4;
/*     */   public ModelRenderer top5;
/*     */   public ModelRenderer top6;
/*     */   public ModelRenderer top8;
/*     */   public ModelRenderer top9;
/*     */   public ModelRenderer top10;
/*     */   
/*     */   public ModelSwitchSectionMandalorian() {
/*  43 */     this.field_78090_t = 64;
/*  44 */     this.field_78089_u = 32;
/*  45 */     this.body10 = new ModelRenderer(this, 14, 6);
/*  46 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  47 */     this.body10.func_78790_a(-1.5F, -2.0F, 2.76F, 3, 2, 1, 0.0F);
/*  48 */     setRotateAngle(this.body10, 0.0F, 3.1415927F, 0.0F);
/*  49 */     this.body3 = new ModelRenderer(this, 0, 19);
/*  50 */     this.body3.func_78793_a(-1.0F, 0.0F, 0.0F);
/*  51 */     this.body3.func_78790_a(-1.0F, -1.0F, -1.0F, 1, 1, 1, 0.0F);
/*  52 */     setRotateAngle(this.body3, 0.0F, -0.47211155F, 0.0F);
/*  53 */     this.body8 = new ModelRenderer(this, 0, 11);
/*  54 */     this.body8.field_78809_i = true;
/*  55 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  56 */     this.body8.func_78790_a(1.98F, -2.0F, -2.5F, 1, 2, 2, 0.0F);
/*  57 */     this.body6 = new ModelRenderer(this, 0, 11);
/*  58 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  59 */     this.body6.func_78790_a(-2.98F, -2.0F, -2.5F, 1, 2, 2, 0.0F);
/*  60 */     this.body17 = new ModelRenderer(this, 0, 6);
/*  61 */     this.body17.func_78793_a(0.0F, -0.5F, -2.5F);
/*  62 */     this.body17.func_78790_a(-2.5F, -0.5F, 5.5F, 5, 1, 4, 0.0F);
/*  63 */     this.top2 = new ModelRenderer(this, 14, 14);
/*  64 */     this.top2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.top2.func_78790_a(-3.0F, -1.0F, 3.0F, 6, 1, 1, 0.0F);
/*  66 */     setRotateAngle(this.top2, 0.0F, 3.1415927F, 0.0F);
/*  67 */     this.body16 = new ModelRenderer(this, 0, 22);
/*  68 */     this.body16.func_78793_a(0.0F, 0.0F, -7.5F);
/*  69 */     this.body16.func_78790_a(-4.5F, -3.0F, 0.0F, 9, 3, 1, 0.0F);
/*  70 */     setRotateAngle(this.body16, 0.2617994F, 0.0F, 0.0F);
/*  71 */     this.body4 = new ModelRenderer(this, 0, 19);
/*  72 */     this.body4.field_78809_i = true;
/*  73 */     this.body4.func_78793_a(1.5F, 0.0F, 3.76F);
/*  74 */     this.body4.func_78790_a(0.0F, -1.0F, -1.0F, 1, 1, 1, 0.0F);
/*  75 */     setRotateAngle(this.body4, 0.0F, 0.46949357F, 0.0F);
/*  76 */     this.body1 = new ModelRenderer(this, 18, 9);
/*  77 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  78 */     this.body1.func_78790_a(-1.5F, -1.0F, 2.76F, 3, 1, 1, 0.0F);
/*  79 */     this.top1 = new ModelRenderer(this, 14, 11);
/*  80 */     this.top1.func_78793_a(0.0F, -1.87F, 0.2F);
/*  81 */     this.top1.func_78790_a(-3.0F, -1.0F, 3.0F, 6, 2, 1, 0.0F);
/*  82 */     this.body15 = new ModelRenderer(this, 0, 0);
/*  83 */     this.body15.func_78793_a(0.0F, -0.9F, 0.0F);
/*  84 */     this.body15.func_78790_a(-4.5F, -1.0F, -7.5F, 9, 1, 5, 0.0F);
/*  85 */     setRotateAngle(this.body15, -0.2617994F, 0.0F, 0.0F);
/*  86 */     this.body18 = new ModelRenderer(this, 0, 11);
/*  87 */     this.body18.func_78793_a(3.5F, -0.5F, -2.5F);
/*  88 */     this.body18.func_78790_a(-1.0F, -0.5F, -0.5F, 2, 1, 10, 0.0F);
/*  89 */     this.top10 = new ModelRenderer(this, 20, 16);
/*  90 */     this.top10.field_78809_i = true;
/*  91 */     this.top10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  92 */     this.top10.func_78790_a(0.0F, 0.0F, -3.0F, 1, 1, 3, 0.0F);
/*  93 */     this.top4 = new ModelRenderer(this, 14, 16);
/*  94 */     this.top4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  95 */     this.top4.func_78790_a(-0.4F, -1.0F, -1.0F, 1, 2, 2, 0.0F);
/*  96 */     setRotateAngle(this.top4, 0.0F, 0.7853982F, 0.0F);
/*  97 */     this.top7 = new ModelRenderer(this, 22, 0);
/*  98 */     this.top7.field_78809_i = true;
/*  99 */     this.top7.func_78793_a(2.0F, 0.0F, 3.0F);
/* 100 */     this.top7.func_78790_a(0.0F, -1.0F, -6.0F, 1, 1, 6, 0.0F);
/* 101 */     this.top9 = new ModelRenderer(this, 25, 16);
/* 102 */     this.top9.field_78809_i = true;
/* 103 */     this.top9.func_78793_a(0.0F, 0.0F, -5.6F);
/* 104 */     this.top9.func_78790_a(-0.6F, -1.0F, -1.0F, 1, 1, 2, 0.0F);
/* 105 */     setRotateAngle(this.top9, 0.0F, 0.7853982F, 0.0F);
/* 106 */     this.body11 = new ModelRenderer(this, 0, 15);
/* 107 */     this.body11.func_78793_a(-1.5F, 0.0F, 3.76F);
/* 108 */     this.body11.func_78790_a(-1.0F, -2.0F, -1.0F, 1, 2, 1, 0.0F);
/* 109 */     setRotateAngle(this.body11, 0.0F, -0.46949357F, 0.0F);
/* 110 */     this.top8 = new ModelRenderer(this, 14, 16);
/* 111 */     this.top8.field_78809_i = true;
/* 112 */     this.top8.func_78793_a(0.0F, 0.0F, 0.0F);
/* 113 */     this.top8.func_78790_a(-0.6F, -1.0F, -1.0F, 1, 2, 2, 0.0F);
/* 114 */     setRotateAngle(this.top8, 0.0F, -0.7853982F, 0.0F);
/* 115 */     this.body19 = new ModelRenderer(this, 0, 11);
/* 116 */     this.body19.func_78793_a(-3.5F, -0.5F, -2.5F);
/* 117 */     this.body19.func_78790_a(-1.0F, -0.5F, -0.5F, 2, 1, 10, 0.0F);
/* 118 */     this.body5 = new ModelRenderer(this, 0, 19);
/* 119 */     this.body5.field_78809_i = true;
/* 120 */     this.body5.func_78793_a(1.0F, 0.0F, 0.0F);
/* 121 */     this.body5.func_78790_a(0.0F, -1.0F, -1.0F, 1, 1, 1, 0.0F);
/* 122 */     setRotateAngle(this.body5, 0.0F, 0.47211155F, 0.0F);
/* 123 */     this.top6 = new ModelRenderer(this, 20, 16);
/* 124 */     this.top6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 125 */     this.top6.func_78790_a(-1.0F, 0.0F, -3.0F, 1, 1, 3, 0.0F);
/* 126 */     this.top5 = new ModelRenderer(this, 25, 16);
/* 127 */     this.top5.func_78793_a(0.0F, 0.0F, -5.6F);
/* 128 */     this.top5.func_78790_a(-0.4F, -1.0F, -1.0F, 1, 1, 2, 0.0F);
/* 129 */     setRotateAngle(this.top5, 0.0F, -0.7853982F, 0.0F);
/* 130 */     this.body9 = new ModelRenderer(this, 1, 15);
/* 131 */     this.body9.field_78809_i = true;
/* 132 */     this.body9.func_78793_a(2.48F, 0.0F, -0.5F);
/* 133 */     this.body9.func_78790_a(-0.5F, -1.0F, 0.0F, 1, 1, 3, 0.0F);
/* 134 */     this.body13 = new ModelRenderer(this, 0, 15);
/* 135 */     this.body13.field_78809_i = true;
/* 136 */     this.body13.func_78793_a(1.5F, 0.0F, 3.76F);
/* 137 */     this.body13.func_78790_a(0.0F, -2.0F, -1.0F, 1, 2, 1, 0.0F);
/* 138 */     setRotateAngle(this.body13, 0.0F, 0.46949357F, 0.0F);
/* 139 */     this.body2 = new ModelRenderer(this, 0, 19);
/* 140 */     this.body2.func_78793_a(-1.5F, 0.0F, 3.76F);
/* 141 */     this.body2.func_78790_a(-1.0F, -1.0F, -1.0F, 1, 1, 1, 0.0F);
/* 142 */     setRotateAngle(this.body2, 0.0F, -0.46949357F, 0.0F);
/* 143 */     this.body12 = new ModelRenderer(this, 0, 15);
/* 144 */     this.body12.func_78793_a(-1.0F, 0.0F, 0.0F);
/* 145 */     this.body12.func_78790_a(-1.0F, -2.0F, -1.0F, 1, 2, 1, 0.0F);
/* 146 */     setRotateAngle(this.body12, 0.0F, -0.47211155F, 0.0F);
/* 147 */     this.body14 = new ModelRenderer(this, 0, 15);
/* 148 */     this.body14.field_78809_i = true;
/* 149 */     this.body14.func_78793_a(1.0F, 0.0F, 0.0F);
/* 150 */     this.body14.func_78790_a(0.0F, -2.0F, -1.0F, 1, 2, 1, 0.0F);
/* 151 */     setRotateAngle(this.body14, 0.0F, 0.47211155F, 0.0F);
/* 152 */     this.top3 = new ModelRenderer(this, 22, 0);
/* 153 */     this.top3.func_78793_a(-2.0F, 0.0F, 3.0F);
/* 154 */     this.top3.func_78790_a(-1.0F, -1.0F, -6.0F, 1, 1, 6, 0.0F);
/* 155 */     this.body7 = new ModelRenderer(this, 1, 15);
/* 156 */     this.body7.func_78793_a(-2.48F, 0.0F, -0.5F);
/* 157 */     this.body7.func_78790_a(-0.5F, -1.0F, 0.0F, 1, 1, 3, 0.0F);
/* 158 */     this.body1.func_78792_a(this.body10);
/* 159 */     this.body2.func_78792_a(this.body3);
/* 160 */     this.body1.func_78792_a(this.body8);
/* 161 */     this.body1.func_78792_a(this.body6);
/* 162 */     this.body15.func_78792_a(this.body17);
/* 163 */     this.top1.func_78792_a(this.top2);
/* 164 */     this.body15.func_78792_a(this.body16);
/* 165 */     this.body1.func_78792_a(this.body4);
/* 166 */     this.body1.func_78792_a(this.body15);
/* 167 */     this.body15.func_78792_a(this.body18);
/* 168 */     this.top7.func_78792_a(this.top10);
/* 169 */     this.top3.func_78792_a(this.top4);
/* 170 */     this.top1.func_78792_a(this.top7);
/* 171 */     this.top7.func_78792_a(this.top9);
/* 172 */     this.body10.func_78792_a(this.body11);
/* 173 */     this.top7.func_78792_a(this.top8);
/* 174 */     this.body15.func_78792_a(this.body19);
/* 175 */     this.body4.func_78792_a(this.body5);
/* 176 */     this.top3.func_78792_a(this.top6);
/* 177 */     this.top3.func_78792_a(this.top5);
/* 178 */     this.body8.func_78792_a(this.body9);
/* 179 */     this.body10.func_78792_a(this.body13);
/* 180 */     this.body1.func_78792_a(this.body2);
/* 181 */     this.body11.func_78792_a(this.body12);
/* 182 */     this.body13.func_78792_a(this.body14);
/* 183 */     this.top1.func_78792_a(this.top3);
/* 184 */     this.body6.func_78792_a(this.body7);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 190 */     this.body1.func_78785_a(f5);
/* 191 */     GL11.glPushMatrix();
/* 192 */     GL11.glTranslatef(this.top1.field_82906_o, this.top1.field_82908_p, this.top1.field_82907_q);
/* 193 */     GL11.glTranslatef(this.top1.field_78800_c * f5, this.top1.field_78797_d * f5, this.top1.field_78798_e * f5);
/* 194 */     GL11.glScaled(0.92D, 1.0D, 0.9D);
/* 195 */     GL11.glTranslatef(-this.top1.field_82906_o, -this.top1.field_82908_p, -this.top1.field_82907_q);
/* 196 */     GL11.glTranslatef(-this.top1.field_78800_c * f5, -this.top1.field_78797_d * f5, -this.top1.field_78798_e * f5);
/* 197 */     this.top1.func_78785_a(f5);
/* 198 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 203 */     modelRenderer.field_78795_f = x;
/* 204 */     modelRenderer.field_78796_g = y;
/* 205 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelSwitchSectionMandalorian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */