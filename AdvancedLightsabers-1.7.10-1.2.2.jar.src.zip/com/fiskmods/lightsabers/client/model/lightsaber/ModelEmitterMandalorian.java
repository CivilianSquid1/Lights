/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelEmitterMandalorian
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer peg1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer peg2;
/*     */   public ModelRenderer peg3;
/*     */   public ModelRenderer peg4;
/*     */   public ModelRenderer peg5;
/*     */   public ModelRenderer peg6;
/*     */   public ModelRenderer peg7;
/*     */   public ModelRenderer peg8;
/*     */   public ModelRenderer peg9;
/*     */   public ModelRenderer peg10;
/*     */   
/*     */   public ModelEmitterMandalorian() {
/*  42 */     this.field_78090_t = 64;
/*  43 */     this.field_78089_u = 32;
/*  44 */     this.peg6 = new ModelRenderer(this, 14, 15);
/*  45 */     this.peg6.func_78793_a(0.0F, -2.0F, 0.0F);
/*  46 */     this.peg6.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/*  47 */     this.body14 = new ModelRenderer(this, 0, 0);
/*  48 */     this.body14.field_78809_i = true;
/*  49 */     this.body14.func_78793_a(2.5F, -12.72F, 3.5F);
/*  50 */     this.body14.func_78790_a(-0.5F, -3.0F, -1.5F, 1, 3, 2, 0.0F);
/*  51 */     this.body15 = new ModelRenderer(this, 12, 0);
/*  52 */     this.body15.field_78809_i = true;
/*  53 */     this.body15.func_78793_a(0.0F, -3.0F, 0.5F);
/*  54 */     this.body15.func_78790_a(-0.5F, 0.0F, -1.0F, 1, 1, 1, 0.0F);
/*  55 */     setRotateAngle(this.body15, -1.1248647F, 0.0F, 0.0F);
/*  56 */     this.peg1 = new ModelRenderer(this, 14, 15);
/*  57 */     this.peg1.func_78793_a(0.0F, -0.93F, -1.1F);
/*  58 */     this.peg1.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/*  59 */     this.body13 = new ModelRenderer(this, 8, 2);
/*  60 */     this.body13.func_78793_a(0.0F, 0.0F, -2.0F);
/*  61 */     this.body13.func_78790_a(-0.5F, -1.0F, -1.5F, 1, 1, 2, 0.0F);
/*  62 */     this.body17 = new ModelRenderer(this, 8, 0);
/*  63 */     this.body17.field_78809_i = true;
/*  64 */     this.body17.func_78793_a(0.0F, 6.39F, 0.0F);
/*  65 */     this.body17.func_78790_a(-0.5F, 0.0F, -0.5F, 1, 1, 1, 0.0F);
/*  66 */     this.body10 = new ModelRenderer(this, 12, 0);
/*  67 */     this.body10.func_78793_a(0.0F, -3.0F, 0.5F);
/*  68 */     this.body10.func_78790_a(-0.5F, 0.0F, -1.0F, 1, 1, 1, 0.0F);
/*  69 */     setRotateAngle(this.body10, -1.1248647F, 0.0F, 0.0F);
/*  70 */     this.body7 = new ModelRenderer(this, 14, 0);
/*  71 */     this.body7.field_78809_i = true;
/*  72 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  73 */     this.body7.func_78790_a(-0.6F, -13.0F, -1.0F, 1, 13, 2, 0.0F);
/*  74 */     setRotateAngle(this.body7, 0.0F, -0.7853982F, 0.0F);
/*  75 */     this.body8 = new ModelRenderer(this, 14, 0);
/*  76 */     this.body8.field_78809_i = true;
/*  77 */     this.body8.func_78793_a(0.0F, 0.0F, -6.0F);
/*  78 */     this.body8.func_78790_a(-0.6F, -13.0F, -1.0F, 1, 13, 2, 0.0F);
/*  79 */     setRotateAngle(this.body8, 0.0F, 0.7853982F, 0.0F);
/*  80 */     this.body16 = new ModelRenderer(this, 0, 19);
/*  81 */     this.body16.field_78809_i = true;
/*  82 */     this.body16.func_78793_a(0.0F, 1.0F, -0.5F);
/*  83 */     this.body16.func_78790_a(-0.5F, 0.0F, -0.5F, 1, 7, 2, 0.0F);
/*  84 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  85 */     this.body3.func_78793_a(-2.0F, 0.0F, 3.0F);
/*  86 */     this.body3.func_78790_a(-1.0F, -13.0F, -6.0F, 1, 13, 6, 0.0F);
/*  87 */     this.body5 = new ModelRenderer(this, 14, 0);
/*  88 */     this.body5.func_78793_a(0.0F, 0.0F, -6.0F);
/*  89 */     this.body5.func_78790_a(-0.4F, -13.0F, -1.0F, 1, 13, 2, 0.0F);
/*  90 */     setRotateAngle(this.body5, 0.0F, -0.7853982F, 0.0F);
/*  91 */     this.peg2 = new ModelRenderer(this, 14, 15);
/*  92 */     this.peg2.func_78793_a(0.0F, -2.0F, 0.0F);
/*  93 */     this.peg2.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/*  94 */     this.peg10 = new ModelRenderer(this, 14, 15);
/*  95 */     this.peg10.func_78793_a(0.0F, -2.0F, 0.0F);
/*  96 */     this.peg10.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/*  97 */     this.body9 = new ModelRenderer(this, 0, 0);
/*  98 */     this.body9.func_78793_a(-2.5F, -12.72F, 3.5F);
/*  99 */     this.body9.func_78790_a(-0.5F, -3.0F, -1.5F, 1, 3, 2, 0.0F);
/* 100 */     this.peg3 = new ModelRenderer(this, 14, 15);
/* 101 */     this.peg3.func_78793_a(0.0F, -2.0F, 0.0F);
/* 102 */     this.peg3.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 103 */     this.body18 = new ModelRenderer(this, 8, 2);
/* 104 */     this.body18.field_78809_i = true;
/* 105 */     this.body18.func_78793_a(0.0F, 0.0F, -2.0F);
/* 106 */     this.body18.func_78790_a(-0.5F, -1.0F, -1.5F, 1, 1, 2, 0.0F);
/* 107 */     this.body11 = new ModelRenderer(this, 0, 19);
/* 108 */     this.body11.func_78793_a(0.0F, 1.0F, -0.5F);
/* 109 */     this.body11.func_78790_a(-0.5F, 0.0F, -0.5F, 1, 7, 2, 0.0F);
/* 110 */     this.peg8 = new ModelRenderer(this, 14, 15);
/* 111 */     this.peg8.func_78793_a(0.0F, -2.0F, 0.0F);
/* 112 */     this.peg8.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 113 */     this.peg9 = new ModelRenderer(this, 14, 15);
/* 114 */     this.peg9.func_78793_a(0.0F, -2.0F, 0.0F);
/* 115 */     this.peg9.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 116 */     this.peg5 = new ModelRenderer(this, 14, 15);
/* 117 */     this.peg5.func_78793_a(0.0F, -2.0F, 0.0F);
/* 118 */     this.peg5.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 119 */     this.body2 = new ModelRenderer(this, 20, 0);
/* 120 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 121 */     this.body2.func_78790_a(-3.0F, -13.0F, 3.0F, 6, 13, 1, 0.0F);
/* 122 */     setRotateAngle(this.body2, 0.0F, 3.1415927F, 0.0F);
/* 123 */     this.peg4 = new ModelRenderer(this, 14, 15);
/* 124 */     this.peg4.func_78793_a(0.0F, -2.0F, 0.0F);
/* 125 */     this.peg4.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 126 */     this.body1 = new ModelRenderer(this, 20, 0);
/* 127 */     this.body1.func_78793_a(0.0F, 0.0F, 0.2F);
/* 128 */     this.body1.func_78790_a(-3.0F, -13.0F, 3.0F, 6, 13, 1, 0.0F);
/* 129 */     this.peg7 = new ModelRenderer(this, 14, 15);
/* 130 */     this.peg7.func_78793_a(0.0F, -2.0F, 0.0F);
/* 131 */     this.peg7.func_78790_a(-3.5F, 0.0F, -3.0F, 7, 1, 3, 0.0F);
/* 132 */     this.body12 = new ModelRenderer(this, 8, 0);
/* 133 */     this.body12.func_78793_a(0.0F, 6.39F, 0.0F);
/* 134 */     this.body12.func_78790_a(-0.5F, 0.0F, -0.5F, 1, 1, 1, 0.0F);
/* 135 */     this.body6 = new ModelRenderer(this, 0, 0);
/* 136 */     this.body6.field_78809_i = true;
/* 137 */     this.body6.func_78793_a(2.0F, 0.0F, 3.0F);
/* 138 */     this.body6.func_78790_a(0.0F, -13.0F, -6.0F, 1, 13, 6, 0.0F);
/* 139 */     this.body4 = new ModelRenderer(this, 14, 0);
/* 140 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/* 141 */     this.body4.func_78790_a(-0.4F, -13.0F, -1.0F, 1, 13, 2, 0.0F);
/* 142 */     setRotateAngle(this.body4, 0.0F, 0.7853982F, 0.0F);
/* 143 */     this.peg5.func_78792_a(this.peg6);
/* 144 */     this.body1.func_78792_a(this.body14);
/* 145 */     this.body14.func_78792_a(this.body15);
/* 146 */     this.body9.func_78792_a(this.body13);
/* 147 */     this.body16.func_78792_a(this.body17);
/* 148 */     this.body9.func_78792_a(this.body10);
/* 149 */     this.body6.func_78792_a(this.body7);
/* 150 */     this.body6.func_78792_a(this.body8);
/* 151 */     this.body15.func_78792_a(this.body16);
/* 152 */     this.body1.func_78792_a(this.body3);
/* 153 */     this.body3.func_78792_a(this.body5);
/* 154 */     this.peg1.func_78792_a(this.peg2);
/* 155 */     this.peg9.func_78792_a(this.peg10);
/* 156 */     this.body1.func_78792_a(this.body9);
/* 157 */     this.peg2.func_78792_a(this.peg3);
/* 158 */     this.body14.func_78792_a(this.body18);
/* 159 */     this.body10.func_78792_a(this.body11);
/* 160 */     this.peg7.func_78792_a(this.peg8);
/* 161 */     this.peg8.func_78792_a(this.peg9);
/* 162 */     this.peg4.func_78792_a(this.peg5);
/* 163 */     this.body1.func_78792_a(this.body2);
/* 164 */     this.peg3.func_78792_a(this.peg4);
/* 165 */     this.peg6.func_78792_a(this.peg7);
/* 166 */     this.body11.func_78792_a(this.body12);
/* 167 */     this.body1.func_78792_a(this.body6);
/* 168 */     this.body3.func_78792_a(this.body4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 174 */     GL11.glPushMatrix();
/* 175 */     GL11.glTranslatef(this.peg1.field_82906_o, this.peg1.field_82908_p, this.peg1.field_82907_q);
/* 176 */     GL11.glTranslatef(this.peg1.field_78800_c * f5, this.peg1.field_78797_d * f5, this.peg1.field_78798_e * f5);
/* 177 */     GL11.glScaled(0.9D, 0.5D, 1.0D);
/* 178 */     GL11.glTranslatef(-this.peg1.field_82906_o, -this.peg1.field_82908_p, -this.peg1.field_82907_q);
/* 179 */     GL11.glTranslatef(-this.peg1.field_78800_c * f5, -this.peg1.field_78797_d * f5, -this.peg1.field_78798_e * f5);
/* 180 */     this.peg1.func_78785_a(f5);
/* 181 */     GL11.glPopMatrix();
/* 182 */     GL11.glPushMatrix();
/* 183 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 184 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 185 */     GL11.glScaled(0.92D, 0.85D, 0.9D);
/* 186 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 187 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 188 */     this.body1.func_78785_a(f5);
/* 189 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 194 */     modelRenderer.field_78795_f = x;
/* 195 */     modelRenderer.field_78796_g = y;
/* 196 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelEmitterMandalorian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */