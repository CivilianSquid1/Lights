/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelEmitterMechanical
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer guard1;
/*     */   public ModelRenderer guard3;
/*     */   public ModelRenderer guard4;
/*     */   public ModelRenderer guard5;
/*     */   public ModelRenderer guard6;
/*     */   public ModelRenderer panel1;
/*     */   public ModelRenderer panel2;
/*     */   public ModelRenderer frontButton1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body15;
/*     */   public ModelRenderer body19;
/*     */   public ModelRenderer body28;
/*     */   public ModelRenderer body29;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body16;
/*     */   public ModelRenderer body17;
/*     */   public ModelRenderer body18;
/*     */   public ModelRenderer body20;
/*     */   public ModelRenderer body21;
/*     */   public ModelRenderer body22;
/*     */   public ModelRenderer guard2;
/*     */   public ModelRenderer frontButton2;
/*     */   public ModelRenderer frontButton3;
/*     */   
/*     */   public ModelEmitterMechanical() {
/*  49 */     this.field_78090_t = 64;
/*  50 */     this.field_78089_u = 32;
/*  51 */     this.body28 = new ModelRenderer(this, 0, 30);
/*  52 */     this.body28.func_78793_a(-0.8F, -19.76F, 3.1F);
/*  53 */     this.body28.func_78790_a(-1.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/*  54 */     setRotateAngle(this.body28, 0.29670596F, -0.2617994F, -0.20943952F);
/*  55 */     this.body12 = new ModelRenderer(this, 0, 0);
/*  56 */     this.body12.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.body12.func_78790_a(-1.5F, -15.0F, 2.62F, 3, 15, 1, 0.0F);
/*  58 */     setRotateAngle(this.body12, 0.0F, 3.1415927F, 0.0F);
/*  59 */     this.body16 = new ModelRenderer(this, 8, 19);
/*  60 */     this.body16.func_78793_a(-0.91F, -15.19F, 3.12F);
/*  61 */     this.body16.func_78790_a(0.0F, -1.0F, -0.5F, 3, 1, 1, 0.0F);
/*  62 */     setRotateAngle(this.body16, 0.0F, 0.0F, -0.62831855F);
/*  63 */     this.guard1 = new ModelRenderer(this, 34, 17);
/*  64 */     this.guard1.func_78793_a(0.0F, -12.0F, -2.5F);
/*  65 */     this.guard1.func_78790_a(-4.0F, -1.0F, 0.0F, 8, 2, 7, 0.0F);
/*  66 */     this.body10 = new ModelRenderer(this, 8, 0);
/*  67 */     this.body10.field_78809_i = true;
/*  68 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body10.func_78790_a(-1.5F, -15.0F, 2.62F, 3, 15, 1, 0.0F);
/*  70 */     setRotateAngle(this.body10, 0.0F, 2.3561945F, 0.0F);
/*  71 */     this.body18 = new ModelRenderer(this, 4, 21);
/*  72 */     this.body18.func_78793_a(-0.8F, -0.2F, 0.0F);
/*  73 */     this.body18.func_78790_a(-0.4F, -0.5F, -0.5F, 1, 1, 1, 0.0F);
/*  74 */     this.body11 = new ModelRenderer(this, 0, 19);
/*  75 */     this.body11.field_78809_i = true;
/*  76 */     this.body11.func_78793_a(1.16F, -14.06F, 3.12F);
/*  77 */     this.body11.func_78790_a(-3.0F, -1.0F, -0.5F, 3, 1, 1, 0.0F);
/*  78 */     setRotateAngle(this.body11, 0.0F, 0.0F, 0.33161256F);
/*  79 */     this.body13 = new ModelRenderer(this, 8, 0);
/*  80 */     this.body13.func_78793_a(0.0F, 0.0F, 0.0F);
/*  81 */     this.body13.func_78790_a(-1.5F, -15.0F, 2.62F, 3, 15, 1, 0.0F);
/*  82 */     setRotateAngle(this.body13, 0.0F, -2.3561945F, 0.0F);
/*  83 */     this.body5 = new ModelRenderer(this, 8, 21);
/*  84 */     this.body5.field_78809_i = true;
/*  85 */     this.body5.func_78793_a(0.0F, 1.0F, 0.0F);
/*  86 */     this.body5.func_78790_a(-1.0F, -0.5F, -0.5F, 1, 1, 1, 0.0F);
/*  87 */     this.frontButton3 = new ModelRenderer(this, 41, 0);
/*  88 */     this.frontButton3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  89 */     this.frontButton3.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/*  90 */     setRotateAngle(this.frontButton3, 0.0F, -2.1816616F, 0.0F);
/*  91 */     this.body22 = new ModelRenderer(this, 8, 21);
/*  92 */     this.body22.func_78793_a(0.0F, 1.0F, 0.0F);
/*  93 */     this.body22.func_78790_a(0.0F, -0.5F, -0.5F, 1, 1, 1, 0.0F);
/*  94 */     this.guard3 = new ModelRenderer(this, 44, 21);
/*  95 */     this.guard3.func_78793_a(-2.6F, -13.0F, -3.94F);
/*  96 */     this.guard3.func_78790_a(0.0F, 0.0F, 0.0F, 5, 2, 3, 0.0F);
/*  97 */     this.body7 = new ModelRenderer(this, 8, 19);
/*  98 */     this.body7.field_78809_i = true;
/*  99 */     this.body7.func_78793_a(0.91F, -15.19F, 3.12F);
/* 100 */     this.body7.func_78790_a(-3.0F, -1.0F, -0.5F, 3, 1, 1, 0.0F);
/* 101 */     setRotateAngle(this.body7, 0.0F, 0.0F, 0.62831855F);
/* 102 */     this.guard6 = new ModelRenderer(this, 40, 17);
/* 103 */     this.guard6.func_78793_a(-4.0F, -11.0F, 2.5F);
/* 104 */     this.guard6.func_78790_a(0.0F, 0.0F, 0.0F, 8, 2, 2, 0.0F);
/* 105 */     this.body4 = new ModelRenderer(this, 0, 24);
/* 106 */     this.body4.field_78809_i = true;
/* 107 */     this.body4.func_78793_a(0.13F, -0.94F, 0.0F);
/* 108 */     this.body4.func_78790_a(0.0F, -0.5F, -0.5F, 1, 3, 1, 0.0F);
/* 109 */     setRotateAngle(this.body4, 0.0F, 0.0F, -0.7679449F);
/* 110 */     this.body17 = new ModelRenderer(this, 0, 21);
/* 111 */     this.body17.func_78793_a(1.0F, -15.9F, 3.12F);
/* 112 */     this.body17.func_78790_a(-0.5F, -1.5F, -0.5F, 1, 2, 1, 0.0F);
/* 113 */     this.frontButton2 = new ModelRenderer(this, 41, 0);
/* 114 */     this.frontButton2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 115 */     this.frontButton2.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 116 */     setRotateAngle(this.frontButton2, 0.0F, 2.1816616F, 0.0F);
/* 117 */     this.body2 = new ModelRenderer(this, 24, 0);
/* 118 */     this.body2.field_78809_i = true;
/* 119 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 120 */     this.body2.func_78790_a(-1.5F, -18.0F, 2.62F, 3, 18, 1, 0.0F);
/* 121 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/* 122 */     this.body29 = new ModelRenderer(this, 0, 30);
/* 123 */     this.body29.field_78809_i = true;
/* 124 */     this.body29.func_78793_a(0.8F, -19.76F, 3.1F);
/* 125 */     this.body29.func_78790_a(-1.0F, -0.5F, -0.5F, 2, 1, 1, 0.0F);
/* 126 */     setRotateAngle(this.body29, 0.29670596F, 0.2617994F, 0.20943952F);
/* 127 */     this.guard2 = new ModelRenderer(this, 44, 21);
/* 128 */     this.guard2.func_78793_a(-4.0F, 0.0F, 0.0F);
/* 129 */     this.guard2.func_78790_a(0.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
/* 130 */     setRotateAngle(this.guard2, 0.0F, 0.7958701F, 0.0F);
/* 131 */     this.body1 = new ModelRenderer(this, 32, 0);
/* 132 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 133 */     this.body1.func_78790_a(-1.5F, -20.0F, 2.62F, 3, 20, 1, 0.0F);
/* 134 */     this.guard5 = new ModelRenderer(this, 40, 10);
/* 135 */     this.guard5.func_78793_a(-4.0F, -11.12F, 0.38F);
/* 136 */     this.guard5.func_78790_a(0.0F, 0.0F, 0.0F, 8, 3, 2, 0.0F);
/* 137 */     setRotateAngle(this.guard5, 0.7853982F, 0.0F, 0.0F);
/* 138 */     this.body9 = new ModelRenderer(this, 4, 21);
/* 139 */     this.body9.field_78809_i = true;
/* 140 */     this.body9.func_78793_a(0.8F, -0.2F, 0.0F);
/* 141 */     this.body9.func_78790_a(-0.6F, -0.5F, -0.5F, 1, 1, 1, 0.0F);
/* 142 */     this.frontButton1 = new ModelRenderer(this, 41, 0);
/* 143 */     this.frontButton1.func_78793_a(1.8F, -6.0F, 2.0F);
/* 144 */     this.frontButton1.func_78790_a(-1.5F, -4.0F, -0.38F, 3, 4, 4, 0.0F);
/* 145 */     setRotateAngle(this.frontButton1, 1.5707964F, -2.3561945F, 0.0F);
/* 146 */     this.panel2 = new ModelRenderer(this, 26, 22);
/* 147 */     this.panel2.func_78793_a(-1.0F, -16.0F, 3.0F);
/* 148 */     this.panel2.func_78790_a(0.0F, 0.0F, 0.0F, 2, 3, 1, 0.0F);
/* 149 */     this.body14 = new ModelRenderer(this, 0, 19);
/* 150 */     this.body14.func_78793_a(-1.16F, -14.06F, 3.12F);
/* 151 */     this.body14.func_78790_a(0.0F, -1.0F, -0.5F, 3, 1, 1, 0.0F);
/* 152 */     setRotateAngle(this.body14, 0.0F, 0.0F, -0.33161256F);
/* 153 */     this.body8 = new ModelRenderer(this, 0, 21);
/* 154 */     this.body8.field_78809_i = true;
/* 155 */     this.body8.func_78793_a(-1.0F, -15.9F, 3.12F);
/* 156 */     this.body8.func_78790_a(-0.5F, -1.5F, -0.5F, 1, 2, 1, 0.0F);
/* 157 */     this.body21 = new ModelRenderer(this, 0, 24);
/* 158 */     this.body21.func_78793_a(-0.13F, -0.94F, 0.0F);
/* 159 */     this.body21.func_78790_a(-1.0F, -0.5F, -0.5F, 1, 3, 1, 0.0F);
/* 160 */     setRotateAngle(this.body21, 0.0F, 0.0F, 0.7679449F);
/* 161 */     this.guard4 = new ModelRenderer(this, 44, 21);
/* 162 */     this.guard4.func_78793_a(2.61F, -13.0F, -3.94F);
/* 163 */     this.guard4.func_78790_a(0.0F, 0.0F, 0.0F, 2, 2, 3, 0.0F);
/* 164 */     setRotateAngle(this.guard4, 0.0F, -0.80285144F, 0.0F);
/* 165 */     this.body6 = new ModelRenderer(this, 16, 0);
/* 166 */     this.body6.field_78809_i = true;
/* 167 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/* 168 */     this.body6.func_78790_a(-1.5F, -16.0F, 2.62F, 3, 16, 1, 0.0F);
/* 169 */     setRotateAngle(this.body6, 0.0F, 1.5707964F, 0.0F);
/* 170 */     this.body3 = new ModelRenderer(this, 4, 23);
/* 171 */     this.body3.field_78809_i = true;
/* 172 */     this.body3.func_78793_a(-1.0F, -18.0F, 3.12F);
/* 173 */     this.body3.func_78790_a(-0.5F, -2.0F, -0.5F, 1, 2, 1, 0.0F);
/* 174 */     this.body19 = new ModelRenderer(this, 24, 0);
/* 175 */     this.body19.func_78793_a(0.0F, 0.0F, 0.0F);
/* 176 */     this.body19.func_78790_a(-1.5F, -18.0F, 2.62F, 3, 18, 1, 0.0F);
/* 177 */     setRotateAngle(this.body19, 0.0F, -0.7853982F, 0.0F);
/* 178 */     this.body20 = new ModelRenderer(this, 4, 23);
/* 179 */     this.body20.func_78793_a(1.0F, -18.0F, 3.12F);
/* 180 */     this.body20.func_78790_a(-0.5F, -2.0F, -0.5F, 1, 2, 1, 0.0F);
/* 181 */     this.panel1 = new ModelRenderer(this, 26, 22);
/* 182 */     this.panel1.func_78793_a(-1.0F, -9.0F, 3.0F);
/* 183 */     this.panel1.func_78790_a(0.0F, 0.0F, 0.0F, 2, 5, 1, 0.0F);
/* 184 */     this.body15 = new ModelRenderer(this, 16, 0);
/* 185 */     this.body15.func_78793_a(0.0F, 0.0F, 0.0F);
/* 186 */     this.body15.func_78790_a(-1.5F, -16.0F, 2.62F, 3, 16, 1, 0.0F);
/* 187 */     setRotateAngle(this.body15, 0.0F, -1.5707964F, 0.0F);
/* 188 */     this.body1.func_78792_a(this.body28);
/* 189 */     this.body1.func_78792_a(this.body12);
/* 190 */     this.body15.func_78792_a(this.body16);
/* 191 */     this.body1.func_78792_a(this.body10);
/* 192 */     this.body17.func_78792_a(this.body18);
/* 193 */     this.body10.func_78792_a(this.body11);
/* 194 */     this.body1.func_78792_a(this.body13);
/* 195 */     this.body4.func_78792_a(this.body5);
/* 196 */     this.frontButton1.func_78792_a(this.frontButton3);
/* 197 */     this.body21.func_78792_a(this.body22);
/* 198 */     this.body6.func_78792_a(this.body7);
/* 199 */     this.body3.func_78792_a(this.body4);
/* 200 */     this.body15.func_78792_a(this.body17);
/* 201 */     this.frontButton1.func_78792_a(this.frontButton2);
/* 202 */     this.body1.func_78792_a(this.body2);
/* 203 */     this.body1.func_78792_a(this.body29);
/* 204 */     this.guard1.func_78792_a(this.guard2);
/* 205 */     this.body8.func_78792_a(this.body9);
/* 206 */     this.body13.func_78792_a(this.body14);
/* 207 */     this.body6.func_78792_a(this.body8);
/* 208 */     this.body20.func_78792_a(this.body21);
/* 209 */     this.body1.func_78792_a(this.body6);
/* 210 */     this.body2.func_78792_a(this.body3);
/* 211 */     this.body1.func_78792_a(this.body19);
/* 212 */     this.body19.func_78792_a(this.body20);
/* 213 */     this.body1.func_78792_a(this.body15);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 219 */     this.guard1.func_78785_a(f5);
/* 220 */     GL11.glPushMatrix();
/* 221 */     GL11.glTranslatef(this.guard3.field_82906_o, this.guard3.field_82908_p, this.guard3.field_82907_q);
/* 222 */     GL11.glTranslatef(this.guard3.field_78800_c * f5, this.guard3.field_78797_d * f5, this.guard3.field_78798_e * f5);
/* 223 */     GL11.glScaled(1.04D, 1.0D, 1.0D);
/* 224 */     GL11.glTranslatef(-this.guard3.field_82906_o, -this.guard3.field_82908_p, -this.guard3.field_82907_q);
/* 225 */     GL11.glTranslatef(-this.guard3.field_78800_c * f5, -this.guard3.field_78797_d * f5, -this.guard3.field_78798_e * f5);
/* 226 */     this.guard3.func_78785_a(f5);
/* 227 */     GL11.glPopMatrix();
/* 228 */     this.guard6.func_78785_a(f5);
/* 229 */     this.body1.func_78785_a(f5);
/* 230 */     this.guard5.func_78785_a(f5);
/* 231 */     GL11.glPushMatrix();
/* 232 */     GL11.glTranslatef(this.frontButton1.field_82906_o, this.frontButton1.field_82908_p, this.frontButton1.field_82907_q);
/* 233 */     GL11.glTranslatef(this.frontButton1.field_78800_c * f5, this.frontButton1.field_78797_d * f5, this.frontButton1.field_78798_e * f5);
/* 234 */     GL11.glScaled(0.3D, 0.3D, 0.3D);
/* 235 */     GL11.glTranslatef(-this.frontButton1.field_82906_o, -this.frontButton1.field_82908_p, -this.frontButton1.field_82907_q);
/* 236 */     GL11.glTranslatef(-this.frontButton1.field_78800_c * f5, -this.frontButton1.field_78797_d * f5, -this.frontButton1.field_78798_e * f5);
/* 237 */     this.frontButton1.func_78785_a(f5);
/* 238 */     GL11.glPopMatrix();
/* 239 */     this.panel2.func_78785_a(f5);
/* 240 */     this.guard4.func_78785_a(f5);
/* 241 */     this.panel1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 246 */     modelRenderer.field_78795_f = x;
/* 247 */     modelRenderer.field_78796_g = y;
/* 248 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelEmitterMechanical.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */