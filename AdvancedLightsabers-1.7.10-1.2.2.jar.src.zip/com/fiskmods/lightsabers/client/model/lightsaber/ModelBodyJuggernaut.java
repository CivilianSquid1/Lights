/*     */ package com.fiskmods.lightsabers.client.model.lightsaber;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ModelBodyJuggernaut
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer body1;
/*     */   public ModelRenderer body2;
/*     */   public ModelRenderer body3;
/*     */   public ModelRenderer body4;
/*     */   public ModelRenderer body5;
/*     */   public ModelRenderer body6;
/*     */   public ModelRenderer body7;
/*     */   public ModelRenderer body8;
/*     */   public ModelRenderer body9;
/*     */   public ModelRenderer body10;
/*     */   public ModelRenderer body11;
/*     */   public ModelRenderer body12;
/*     */   public ModelRenderer body13;
/*     */   public ModelRenderer body14;
/*     */   public ModelRenderer body15;
/*     */   
/*     */   public ModelBodyJuggernaut() {
/*  29 */     this.field_78090_t = 64;
/*  30 */     this.field_78089_u = 32;
/*  31 */     this.body15 = new ModelRenderer(this, 8, 0);
/*  32 */     this.body15.func_78793_a(0.0F, 0.0F, 0.0F);
/*  33 */     this.body15.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  34 */     setRotateAngle(this.body15, 0.0F, 0.8976228F, 0.0F);
/*  35 */     this.body4 = new ModelRenderer(this, 0, 0);
/*  36 */     this.body4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  37 */     this.body4.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  38 */     setRotateAngle(this.body4, 0.0F, 2.3561945F, 0.0F);
/*  39 */     this.body2 = new ModelRenderer(this, 0, 0);
/*  40 */     this.body2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  41 */     this.body2.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  42 */     setRotateAngle(this.body2, 0.0F, 0.7853982F, 0.0F);
/*  43 */     this.body3 = new ModelRenderer(this, 0, 0);
/*  44 */     this.body3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  45 */     this.body3.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  46 */     setRotateAngle(this.body3, 0.0F, 1.5707964F, 0.0F);
/*  47 */     this.body11 = new ModelRenderer(this, 8, 0);
/*  48 */     this.body11.func_78793_a(0.0F, 0.0F, 0.0F);
/*  49 */     this.body11.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  50 */     setRotateAngle(this.body11, 0.0F, 0.8976228F, 0.0F);
/*  51 */     this.body6 = new ModelRenderer(this, 0, 0);
/*  52 */     this.body6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  53 */     this.body6.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  54 */     setRotateAngle(this.body6, 0.0F, -2.3561945F, 0.0F);
/*  55 */     this.body8 = new ModelRenderer(this, 0, 0);
/*  56 */     this.body8.func_78793_a(0.0F, 0.0F, 0.0F);
/*  57 */     this.body8.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  58 */     setRotateAngle(this.body8, 0.0F, -0.7853982F, 0.0F);
/*  59 */     this.body10 = new ModelRenderer(this, 8, 0);
/*  60 */     this.body10.func_78793_a(0.0F, 0.0F, 0.0F);
/*  61 */     this.body10.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  62 */     setRotateAngle(this.body10, 0.0F, 0.8976228F, 0.0F);
/*  63 */     this.body7 = new ModelRenderer(this, 0, 0);
/*  64 */     this.body7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  65 */     this.body7.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  66 */     setRotateAngle(this.body7, 0.0F, -1.5707964F, 0.0F);
/*  67 */     this.body1 = new ModelRenderer(this, 0, 0);
/*  68 */     this.body1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  69 */     this.body1.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  70 */     this.body9 = new ModelRenderer(this, 8, 0);
/*  71 */     this.body9.func_78793_a(0.0F, 0.0F, 0.0F);
/*  72 */     this.body9.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  73 */     this.body12 = new ModelRenderer(this, 8, 0);
/*  74 */     this.body12.func_78793_a(0.0F, 0.0F, 0.0F);
/*  75 */     this.body12.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  76 */     setRotateAngle(this.body12, 0.0F, 0.8976228F, 0.0F);
/*  77 */     this.body5 = new ModelRenderer(this, 0, 0);
/*  78 */     this.body5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  79 */     this.body5.func_78790_a(-1.5F, 0.0F, 2.62F, 3, 16, 1, 0.0F);
/*  80 */     setRotateAngle(this.body5, 0.0F, 3.1415927F, 0.0F);
/*  81 */     this.body14 = new ModelRenderer(this, 8, 0);
/*  82 */     this.body14.func_78793_a(0.0F, 0.0F, 0.0F);
/*  83 */     this.body14.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  84 */     setRotateAngle(this.body14, 0.0F, 0.8976228F, 0.0F);
/*  85 */     this.body13 = new ModelRenderer(this, 8, 0);
/*  86 */     this.body13.func_78793_a(0.0F, 0.0F, 0.0F);
/*  87 */     this.body13.func_78790_a(-0.5F, 0.0F, 3.52F, 1, 16, 1, 0.0F);
/*  88 */     setRotateAngle(this.body13, 0.0F, 0.8976228F, 0.0F);
/*  89 */     this.body14.func_78792_a(this.body15);
/*  90 */     this.body1.func_78792_a(this.body4);
/*  91 */     this.body1.func_78792_a(this.body2);
/*  92 */     this.body1.func_78792_a(this.body3);
/*  93 */     this.body10.func_78792_a(this.body11);
/*  94 */     this.body1.func_78792_a(this.body6);
/*  95 */     this.body1.func_78792_a(this.body8);
/*  96 */     this.body9.func_78792_a(this.body10);
/*  97 */     this.body1.func_78792_a(this.body7);
/*  98 */     this.body1.func_78792_a(this.body9);
/*  99 */     this.body11.func_78792_a(this.body12);
/* 100 */     this.body1.func_78792_a(this.body5);
/* 101 */     this.body13.func_78792_a(this.body14);
/* 102 */     this.body12.func_78792_a(this.body13);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 108 */     GL11.glPushMatrix();
/* 109 */     GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 110 */     GL11.glTranslatef(this.body1.field_82906_o, this.body1.field_82908_p, this.body1.field_82907_q);
/* 111 */     GL11.glTranslatef(this.body1.field_78800_c * f5, this.body1.field_78797_d * f5, this.body1.field_78798_e * f5);
/* 112 */     GL11.glScaled(0.8D, 1.0D, 0.8D);
/* 113 */     GL11.glTranslatef(-this.body1.field_82906_o, -this.body1.field_82908_p, -this.body1.field_82907_q);
/* 114 */     GL11.glTranslatef(-this.body1.field_78800_c * f5, -this.body1.field_78797_d * f5, -this.body1.field_78798_e * f5);
/* 115 */     this.body1.func_78785_a(f5);
/* 116 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 121 */     modelRenderer.field_78795_f = x;
/* 122 */     modelRenderer.field_78796_g = y;
/* 123 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\lightsaber\ModelBodyJuggernaut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */