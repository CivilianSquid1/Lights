/*     */ package com.fiskmods.lightsabers.client.model;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import java.util.Random;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelLightsaberBlade
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer blade;
/*     */   public int bladeLength;
/*     */   
/*     */   public ModelLightsaberBlade(int length) {
/*  26 */     this.field_78090_t = 64;
/*  27 */     this.field_78089_u = 32;
/*  28 */     this.blade = new ModelRenderer(this, 0, 0);
/*  29 */     this.blade.func_78789_a(-0.5F, -length, -0.5F, 1, length, 1);
/*  30 */     this.bladeLength = length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderInner(LightsaberData data, ItemStack stack, float[] rgb, boolean inWorld, boolean isCrossguard) {
/*  35 */     boolean fineCut = data.hasFocusingCrystal(FocusingCrystal.FINE_CUT);
/*     */     
/*  37 */     if (isCrossguard && fineCut)
/*     */     {
/*  39 */       GL11.glScalef(1.0F, 1.2F, 1.0F);
/*     */     }
/*     */     
/*  42 */     if (data.hasFocusingCrystal(FocusingCrystal.INVERTING)) {
/*     */       
/*  44 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/*     */     }
/*  46 */     else if (data.hasFocusingCrystal(FocusingCrystal.PRISMATIC)) {
/*     */       
/*  48 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], 1.0F);
/*     */     }
/*     */     else {
/*     */       
/*  52 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     
/*  55 */     if (data.hasFocusingCrystal(FocusingCrystal.COMPRESSED))
/*     */     {
/*  57 */       GL11.glScalef(0.6F, 1.0F, 0.6F);
/*     */     }
/*     */     
/*  60 */     if (data.hasFocusingCrystal(FocusingCrystal.CRACKED)) {
/*     */       
/*  62 */       float divider = 60.0F;
/*  63 */       int ticks = (Minecraft.func_71410_x()).field_71439_g.field_70173_aa;
/*  64 */       Random rand = new Random((ticks % 100 * 1000));
/*  65 */       Random prev = new Random(((ticks - 1) % 100 * 1000));
/*     */       
/*  67 */       Supplier<Float> nextFloat = () -> Float.valueOf(ALRenderHelper.median(rand.nextFloat(), prev.nextFloat()));
/*     */       
/*  69 */       for (int i = 0; i < 4; i++) {
/*     */         
/*  71 */         GL11.glPushMatrix();
/*     */         
/*  73 */         if (i != 0) {
/*     */           
/*  75 */           GL11.glTranslatef((((Float)nextFloat.get()).floatValue() - 0.5F) / divider, 0.0F, (((Float)nextFloat.get()).floatValue() - 0.5F) / divider);
/*     */           
/*  77 */           for (int j = 0; j < this.bladeLength; j++) {
/*     */             
/*  79 */             GL11.glPushMatrix();
/*  80 */             GL11.glRotatef(((Float)nextFloat.get()).floatValue() * 360.0F, 0.0F, 1.0F, 0.0F);
/*  81 */             GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*  82 */             GL11.glTranslatef(0.0F, 0.05F - (1.0F - ((Float)nextFloat.get()).floatValue() * 0.2F) / 16.0F, (1.0F + ((Float)nextFloat.get()).floatValue() * this.bladeLength) / 16.0F);
/*  83 */             ALRenderHelper.drawTip(0.04F, 0.0F);
/*  84 */             GL11.glPopMatrix();
/*     */           } 
/*     */         } 
/*     */         
/*  88 */         if (!fineCut) {
/*     */           
/*  90 */           this.blade.func_78785_a(0.0625F);
/*  91 */           GL11.glTranslatef(0.0F, -(0.5F + this.bladeLength) / 16.0F, 0.03125F);
/*  92 */           ALRenderHelper.drawTip(0.03125F, 0.125F);
/*     */         } 
/*     */         
/*  95 */         GL11.glPopMatrix();
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     if (fineCut) {
/*     */       
/* 101 */       Tessellator tessellator = Tessellator.field_78398_a;
/* 102 */       float f = 0.0625F;
/* 103 */       float length = f * this.bladeLength * 0.7F;
/* 104 */       float edge = f * 1.5F;
/* 105 */       float edgeAngle = -f * 1.5F;
/* 106 */       float length1 = f * this.bladeLength * 0.3F;
/* 107 */       float edge1 = f / 2.0F;
/* 108 */       float tip = f * 1.5F;
/*     */       
/* 110 */       tessellator.func_78382_b();
/* 111 */       tessellator.func_78377_a((-f / 2.0F), -length, (f / 2.0F));
/* 112 */       tessellator.func_78377_a(0.0D, -length, edge);
/* 113 */       tessellator.func_78377_a(0.0D, edgeAngle, edge);
/* 114 */       tessellator.func_78377_a((-f / 2.0F), -f, (f / 2.0F));
/* 115 */       tessellator.func_78377_a((f / 2.0F), -length, (f / 2.0F));
/* 116 */       tessellator.func_78377_a(0.0D, -length, edge);
/* 117 */       tessellator.func_78377_a(0.0D, edgeAngle, edge);
/* 118 */       tessellator.func_78377_a((f / 2.0F), -f, (f / 2.0F));
/* 119 */       tessellator.func_78377_a((f / 2.0F), -f, (f / 2.0F));
/* 120 */       tessellator.func_78377_a(0.0D, edgeAngle, edge);
/* 121 */       tessellator.func_78377_a(0.0D, edgeAngle, edge);
/* 122 */       tessellator.func_78377_a((-f / 2.0F), -f, (f / 2.0F));
/* 123 */       tessellator.func_78377_a((-f / 2.0F), (0.0F - length), (f / 2.0F));
/* 124 */       tessellator.func_78377_a((-f / 2.0F), (-length1 - length), edge1);
/* 125 */       tessellator.func_78377_a(0.0D, (-length1 - length), edge1);
/* 126 */       tessellator.func_78377_a(0.0D, (0.0F - length), edge);
/* 127 */       tessellator.func_78377_a((f / 2.0F), (0.0F - length), (f / 2.0F));
/* 128 */       tessellator.func_78377_a((f / 2.0F), (-length1 - length), edge1);
/* 129 */       tessellator.func_78377_a(0.0D, (-length1 - length), edge1);
/* 130 */       tessellator.func_78377_a(0.0D, (0.0F - length), edge);
/* 131 */       tessellator.func_78377_a((-f / 2.0F), (0.0F - f * this.bladeLength), (f / 2.0F));
/* 132 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 133 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 134 */       tessellator.func_78377_a((-f / 2.0F), (0.0F - f * this.bladeLength), (-f / 2.0F));
/* 135 */       tessellator.func_78377_a((f / 2.0F), (0.0F - f * this.bladeLength), (f / 2.0F));
/* 136 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 137 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 138 */       tessellator.func_78377_a((f / 2.0F), (0.0F - f * this.bladeLength), (-f / 2.0F));
/* 139 */       tessellator.func_78377_a((-f / 2.0F), (0.0F - f * this.bladeLength), (-f / 2.0F));
/* 140 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 141 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 142 */       tessellator.func_78377_a((f / 2.0F), (0.0F - f * this.bladeLength), (-f / 2.0F));
/* 143 */       tessellator.func_78377_a((-f / 2.0F), (0.0F - f * this.bladeLength), (f / 2.0F));
/* 144 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 145 */       tessellator.func_78377_a(0.0D, (-tip - f * this.bladeLength), (-f / 2.0F));
/* 146 */       tessellator.func_78377_a((f / 2.0F), (0.0F - f * this.bladeLength), (f / 2.0F));
/* 147 */       tessellator.func_78381_a();
/*     */       
/* 149 */       this.blade.func_78785_a(0.0625F);
/*     */     }
/*     */     else {
/*     */       
/* 153 */       this.blade.func_78785_a(0.0625F);
/* 154 */       GL11.glTranslatef(0.0F, -0.0625F * (0.5F + this.bladeLength), 0.03125F);
/* 155 */       ALRenderHelper.drawTip(0.03125F, 0.125F);
/*     */     } 
/*     */     
/* 158 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderOuter(LightsaberData data, ItemStack itemstack, float[] rgb, boolean inWorld) {
/* 163 */     boolean fineCut = data.hasFocusingCrystal(FocusingCrystal.FINE_CUT);
/* 164 */     int smooth = 10;
/* 165 */     float width = 0.6F;
/* 166 */     float f = 1.0F;
/* 167 */     float f1 = 1.0F;
/* 168 */     float f2 = 1.0F;
/* 169 */     float f3 = 0.1F;
/*     */     
/* 171 */     if (data.hasFocusingCrystal(FocusingCrystal.COMPRESSED)) {
/*     */       
/* 173 */       width = 0.4F;
/* 174 */       smooth = 7;
/* 175 */       f3 = 0.07F;
/*     */     } 
/*     */     
/* 178 */     if (data.hasFocusingCrystal(FocusingCrystal.INVERTING) && data.hasFocusingCrystal(FocusingCrystal.PRISMATIC)) {
/*     */       
/* 180 */       rgb = new float[3];
/* 181 */       f3 *= 1.5F;
/* 182 */       GL11.glBlendFunc(770, 771);
/*     */     } 
/*     */     
/* 185 */     if (fineCut) {
/*     */       
/* 187 */       f *= 0.55F;
/* 188 */       f1 *= 0.925F;
/* 189 */       f2 *= 1.1F;
/*     */     } 
/*     */     
/* 192 */     if (inWorld) {
/*     */       
/* 194 */       width *= ModConfig.renderGlobalMultiplier * ModConfig.renderWidthMultiplier;
/* 195 */       smooth = (int)(smooth * ModConfig.renderGlobalMultiplier * ModConfig.renderSmoothingMultiplier);
/*     */     } 
/*     */     
/* 198 */     if (itemstack.func_82833_r().equals("jeb_"))
/*     */     {
/* 200 */       smooth = (int)(smooth * 0.25F);
/*     */     }
/*     */     
/* 203 */     int layerCount = 5 * smooth;
/* 204 */     float opacityMultiplier = inWorld ? (ModConfig.renderGlobalMultiplier * ModConfig.renderOpacityMultiplier) : 1.0F;
/*     */     
/* 206 */     for (int i = 0; i < layerCount; i++) {
/*     */       
/* 208 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], f3 / smooth * opacityMultiplier);
/* 209 */       float scale = 1.0F + i * width / smooth;
/* 210 */       float f4 = i / layerCount * 50.0F;
/*     */       
/* 212 */       GL11.glPushMatrix();
/* 213 */       GL11.glScaled((scale * f), ((1.0F - f4 * (fineCut ? 0.003F : 0.005F) + 0.2F) * f1), (scale * f2));
/* 214 */       GL11.glTranslatef(0.0F, -f4 / 400.0F + 0.06F, 0.0F);
/*     */       
/* 216 */       if (fineCut)
/*     */       {
/* 218 */         GL11.glTranslatef(0.0F, 0.0F, 0.005F + f4 * 1.0E-5F);
/*     */       }
/*     */       
/* 221 */       this.blade.func_78785_a(0.0625F);
/* 222 */       GL11.glPopMatrix();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderCrossguardOuter(LightsaberData data, ItemStack itemstack, float[] rgb, boolean inWorld) {
/* 235 */     boolean fineCut = data.hasFocusingCrystal(FocusingCrystal.FINE_CUT);
/* 236 */     int smooth = 10;
/* 237 */     float width = 0.4F;
/* 238 */     float f = 1.0F;
/* 239 */     float f1 = 1.0F;
/* 240 */     float f2 = 1.0F;
/* 241 */     float f3 = 0.1F;
/*     */     
/* 243 */     if (data.hasFocusingCrystal(FocusingCrystal.INVERTING) && data.hasFocusingCrystal(FocusingCrystal.PRISMATIC)) {
/*     */       
/* 245 */       rgb = new float[3];
/* 246 */       GL11.glBlendFunc(770, 771);
/*     */     } 
/*     */     
/* 249 */     if (data.hasFocusingCrystal(FocusingCrystal.COMPRESSED)) {
/*     */       
/* 251 */       width = 0.2F;
/* 252 */       smooth = 7;
/* 253 */       f1 = 0.9F;
/* 254 */       f3 = 0.07F;
/*     */     } 
/*     */     
/* 257 */     if (fineCut) {
/*     */       
/* 259 */       f *= 0.55F;
/* 260 */       f1 *= 0.925F;
/* 261 */       f2 *= 1.3F;
/*     */     } 
/*     */     
/* 264 */     if (inWorld) {
/*     */       
/* 266 */       width *= ModConfig.renderGlobalMultiplier * ModConfig.renderWidthMultiplier;
/* 267 */       smooth = (int)(smooth * ModConfig.renderGlobalMultiplier * ModConfig.renderSmoothingMultiplier);
/*     */     } 
/*     */     
/* 270 */     if (itemstack.func_82833_r().equals("jeb_"))
/*     */     {
/* 272 */       smooth = (int)(smooth * 0.25F);
/*     */     }
/*     */     
/* 275 */     int layerCount = 5 * smooth;
/*     */     
/* 277 */     for (int i = 0; i < layerCount; i++) {
/*     */       
/* 279 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], f3 / smooth * (inWorld ? (ModConfig.renderGlobalMultiplier * ModConfig.renderOpacityMultiplier) : 1.0F));
/* 280 */       float scale = 1.0F + i * width / smooth;
/* 281 */       float f4 = i / layerCount * 50.0F;
/*     */       
/* 283 */       GL11.glPushMatrix();
/* 284 */       GL11.glScaled((scale * f), ((1.0F - f4 * 0.05F + 2.0F) * f1), (scale * f2));
/* 285 */       GL11.glTranslatef(0.0F, -f4 / 400.0F + 0.06F, 0.0F);
/*     */       
/* 287 */       if (fineCut)
/*     */       {
/* 289 */         GL11.glTranslatef(0.0F, 0.0F, 0.005F + f4 * 1.0E-5F);
/*     */       }
/*     */       
/* 292 */       this.blade.func_78785_a(0.0625F);
/* 293 */       GL11.glPopMatrix();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\model\ModelLightsaberBlade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */