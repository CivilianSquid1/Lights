/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class RenderItemLightsaberForge
/*    */   implements IItemRenderer
/*    */ {
/* 15 */   private final TileEntity tile = (TileEntity)new TileEntityLightsaberForge();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 20 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 26 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 32 */     float scale = 0.65F;
/* 33 */     GL11.glScalef(scale, scale, scale);
/*    */     
/* 35 */     if (type == IItemRenderer.ItemRenderType.ENTITY || type == IItemRenderer.ItemRenderType.INVENTORY) {
/*    */       
/* 37 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/* 38 */       GL11.glTranslatef(0.0F, -0.75F, -0.5F);
/*    */     }
/* 40 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*    */       
/* 42 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 43 */       GL11.glTranslatef(-0.5F, 0.0F, -1.5F);
/*    */     }
/* 45 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON || type == IItemRenderer.ItemRenderType.FIRST_PERSON_MAP) {
/*    */       
/* 47 */       GL11.glTranslatef(0.5F, 0.75F, 0.5F);
/*    */     } 
/*    */     
/* 50 */     this.tile.field_145854_h = Block.func_149634_a(item.func_77973_b());
/* 51 */     TileEntityRendererDispatcher.field_147556_a.func_147549_a(this.tile, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */