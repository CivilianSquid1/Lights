/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class RenderItemSithCoffin
/*    */   implements IItemRenderer
/*    */ {
/* 14 */   private final TileEntity tile = (TileEntity)new TileEntitySithCoffin();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 19 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 25 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 31 */     float scale = 0.6F;
/* 32 */     GL11.glScalef(scale, scale, scale);
/*    */     
/* 34 */     if (type == IItemRenderer.ItemRenderType.ENTITY || type == IItemRenderer.ItemRenderType.INVENTORY) {
/*    */       
/* 36 */       GL11.glTranslatef(0.5F, -0.8F, 1.0F);
/*    */     }
/* 38 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*    */       
/* 40 */       GL11.glTranslatef(1.5F, 0.0F, 1.5F);
/*    */     }
/* 42 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON || type == IItemRenderer.ItemRenderType.FIRST_PERSON_MAP) {
/*    */       
/* 44 */       GL11.glTranslatef(1.5F, 0.0F, 1.5F);
/*    */     } 
/*    */     
/* 47 */     GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 48 */     TileEntityRendererDispatcher.field_147556_a.func_147549_a(this.tile, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */