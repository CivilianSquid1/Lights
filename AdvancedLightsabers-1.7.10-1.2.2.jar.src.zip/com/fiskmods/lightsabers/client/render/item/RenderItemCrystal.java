/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderItemCrystal
/*    */   implements IItemRenderer
/*    */ {
/* 14 */   private final TileEntityCrystal tile = new TileEntityCrystal();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 19 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 25 */     return (type != IItemRenderer.ItemRenderType.EQUIPPED);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 31 */     float scale = 2.5F;
/*    */     
/* 33 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/*    */       
/* 35 */       GL11.glTranslatef(-0.5F, 0.5F, -0.5F);
/*    */     }
/* 37 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*    */       
/* 39 */       GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
/* 40 */       GL11.glRotatef(15.0F, 1.0F, 0.0F, 0.0F);
/* 41 */       GL11.glTranslatef(-0.275F, -0.05F, -0.85F);
/* 42 */       scale /= 1.75F;
/*    */     }
/* 44 */     else if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*    */       
/* 46 */       GL11.glTranslatef(-1.25F, -0.5F, -1.25F);
/*    */     }
/* 48 */     else if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/*    */       
/* 50 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 51 */       GL11.glTranslatef(-0.5F, -1.0F, -0.5F);
/*    */     } 
/*    */     
/* 54 */     GL11.glScalef(scale, scale, scale);
/* 55 */     this.tile.setColor(ItemCrystal.get(item));
/* 56 */     TileEntityRendererDispatcher.field_147556_a.func_147549_a((TileEntity)this.tile, 0.0D, 0.0D, 0.0D, 1.0F);
/* 57 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */