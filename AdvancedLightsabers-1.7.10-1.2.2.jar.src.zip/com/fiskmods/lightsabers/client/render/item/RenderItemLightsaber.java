/*     */ package com.fiskmods.lightsabers.client.render.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.fiskmods.lightsabers.helper.ModelHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderItemLightsaber
/*     */   implements IItemRenderer
/*     */ {
/*     */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/*  22 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/*  28 */     return (type == IItemRenderer.ItemRenderType.ENTITY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack stack, Object... args) {
/*  34 */     LightsaberData data = LightsaberData.get(stack);
/*  35 */     GL11.glPushMatrix();
/*     */     
/*  37 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/*     */       
/*  39 */       GL11.glRotatef(-100.0F, 0.0F, 1.0F, 0.0F);
/*  40 */       GL11.glRotatef(-150.0F, 1.0F, 0.0F, 0.0F);
/*  41 */       GL11.glRotatef(5.0F, 0.0F, 0.0F, 1.0F);
/*  42 */       GL11.glTranslatef(0.0F, 0.275F, 0.85F);
/*     */       
/*  44 */       float scale = 0.2F;
/*  45 */       GL11.glScalef(scale, scale, scale);
/*  46 */       ALRenderHelper.renderLightsaber(stack, false);
/*     */     }
/*  48 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*     */       
/*  50 */       GL11.glTranslatef(0.7F, 0.3F, 0.0F);
/*  51 */       GL11.glRotatef(-150.0F, 0.0F, 0.0F, 1.0F);
/*  52 */       GL11.glRotatef(-85.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/*  54 */       if (args[1] instanceof EntityLivingBase)
/*     */       {
/*  56 */         ModelHelper.applyLightsaberItemRotation((EntityLivingBase)args[1], stack);
/*     */       }
/*     */       
/*  59 */       float scale = 0.175F;
/*  60 */       GL11.glScalef(scale, scale, scale);
/*  61 */       ALRenderHelper.renderLightsaber(data, stack, true);
/*     */     }
/*  63 */     else if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*     */       
/*  65 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*  66 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/*  68 */       float scale = 0.3F;
/*  69 */       GL11.glScalef(scale, scale, scale);
/*     */       
/*  71 */       if (((EntityItem)args[1]).field_70290_d != 0.0F)
/*     */       {
/*  73 */         GL11.glTranslatef(0.0F, -data.getHeight() / 48.0F, 0.0F);
/*     */       }
/*     */       
/*  76 */       if (stack.func_82837_s() && (stack.func_82833_r().equals("Dinnerbone") || stack.func_82833_r().equals("Grumm")))
/*     */       {
/*  78 */         GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */       
/*  81 */       ALRenderHelper.renderLightsaberHilt(data);
/*     */     }
/*  83 */     else if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/*     */       
/*  85 */       Tessellator tessellator = Tessellator.field_78398_a;
/*  86 */       float[] rgb = data.getRGB(stack);
/*  87 */       float triangle = 4.0F;
/*     */       
/*  89 */       GL11.glDisable(2896);
/*  90 */       GL11.glDisable(3553);
/*  91 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], 1.0F);
/*  92 */       tessellator.func_78382_b();
/*  93 */       tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/*  94 */       tessellator.func_78377_a(triangle, 0.0D, 0.0D);
/*  95 */       tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/*  96 */       tessellator.func_78377_a(0.0D, triangle, 0.0D);
/*  97 */       tessellator.func_78381_a();
/*     */       
/*  99 */       if (data.hasFocusingCrystal(FocusingCrystal.INVERTING)) {
/*     */         
/* 101 */         triangle /= 1.5F;
/* 102 */         GL11.glPushMatrix();
/* 103 */         GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/* 104 */         GL11.glTranslatef(triangle / 8.0F, triangle / 8.0F, 0.0F);
/* 105 */         tessellator.func_78382_b();
/* 106 */         tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/* 107 */         tessellator.func_78377_a(triangle, 0.0D, 0.0D);
/* 108 */         tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/* 109 */         tessellator.func_78377_a(0.0D, triangle, 0.0D);
/* 110 */         tessellator.func_78381_a();
/* 111 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/* 114 */       GL11.glEnable(3553);
/* 115 */       GL11.glEnable(2896);
/* 116 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 117 */       GL11.glTranslatef(-2.0F, 3.0F, 0.0F);
/* 118 */       GL11.glScalef(10.0F, 10.0F, 10.0F);
/* 119 */       GL11.glTranslatef(1.0F, 0.5F, 1.0F);
/* 120 */       GL11.glScalef(1.0F, 1.0F, -1.0F);
/* 121 */       GL11.glRotatef(210.0F, 1.0F, 0.0F, 0.0F);
/* 122 */       GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
/* 123 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/* 124 */       GL11.glRotatef(-20.0F, 0.0F, 0.0F, 1.0F);
/* 125 */       GL11.glRotatef(-45.0F, 1.0F, 0.0F, 0.0F);
/* 126 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 127 */       GL11.glRotatef(-110.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/* 129 */       if (stack.func_82837_s() && (stack.func_82833_r().equals("Dinnerbone") || stack.func_82833_r().equals("Grumm")))
/*     */       {
/* 131 */         GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */       
/* 134 */       GL11.glTranslatef(0.0F, 0.05F, 0.0F);
/*     */       
/* 136 */       float scale = 0.5F;
/* 137 */       GL11.glScalef(scale, scale, scale);
/* 138 */       ALRenderHelper.renderLightsaberHilt(data);
/*     */     } 
/*     */     
/* 141 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */