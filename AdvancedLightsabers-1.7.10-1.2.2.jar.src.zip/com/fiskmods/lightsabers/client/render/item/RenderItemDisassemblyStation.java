/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public enum RenderItemDisassemblyStation
/*    */   implements IItemRenderer
/*    */ {
/* 14 */   INSTANCE;
/*    */   RenderItemDisassemblyStation() {
/* 16 */     this.tile = (TileEntity)new TileEntityDisassemblyStation();
/*    */   }
/*    */   private final TileEntity tile;
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 21 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 27 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 33 */     float scale = 0.6F;
/* 34 */     GL11.glScalef(scale, scale, scale);
/*    */     
/* 36 */     if (type == IItemRenderer.ItemRenderType.ENTITY || type == IItemRenderer.ItemRenderType.INVENTORY) {
/*    */       
/* 38 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/* 39 */       GL11.glTranslatef(0.0F, -0.85F, -0.5F);
/*    */     }
/* 41 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*    */       
/* 43 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 44 */       GL11.glTranslatef(-0.5F, 0.0F, -1.5F);
/*    */     }
/* 46 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON || type == IItemRenderer.ItemRenderType.FIRST_PERSON_MAP) {
/*    */       
/* 48 */       GL11.glTranslatef(0.5F, 0.75F, 0.5F);
/*    */     } 
/*    */     
/* 51 */     TileEntityRendererDispatcher.field_147556_a.func_147549_a(this.tile, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */