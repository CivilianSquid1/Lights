/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class RenderItemHolocron
/*    */   implements IItemRenderer
/*    */ {
/* 14 */   private final TileEntity tile = (TileEntity)new TileEntityHolocron();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 19 */     return (type != IItemRenderer.ItemRenderType.INVENTORY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 25 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 31 */     if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*    */       
/* 33 */       GL11.glTranslatef(-0.5F, -0.25F, -0.5F);
/*    */     }
/* 35 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*    */       
/* 37 */       GL11.glTranslatef(0.25F, 0.25F, 0.25F);
/*    */     }
/* 39 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON || type == IItemRenderer.ItemRenderType.FIRST_PERSON_MAP) {
/*    */       
/* 41 */       GL11.glTranslatef(0.25F, 0.25F, 0.25F);
/*    */     } 
/*    */     
/* 44 */     this.tile.field_145847_g = item.func_77960_j();
/* 45 */     TileEntityRendererDispatcher.field_147556_a.func_147549_a(this.tile, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemHolocron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */