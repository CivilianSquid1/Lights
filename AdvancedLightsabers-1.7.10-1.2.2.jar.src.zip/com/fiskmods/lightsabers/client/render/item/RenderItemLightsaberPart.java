/*     */ package com.fiskmods.lightsabers.client.render.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.render.hilt.HiltRenderer;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderItemLightsaberPart
/*     */   implements IItemRenderer
/*     */ {
/*     */   public PartType partType;
/*     */   
/*     */   public RenderItemLightsaberPart(PartType type) {
/*  24 */     this.partType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/*  30 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/*  36 */     return (type == IItemRenderer.ItemRenderType.ENTITY || type == IItemRenderer.ItemRenderType.INVENTORY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack itemstack, Object... data) {
/*  42 */     Hilt hilt = ItemLightsaberPart.get(itemstack);
/*  43 */     HiltRenderer renderer = HiltRenderer.get(hilt);
/*     */     
/*  45 */     float scale = 0.4F;
/*  46 */     float height = (hilt.getPart(this.partType)).height;
/*  47 */     float f = height * (this.partType.isLowerPart() ? -1 : true) / 2.0F * 0.0625F;
/*     */     
/*  49 */     GL11.glPushMatrix();
/*  50 */     Minecraft.func_71410_x().func_110434_K().func_110577_a(renderer.getTexture(this.partType));
/*     */     
/*  52 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/*     */       
/*  54 */       GL11.glRotatef(-100.0F, 0.0F, 1.0F, 0.0F);
/*  55 */       GL11.glRotatef(-150.0F, 1.0F, 0.0F, 0.0F);
/*  56 */       GL11.glRotatef(5.0F, 0.0F, 0.0F, 1.0F);
/*  57 */       GL11.glTranslatef(0.0F, 0.15F, 0.9F);
/*     */     }
/*  59 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*     */       
/*  61 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/*  62 */       GL11.glRotatef(-150.0F, 1.0F, 0.0F, 0.0F);
/*  63 */       GL11.glRotatef(0.0F, 0.0F, 0.0F, 1.0F);
/*  64 */       GL11.glTranslatef(0.1F, 0.15F, 0.475F);
/*  65 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/*  66 */       GL11.glRotatef(-20.0F, 0.0F, 1.0F, 1.0F);
/*  67 */       GL11.glRotatef(-10.0F, 1.0F, 0.0F, 0.0F);
/*     */     }
/*  69 */     else if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*     */       
/*  71 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*     */     }
/*  73 */     else if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/*     */       
/*  75 */       GL11.glRotatef(-20.0F, 0.0F, 0.0F, 1.0F);
/*  76 */       GL11.glRotatef(-45.0F, 1.0F, 0.0F, 0.0F);
/*  77 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*  78 */       GL11.glTranslatef(0.0F, 0.05F, 0.0F);
/*  79 */       GL11.glRotatef(-110.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/*  81 */       if (this.partType == PartType.POMMEL && height <= 4.0F) {
/*     */         
/*  83 */         scale = 2.0F;
/*     */       }
/*     */       else {
/*     */         
/*  87 */         scale = 1.0F;
/*     */       } 
/*     */       
/*  90 */       if (height * scale > 20.0F)
/*     */       {
/*  92 */         scale = 20.0F / height;
/*     */       }
/*     */     } 
/*     */     
/*  96 */     if (scale != 1.0F)
/*     */     {
/*  98 */       GL11.glScalef(scale, scale, scale);
/*     */     }
/*     */     
/* 101 */     GL11.glTranslatef(0.0F, f, 0.0F);
/* 102 */     renderer.getModel(this.partType).func_78088_a(null, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F);
/* 103 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemLightsaberPart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */