/*    */ package com.fiskmods.lightsabers.client.render.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberStand;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public enum RenderItemLightsaberStand
/*    */   implements IItemRenderer
/*    */ {
/* 13 */   INSTANCE;
/*    */   RenderItemLightsaberStand() {
/* 15 */     this.tile = new TileEntityLightsaberStand();
/*    */   }
/*    */   private final TileEntityLightsaberStand tile;
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 20 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 26 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 32 */     float scale = 2.0F;
/*    */     
/* 34 */     if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/*    */       
/* 36 */       GL11.glScalef(scale, scale, scale);
/* 37 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 38 */       GL11.glTranslatef(-0.5F, -0.125F, -0.5F);
/*    */     }
/* 40 */     else if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*    */       
/* 42 */       GL11.glScalef(scale, scale, scale);
/* 43 */       GL11.glTranslatef(-0.5F, 0.0F, -0.5F);
/*    */     }
/* 45 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED || type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/*    */       
/* 47 */       GL11.glTranslatef(-0.5F, 0.25F, -0.5F);
/* 48 */       GL11.glScalef(scale, scale, scale);
/*    */     }
/*    */     else {
/*    */       
/* 52 */       GL11.glScalef(scale, scale, scale);
/*    */     } 
/*    */ 
/*    */     
/*    */     try {
/* 57 */       TileEntityRendererDispatcher.field_147556_a.func_147549_a((TileEntity)this.tile, 0.0D, 1.0D, 0.0D, 0.0F);
/*    */     }
/* 59 */     catch (Exception e) {
/*    */       
/* 61 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemLightsaberStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */