/*     */ package com.fiskmods.lightsabers.client.render.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.fiskmods.lightsabers.helper.ModelHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderItemDoubleLightsaber
/*     */   implements IItemRenderer
/*     */ {
/*     */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/*  25 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/*  31 */     return (type == IItemRenderer.ItemRenderType.ENTITY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack itemstack, Object... args) {
/*  37 */     LightsaberData[] array = ItemDoubleLightsaber.get(itemstack);
/*     */     
/*  39 */     GL11.glPushMatrix();
/*     */     
/*  41 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/*     */       
/*  43 */       GL11.glRotatef(-100.0F, 0.0F, 1.0F, 0.0F);
/*  44 */       GL11.glRotatef(-150.0F, 1.0F, 0.0F, 0.0F);
/*  45 */       GL11.glRotatef(95.0F, 0.0F, 0.0F, 1.0F);
/*  46 */       GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*  47 */       GL11.glTranslatef(-0.1F, -0.2F, 1.1F);
/*     */       
/*  49 */       if (args.length > 1 && args[1] instanceof EntityPlayer) {
/*     */         
/*  51 */         EntityPlayer player = (EntityPlayer)args[1];
/*  52 */         float f = player.field_70722_aY - (player.field_70722_aY - player.field_70721_aZ) * ClientEventHandler.renderTick;
/*  53 */         float f1 = MathHelper.func_76134_b((player.field_70754_ba - player.field_70721_aZ * (1.0F - ClientEventHandler.renderTick)) * 0.6662F) * 1.4F * f;
/*  54 */         float f2 = player.func_70678_g(ClientEventHandler.renderTick);
/*  55 */         float f3 = ((f2 > 0.5F) ? (1.0F - f2) : f2) * 2.0F;
/*  56 */         GL11.glRotatef(90.0F * f, 0.0F, 0.0F, 1.0F);
/*  57 */         GL11.glTranslatef(0.2F * f3 + 0.8F * f, 0.5F * f3, 0.4F * f);
/*  58 */         GL11.glRotatef(30.0F * f3, 1.0F, 0.0F, 0.0F);
/*  59 */         GL11.glRotatef(360.0F * f2, 0.0F, 0.0F, 1.0F);
/*     */       } 
/*     */       
/*  62 */       float scale = 0.2F;
/*  63 */       GL11.glScalef(scale, scale, scale);
/*  64 */       ALRenderHelper.renderLightsaber(array, itemstack, true);
/*     */     }
/*  66 */     else if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*     */       
/*  68 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/*  69 */       GL11.glRotatef(-150.0F, 1.0F, 0.0F, 0.0F);
/*  70 */       GL11.glTranslatef(-0.15F + LightsaberData.getHeight(itemstack) * 0.0015F, 0.14F, 0.75F);
/*     */       
/*  72 */       if (args[1] instanceof EntityLivingBase)
/*     */       {
/*  74 */         ModelHelper.applyLightsaberItemRotation((EntityLivingBase)args[1], itemstack);
/*     */       }
/*     */       
/*  77 */       float scale = 0.175F;
/*  78 */       GL11.glScalef(scale, scale, scale);
/*  79 */       ALRenderHelper.renderLightsaber(array, itemstack, true);
/*     */     }
/*  81 */     else if (type == IItemRenderer.ItemRenderType.ENTITY) {
/*     */       
/*  83 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*  84 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/*  86 */       if (((EntityItem)args[1]).field_70290_d != 0.0F)
/*     */       {
/*  88 */         GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/*     */       }
/*     */       
/*  91 */       float scale = 0.3F;
/*  92 */       GL11.glScalef(scale, scale, scale);
/*  93 */       ALRenderHelper.renderLightsaberHilt(array);
/*     */     }
/*  95 */     else if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/*     */       
/*  97 */       Tessellator tessellator = Tessellator.field_78398_a;
/*  98 */       float[] rgb = array[0].getRGB(itemstack);
/*  99 */       float triangle = 4.0F;
/*     */       
/* 101 */       GL11.glPushMatrix();
/* 102 */       GL11.glDisable(2896);
/* 103 */       GL11.glDisable(3553);
/* 104 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], 1.0F);
/* 105 */       tessellator.func_78371_b(4);
/* 106 */       tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/* 107 */       tessellator.func_78377_a(triangle, 0.0D, 0.0D);
/* 108 */       tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/* 109 */       tessellator.func_78381_a();
/* 110 */       rgb = array[1].getRGB(itemstack);
/* 111 */       GL11.glColor4f(rgb[0], rgb[1], rgb[2], 1.0F);
/* 112 */       tessellator.func_78371_b(4);
/* 113 */       tessellator.func_78377_a(0.0D, triangle, 0.0D);
/* 114 */       tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/* 115 */       tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/* 116 */       tessellator.func_78381_a();
/* 117 */       triangle /= 1.5F;
/* 118 */       GL11.glTranslatef(triangle / 8.0F, triangle / 8.0F, 0.0F);
/* 119 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/*     */       
/* 121 */       if (array[0].hasFocusingCrystal(FocusingCrystal.INVERTING)) {
/*     */         
/* 123 */         tessellator.func_78371_b(4);
/* 124 */         tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/* 125 */         tessellator.func_78377_a(triangle, 0.0D, 0.0D);
/* 126 */         tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/* 127 */         tessellator.func_78381_a();
/*     */       } 
/*     */       
/* 130 */       if (array[1].hasFocusingCrystal(FocusingCrystal.INVERTING)) {
/*     */         
/* 132 */         tessellator.func_78371_b(4);
/* 133 */         tessellator.func_78377_a(0.0D, triangle, 0.0D);
/* 134 */         tessellator.func_78377_a((triangle / 2.0F), (triangle / 2.0F), 0.0D);
/* 135 */         tessellator.func_78377_a(0.0D, 0.0D, 0.0D);
/* 136 */         tessellator.func_78381_a();
/*     */       } 
/*     */       
/* 139 */       GL11.glEnable(3553);
/* 140 */       GL11.glEnable(2896);
/* 141 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 142 */       GL11.glPopMatrix();
/* 143 */       GL11.glTranslatef(-2.0F, 3.0F, 0.0F);
/* 144 */       GL11.glScalef(10.0F, 10.0F, 10.0F);
/* 145 */       GL11.glTranslatef(1.0F, 0.5F, 1.0F);
/* 146 */       GL11.glScalef(1.0F, 1.0F, -1.0F);
/* 147 */       GL11.glRotatef(210.0F, 1.0F, 0.0F, 0.0F);
/* 148 */       GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
/* 149 */       GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/* 150 */       GL11.glRotatef(-20.0F, 0.0F, 0.0F, 1.0F);
/* 151 */       GL11.glRotatef(-45.0F, 1.0F, 0.0F, 0.0F);
/* 152 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 153 */       GL11.glRotatef(-110.0F, 0.0F, 1.0F, 0.0F);
/* 154 */       GL11.glTranslatef(0.0F, 0.05F, 0.05F);
/*     */       
/* 156 */       float scale = 0.3F;
/* 157 */       GL11.glScalef(scale, scale, scale);
/* 158 */       ALRenderHelper.renderLightsaberHilt(array);
/*     */     } 
/*     */     
/* 161 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\item\RenderItemDoubleLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */