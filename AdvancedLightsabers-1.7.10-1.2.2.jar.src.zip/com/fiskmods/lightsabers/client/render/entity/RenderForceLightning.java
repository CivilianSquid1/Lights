/*     */ package com.fiskmods.lightsabers.client.render.entity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.entity.EntityForceLightning;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderForceLightning
/*     */   extends Render
/*     */ {
/*     */   public void render(EntityForceLightning forceLightning, double x, double y, double z, float f, float partialTicks) {
/*  35 */     EntityClientPlayerMP entityClientPlayerMP = (Minecraft.func_71410_x()).field_71439_g;
/*  36 */     EntityLivingBase caster = forceLightning.entity;
/*     */     
/*  38 */     Vec3 src = caster.func_70666_h(partialTicks).func_72441_c(0.0D, VectorHelper.getOffset(caster), 0.0D);
/*     */     
/*  40 */     if (forceLightning.func_70089_S()) {
/*     */       
/*  42 */       x = src.field_72450_a - RenderManager.field_78725_b;
/*  43 */       y = src.field_72448_b - RenderManager.field_78726_c;
/*  44 */       z = src.field_72449_c - RenderManager.field_78723_d;
/*     */       
/*  46 */       GL11.glPushMatrix();
/*  47 */       GL11.glTranslated(x, y, z);
/*  48 */       ALRenderHelper.setupRenderLightning();
/*  49 */       renderLightning(caster, StatusEffect.getTargets(caster, Effect.DRAIN), Vec3.func_72443_a(1.0D, 0.4000000059604645D, 0.0D), 2, partialTicks);
/*     */       
/*  51 */       StatusEffect effect = StatusEffect.get(caster, Effect.LIGHTNING);
/*     */       
/*  53 */       if (effect != null) {
/*     */         
/*  55 */         Random rand = new Random((caster.field_70173_aa * 100000));
/*  56 */         EntityLivingBase target = ALHelper.getForceLightningTarget(caster);
/*  57 */         Vec3 color = Vec3.func_72443_a(0.0D, 0.0D, 1.0D);
/*     */         
/*  59 */         for (int hand = 0; hand < 2; hand++) {
/*     */           
/*  61 */           for (int j = 0; j < 2 + effect.amplifier; j++) {
/*     */             
/*  63 */             Vec3 dst = Vec3.func_72443_a(0.0D, 0.0D, 7.0D);
/*  64 */             dst.func_72440_a(-(caster.field_70125_A + (caster.field_70125_A - caster.field_70127_C) * partialTicks) * 3.1415927F / 180.0F);
/*  65 */             dst.func_72442_b(-(caster.field_70759_as + (caster.field_70759_as - caster.field_70758_at) * partialTicks) * 3.1415927F / 180.0F);
/*  66 */             dst = VectorHelper.add(caster.func_70666_h(partialTicks), dst).func_72441_c(0.0D, 0.0D, 0.0D);
/*     */             
/*  68 */             Vec3 targetVec = null;
/*  69 */             MovingObjectPosition rayTrace = caster.field_70170_p.func_72933_a(src, VectorHelper.copy(dst));
/*     */             
/*  71 */             if (rayTrace == null) {
/*     */               
/*  73 */               targetVec = dst;
/*     */             }
/*     */             else {
/*     */               
/*  77 */               targetVec = rayTrace.field_72307_f;
/*     */             } 
/*     */             
/*  80 */             if (target != null)
/*     */             {
/*  82 */               targetVec = target.func_70666_h(partialTicks).func_72441_c(0.0D, (target.field_70131_O / 2.0F), 0.0D);
/*     */             }
/*     */             
/*  85 */             renderLightning(caster, targetVec, color, rand, 1.5F + effect.amplifier * 0.5F, (hand == 0), partialTicks);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  90 */       ALRenderHelper.finishRenderLightning();
/*  91 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderLightning(EntityLivingBase caster, List<EntityLivingBase> targets, Vec3 color, int lightningAmount, float partialTicks) {
/*  97 */     Random rand = new Random((caster.field_70173_aa * 100000));
/*  98 */     EntityClientPlayerMP entityClientPlayerMP = (Minecraft.func_71410_x()).field_71439_g;
/*     */     
/* 100 */     for (EntityLivingBase target : targets) {
/*     */       
/* 102 */       Vec3 targetVec = target.func_70666_h(partialTicks).func_72441_c(0.0D, VectorHelper.getOffset(target), 0.0D);
/*     */       
/* 104 */       for (int j = 0; j < lightningAmount; j++)
/*     */       {
/* 106 */         renderLightning(caster, targetVec, color, rand, 1.0F, partialTicks);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderLightning(EntityLivingBase caster, Vec3 targetVec, Vec3 color, Random rand, float spreadFactor, float partialTicks) {
/* 113 */     renderLightning(caster, targetVec, color, rand, spreadFactor, true, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderLightning(EntityLivingBase caster, Vec3 targetVec, Vec3 color, Random rand, float spreadFactor, boolean hand, float partialTicks) {
/* 118 */     Vec3 src = Vec3.func_72443_a((-0.275F * (hand ? true : -1)), -0.25D, 0.800000011920929D);
/* 119 */     Vec3 dst = caster.func_70666_h(partialTicks).func_72441_c(0.0D, VectorHelper.getOffset(caster), 0.0D).func_72444_a(targetVec);
/* 120 */     Vec3 dst1 = VectorHelper.copy(dst);
/* 121 */     Vec3 dst2 = VectorHelper.copy(dst);
/*     */     
/* 123 */     boolean firstPerson = (caster == (Minecraft.func_71410_x()).field_71439_g && (Minecraft.func_71410_x()).field_71474_y.field_74320_O == 0);
/* 124 */     double amount = Math.min(src.func_72438_d(dst) * 0.05D, 1.0D) * (firstPerson ? 0.75D : 1.0D);
/* 125 */     double srcSpread = Math.min(firstPerson ? 0.05D : 0.15D, amount);
/* 126 */     double dstSpread = Math.min(0.2D, amount) * spreadFactor;
/* 127 */     double d = 0.33D;
/* 128 */     double d1 = 0.66D;
/*     */     
/* 130 */     if (firstPerson)
/*     */     {
/* 132 */       src = Vec3.func_72443_a((-0.45F * (hand ? true : -1)), -0.25D, 0.6000000238418579D);
/*     */     }
/*     */     
/* 135 */     Vec3[] asrc = { src, VectorHelper.copy(src) };
/* 136 */     Vec3[] adst = { dst, VectorHelper.copy(dst) };
/* 137 */     Vec3[] adst1 = { dst1, VectorHelper.copy(dst1) };
/* 138 */     Vec3[] adst2 = { dst2, VectorHelper.copy(dst2) };
/*     */     
/* 140 */     for (int i = 0; i < 2; i++) {
/*     */       
/* 142 */       asrc[i].func_72440_a(-ALRenderHelper.median(caster.field_70125_A, caster.field_70127_C) * 3.1415927F / 180.0F);
/* 143 */       asrc[i].func_72442_b(-ALRenderHelper.median(caster.field_70177_z, caster.field_70126_B) * 3.1415927F / 180.0F);
/* 144 */       (asrc[i]).field_72450_a += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * srcSpread;
/* 145 */       (asrc[i]).field_72448_b += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * srcSpread;
/* 146 */       (asrc[i]).field_72449_c += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * srcSpread;
/* 147 */       (adst1[i]).field_72450_a = (adst[i]).field_72450_a * d + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 148 */       (adst1[i]).field_72448_b = (adst[i]).field_72448_b * d + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 149 */       (adst1[i]).field_72449_c = (adst[i]).field_72449_c * d + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 150 */       (adst2[i]).field_72450_a = (adst[i]).field_72450_a * d1 + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 151 */       (adst2[i]).field_72448_b = (adst[i]).field_72448_b * d1 + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 152 */       (adst2[i]).field_72449_c = (adst[i]).field_72449_c * d1 + MathHelper.func_82716_a(rand, -1.0D, 1.0D) * amount;
/* 153 */       (adst[i]).field_72450_a += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * 0.125D;
/* 154 */       (adst[i]).field_72448_b += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * 0.125D;
/* 155 */       (adst[i]).field_72449_c += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * 0.125D;
/* 156 */       (adst1[i]).field_72450_a += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d;
/* 157 */       (adst1[i]).field_72448_b += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d;
/* 158 */       (adst1[i]).field_72449_c += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d;
/* 159 */       (adst2[i]).field_72450_a += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d1;
/* 160 */       (adst2[i]).field_72448_b += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d1;
/* 161 */       (adst2[i]).field_72449_c += MathHelper.func_82716_a(rand, -1.0D, 1.0D) * dstSpread * d1;
/*     */       
/* 163 */       rand.setSeed(((caster.field_70173_aa - 1) * 100000));
/*     */     } 
/*     */     
/* 166 */     src = VectorHelper.add(asrc[1], VectorHelper.multiply(asrc[1].func_72444_a(asrc[0]), partialTicks));
/* 167 */     dst = VectorHelper.add(adst[1], VectorHelper.multiply(adst[1].func_72444_a(adst[0]), partialTicks));
/* 168 */     dst1 = VectorHelper.add(adst1[1], VectorHelper.multiply(adst1[1].func_72444_a(adst1[0]), partialTicks));
/* 169 */     dst2 = VectorHelper.add(adst2[1], VectorHelper.multiply(adst2[1].func_72444_a(adst2[0]), partialTicks));
/*     */     
/* 171 */     float opacity = 1.0F;
/* 172 */     float lineWidth = (5 * (firstPerson ? 2 : 1));
/* 173 */     float innerLineWidth = (1 * (firstPerson ? 2 : 1));
/* 174 */     ALRenderHelper.drawLightningLine(src, dst1, lineWidth, innerLineWidth, color, opacity);
/* 175 */     ALRenderHelper.drawLightningLine(dst1, dst2, lineWidth, innerLineWidth, color, opacity);
/* 176 */     ALRenderHelper.drawLightningLine(dst2, dst, lineWidth, innerLineWidth, color, opacity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(Entity entity, double x, double y, double z, float f, float partialTicks) {
/* 182 */     render((EntityForceLightning)entity, x, y, z, f, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation func_110775_a(Entity entity) {
/* 188 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\entity\RenderForceLightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */