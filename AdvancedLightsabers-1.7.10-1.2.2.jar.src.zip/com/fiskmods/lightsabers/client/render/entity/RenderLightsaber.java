/*    */ package com.fiskmods.lightsabers.client.render.entity;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.entity.EntityLightsaber;
/*    */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*    */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderLightsaber
/*    */   extends Render
/*    */ {
/*    */   public void render(EntityLightsaber entity, double x, double y, double z, float f, float partialTicks) {
/* 23 */     GL11.glPushMatrix();
/* 24 */     GL11.glTranslatef((float)x, (float)y + 0.03F, (float)z);
/* 25 */     GL11.glRotatef(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks - 90.0F, 0.0F, 1.0F, 0.0F);
/* 26 */     GL11.glRotatef(entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks, 0.0F, 0.0F, 1.0F);
/*    */     
/* 28 */     float scale = 0.2F;
/* 29 */     float spin = (entity.field_70173_aa + partialTicks) * 40.0F;
/*    */     
/* 31 */     GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/* 32 */     GL11.glRotatef(spin, 1.0F, 0.0F, 0.0F);
/* 33 */     GL11.glScalef(scale, scale, scale);
/* 34 */     renderLightsaber(entity, x, y, z, spin, partialTicks);
/* 35 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderLightsaber(EntityLightsaber entity, double x, double y, double z, float spin, float partialTicks) {
/* 40 */     ItemStack itemstack = entity.getItem();
/*    */     
/* 42 */     if (itemstack != null)
/*    */     {
/* 44 */       if (itemstack.func_77973_b() == ModItems.doubleLightsaber) {
/*    */         
/* 46 */         if (entity.data == null)
/*    */         {
/* 48 */           entity.data = ItemDoubleLightsaber.get(itemstack);
/*    */         }
/*    */         
/* 51 */         ALRenderHelper.renderLightsaber((LightsaberData[])entity.data, itemstack, true);
/*    */       }
/*    */       else {
/*    */         
/* 55 */         if (entity.data == null)
/*    */         {
/* 57 */           entity.data = LightsaberData.get(itemstack);
/*    */         }
/*    */         
/* 60 */         ALRenderHelper.renderLightsaber((LightsaberData)entity.data, itemstack, true);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_76986_a(Entity entity, double x, double y, double z, float f, float partialTicks) {
/* 74 */     render((EntityLightsaber)entity, x, y, z, f, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\entity\RenderLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */