/*    */ package com.fiskmods.lightsabers.client.render.entity;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.ModelSithGhost;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.renderer.entity.RenderBiped;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderSithGhost
/*    */   extends RenderBiped
/*    */ {
/* 15 */   private static final ResourceLocation textures = new ResourceLocation("lightsabers", "textures/models/sith_ghost.png");
/*    */ 
/*    */   
/*    */   public RenderSithGhost() {
/* 19 */     super((ModelBiped)new ModelSithGhost(), 0.5F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 25 */     return textures;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\entity\RenderSithGhost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */