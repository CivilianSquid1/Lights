/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelSithStoneCoffin;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderSithStoneCoffin
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 15 */   private ResourceLocation texture = new ResourceLocation("lightsabers", "textures/models/sith_stone_coffin.png");
/* 16 */   private ModelSithStoneCoffin model = new ModelSithStoneCoffin();
/*    */ 
/*    */   
/*    */   public void render(TileEntitySithStoneCoffin tileentity, double x, double y, double z, float partialTicks) {
/* 20 */     int metadata = 0;
/*    */     
/* 22 */     if (tileentity.func_145831_w() != null)
/*    */     {
/* 24 */       metadata = tileentity.func_145832_p();
/*    */     }
/*    */     
/* 27 */     GL11.glPushMatrix();
/* 28 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/* 29 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 30 */     GL11.glRotatef((metadata * 90), 0.0F, 1.0F, 0.0F);
/*    */     
/* 32 */     if (metadata < 4) {
/*    */       
/* 34 */       func_147499_a(this.texture);
/* 35 */       this.model.render(tileentity);
/*    */     } 
/*    */     
/* 38 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tileentity, double d, double d1, double d2, float f) {
/* 44 */     render((TileEntitySithStoneCoffin)tileentity, d, d1, d2, f);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderSithStoneCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */