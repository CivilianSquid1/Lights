/*     */ package com.fiskmods.lightsabers.client.render.tile;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderHolocron
/*     */   extends TileEntitySpecialRenderer
/*     */ {
/*     */   public void render(TileEntityHolocron tile, double x, double y, double z, float partialTicks) {
/*  21 */     int metadata = 0;
/*     */     
/*  23 */     if (tile.func_145831_w() != null || tile.field_145847_g != -1)
/*     */     {
/*  25 */       metadata = tile.func_145832_p();
/*     */     }
/*     */     
/*  28 */     Tessellator tessellator = Tessellator.field_78398_a;
/*     */     
/*  30 */     GL11.glPushMatrix();
/*  31 */     GL11.glTranslatef((float)x + 0.5F, (float)y, (float)z + 0.5F);
/*     */ 
/*     */ 
/*     */     
/*  35 */     GL11.glDisable(2896);
/*  36 */     GL11.glEnable(3042);
/*  37 */     GL11.glAlphaFunc(516, 0.1F);
/*  38 */     OpenGlHelper.func_148821_a(770, 771, 1, 0);
/*     */     
/*  40 */     tessellator.func_78375_b(0.0F, 10.0F, 10.0F);
/*  41 */     func_147499_a(TextureMap.field_110575_b);
/*  42 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  44 */     if (metadata == 0) {
/*     */       
/*  46 */       renderJediHolocron(tile, metadata, tessellator, partialTicks);
/*     */     }
/*  48 */     else if (metadata == 1) {
/*     */       
/*  50 */       renderSithHolocron(tile, metadata, tessellator, partialTicks);
/*     */     } 
/*     */     
/*  53 */     GL11.glEnable(3553);
/*  54 */     GL11.glEnable(2896);
/*  55 */     GL11.glDisable(3042);
/*  56 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderJediHolocron(TileEntityHolocron tile, int metadata, Tessellator tessellator, float partialTicks) {
/*  61 */     IIcon iconSide = ModBlocks.holocron.func_149691_a(0, metadata);
/*  62 */     IIcon iconCorner = ModBlocks.holocron.func_149691_a(1, metadata);
/*  63 */     IIcon iconCornerBottom = ModBlocks.holocron.func_149691_a(2, metadata);
/*  64 */     IIcon iconCornerSide = ModBlocks.holocron.func_149691_a(3, metadata);
/*     */     
/*  66 */     float minU = iconSide.func_94214_a(0.0D);
/*  67 */     float maxU = iconSide.func_94214_a(16.0D);
/*  68 */     float minV = iconSide.func_94207_b(0.0D);
/*  69 */     float maxV = iconSide.func_94207_b(16.0D);
/*  70 */     float size = 0.5F;
/*  71 */     float width = 0.707F * size;
/*  72 */     float width1 = MathHelper.func_76129_c(width * width - width / 2.0F * width / 2.0F);
/*  73 */     float height = size * 0.2875F;
/*  74 */     float t = ALRenderHelper.median(tile.openTicks, tile.prevOpenTicks);
/*  75 */     float f = ALRenderHelper.median(tile.openTimer, tile.prevOpenTimer);
/*  76 */     float f1 = MathHelper.func_76126_a(t / 10.0F) / 20.0F;
/*  77 */     float offset = size * (0.5775F + f * (0.3F + f1));
/*  78 */     float rot = 180.0F * f;
/*     */     
/*  80 */     GL11.glTranslatef(0.0F, size / 2.0F + (size / 2.0F + f1) * f, 0.0F);
/*     */     int i;
/*  82 */     for (i = 0; i < 6; i++) {
/*     */       
/*  84 */       tessellator.func_78382_b();
/*  85 */       tessellator.func_78374_a((-size / 2.0F), 0.0D, (size / 2.0F), maxU, maxV);
/*  86 */       tessellator.func_78374_a(0.0D, (-size / 2.0F), (size / 2.0F), maxU, minV);
/*  87 */       tessellator.func_78374_a((size / 2.0F), 0.0D, (size / 2.0F), minU, minV);
/*  88 */       tessellator.func_78374_a(0.0D, (size / 2.0F), (size / 2.0F), minU, maxV);
/*     */       
/*  90 */       GL11.glPushMatrix();
/*     */       
/*  92 */       if (i < 4) {
/*     */         
/*  94 */         GL11.glRotatef((i * 90), 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */       else {
/*     */         
/*  98 */         GL11.glRotatef(((i - 4) * 180 + 90), 1.0F, 0.0F, 0.0F);
/*     */       } 
/*     */       
/* 101 */       tessellator.func_78381_a();
/* 102 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 105 */     for (i = 0; i < 2; i++) {
/*     */       
/* 107 */       for (int j = 0; j < 4; j++) {
/*     */         
/* 109 */         tessellator.func_78371_b(4);
/* 110 */         minU = iconCorner.func_94214_a(0.0D);
/* 111 */         maxU = iconCorner.func_94214_a(8.0D);
/* 112 */         minV = iconCorner.func_94207_b(0.0D);
/* 113 */         maxV = iconCorner.func_94207_b(16.0D);
/* 114 */         tessellator.func_78374_a((-size / 4.0F), (size / 2.0F), (size / 4.0F), maxU, minV);
/* 115 */         tessellator.func_78374_a((-size / 2.0F), (size / 2.0F), 0.0D, minU, minV);
/* 116 */         tessellator.func_78374_a((-size / 2.0F), 0.0D, (size / 2.0F), minU, maxV);
/* 117 */         minU = iconCorner.func_94214_a(16.0D);
/* 118 */         maxU = iconCorner.func_94214_a(8.0D);
/* 119 */         tessellator.func_78374_a((-size / 2.0F), 0.0D, (size / 2.0F), minU, maxV);
/* 120 */         tessellator.func_78374_a(0.0D, (size / 2.0F), (size / 2.0F), minU, minV);
/* 121 */         tessellator.func_78374_a((-size / 4.0F), (size / 2.0F), (size / 4.0F), maxU, minV);
/*     */         
/* 123 */         GL11.glPushMatrix();
/* 124 */         GL11.glRotatef((j * 90), 0.0F, 1.0F, 0.0F);
/*     */         
/* 126 */         if (i == 1)
/*     */         {
/* 128 */           GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*     */         }
/*     */         
/* 131 */         tessellator.func_78381_a();
/* 132 */         GL11.glPopMatrix();
/*     */         
/* 134 */         tessellator.func_78371_b(4);
/* 135 */         minU = iconCornerBottom.func_94214_a(0.0D);
/* 136 */         maxU = iconCornerBottom.func_94214_a(8.0D);
/* 137 */         minV = iconCornerBottom.func_94207_b(0.0D);
/* 138 */         maxV = iconCornerBottom.func_94207_b(16.0D);
/* 139 */         tessellator.func_78374_a(0.0D, ((width1 + width1) / 3.0F), 0.0D, minU, maxV);
/* 140 */         tessellator.func_78374_a((width / 2.0F), (-width1 / 3.0F), 0.0D, minU, minV);
/* 141 */         tessellator.func_78374_a(0.0D, (-width1 / 3.0F), 0.0D, maxU, minV);
/* 142 */         minU = iconCornerBottom.func_94214_a(8.0D);
/* 143 */         maxU = iconCornerBottom.func_94214_a(16.0D);
/* 144 */         tessellator.func_78374_a(0.0D, (-width1 / 3.0F), 0.0D, minU, minV);
/* 145 */         tessellator.func_78374_a((-width / 2.0F), (-width1 / 3.0F), 0.0D, maxU, minV);
/* 146 */         tessellator.func_78374_a(0.0D, ((width1 + width1) / 3.0F), 0.0D, maxU, maxV);
/*     */         
/* 148 */         GL11.glPushMatrix();
/* 149 */         GL11.glRotatef((45 + j * 90), 0.0F, 1.0F, 0.0F);
/* 150 */         GL11.glRotatef(35.0F, 1.0F, 0.0F, 0.0F);
/* 151 */         GL11.glRotatef(rot, 0.0F, 0.0F, 1.0F);
/*     */         
/* 153 */         if (i == 1)
/*     */         {
/* 155 */           GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*     */         }
/*     */         
/* 158 */         GL11.glTranslatef(0.0F, 0.0F, offset);
/* 159 */         tessellator.func_78381_a();
/*     */         
/* 161 */         for (int k = 0; k < 3; k++) {
/*     */           
/* 163 */           tessellator.func_78371_b(4);
/* 164 */           minU = iconCornerSide.func_94214_a(8.0D);
/* 165 */           maxU = iconCornerSide.func_94214_a(16.0D);
/* 166 */           minV = iconCornerSide.func_94207_b(0.0D);
/* 167 */           maxV = iconCornerSide.func_94207_b(16.0D);
/* 168 */           tessellator.func_78374_a(0.0D, (-width1 / 3.0F), 0.0D, minU, maxV);
/* 169 */           tessellator.func_78374_a(0.0D, 0.0D, height, maxU, minV);
/* 170 */           tessellator.func_78374_a((-width / 2.0F), (-width1 / 3.0F), 0.0D, maxU, maxV);
/* 171 */           minU = iconCornerSide.func_94214_a(0.0D);
/* 172 */           maxU = iconCornerSide.func_94214_a(8.0D);
/* 173 */           tessellator.func_78374_a(0.0D, (-width1 / 3.0F), 0.0D, maxU, maxV);
/* 174 */           tessellator.func_78374_a((width / 2.0F), (-width1 / 3.0F), 0.0D, minU, maxV);
/* 175 */           tessellator.func_78374_a(0.0D, 0.0D, height, minU, minV);
/* 176 */           GL11.glRotatef(120.0F, 0.0F, 0.0F, 1.0F);
/* 177 */           tessellator.func_78381_a();
/*     */         } 
/*     */         
/* 180 */         GL11.glPopMatrix();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderSithHolocron(TileEntityHolocron tile, int metadata, Tessellator tessellator, float partialTicks) {
/* 187 */     IIcon iconBottom = ModBlocks.holocron.func_149691_a(0, metadata);
/* 188 */     IIcon iconSide = ModBlocks.holocron.func_149691_a(1, metadata);
/*     */     
/* 190 */     float minU = iconBottom.func_94214_a(0.0D);
/* 191 */     float maxU = iconBottom.func_94214_a(16.0D);
/* 192 */     float minV = iconBottom.func_94207_b(0.0D);
/* 193 */     float maxV = iconBottom.func_94207_b(16.0D);
/* 194 */     float size = 0.5F;
/* 195 */     float t = ALRenderHelper.median(tile.openTicks, tile.prevOpenTicks);
/* 196 */     float f = ALRenderHelper.median(tile.openTimer, tile.prevOpenTimer);
/* 197 */     float f1 = MathHelper.func_76126_a(t / 10.0F) / 20.0F;
/* 198 */     float offset = size * (0.5775F + f * (0.3F + f1));
/* 199 */     float rot = 180.0F * f;
/* 200 */     float height = size;
/*     */     
/* 202 */     GL11.glDisable(2884);
/* 203 */     GL11.glTranslatef(0.0F, size / 2.0F + (size / 2.0F + f1) * f + 1.0E-4F, 0.0F);
/* 204 */     tessellator.func_78382_b();
/* 205 */     tessellator.func_78374_a((size / 2.0F), (-size / 2.0F), (-size / 2.0F), maxU, minV);
/* 206 */     tessellator.func_78374_a((size / 2.0F), (-size / 2.0F), (size / 2.0F), maxU, maxV);
/* 207 */     tessellator.func_78374_a((-size / 2.0F), (-size / 2.0F), (size / 2.0F), minU, maxV);
/* 208 */     tessellator.func_78374_a((-size / 2.0F), (-size / 2.0F), (-size / 2.0F), minU, minV);
/* 209 */     tessellator.func_78381_a();
/*     */     
/* 211 */     for (int i = 0; i < 4; i++) {
/*     */       
/* 213 */       tessellator.func_78371_b(4);
/* 214 */       minU = iconSide.func_94214_a(0.0D);
/* 215 */       maxU = iconSide.func_94214_a(8.0D);
/* 216 */       minV = iconSide.func_94207_b(0.0D);
/* 217 */       maxV = iconSide.func_94207_b(16.0D);
/* 218 */       tessellator.func_78374_a((size / 2.0F), (-size / 2.0F), (-size / 2.0F), minU, maxV);
/* 219 */       tessellator.func_78374_a(0.0D, (-size / 2.0F), (-size / 2.0F), maxU, maxV);
/* 220 */       tessellator.func_78374_a(0.0D, (size / 2.0F), 0.0D, minU, minV);
/* 221 */       minU = iconSide.func_94214_a(8.0D);
/* 222 */       maxU = iconSide.func_94214_a(16.0D);
/* 223 */       tessellator.func_78374_a(0.0D, (-size / 2.0F), (-size / 2.0F), minU, maxV);
/* 224 */       tessellator.func_78374_a((-size / 2.0F), (-size / 2.0F), (-size / 2.0F), maxU, maxV);
/* 225 */       tessellator.func_78374_a(0.0D, (size / 2.0F), 0.0D, maxU, minV);
/* 226 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 227 */       tessellator.func_78381_a();
/*     */     } 
/*     */     
/* 230 */     GL11.glEnable(2884);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_147500_a(TileEntity tileentity, double x, double y, double z, float partialTicks) {
/* 236 */     render((TileEntityHolocron)tileentity, x, y, z, partialTicks);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderHolocron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */