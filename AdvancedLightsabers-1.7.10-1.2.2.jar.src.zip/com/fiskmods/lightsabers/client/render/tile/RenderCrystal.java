/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelCrystal;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*    */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderCrystal
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 16 */   private final ModelCrystal model = new ModelCrystal();
/*    */ 
/*    */   
/*    */   public void render(TileEntityCrystal tile, double x, double y, double z, float partialTicks) {
/* 20 */     float alpha = 0.6F;
/* 21 */     GL11.glPushMatrix();
/* 22 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/* 23 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/*    */     
/* 25 */     if (tile.func_145831_w() != null) {
/*    */       
/* 27 */       adjustRotation(tile, tile.func_145832_p());
/*    */     }
/*    */     else {
/*    */       
/* 31 */       alpha *= ALRenderHelper.getAlpha();
/*    */     } 
/*    */     
/* 34 */     float[] rgb = tile.getColor().getRGB();
/* 35 */     GL11.glColor4f(rgb[0], rgb[1], rgb[2], alpha);
/* 36 */     GL11.glDisable(3553);
/* 37 */     GL11.glEnable(3042);
/* 38 */     GL11.glBlendFunc(770, 771);
/* 39 */     ALRenderHelper.setLighting(61680);
/* 40 */     this.model.render();
/* 41 */     ALRenderHelper.resetLighting();
/* 42 */     GL11.glEnable(3553);
/* 43 */     GL11.glDisable(3042);
/* 44 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   
/*    */   public void adjustRotation(TileEntityCrystal tile, int metadata) {
/* 49 */     if (metadata > 0 && metadata < 5) {
/*    */       
/* 51 */       int[] matrix = { 0, 2, 1, 3 };
/* 52 */       GL11.glRotatef((matrix[metadata - 1] * 90), 0.0F, 1.0F, 0.0F);
/*    */     } 
/*    */     
/* 55 */     if (metadata == 6) {
/*    */       
/* 57 */       GL11.glTranslatef(0.0F, 2.0F, 0.0F);
/* 58 */       GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*    */     } 
/*    */     
/* 61 */     if (metadata != 5 && metadata != 6) {
/*    */       
/* 63 */       GL11.glTranslatef(1.0F, 1.0F, 0.0F);
/* 64 */       GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/*    */     } 
/*    */     
/* 67 */     Random rand = new Random((tile.field_145851_c + tile.field_145848_d + tile.field_145849_e));
/* 68 */     GL11.glRotatef(rand.nextInt(360), 0.0F, 1.0F, 0.0F);
/* 69 */     GL11.glTranslatef(0.0F, rand.nextInt(10) / 40.0F, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tile, double x, double y, double z, float partialTicks) {
/* 75 */     render((TileEntityCrystal)tile, x, y, z, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */