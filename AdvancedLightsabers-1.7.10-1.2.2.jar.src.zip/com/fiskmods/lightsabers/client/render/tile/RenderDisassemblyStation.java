/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.block.BlockDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderDisassemblyStation
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 17 */   private static final ResourceLocation TEXTURE = new ResourceLocation("lightsabers", "textures/models/disassembly_station.png");
/* 18 */   private static final ResourceLocation TEXTURE_LIGHTS = new ResourceLocation("lightsabers", "textures/models/disassembly_station_lights.png");
/* 19 */   private static final ModelDisassemblyStation MODEL = new ModelDisassemblyStation();
/*    */ 
/*    */   
/*    */   public void render(TileEntityDisassemblyStation tile, double x, double y, double z, float partialTicks) {
/* 23 */     int metadata = 0;
/*    */     
/* 25 */     if (tile.func_145831_w() != null)
/*    */     {
/* 27 */       metadata = tile.func_145832_p();
/*    */     }
/*    */     
/* 30 */     GL11.glPushMatrix();
/* 31 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/* 32 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 33 */     GL11.glRotatef((BlockDisassemblyStation.getRotation(metadata) * 90 + 180), 0.0F, 1.0F, 0.0F);
/* 34 */     GL11.glTranslatef(0.5F, 0.0F, 0.0F);
/* 35 */     func_147499_a(TEXTURE);
/* 36 */     MODEL.render(0.0625F);
/* 37 */     ALRenderHelper.setLighting(61680);
/* 38 */     func_147499_a(TEXTURE_LIGHTS);
/* 39 */     MODEL.render(0.0625F);
/* 40 */     ALRenderHelper.resetLighting();
/* 41 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tile, double x, double y, double z, float partialTicks) {
/* 47 */     render((TileEntityDisassemblyStation)tile, x, y, z, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */