/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelSithCoffin;
/*    */ import com.fiskmods.lightsabers.common.block.BlockSithCoffin;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderSithCoffin
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 16 */   private ResourceLocation texture = new ResourceLocation("lightsabers", "textures/models/sith_coffin.png");
/* 17 */   private ModelSithCoffin model = new ModelSithCoffin();
/*    */ 
/*    */   
/*    */   public void render(TileEntitySithCoffin tileentity, double x, double y, double z, float partialTicks) {
/* 21 */     int metadata = 0;
/*    */     
/* 23 */     if (tileentity.func_145831_w() != null)
/*    */     {
/* 25 */       metadata = tileentity.func_145832_p();
/*    */     }
/*    */     
/* 28 */     GL11.glPushMatrix();
/* 29 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/* 30 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 31 */     GL11.glRotatef((metadata * 90 + 180), 0.0F, 1.0F, 0.0F);
/*    */     
/* 33 */     if (!BlockSithCoffin.isBlockFrontOfCoffin(metadata)) {
/*    */       
/* 35 */       func_147499_a(this.texture);
/* 36 */       this.model.render(tileentity);
/*    */     } 
/*    */     
/* 39 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tileentity, double x, double y, double z, float partialTicks) {
/* 45 */     render((TileEntitySithCoffin)tileentity, x, y, z, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */