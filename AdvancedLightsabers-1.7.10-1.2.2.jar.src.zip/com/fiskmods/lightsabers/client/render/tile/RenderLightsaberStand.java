/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelLightsaberStand;
/*    */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberStand;
/*    */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderLightsaberStand
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 21 */   private ResourceLocation texture = new ResourceLocation("lightsabers", "textures/models/lightsaber_stand.png");
/* 22 */   private ModelLightsaberStand model = new ModelLightsaberStand();
/*    */ 
/*    */   
/*    */   public void render(TileEntityLightsaberStand tile, double x, double y, double z, float partialTicks) {
/* 26 */     ItemStack stack = tile.getDisplayStack();
/* 27 */     float scale = 0.15F;
/*    */     
/* 29 */     GL11.glPushMatrix();
/* 30 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F);
/* 31 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 32 */     this.model.rStandTip.field_78800_c = 2.5F;
/* 33 */     this.model.lStandTip.field_78800_c = -3.5F;
/*    */     
/* 35 */     if (tile.func_145831_w() != null) {
/*    */       
/* 37 */       adjustRotation(tile, tile.func_145832_p());
/*    */       
/* 39 */       if (stack != null && stack.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaber) {
/*    */         
/* 41 */         LightsaberData data = LightsaberData.get(stack);
/* 42 */         float f = Math.min(data.getHeightCm() - 25.0F, 0.0F) * 0.2F;
/*    */         
/* 44 */         this.model.rStandTip.field_78800_c += f;
/* 45 */         this.model.lStandTip.field_78800_c -= f;
/*    */       } 
/*    */     } 
/*    */     
/* 49 */     func_147499_a(this.texture);
/* 50 */     this.model.render();
/*    */     
/* 52 */     if (tile.func_145831_w() != null && stack != null) {
/*    */       
/* 54 */       GL11.glTranslatef(0.0F, 1.36F, 0.0F);
/* 55 */       GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/*    */       
/* 57 */       GL11.glScalef(scale, scale, scale);
/* 58 */       GL11.glEnable(32826);
/*    */       
/* 60 */       if (stack.func_77973_b() instanceof ItemDoubleLightsaber) {
/*    */         
/* 62 */         LightsaberData[] data = ItemDoubleLightsaber.get(stack);
/* 63 */         ALRenderHelper.renderLightsaberHilt(data);
/*    */       }
/*    */       else {
/*    */         
/* 67 */         LightsaberData data = LightsaberData.get(stack);
/* 68 */         ALRenderHelper.renderLightsaberHilt(data);
/*    */       } 
/*    */       
/* 71 */       GL11.glDisable(32826);
/*    */     } 
/*    */     
/* 74 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   
/*    */   public void adjustRotation(TileEntityLightsaberStand tile, int metadata) {
/* 79 */     if (metadata > 1) {
/*    */       
/* 81 */       int[] matrix = { 2, 0, 1, 3 };
/* 82 */       GL11.glRotatef((90 * matrix[Math.min(metadata - 2, 3)]), 0.0F, 1.0F, 0.0F);
/* 83 */       GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*    */     }
/* 85 */     else if (metadata == 1) {
/*    */       
/* 87 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/*    */     } 
/*    */     
/* 90 */     GL11.glTranslatef(0.0F, -1.0F, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tile, double x, double y, double z, float partialTicks) {
/* 96 */     render((TileEntityLightsaberStand)tile, x, y, z, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderLightsaberStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */