/*    */ package com.fiskmods.lightsabers.client.render.tile;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.tile.ModelLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.block.BlockLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderLightsaberForge
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 17 */   private ResourceLocation textureLight = new ResourceLocation("lightsabers", "textures/models/lightsaber_forge_light.png");
/* 18 */   private ResourceLocation textureDark = new ResourceLocation("lightsabers", "textures/models/lightsaber_forge_dark.png");
/* 19 */   private ModelLightsaberForge model = new ModelLightsaberForge();
/*    */ 
/*    */   
/*    */   public void render(TileEntityLightsaberForge tile, double x, double y, double z, float partialTicks) {
/* 23 */     int metadata = 0;
/*    */     
/* 25 */     if (tile.func_145831_w() != null)
/*    */     {
/* 27 */       metadata = tile.func_145832_p();
/*    */     }
/*    */     
/* 30 */     GL11.glPushMatrix();
/* 31 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/* 32 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 33 */     GL11.glRotatef((BlockLightsaberForge.getDirection(metadata) * 90 + 180), 0.0F, 1.0F, 0.0F);
/*    */     
/* 35 */     if (!BlockLightsaberForge.isBlockSideOfPanel(metadata)) {
/*    */       
/* 37 */       func_147499_a((tile.func_145838_q() == ModBlocks.lightsaberForgeDark) ? this.textureDark : this.textureLight);
/* 38 */       this.model.render();
/*    */     } 
/*    */     
/* 41 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_147500_a(TileEntity tileentity, double x, double y, double z, float partialTicks) {
/* 47 */     render((TileEntityLightsaberForge)tileentity, x, y, z, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\tile\RenderLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */