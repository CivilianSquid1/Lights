/*    */ package com.fiskmods.lightsabers.client.render.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import fiskfille.utils.registry.FiskRegistryEntry;
/*    */ import fiskfille.utils.registry.FiskSimpleRegistry;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public abstract class HiltRenderer
/*    */   extends FiskRegistryEntry<HiltRenderer>
/*    */ {
/* 14 */   public static final FiskSimpleRegistry<HiltRenderer> REGISTRY = new FiskSimpleRegistry("lightsabers", "graflex");
/*    */ 
/*    */   
/*    */   public static void register(String key, HiltRenderer value) {
/* 18 */     REGISTRY.putObject(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void register(Hilt key, HiltRenderer value) {
/* 23 */     register(key.delegate.name(), value);
/*    */   }
/*    */ 
/*    */   
/*    */   public static HiltRenderer get(String key) {
/* 28 */     return (HiltRenderer)REGISTRY.getObject(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public static HiltRenderer get(Hilt key) {
/* 33 */     return (key == null) ? null : get(key.delegate.name());
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract ModelBase getEmitter();
/*    */   
/*    */   public abstract ModelBase getSwitchSection();
/*    */   
/*    */   public abstract ModelBase getBody();
/*    */   
/*    */   public abstract ModelBase getPommel();
/*    */   
/*    */   public ModelBase getModel(PartType type) {
/* 46 */     switch (type) {
/*    */       
/*    */       case EMITTER:
/* 49 */         return getEmitter();
/*    */       case SWITCH_SECTION:
/* 51 */         return getSwitchSection();
/*    */       case BODY:
/* 53 */         return getBody();
/*    */     } 
/* 55 */     return getPommel();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceLocation getTexture(PartType type) {
/* 61 */     return new ResourceLocation(getDomain(), String.format("textures/models/lightsaber/%s_%s.png", new Object[] { type.textureName, getRegistryName().func_110623_a() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public final Hilt getHilt() {
/* 66 */     return (Hilt)Hilt.REGISTRY.getObject(this.delegate.name());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\hilt\HiltRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */