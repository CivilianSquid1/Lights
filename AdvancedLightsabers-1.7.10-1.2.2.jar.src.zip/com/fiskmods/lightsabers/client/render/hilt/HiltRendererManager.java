/*    */ package com.fiskmods.lightsabers.client.render.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyDroideka;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyFulcrum;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyFury;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyGraflex;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyImperial;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyJuggernaut;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyKnighted;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyMandalorian;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyMauler;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyMechanical;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyProdigalSon;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyRebel;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyReborn;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyRedeemer;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelBodyVaid;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterDroideka;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterFulcrum;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterFury;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterGraflex;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterImperial;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterJuggernaut;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterKnighted;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterMandalorian;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterMauler;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterMechanical;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterProdigalSon;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterRebel;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterReborn;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterRedeemer;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelEmitterVaid;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelDroideka;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelFulcrum;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelFury;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelGraflex;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelImperial;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelJuggernaut;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelKnighted;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelMandalorian;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelMauler;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelMechanical;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelProdigalSon;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelRebel;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelReborn;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelRedeemer;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelPommelVaid;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionDroideka;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionFulcrum;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionFury;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionGraflex;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionImperial;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionJuggernaut;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionKnighted;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionMandalorian;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionMauler;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionMechanical;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionProdigalSon;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionRebel;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionReborn;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionRedeemer;
/*    */ import com.fiskmods.lightsabers.client.model.lightsaber.ModelSwitchSectionVaid;
/*    */ import com.fiskmods.lightsabers.common.hilt.HiltManager;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ 
/*    */ public class HiltRendererManager
/*    */ {
/*    */   public static void register() {
/* 69 */     HiltRenderer.register(HiltManager.GRAFLEX, new HiltRendererBase((ModelBase)new ModelEmitterGraflex(), (ModelBase)new ModelSwitchSectionGraflex(), (ModelBase)new ModelBodyGraflex(), (ModelBase)new ModelPommelGraflex()));
/* 70 */     HiltRenderer.register(HiltManager.REDEEMER, new HiltRendererBase((ModelBase)new ModelEmitterRedeemer(), (ModelBase)new ModelSwitchSectionRedeemer(), (ModelBase)new ModelBodyRedeemer(), (ModelBase)new ModelPommelRedeemer()));
/* 71 */     HiltRenderer.register(HiltManager.MAULER, new HiltRendererBase((ModelBase)new ModelEmitterMauler(), (ModelBase)new ModelSwitchSectionMauler(), (ModelBase)new ModelBodyMauler(), (ModelBase)new ModelPommelMauler()));
/* 72 */     HiltRenderer.register(HiltManager.PRODIGAL_SON, new HiltRendererBase((ModelBase)new ModelEmitterProdigalSon(), (ModelBase)new ModelSwitchSectionProdigalSon(), (ModelBase)new ModelBodyProdigalSon(), (ModelBase)new ModelPommelProdigalSon()));
/* 73 */     HiltRenderer.register(HiltManager.KNIGHTED, new HiltRendererBase((ModelBase)new ModelEmitterKnighted(), (ModelBase)new ModelSwitchSectionKnighted(), (ModelBase)new ModelBodyKnighted(), (ModelBase)new ModelPommelKnighted()));
/* 74 */     HiltRenderer.register(HiltManager.VAID_ANCIENT, new HiltRendererBase((ModelBase)new ModelEmitterVaid(), (ModelBase)new ModelSwitchSectionVaid(), (ModelBase)new ModelBodyVaid(), (ModelBase)new ModelPommelVaid()));
/* 75 */     HiltRenderer.register(HiltManager.VAID_MODERN, new HiltRendererBase((ModelBase)new ModelEmitterVaid(), (ModelBase)new ModelSwitchSectionVaid(), (ModelBase)new ModelBodyVaid(), (ModelBase)new ModelPommelVaid()));
/* 76 */     HiltRenderer.register(HiltManager.DROIDEKA, new HiltRendererBase((ModelBase)new ModelEmitterDroideka(), (ModelBase)new ModelSwitchSectionDroideka(), (ModelBase)new ModelBodyDroideka(), (ModelBase)new ModelPommelDroideka()));
/* 77 */     HiltRenderer.register(HiltManager.FULCRUM, new HiltRendererBase((ModelBase)new ModelEmitterFulcrum(), (ModelBase)new ModelSwitchSectionFulcrum(), (ModelBase)new ModelBodyFulcrum(), (ModelBase)new ModelPommelFulcrum()));
/* 78 */     HiltRenderer.register(HiltManager.JUGGERNAUT, new HiltRendererBase((ModelBase)new ModelEmitterJuggernaut(), (ModelBase)new ModelSwitchSectionJuggernaut(), (ModelBase)new ModelBodyJuggernaut(), (ModelBase)new ModelPommelJuggernaut()));
/* 79 */     HiltRenderer.register(HiltManager.MECHANICAL, new HiltRendererBase((ModelBase)new ModelEmitterMechanical(), (ModelBase)new ModelSwitchSectionMechanical(), (ModelBase)new ModelBodyMechanical(), (ModelBase)new ModelPommelMechanical()));
/* 80 */     HiltRenderer.register(HiltManager.MANDALORIAN, new HiltRendererBase((ModelBase)new ModelEmitterMandalorian(), (ModelBase)new ModelSwitchSectionMandalorian(), (ModelBase)new ModelBodyMandalorian(), (ModelBase)new ModelPommelMandalorian()));
/* 81 */     HiltRenderer.register(HiltManager.FURY, new HiltRendererBase((ModelBase)new ModelEmitterFury(), (ModelBase)new ModelSwitchSectionFury(), (ModelBase)new ModelBodyFury(), (ModelBase)new ModelPommelFury()));
/* 82 */     HiltRenderer.register(HiltManager.REBEL, new HiltRendererBase((ModelBase)new ModelEmitterRebel(), (ModelBase)new ModelSwitchSectionRebel(), (ModelBase)new ModelBodyRebel(), (ModelBase)new ModelPommelRebel()));
/* 83 */     HiltRenderer.register(HiltManager.IMPERIAL, new HiltRendererBase((ModelBase)new ModelEmitterImperial(), (ModelBase)new ModelSwitchSectionImperial(), (ModelBase)new ModelBodyImperial(), (ModelBase)new ModelPommelImperial()));
/* 84 */     HiltRenderer.register(HiltManager.REBORN, new HiltRendererOneTwelve((ModelBase)new ModelEmitterReborn(), (ModelBase)new ModelSwitchSectionReborn(), (ModelBase)new ModelBodyReborn(), (ModelBase)new ModelPommelReborn()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\hilt\HiltRendererManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */