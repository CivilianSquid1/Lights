/*    */ package com.fiskmods.lightsabers.client.render.hilt;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ 
/*    */ public class HiltRendererBase
/*    */   extends HiltRenderer
/*    */ {
/*    */   public final ModelBase emitter;
/*    */   public final ModelBase switchSection;
/*    */   public final ModelBase body;
/*    */   public final ModelBase pommel;
/*    */   
/*    */   public HiltRendererBase(ModelBase emitter, ModelBase switchSection, ModelBase body, ModelBase pommel) {
/* 14 */     this.emitter = emitter;
/* 15 */     this.switchSection = switchSection;
/* 16 */     this.body = body;
/* 17 */     this.pommel = pommel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ModelBase getEmitter() {
/* 23 */     return this.emitter;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ModelBase getSwitchSection() {
/* 29 */     return this.switchSection;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ModelBase getBody() {
/* 35 */     return this.body;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ModelBase getPommel() {
/* 41 */     return this.pommel;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\hilt\HiltRendererBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */