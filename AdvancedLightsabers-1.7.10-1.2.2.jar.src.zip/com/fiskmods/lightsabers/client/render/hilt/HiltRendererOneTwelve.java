/*    */ package com.fiskmods.lightsabers.client.render.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public class HiltRendererOneTwelve
/*    */   extends HiltRendererBase
/*    */ {
/*    */   public HiltRendererOneTwelve(ModelBase emitter, ModelBase switchSection, ModelBase body, ModelBase pommel) {
/* 12 */     super(emitter, switchSection, body, pommel);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceLocation getTexture(PartType type) {
/* 18 */     return new ResourceLocation(getDomain(), String.format("textures/models/lightsaber/%s.png", new Object[] { getRegistryName().func_110623_a() }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\hilt\HiltRendererOneTwelve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */