/*    */ package com.fiskmods.lightsabers.client.render;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Lightning
/*    */ {
/* 12 */   public List<Lightning> children = Lists.newArrayList();
/*    */   
/*    */   public Lightning parent;
/*    */   
/*    */   public float length;
/*    */   public float scale;
/*    */   public float rotateAngleX;
/*    */   public float rotateAngleY;
/*    */   public float rotateAngleZ;
/*    */   public Vec3 lightningColor;
/*    */   
/*    */   public Lightning(float f) {
/* 24 */     this(f, Vec3.func_72443_a(1.0D, 1.0D, 1.0D));
/*    */   }
/*    */ 
/*    */   
/*    */   public Lightning(float f, Vec3 color) {
/* 29 */     this.length = f;
/* 30 */     this.lightningColor = color;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate(World world) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Lightning addChild(Lightning child) {
/* 49 */     child.parent = this;
/* 50 */     child.lightningColor = this.lightningColor;
/* 51 */     this.children.add(child);
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Lightning setRotation(float rotX, float rotY, float rotZ) {
/* 57 */     this.rotateAngleX = rotX;
/* 58 */     this.rotateAngleY = rotY;
/* 59 */     this.rotateAngleZ = rotZ;
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Lightning setScale(float f) {
/* 65 */     this.scale = f;
/* 66 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\client\render\Lightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */