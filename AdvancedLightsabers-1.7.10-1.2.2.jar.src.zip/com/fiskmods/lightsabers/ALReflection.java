/*    */ package com.fiskmods.lightsabers;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.reflection.GenericField;
/*    */ import java.util.List;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALReflection
/*    */ {
/*    */   public static GenericField<NBTTagList, List> tagList;
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public static void client() {}
/*    */   
/*    */   public static void common() {
/* 21 */     tagList = new GenericField(NBTTagList.class, List.class, new String[] { "field_74747_a", "tagList" });
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\ALReflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */