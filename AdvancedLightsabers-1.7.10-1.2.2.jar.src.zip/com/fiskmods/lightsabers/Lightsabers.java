/*    */ package com.fiskmods.lightsabers;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.command.CommandForce;
/*    */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.proxy.CommonProxy;
/*    */ import cpw.mods.fml.common.Loader;
/*    */ import cpw.mods.fml.common.Mod;
/*    */ import cpw.mods.fml.common.Mod.EventHandler;
/*    */ import cpw.mods.fml.common.Mod.Instance;
/*    */ import cpw.mods.fml.common.SidedProxy;
/*    */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLServerStartingEvent;
/*    */ import fiskfille.utils.FiskUtils;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraftforge.common.config.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mod(modid = "lightsabers", name = "Advanced Lightsabers", version = "1.2.2", dependencies = "required-after:Forge@[10.13.4.1558,);after:battlegear2;after:DynamicLights", guiFactory = "com.fiskmods.lightsabers.client.gui.GuiFactoryAL")
/*    */ public class Lightsabers
/*    */ {
/*    */   public static final String NAME = "Advanced Lightsabers";
/*    */   public static final String MODID = "lightsabers";
/*    */   public static final String VERSION = "1.2.2";
/*    */   @Instance
/*    */   public static Lightsabers instance;
/*    */   @SidedProxy(clientSide = "com.fiskmods.lightsabers.common.proxy.ClientProxy", serverSide = "com.fiskmods.lightsabers.common.proxy.CommonProxy")
/*    */   public static CommonProxy proxy;
/*    */   
/* 41 */   public static final CreativeTabs CREATIVE_TAB = new CreativeTabs("lightsabers")
/*    */     {
/*    */       
/*    */       public Item func_78016_d()
/*    */       {
/* 46 */         return ModItems.lightsaber;
/*    */       }
/*    */     };
/*    */ 
/*    */   
/*    */   public static boolean isBattlegearLoaded;
/*    */   public static boolean isDynamicLightsLoaded;
/*    */   
/*    */   @EventHandler
/*    */   public void preInit(FMLPreInitializationEvent event) {
/* 56 */     FiskUtils.hook(FiskUtils.Hook.PREINIT);
/*    */     
/* 58 */     isBattlegearLoaded = Loader.isModLoaded("battlegear2");
/* 59 */     isDynamicLightsLoaded = Loader.isModLoaded("DynamicLights");
/*    */     
/* 61 */     Configuration config = new Configuration(event.getSuggestedConfigurationFile());
/* 62 */     config.load();
/* 63 */     ModConfig.load(config);
/*    */     
/* 65 */     if (config.hasChanged())
/*    */     {
/* 67 */       config.save();
/*    */     }
/*    */     
/* 70 */     proxy.preInit();
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void init(FMLInitializationEvent event) {
/* 76 */     FiskUtils.hook(FiskUtils.Hook.INIT);
/* 77 */     proxy.init();
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void postInit(FMLPostInitializationEvent event) {
/* 83 */     FiskUtils.hook(FiskUtils.Hook.POSTINIT);
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void serverStart(FMLServerStartingEvent event) {
/* 89 */     event.registerServerCommand((ICommand)new CommandForce());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\Lightsabers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */