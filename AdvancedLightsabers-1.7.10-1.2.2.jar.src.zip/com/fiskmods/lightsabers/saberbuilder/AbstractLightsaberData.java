/*     */ package com.fiskmods.lightsabers.saberbuilder;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLightsaberData
/*     */ {
/*     */   public long hash;
/*     */   
/*     */   public AbstractLightsaberData() {
/*  15 */     this(0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData(long hashCode) {
/*  20 */     this.hash = hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getIDForObject(Hilt paramHilt);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Hilt getObjectById(int paramInt);
/*     */ 
/*     */   
/*     */   protected abstract AbstractLightsaberData createNew(long paramLong);
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData copy() {
/*  36 */     return createNew(this.hash);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData strip() {
/*  46 */     this.hash = (createNew(0L).set(getHilt()).set(getColor()).set(getFocusingCrystals())).hash;
/*  47 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hilt get(PartType type) {
/*  56 */     return getObjectById((int)(this.hash >> type.ordinal() * 6) & 0x3F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hilt[] getHilt() {
/*  64 */     Hilt[] hilt = new Hilt[4];
/*     */     
/*  66 */     for (int i = 0; i < hilt.length; i++)
/*     */     {
/*  68 */       hilt[i] = get(PartType.values()[i]);
/*     */     }
/*     */     
/*  71 */     return hilt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHiltUniform() {
/*  80 */     Hilt[] hilt = getHilt();
/*     */     
/*  82 */     for (int i = 0; i < hilt.length; i++) {
/*     */       
/*  84 */       if (i > 0 && hilt[i - 1] != hilt[i])
/*     */       {
/*  86 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getHiltBits() {
/*  98 */     return this.hash & 0xFFFFFFL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hilt.Part getPart(PartType type) {
/* 106 */     return get(type).getPart(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 114 */     float height = 0.0F;
/*     */     
/* 116 */     for (PartType type : PartType.values())
/*     */     {
/* 118 */       height += (getPart(type)).height;
/*     */     }
/*     */     
/* 121 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeightCm() {
/* 129 */     return getHeight() * 0.575F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CrystalColor getColor() {
/* 137 */     return CrystalColor.get((int)(this.hash >> 24L & 0xFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FocusingCrystal[] getFocusingCrystals() {
/* 146 */     FocusingCrystal[] crystals = new FocusingCrystal[(FocusingCrystal.values()).length];
/* 147 */     int i = -1;
/*     */     
/* 149 */     for (FocusingCrystal crystal : FocusingCrystal.values()) {
/*     */       
/* 151 */       if (hasFocusingCrystal(crystal))
/*     */       {
/* 153 */         crystals[++i] = crystal;
/*     */       }
/*     */     } 
/*     */     
/* 157 */     FocusingCrystal[] array = new FocusingCrystal[++i];
/*     */     
/* 159 */     if (array.length > 0)
/*     */     {
/* 161 */       System.arraycopy(crystals, 0, array, 0, i);
/*     */     }
/*     */     
/* 164 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFocusingCrystal(FocusingCrystal crystal) {
/* 173 */     return ((this.hash >> 32L & crystal.getCode()) == crystal.getCode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData set(PartType type, Hilt hilt) {
/* 185 */     int shift = type.ordinal() * 6;
/* 186 */     this.hash &= 63L << shift ^ 0xFFFFFFFFFFFFFFFFL;
/* 187 */     this.hash |= (getIDForObject(hilt) << shift);
/*     */     
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData set(Hilt... hilt) {
/* 206 */     for (int i = 0; i < Math.min((PartType.values()).length, hilt.length); i++)
/*     */     {
/* 208 */       set(PartType.values()[i], hilt[i]);
/*     */     }
/*     */     
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData set(Hilt hilt) {
/* 223 */     return set(new Hilt[] { hilt, hilt, hilt, hilt });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData set(CrystalColor color) {
/* 234 */     this.hash &= 0xFFFFFFFF00FFFFFFL;
/* 235 */     this.hash |= ((color.id & 0xFF) << 24);
/*     */     
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData set(FocusingCrystal... crystals) {
/* 250 */     this.hash &= 0xFFFF0000FFFFFFFFL;
/*     */     
/* 252 */     for (FocusingCrystal crystal : crystals) {
/*     */       
/* 254 */       if (crystal != null)
/*     */       {
/* 256 */         add(crystal);
/*     */       }
/*     */     } 
/*     */     
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData add(FocusingCrystal crystal) {
/* 271 */     this.hash |= crystal.getCode() << 32L;
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLightsaberData remove(FocusingCrystal crystal) {
/* 283 */     this.hash &= crystal.getCode() << 32L ^ 0xFFFFFFFFFFFFFFFFL;
/* 284 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 290 */     return (int)(this.hash & 0xFFFFFFFL) * 31 + (int)(this.hash >> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 296 */     return (obj instanceof AbstractLightsaberData && this.hash == ((AbstractLightsaberData)obj).hash);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\saberbuilder\AbstractLightsaberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */