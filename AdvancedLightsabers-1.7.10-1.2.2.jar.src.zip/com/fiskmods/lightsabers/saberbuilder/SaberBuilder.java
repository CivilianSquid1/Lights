/*     */ package com.fiskmods.lightsabers.saberbuilder;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.hilt.HiltManager;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.ui.UIWindow;
/*     */ import com.google.common.collect.BiMap;
/*     */ import com.google.common.collect.HashBiMap;
/*     */ import com.google.common.collect.Lists;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaberBuilder
/*     */   extends UIWindow
/*     */ {
/*  36 */   private static final Map<String, Hilt> HILTS = new LinkedHashMap<>();
/*  37 */   private static final BiMap<Hilt, Integer> HILT_IDS = (BiMap<Hilt, Integer>)HashBiMap.create();
/*     */   
/*  39 */   private final int margin = 5;
/*     */   private final int width;
/*  41 */   private AbstractLightsaberData data = new LData(0L);
/*     */   
/*  43 */   private final String[] partNames = new String[] { "Emitter", "Switch Section", "Grip", "Pommel" };
/*  44 */   private final JComboBox[] hiltParts = new JComboBox[this.partNames.length];
/*  45 */   private final JComboBox[] focusingCrystals = new JComboBox[2];
/*     */   
/*  47 */   private final JComboBox colorCrystal = new JComboBox<>(CrystalColor.values());
/*  48 */   private final JButton colorPreview = new JButton();
/*     */   
/*  50 */   private final JTextField hexField = new JTextField("#0");
/*  51 */   private final JTextField commandField = new JTextField();
/*     */ 
/*     */   
/*     */   private SaberBuilder(String title, int width, int height) {
/*  55 */     super(title, width, height);
/*  56 */     this.width = width;
/*     */     
/*  58 */     Vector<?> v = new Vector(HILTS.keySet());
/*     */     
/*  60 */     for (int i = 0; i < this.partNames.length; i++) {
/*     */       
/*  62 */       JComboBox box = this.hiltParts[i] = new JComboBox(v);
/*  63 */       add(i % 2 + 1, 2, this.partNames[i], box, i / 2);
/*     */       
/*  65 */       int k = i;
/*  66 */       box.addActionListener(e -> {
/*     */             this.data.set(PartType.values()[j], HILTS.get(box.getSelectedItem()));
/*     */ 
/*     */             
/*     */             updateScreen();
/*     */           });
/*     */     } 
/*     */     
/*  74 */     List<String> list = Lists.newArrayList((Object[])FocusingCrystal.values());
/*  75 */     list.add(0, "-");
/*  76 */     Vector<String> vector = new Vector<>(list);
/*     */     
/*  78 */     add(1, 2, "Focusing Crystals", this.focusingCrystals[0] = new JComboBox<>(vector), 2);
/*  79 */     add(2, 2, "", this.focusingCrystals[1] = new JComboBox<>(vector), 2);
/*     */     
/*  81 */     for (int j = 0; j < 2; j++) {
/*     */       
/*  83 */       this.focusingCrystals[j].addActionListener(e -> {
/*     */             this.data.set(new FocusingCrystal[] { getFocusingCrystal(0), getFocusingCrystal(1) });
/*     */ 
/*     */             
/*     */             updateScreen();
/*     */           });
/*     */     } 
/*     */     
/*  91 */     this.colorPreview.setFocusable(false);
/*  92 */     this.colorPreview.setBorderPainted(true);
/*  93 */     this.colorCrystal.addActionListener(e -> {
/*     */           this.data.set(getColor());
/*     */           
/*     */           updateScreen();
/*     */         });
/*  98 */     add(1, 2, "Color", this.colorCrystal, 3);
/*  99 */     add(2, 2, "", this.colorPreview, 3);
/*     */ 
/*     */     
/* 102 */     Font f = this.hexField.getFont();
/* 103 */     this.hexField.setFont(new Font(f.getName(), 1, f.getSize() * 2));
/* 104 */     this.hexField.addActionListener(e -> loadHex());
/* 105 */     this.hexField.addFocusListener(new FocusListener()
/*     */         {
/*     */           
/*     */           public void focusLost(FocusEvent e)
/*     */           {
/* 110 */             SaberBuilder.this.updateScreen();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void focusGained(FocusEvent e) {
/* 116 */             String s = SaberBuilder.this.hexField.getText();
/*     */             
/* 118 */             if (s.startsWith("#"))
/*     */             {
/* 120 */               SaberBuilder.this.hexField.setText(s.substring(1));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 125 */     add(this.hexField, 5, height - 40 - 5, (width - 5) / 2, 40);
/*     */ 
/*     */     
/* 128 */     f = this.commandField.getFont();
/* 129 */     this.commandField.setEditable(false);
/* 130 */     this.commandField.setFont(new Font(f.getName(), 1, f.getSize()));
/* 131 */     add(1, 1, "Command", this.commandField, 4);
/*     */ 
/*     */     
/* 134 */     updateScreen();
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadHex() {
/* 139 */     String s = this.hexField.getText();
/*     */     
/* 141 */     if (s.isEmpty()) {
/*     */       
/* 143 */       s = "0";
/*     */     }
/* 145 */     else if (!s.startsWith("#")) {
/*     */       
/* 147 */       s = "#" + s;
/*     */     } 
/*     */     
/* 150 */     setHash(Long.decode(s).longValue());
/* 151 */     updateScreen();
/*     */   }
/*     */ 
/*     */   
/*     */   private void setHash(long hash) {
/* 156 */     this.data = (new LData(hash)).strip();
/* 157 */     this.colorCrystal.setSelectedItem(this.data.getColor());
/*     */     
/* 159 */     for (int i = 0; i < this.partNames.length; i++) {
/*     */       
/* 161 */       int id = ((Integer)HILT_IDS.getOrDefault(this.data.get(PartType.values()[i]), Integer.valueOf(0))).intValue();
/*     */       
/* 163 */       if (id >= HILTS.size())
/*     */       {
/* 165 */         id = 0;
/*     */       }
/*     */       
/* 168 */       this.hiltParts[i].setSelectedIndex(id);
/*     */     } 
/*     */     
/* 171 */     FocusingCrystal[] crystals = this.data.getFocusingCrystals();
/* 172 */     this.focusingCrystals[0].setSelectedIndex(0);
/* 173 */     this.focusingCrystals[1].setSelectedIndex(0);
/*     */     
/* 175 */     for (int j = 0; j < crystals.length; j++)
/*     */     {
/* 177 */       this.focusingCrystals[j].setSelectedIndex(crystals[j].ordinal() + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateScreen() {
/* 183 */     String s = Long.toHexString(this.data.hash).toUpperCase(Locale.ROOT);
/*     */     
/* 185 */     if (!this.hexField.hasFocus())
/*     */     {
/* 187 */       s = "#" + s;
/*     */     }
/*     */     
/* 190 */     this.hexField.setText(s);
/* 191 */     this.colorPreview.setBackground(new Color((getColor()).color));
/*     */     
/* 193 */     if (!s.startsWith("#"))
/*     */     {
/* 195 */       s = "#" + s;
/*     */     }
/*     */     
/* 198 */     this.commandField.setText(String.format("/give @p %s:lightsaber 1 0 {%s:\"%s\"}", new Object[] { "lightsabers", "Lightsaber", s }));
/*     */   }
/*     */ 
/*     */   
/*     */   private FocusingCrystal getFocusingCrystal(int slot) {
/* 203 */     Object obj = this.focusingCrystals[slot].getSelectedItem();
/*     */     
/* 205 */     if (obj instanceof FocusingCrystal)
/*     */     {
/* 207 */       return (FocusingCrystal)obj;
/*     */     }
/*     */     
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private CrystalColor getColor() {
/* 215 */     return (CrystalColor)this.colorCrystal.getSelectedItem();
/*     */   }
/*     */ 
/*     */   
/*     */   private void add(int index, int stack, String text, JComponent comp, int row) {
/* 220 */     int w = this.width - 5 * (stack - 1);
/* 221 */     add(text, comp, 5 * index + w / stack * (index - 1), 5 + row * 45, w / stack);
/*     */   }
/*     */ 
/*     */   
/*     */   private void add(String text, JComponent comp, int x, int y, int width) {
/* 226 */     if (!text.isEmpty())
/*     */     {
/* 228 */       add(text, x, y, width - 5, 20);
/*     */     }
/*     */     
/* 231 */     add(comp, x, y + 20, width, 20);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 238 */       int nextId = -1;
/*     */       
/* 240 */       for (Field field : HiltManager.class.getFields()) {
/*     */         
/* 242 */         if (Hilt.class.isAssignableFrom(field.getType())) {
/*     */           
/* 244 */           Hilt hilt = (Hilt)field.get(null);
/* 245 */           HILTS.put(field.getName().toLowerCase(Locale.ROOT), hilt);
/* 246 */           HILT_IDS.put(hilt, Integer.valueOf(++nextId));
/*     */         } 
/*     */       } 
/*     */       
/* 250 */       (new SaberBuilder("Lightsaber Builder", 400, 300)).open();
/*     */     }
/* 252 */     catch (Exception e) {
/*     */       
/* 254 */       int width = 400;
/* 255 */       int height = 200;
/* 256 */       UIWindow window = new UIWindow("Lightsaber Builder", width, height);
/* 257 */       StringWriter w = new StringWriter();
/* 258 */       JTextArea log = new JTextArea();
/*     */       
/* 260 */       e.printStackTrace(new PrintWriter(w));
/* 261 */       log.setText(w.getBuffer().toString());
/* 262 */       log.setForeground(Color.RED);
/* 263 */       log.setEditable(false);
/*     */       
/* 265 */       window.add("A critical error occurred:", 5, 5, width - 10, 20);
/* 266 */       window.add(new JButton("Close"), width / 4, height - 25, width / 2, 20, event -> System.exit(-1));
/* 267 */       window.add(log, 5, 30, width - 10, height - 65);
/* 268 */       window.open();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class LData
/*     */     extends AbstractLightsaberData
/*     */   {
/*     */     private LData(long hashCode) {
/* 276 */       super(hashCode);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int getIDForObject(Hilt hilt) {
/* 282 */       return ((Integer)SaberBuilder.HILT_IDS.getOrDefault(hilt, Integer.valueOf(0))).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Hilt getObjectById(int id) {
/* 288 */       return (Hilt)SaberBuilder.HILT_IDS.inverse().getOrDefault(Integer.valueOf(id), SaberBuilder.HILT_IDS.inverse().get(Integer.valueOf(0)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected AbstractLightsaberData createNew(long hashCode) {
/* 294 */       return new LData(hashCode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\saberbuilder\SaberBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */