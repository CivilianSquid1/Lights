/*    */ package com.fiskmods.lightsabers.helper;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import com.fiskmods.lightsabers.common.force.PowerData;
/*    */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*    */ import com.google.common.base.Predicate;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALPredicates
/*    */ {
/*    */   public static Predicate<Power> isUnlocked(final EntityPlayer player) {
/* 14 */     return new Predicate<Power>()
/*    */       {
/*    */         
/*    */         public boolean apply(Power input)
/*    */         {
/* 19 */           return PowerManager.hasPowerUnlocked(player, input);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public static Predicate<PowerData> isRelevant(final EntityPlayer player) {
/* 26 */     return new Predicate<PowerData>()
/*    */       {
/*    */         
/*    */         public boolean apply(PowerData input)
/*    */         {
/* 31 */           return (input.isUnlocked() && input.power.isUsable() && ALHelper.getUnlockedChildren(player, input.power).isEmpty());
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\helper\ALPredicates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */