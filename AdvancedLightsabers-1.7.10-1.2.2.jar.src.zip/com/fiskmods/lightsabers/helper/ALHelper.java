/*     */ package com.fiskmods.lightsabers.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.render.Lightning;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.force.ForceSide;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Sets;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ALHelper
/*     */ {
/*     */   public static int getXpBarCap(int level) {
/*  36 */     return (level >= 30) ? (62 + (level - 30) * 7) : ((level >= 15) ? (17 + (level - 15) * 3) : 17);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getTotalXp(EntityPlayer player) {
/*  41 */     int totalXp = Math.round(player.func_71050_bK() * player.field_71106_cc);
/*     */     
/*  43 */     for (int i = 0; i < player.field_71068_ca; i++)
/*     */     {
/*  45 */       totalXp += getXpBarCap(i);
/*     */     }
/*     */     
/*  48 */     return totalXp;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getTotalXpToReachLevel(EntityPlayer player, int level) {
/*  53 */     int i = 0;
/*     */     
/*  55 */     for (int j = 0; j < level; j++)
/*     */     {
/*  57 */       i += getXpBarCap(j + 1);
/*     */     }
/*     */     
/*  60 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void removeExperience(EntityPlayer player, int amount) {
/*  65 */     player.field_71067_cb = getTotalXp(player);
/*     */     
/*  67 */     if (player.field_71106_cc > 0.0F && player.field_71068_ca >= 0) {
/*     */       
/*  69 */       player.field_71067_cb--;
/*  70 */       player.field_71106_cc -= 1.0F / player.func_71050_bK();
/*     */     }
/*  72 */     else if (player.field_71068_ca > 0) {
/*     */       
/*  74 */       player.field_71067_cb--;
/*  75 */       player.field_71068_ca--;
/*  76 */       player.field_71106_cc = (player.func_71050_bK() - 2) / player.func_71050_bK();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getConventionalName(String s) {
/*  82 */     String s1 = getUnconventionalName(s);
/*  83 */     return s1.substring(0, 1).toLowerCase(Locale.ROOT) + s1.substring(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getUnconventionalName(String s) {
/*  88 */     s = s.toLowerCase(Locale.ROOT);
/*     */     
/*  90 */     for (int i = 0; i < s.length(); i++) {
/*     */       
/*  92 */       if (i > 0 && s.charAt(i - 1) == '_' && i < s.length())
/*     */       {
/*  94 */         s = s.substring(0, i) + s.substring(i, i + 1).toUpperCase() + s.substring(i + 1);
/*     */       }
/*     */     } 
/*     */     
/*  98 */     s = s.replace(" ", "").replace("'", "").replace("/", "").replace("\\", "").replace("_", "").replace("-", "").replace("(", "").replace(")", "");
/*  99 */     return s.substring(0, 1).toUpperCase() + s.substring(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Power> getPowers(ForceSide side) {
/* 104 */     List<Power> list = Lists.newArrayList();
/*     */     
/* 106 */     for (Power power : Power.POWERS) {
/*     */       
/* 108 */       if (side == power.getSide())
/*     */       {
/* 110 */         list.add(power);
/*     */       }
/*     */     } 
/*     */     
/* 114 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getCompletion(EntityPlayer player, ForceSide side) {
/* 119 */     int powers = getPowers(side).size();
/* 120 */     float f = 0.0F;
/*     */     
/* 122 */     for (PowerData data : ALData.POWERS.get((Entity)player)) {
/*     */       
/* 124 */       if (data.isUnlocked() && data.power != side.getPower() && side == data.power.getSide())
/*     */       {
/* 126 */         f += 1.0F / (powers - 1);
/*     */       }
/*     */     } 
/*     */     
/* 130 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getForceBalance(EntityPlayer player) {
/* 135 */     float light = getCompletion(player, ForceSide.LIGHT);
/* 136 */     float dark = getCompletion(player, ForceSide.DARK);
/*     */     
/* 138 */     if (light != 0.0F || dark != 0.0F) {
/*     */       
/* 140 */       if (light > dark)
/*     */       {
/* 142 */         return 1.0F - dark / light;
/*     */       }
/* 144 */       if (dark > light)
/*     */       {
/* 146 */         return -1.0F + light / dark;
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte getBasePower(EntityPlayer player) {
/* 155 */     return ((PowerData.Container)ALData.POWERS.get((Entity)player)).getBasePower();
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getForcePowerMax(EntityPlayer player) {
/* 160 */     return ((PowerData.Container)ALData.POWERS.get((Entity)player)).getForceMax();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getForcePowerRegen(EntityPlayer player) {
/* 165 */     return ((PowerData.Container)ALData.POWERS.get((Entity)player)).getRegen();
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<PowerData> getRelevantPowers(EntityPlayer player) {
/* 170 */     return Lists.newArrayList(Iterables.filter((Iterable)ALData.POWERS.get((Entity)player), ALPredicates.isRelevant(player)));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Set<Power> getUnlockedChildren(EntityPlayer player, Power power) {
/* 175 */     return Sets.filter(power.children, ALPredicates.isUnlocked(player));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isAlly(EntityLivingBase to, EntityLivingBase entity) {
/* 180 */     if (entity instanceof EntityTameable && ((EntityTameable)entity).func_70902_q() == to)
/*     */     {
/* 182 */       return true;
/*     */     }
/* 184 */     if (entity instanceof net.minecraft.entity.monster.EntityMob || entity.func_70643_av() == to)
/*     */     {
/* 186 */       return false;
/*     */     }
/* 188 */     if (entity.func_96124_cp() != null && entity.func_96124_cp().func_142054_a(to.func_96124_cp()))
/*     */     {
/* 190 */       return true;
/*     */     }
/* 192 */     if (to.func_110144_aD() == entity)
/*     */     {
/* 194 */       return (to.func_142013_aG() > 1200);
/*     */     }
/*     */     
/* 197 */     return (to.field_70154_o == entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityLivingBase getForceLightningTarget(EntityLivingBase caster) {
/* 202 */     StatusEffect effect = StatusEffect.get(caster, Effect.LIGHTNING);
/*     */     
/* 204 */     if (effect != null) {
/*     */       
/* 206 */       Vec3 src = VectorHelper.getOffsetCoords(caster, 0.0D, 0.0D, 0.0D);
/* 207 */       Vec3 dst = VectorHelper.getOffsetCoords(caster, 0.0D, 0.0D, 7.0D);
/* 208 */       Vec3 hitVec = null;
/* 209 */       MovingObjectPosition rayTrace = caster.field_70170_p.func_72933_a(VectorHelper.copy(src), VectorHelper.copy(dst));
/*     */       
/* 211 */       if (rayTrace == null) {
/*     */         
/* 213 */         hitVec = dst;
/*     */       }
/*     */       else {
/*     */         
/* 217 */         hitVec = rayTrace.field_72307_f;
/*     */       } 
/*     */       
/* 220 */       double distance = caster.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */       double point;
/* 222 */       for (point = 0.0D; point <= distance; point += 0.15D) {
/*     */         
/* 224 */         Vec3 particleVec = VectorHelper.getOffsetCoords(caster, 0.0D, 0.0D, point);
/*     */         
/* 226 */         for (EntityLivingBase entity : VectorHelper.getEntitiesNear(EntityLivingBase.class, caster.field_70170_p, particleVec, 1.0D)) {
/*     */           
/* 228 */           if (entity != null && entity != caster && caster.field_70154_o != entity) {
/*     */             
/* 230 */             hitVec.field_72450_a = entity.field_70165_t;
/* 231 */             hitVec.field_72448_b = entity.field_70163_u;
/* 232 */             hitVec.field_72449_c = entity.field_70161_v;
/* 233 */             rayTrace = new MovingObjectPosition((Entity)entity, hitVec);
/* 234 */             distance = caster.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 240 */       if (rayTrace != null)
/*     */       {
/* 242 */         if (rayTrace.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && rayTrace.field_72308_g instanceof EntityLivingBase) {
/*     */           
/* 244 */           EntityLivingBase entity = (EntityLivingBase)rayTrace.field_72308_g;
/*     */           
/* 246 */           return entity;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Lightning createLightning(Vec3 color, long seed, float length) {
/* 256 */     Random rand = new Random();
/*     */     
/* 258 */     if (seed != 0L)
/*     */     {
/* 260 */       rand.setSeed(seed);
/*     */     }
/*     */     
/* 263 */     Lightning lightning = (new Lightning(rand.nextFloat() * length, color)).setRotation(rand.nextFloat() * 360.0F, rand.nextFloat() * 360.0F, rand.nextFloat() * 360.0F);
/* 264 */     branchLightning(lightning, rand, length, 0);
/*     */     
/* 266 */     return lightning;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void branchLightning(Lightning lightning, Random rand, float length, int branch) {
/* 271 */     Lightning lightning1 = (new Lightning(rand.nextFloat() * length)).setRotation(rand.nextFloat() * rand.nextFloat() * 90.0F, rand.nextFloat() * rand.nextFloat() * 90.0F, rand.nextFloat() * rand.nextFloat() * 90.0F);
/* 272 */     lightning.addChild(lightning1);
/*     */     
/* 274 */     if (branch < 10)
/*     */     {
/* 276 */       if (rand.nextDouble() < 1.0D - branch * 0.1D)
/*     */       {
/* 278 */         branchLightning(lightning1, rand, length, ++branch);
/*     */       }
/*     */     }
/*     */     
/* 282 */     if (rand.nextDouble() < 0.1D)
/*     */     {
/* 284 */       branchLightning(lightning, rand, length, 7);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dropItem(World world, int x, int y, int z, ItemStack stack, Random rand) {
/* 290 */     float f = rand.nextFloat() * 0.8F + 0.1F;
/* 291 */     float f1 = rand.nextFloat() * 0.8F + 0.1F;
/* 292 */     float f2 = rand.nextFloat() * 0.8F + 0.1F;
/*     */     
/* 294 */     while (stack.field_77994_a > 0) {
/*     */       
/* 296 */       int i = rand.nextInt(21) + 10;
/*     */       
/* 298 */       if (i > stack.field_77994_a)
/*     */       {
/* 300 */         i = stack.field_77994_a;
/*     */       }
/*     */       
/* 303 */       stack.field_77994_a -= i;
/* 304 */       EntityItem entity = new EntityItem(world, (x + f), (y + f1), (z + f2), new ItemStack(stack.func_77973_b(), i, stack.func_77960_j()));
/*     */       
/* 306 */       if (stack.func_77942_o())
/*     */       {
/* 308 */         entity.func_92059_d().func_77982_d((NBTTagCompound)stack.func_77978_p().func_74737_b());
/*     */       }
/*     */       
/* 311 */       float f3 = 0.05F;
/* 312 */       entity.field_70159_w = ((float)rand.nextGaussian() * f3);
/* 313 */       entity.field_70181_x = ((float)rand.nextGaussian() * f3 + 0.2F);
/* 314 */       entity.field_70179_y = ((float)rand.nextGaussian() * f3);
/* 315 */       world.func_72838_d((Entity)entity);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\helper\ALHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */