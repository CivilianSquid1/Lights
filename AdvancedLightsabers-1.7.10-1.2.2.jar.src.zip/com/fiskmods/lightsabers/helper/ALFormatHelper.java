/*    */ package com.fiskmods.lightsabers.helper;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ public class ALFormatHelper
/*    */ {
/*    */   public static String formatNumber(float f) {
/*  9 */     String s = (long)f + "";
/*    */     
/* 11 */     if (!s.contains("E")) {
/*    */       
/* 13 */       String s1 = "";
/*    */       
/* 15 */       for (int i = 0; i < s.length(); i++) {
/*    */         
/* 17 */         s1 = s1 + s.charAt(i);
/*    */         
/* 19 */         if ((s.length() - i) % 3 == 1)
/*    */         {
/* 21 */           s1 = s1 + ",";
/*    */         }
/*    */       } 
/*    */       
/* 25 */       return s1.substring(0, s1.length() - 1);
/*    */     } 
/*    */     
/* 28 */     return s;
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getConventionalName(String s) {
/* 33 */     String s1 = s.replace(" ", "").replace("'", "").replace("/", "").replace("\\", "").replace("_", "").replace("-", "").replace("(", "").replace(")", "");
/* 34 */     return s1.substring(0, 1).toLowerCase(Locale.ROOT) + s1.substring(1);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getUnconventionalName(String s) {
/* 39 */     s = s.toLowerCase(Locale.ROOT);
/*    */     
/* 41 */     for (int i = 0; i < s.length(); i++) {
/*    */       
/* 43 */       if (i > 0 && s.charAt(i - 1) == '_' && i < s.length())
/*    */       {
/* 45 */         s = s.substring(0, i) + s.substring(i, i + 1).toUpperCase(Locale.ROOT) + s.substring(i + 1);
/*    */       }
/*    */     } 
/*    */     
/* 49 */     s = s.replace(" ", "").replace("'", "").replace("/", "").replace("\\", "").replace("_", "").replace("-", "").replace("(", "").replace(")", "");
/* 50 */     return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\helper\ALFormatHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */