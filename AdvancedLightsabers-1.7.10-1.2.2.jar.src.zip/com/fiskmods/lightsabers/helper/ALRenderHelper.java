/*     */ package com.fiskmods.lightsabers.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.model.ModelLightsaberBlade;
/*     */ import com.fiskmods.lightsabers.client.render.Lightning;
/*     */ import com.fiskmods.lightsabers.client.render.hilt.HiltRenderer;
/*     */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import java.awt.Color;
/*     */ import java.nio.FloatBuffer;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.ItemRenderer;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.texture.TextureUtil;
/*     */ import net.minecraft.client.shader.ShaderGroup;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ALRenderHelper
/*     */ {
/*  48 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  50 */   public static final ResourceLocation SHADER_GRAY = new ResourceLocation("shaders/post/desaturate.json");
/*  51 */   public static final ResourceLocation SHADER_BLUE = new ResourceLocation("lightsabers", "shaders/post/blue.json");
/*  52 */   public static final ResourceLocation SHADER_BLUR = new ResourceLocation("lightsabers", "shaders/post/mild_phosphor.json");
/*     */   
/*  54 */   private static final ModelLightsaberBlade LIGHTSABER_BLADE = new ModelLightsaberBlade(38);
/*  55 */   private static final ModelLightsaberBlade CROSSGUARD_BLADE = new ModelLightsaberBlade(4);
/*     */   
/*     */   public static boolean overrideColor = false;
/*     */   
/*     */   private static float lastBrightnessX;
/*     */   
/*     */   private static float lastBrightnessY;
/*     */   public static final int LIGHTING_LUMINOUS = 61680;
/*     */   
/*     */   public static void setLighting(int lighting) {
/*  65 */     storeLighting();
/*  66 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, (lighting % 65536 / 255), (lighting / 65536 / 255));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void storeLighting() {
/*  71 */     lastBrightnessX = OpenGlHelper.lastBrightnessX;
/*  72 */     lastBrightnessY = OpenGlHelper.lastBrightnessY;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void resetLighting() {
/*  77 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, lastBrightnessX, lastBrightnessY);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setGlColor(Color color, float alpha) {
/*  82 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setGlColor(Color color) {
/*  87 */     setGlColor(color, color.getAlpha() / 255.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setVecColor(Vec3 vec) {
/*  92 */     GL11.glColor4f((float)vec.field_72450_a, (float)vec.field_72448_b, (float)vec.field_72449_c, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void applyColorFromItemStack(ItemStack itemstack, int pass) {
/*  97 */     int color = itemstack.func_77973_b().func_82790_a(itemstack, pass);
/*  98 */     float r = (color >> 16 & 0xFF) / 255.0F;
/*  99 */     float g = (color >> 8 & 0xFF) / 255.0F;
/* 100 */     float b = (color & 0xFF) / 255.0F;
/* 101 */     GL11.glColor4f(r, g, b, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getColorFromHex(int hex) {
/* 106 */     float r = (hex >> 16 & 0xFF) / 255.0F;
/* 107 */     float g = (hex >> 8 & 0xFF) / 255.0F;
/* 108 */     float b = (hex & 0xFF) / 255.0F;
/* 109 */     return Vec3.func_72443_a(r, g, b);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getHex(Vec3 color) {
/* 114 */     int r = (int)Math.round(color.field_72450_a * 255.0D);
/* 115 */     int g = (int)Math.round(color.field_72448_b * 255.0D);
/* 116 */     int b = (int)Math.round(color.field_72449_c * 255.0D);
/* 117 */     return r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setAlpha(float alpha) {
/* 122 */     FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(16);
/* 123 */     floatBuffer.rewind();
/* 124 */     GL11.glGetFloat(2816, floatBuffer);
/* 125 */     GL11.glColor4f(floatBuffer.get(), floatBuffer.get(), floatBuffer.get(), alpha);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getAlpha() {
/* 130 */     FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(16);
/* 131 */     floatBuffer.rewind();
/* 132 */     GL11.glGetFloat(2816, floatBuffer);
/*     */     
/* 134 */     return floatBuffer.get(3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void overrideColor(boolean override) {
/* 139 */     overrideColor = override;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaber(LightsaberData data, ItemStack itemstack, boolean inWorld) {
/* 144 */     renderLightsaberHilt(data);
/* 145 */     GL11.glScalef(3.0F, 3.0F, 3.0F);
/* 146 */     GL11.glTranslatef(0.0F, -((data.getPart(PartType.SWITCH_SECTION)).height + (data.getPart(PartType.EMITTER)).height) * 0.0234375F, 0.0F);
/* 147 */     renderLightsaberBlade(data, itemstack, inWorld);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaber(LightsaberData[] array, ItemStack itemstack, boolean inWorld) {
/* 152 */     for (int i = 0; i < array.length; i++) {
/*     */       
/* 154 */       GL11.glPushMatrix();
/*     */       
/* 156 */       if (i == 1) {
/*     */         
/* 158 */         GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 159 */         GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */       } 
/*     */       
/* 162 */       GL11.glTranslatef(0.0F, -array[i].getHeight() / 32.0F, 0.0F);
/* 163 */       renderLightsaber(array[i], itemstack, inWorld);
/* 164 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaber(ItemStack itemstack, boolean inWorld) {
/* 170 */     if (itemstack.func_77973_b() == ModItems.doubleLightsaber) {
/*     */       
/* 172 */       renderLightsaber(ItemDoubleLightsaber.get(itemstack), itemstack, inWorld);
/*     */     }
/*     */     else {
/*     */       
/* 176 */       renderLightsaber(LightsaberData.get(itemstack), itemstack, inWorld);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaberHilt(LightsaberData data) {
/* 182 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 183 */     GL11.glTranslatef(0.0F, -((data.getPart(PartType.BODY)).height + (data.getPart(PartType.POMMEL)).height - data.getHeight() / 2.0F) / 16.0F, 0.0F);
/*     */     
/* 185 */     for (PartType type : PartType.values()) {
/*     */       Hilt.Part body; float[] insn;
/* 187 */       HiltRenderer renderer = HiltRenderer.get(data.get(type));
/* 188 */       ModelBase model = renderer.getModel(type);
/*     */       
/* 190 */       mc.func_110434_K().func_110577_a(renderer.getTexture(type));
/*     */       
/* 192 */       switch (type) {
/*     */         
/*     */         case EMITTER:
/* 195 */           GL11.glPushMatrix();
/* 196 */           GL11.glTranslatef(0.0F, -(data.getPart(PartType.SWITCH_SECTION)).height / 16.0F, 0.0F);
/* 197 */           model.func_78088_a(null, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F);
/* 198 */           GL11.glPopMatrix();
/*     */           break;
/*     */         case POMMEL:
/* 201 */           GL11.glPushMatrix();
/* 202 */           body = data.getPart(PartType.BODY);
/* 203 */           insn = body.glInstructions;
/*     */           
/* 205 */           if (insn != null && insn.length > 0) {
/*     */             
/* 207 */             for (int i = 0; i < insn.length; i++) {
/*     */               
/* 209 */               float f = insn[i];
/*     */               
/* 211 */               if ((i & 0x1) == 0)
/*     */               {
/* 213 */                 GL11.glTranslatef(0.0F, f / 16.0F, 0.0F);
/*     */               }
/*     */               else
/*     */               {
/* 217 */                 GL11.glRotatef(f, 1.0F, 0.0F, 0.0F);
/*     */               }
/*     */             
/*     */             } 
/*     */           } else {
/*     */             
/* 223 */             GL11.glTranslatef(0.0F, body.height / 16.0F, 0.0F);
/*     */           } 
/*     */           
/* 226 */           model.func_78088_a(null, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F);
/* 227 */           GL11.glPopMatrix();
/*     */           break;
/*     */         default:
/* 230 */           model.func_78088_a(null, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaberHilt(LightsaberData[] array) {
/* 238 */     for (int i = 0; i < array.length; i++) {
/*     */       
/* 240 */       GL11.glPushMatrix();
/*     */       
/* 242 */       if (i == 1) {
/*     */         
/* 244 */         GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 245 */         GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */       } 
/*     */       
/* 248 */       GL11.glTranslatef(0.0F, -array[i].getHeight() / 32.0F, 0.0F);
/* 249 */       renderLightsaberHilt(array[i]);
/* 250 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightsaberBlade(LightsaberData data, ItemStack itemstack, boolean inWorld) {
/* 256 */     if (ItemLightsaberBase.isActive(itemstack)) {
/*     */       
/* 258 */       if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("Special", 8)) {
/*     */         
/* 260 */         Item item = (Item)Item.field_150901_e.func_82594_a(itemstack.func_77978_p().func_74779_i("Special"));
/*     */         
/* 262 */         if (item != null) {
/*     */           TextureAtlasSprite textureAtlasSprite;
/* 264 */           IIcon icon = item.func_77617_a(0);
/* 265 */           Tessellator tessellator = Tessellator.field_78398_a;
/* 266 */           float f = mc.field_71439_g.field_70173_aa + ClientEventHandler.renderTick;
/*     */           
/* 268 */           if (icon == null)
/*     */           {
/* 270 */             textureAtlasSprite = ((TextureMap)mc.func_110434_K().func_110581_b(TextureMap.field_110576_c)).func_110572_b("missingno");
/*     */           }
/*     */           
/* 273 */           mc.func_110434_K().func_110577_a(TextureMap.field_110576_c);
/* 274 */           TextureUtil.func_152777_a(false, false, 1.0F);
/* 275 */           GL11.glPushMatrix();
/* 276 */           GL11.glEnable(32826);
/* 277 */           GL11.glScaled(-2.0D, (-2.0F + MathHelper.func_76134_b(f) * 0.1F), (2.0F + MathHelper.func_76126_a(f) * 0.15F));
/* 278 */           GL11.glRotated(-(1.0F - 2.0F * MathHelper.func_76134_b(f / 2.0F + 1.0F)), 0.0D, 0.0D, 1.0D);
/* 279 */           GL11.glRotated((1.0F - 2.0F * MathHelper.func_76126_a(f / 2.0F + 3.0F)), 1.0D, 0.0D, 0.0D);
/* 280 */           GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/* 281 */           GL11.glTranslatef(0.705F, 0.4F, 0.03125F);
/* 282 */           GL11.glRotatef(135.0F, 0.0F, 0.0F, 1.0F);
/* 283 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 284 */           ItemRenderer.func_78439_a(tessellator, textureAtlasSprite.func_94212_f(), textureAtlasSprite.func_94206_g(), textureAtlasSprite.func_94209_e(), textureAtlasSprite.func_94210_h(), textureAtlasSprite.func_94211_a(), textureAtlasSprite.func_94216_b(), 0.0625F);
/* 285 */           GL11.glDisable(32826);
/* 286 */           GL11.glPopMatrix();
/* 287 */           TextureUtil.func_147945_b();
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 292 */       Hilt.Part emitter = data.getPart(PartType.EMITTER);
/* 293 */       boolean prevCull = GL11.glGetBoolean(2884);
/* 294 */       float[] crossguard = emitter.crossguard;
/* 295 */       float[] rgb = data.getRGB(itemstack);
/*     */       
/* 297 */       GL11.glPushMatrix();
/* 298 */       GL11.glDisable(2896);
/* 299 */       GL11.glDisable(3553);
/* 300 */       setLighting(MathHelper.func_76123_f(61680.0F * ModConfig.renderLightingMultiplier));
/* 301 */       GL11.glDepthMask(false);
/* 302 */       GL11.glEnable(3042);
/* 303 */       GL11.glBlendFunc(770, 32772);
/* 304 */       GL11.glTranslatef(0.0F, 0.095F, 0.0F);
/*     */       
/* 306 */       GL11.glAlphaFunc(516, 0.99F);
/* 307 */       GL11.glDisable(3008);
/* 308 */       GL11.glDisable(2884);
/*     */       
/* 310 */       if (emitter.hasCrossguard())
/*     */       {
/* 312 */         for (int i = -1; i <= 1; i += 2) {
/*     */           
/* 314 */           GL11.glPushMatrix();
/* 315 */           GL11.glTranslatef(crossguard[0], crossguard[1], crossguard[2] * -i);
/* 316 */           GL11.glRotatef((i * 90), 1.0F, 0.0F, 0.0F);
/*     */           
/* 318 */           if (i == 1)
/*     */           {
/* 320 */             GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */           }
/*     */           
/* 323 */           CROSSGUARD_BLADE.renderCrossguardOuter(data, itemstack, rgb, inWorld);
/* 324 */           GL11.glPopMatrix();
/*     */         } 
/*     */       }
/*     */       
/* 328 */       LIGHTSABER_BLADE.renderOuter(data, itemstack, rgb, inWorld);
/* 329 */       GL11.glDisable(3042);
/*     */       
/* 331 */       GL11.glDepthMask(true);
/* 332 */       GL11.glAlphaFunc(516, 0.1F);
/*     */       
/* 334 */       GL11.glPushMatrix();
/*     */       
/* 336 */       if (emitter.hasCrossguard())
/*     */       {
/* 338 */         for (int i = -1; i <= 1; i += 2) {
/*     */           
/* 340 */           GL11.glPushMatrix();
/* 341 */           GL11.glTranslatef(crossguard[0], crossguard[1], crossguard[2] * -i);
/* 342 */           GL11.glRotatef((i * 90), 1.0F, 0.0F, 0.0F);
/*     */           
/* 344 */           if (i == 1)
/*     */           {
/* 346 */             GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */           }
/*     */           
/* 349 */           CROSSGUARD_BLADE.renderInner(data, itemstack, rgb, inWorld, true);
/* 350 */           GL11.glPopMatrix();
/*     */         } 
/*     */       }
/*     */       
/* 354 */       LIGHTSABER_BLADE.renderInner(data, itemstack, rgb, inWorld, false);
/* 355 */       GL11.glPopMatrix();
/*     */       
/* 357 */       GL11.glEnable(3553);
/* 358 */       GL11.glEnable(2896);
/* 359 */       GL11.glEnable(3008);
/* 360 */       GL11.glBlendFunc(770, 771);
/*     */       
/* 362 */       if (prevCull)
/*     */       {
/* 364 */         GL11.glEnable(2884);
/*     */       }
/*     */       
/* 367 */       resetLighting();
/* 368 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawTip(float size, float tip) {
/* 374 */     float f = 0.0625F;
/* 375 */     float f1 = f / 2.0F;
/*     */     
/* 377 */     Tessellator tessellator = Tessellator.field_78398_a;
/* 378 */     tessellator.func_78382_b();
/* 379 */     tessellator.func_78377_a(size, size, 0.0D);
/* 380 */     tessellator.func_78377_a(-size, size, 0.0D);
/* 381 */     tessellator.func_78377_a((-size + f1), (-size - tip), -f1);
/* 382 */     tessellator.func_78377_a((size - f1), (-size - tip), -f1);
/* 383 */     tessellator.func_78377_a(size, size, -f);
/* 384 */     tessellator.func_78377_a(-size, size, -f);
/* 385 */     tessellator.func_78377_a((-size + f1), (-size - tip), (-f + f1));
/* 386 */     tessellator.func_78377_a((size - f1), (-size - tip), (-f + f1));
/* 387 */     tessellator.func_78377_a(-f1, size, (size - f1));
/* 388 */     tessellator.func_78377_a(-f1, size, (-size - f1));
/* 389 */     tessellator.func_78377_a(0.0D, (-size - tip), -size);
/* 390 */     tessellator.func_78377_a(0.0D, (-size - tip), (size - f));
/* 391 */     tessellator.func_78377_a(f1, size, (size - f1));
/* 392 */     tessellator.func_78377_a(f1, size, (-size - f1));
/* 393 */     tessellator.func_78377_a(0.0D, (-size - tip), -size);
/* 394 */     tessellator.func_78377_a(0.0D, (-size - tip), (size - f));
/* 395 */     tessellator.func_78381_a();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void startGlScissor(int x, int y, int width, int height) {
/* 400 */     ScaledResolution reso = new ScaledResolution(mc, mc.field_71443_c, mc.field_71440_d);
/*     */     
/* 402 */     double scaleW = mc.field_71443_c / reso.func_78327_c();
/* 403 */     double scaleH = mc.field_71440_d / reso.func_78324_d();
/*     */     
/* 405 */     if (width <= 0 || height <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 409 */     if (x < 0)
/*     */     {
/* 411 */       x = 0;
/*     */     }
/* 413 */     if (y < 0)
/*     */     {
/* 415 */       y = 0;
/*     */     }
/*     */     
/* 418 */     GL11.glEnable(3089);
/* 419 */     GL11.glScissor((int)Math.floor(x * scaleW), (int)Math.floor(mc.field_71440_d - (y + height) * scaleH), (int)Math.floor((x + width) * scaleW) - (int)Math.floor(x * scaleW), (int)Math.floor(mc.field_71440_d - y * scaleH) - (int)Math.floor(mc.field_71440_d - (y + height) * scaleH));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void endGlScissor() {
/* 424 */     GL11.glDisable(3089);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float median(double curr, double prev) {
/* 429 */     return (float)(prev + (curr - prev) * ClientEventHandler.renderTick);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void startShaders(ResourceLocation resourcelocation) {
/* 434 */     if (OpenGlHelper.field_148824_g && (mc.field_71460_t.field_147707_d == null || !mc.field_71460_t.field_147707_d.func_148022_b().equals(resourcelocation.toString()))) {
/*     */       
/* 436 */       if (mc.field_71460_t.field_147707_d != null)
/*     */       {
/* 438 */         mc.field_71460_t.field_147707_d.func_148021_a();
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 443 */         mc.field_71460_t.field_147707_d = new ShaderGroup(mc.func_110434_K(), mc.func_110442_L(), mc.func_147110_a(), resourcelocation);
/* 444 */         mc.field_71460_t.field_147707_d.func_148026_a(mc.field_71443_c, mc.field_71440_d);
/*     */       }
/* 446 */       catch (Exception e) {
/*     */         
/* 448 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void stopShaders() {
/* 455 */     mc.field_71460_t.func_147703_b();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canGazeEntity(EntityPlayer player, EntityLivingBase entity, int amplifier) {
/* 460 */     StatusEffect status = StatusEffect.get((EntityLivingBase)player, Effect.GAZE);
/*     */     
/* 462 */     if (amplifier == 0)
/*     */     {
/* 464 */       return (!entity.func_98034_c(player) && !(entity instanceof EntityPlayer));
/*     */     }
/* 466 */     if (amplifier == 1)
/*     */     {
/* 468 */       return !entity.func_98034_c(player);
/*     */     }
/*     */     
/* 471 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLightning(Lightning lightning, float opacity) {
/* 476 */     if (lightning.rotateAngleZ != 0.0F)
/*     */     {
/* 478 */       GL11.glRotatef(lightning.rotateAngleZ, 0.0F, 0.0F, 1.0F);
/*     */     }
/*     */     
/* 481 */     if (lightning.rotateAngleY != 0.0F)
/*     */     {
/* 483 */       GL11.glRotatef(lightning.rotateAngleY, 0.0F, 1.0F, 0.0F);
/*     */     }
/*     */     
/* 486 */     if (lightning.rotateAngleX != 0.0F)
/*     */     {
/* 488 */       GL11.glRotatef(lightning.rotateAngleX, 1.0F, 0.0F, 0.0F);
/*     */     }
/*     */     
/* 491 */     drawLightningLine(Vec3.func_72443_a(0.0D, 0.0D, 0.0D), Vec3.func_72443_a(0.0D, lightning.length, 0.0D), 5.0F, 1.0F, lightning.lightningColor, opacity);
/* 492 */     GL11.glTranslatef(0.0F, lightning.length, 0.0F);
/*     */     
/* 494 */     for (Lightning lightning1 : lightning.children) {
/*     */       
/* 496 */       GL11.glPushMatrix();
/* 497 */       renderLightning(lightning1, opacity);
/* 498 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawLightningLine(Vec3 start, Vec3 end, float lineWidth, float innerLineWidth, Vec3 color, float alpha) {
/* 504 */     if (start == null || end == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 509 */     Tessellator tessellator = Tessellator.field_78398_a;
/* 510 */     float prevWidth = GL11.glGetFloat(2849);
/*     */     
/* 512 */     if (lineWidth > 0.0F) {
/*     */       
/* 514 */       GL11.glLineWidth(lineWidth);
/* 515 */       tessellator.func_78371_b(3);
/* 516 */       tessellator.func_78369_a((float)color.field_72450_a, (float)color.field_72448_b, (float)color.field_72449_c, alpha);
/* 517 */       tessellator.func_78377_a(start.field_72450_a, start.field_72448_b, start.field_72449_c);
/* 518 */       tessellator.func_78377_a(end.field_72450_a, end.field_72448_b, end.field_72449_c);
/* 519 */       tessellator.func_78381_a();
/*     */     } 
/*     */     
/* 522 */     if (innerLineWidth > 0.0F) {
/*     */       
/* 524 */       GL11.glLineWidth(innerLineWidth);
/* 525 */       tessellator.func_78371_b(3);
/* 526 */       tessellator.func_78369_a(1.0F, 1.0F, 1.0F, MathHelper.func_76131_a(alpha - 0.2F, 0.0F, 1.0F));
/* 527 */       tessellator.func_78377_a(start.field_72450_a, start.field_72448_b, start.field_72449_c);
/* 528 */       tessellator.func_78377_a(end.field_72450_a, end.field_72448_b, end.field_72449_c);
/* 529 */       tessellator.func_78381_a();
/*     */     } 
/*     */     
/* 532 */     GL11.glLineWidth(prevWidth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupRenderLightning() {
/* 539 */     GL11.glBlendFunc(770, 32772);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 546 */     GL11.glPushMatrix();
/* 547 */     GL11.glDisable(3553);
/* 548 */     GL11.glDisable(2896);
/* 549 */     GL11.glEnable(3042);
/* 550 */     OpenGlHelper.func_148821_a(770, 771, 1, 0);
/* 551 */     GL11.glBlendFunc(770, 1);
/* 552 */     GL11.glAlphaFunc(516, 0.003921569F);
/* 553 */     GL11.glDepthMask(false);
/* 554 */     setLighting(61680);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void finishRenderLightning() {
/* 559 */     resetLighting();
/* 560 */     GL11.glDepthMask(true);
/* 561 */     GL11.glDisable(3042);
/* 562 */     GL11.glEnable(2896);
/* 563 */     GL11.glEnable(3553);
/* 564 */     GL11.glPopMatrix();
/*     */ 
/*     */ 
/*     */     
/* 568 */     GL11.glBlendFunc(770, 771);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupRenderItemIntoGUI() {
/* 574 */     GL11.glEnable(32826);
/* 575 */     GL11.glEnable(2903);
/* 576 */     GL11.glEnable(2896);
/* 577 */     GL11.glEnable(3042);
/* 578 */     RenderHelper.func_74520_c();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void finishRenderItemIntoGUI() {
/* 583 */     GL11.glDisable(3042);
/* 584 */     GL11.glDisable(2896);
/* 585 */     GL11.glDepthMask(true);
/* 586 */     GL11.glEnable(2929);
/* 587 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void faceVec(Vec3 src, Vec3 dst) {
/* 592 */     double d0 = dst.field_72450_a - src.field_72450_a;
/* 593 */     double d1 = dst.field_72448_b - src.field_72448_b;
/* 594 */     double d2 = dst.field_72449_c - src.field_72449_c;
/* 595 */     double d3 = MathHelper.func_76133_a(d0 * d0 + d2 * d2);
/* 596 */     float yaw = (float)(Math.atan2(d2, d0) * 180.0D / Math.PI) - 90.0F;
/* 597 */     float pitch = (float)-(Math.atan2(d1, d3) * 180.0D / Math.PI);
/* 598 */     GL11.glRotated(-yaw, 0.0D, 1.0D, 0.0D);
/* 599 */     GL11.glRotated(pitch, 1.0D, 0.0D, 0.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\helper\ALRenderHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */