/*     */ package com.fiskmods.lightsabers.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.Map;
/*     */ import mods.battlegear2.api.core.BattlegearUtils;
/*     */ import mods.battlegear2.client.utils.BattlegearRenderHelper;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelHelper
/*     */ {
/*  30 */   public static final Map<Class<? extends ModelBiped>, Float> ARMS = Maps.newHashMap();
/*     */ 
/*     */   
/*     */   public static void renderBipedPre(ModelBiped model, Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  34 */     if (!ARMS.containsKey(model.getClass()))
/*     */     {
/*  36 */       ARMS.put(model.getClass(), Float.valueOf(model.field_78112_f.field_78797_d));
/*     */     }
/*     */     
/*  39 */     model.field_78112_f.field_78797_d = ((Float)ARMS.get(model.getClass())).floatValue();
/*  40 */     model.field_78113_g.field_78797_d = ((Float)ARMS.get(model.getClass())).floatValue();
/*     */     
/*  42 */     if (Lightsabers.isBattlegearLoaded)
/*     */     {
/*  44 */       BattlegearRenderHelper.moveOffHandArm(entity, model, f5);
/*     */     }
/*     */     
/*  47 */     setRotationAngles(model, f, f1, f2, f3, f4, f5, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderBipedPost(ModelBiped model, Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {}
/*     */ 
/*     */   
/*     */   public static void setRotationAngles(ModelBiped model, float f, float f1, float f2, float f3, float f4, float f5, Entity entity1) {
/*  56 */     if (entity1 instanceof EntityLivingBase) {
/*     */       
/*  58 */       EntityLivingBase entity = (EntityLivingBase)entity1;
/*  59 */       ItemStack heldItem = entity.func_70694_bm();
/*     */       
/*  61 */       if (heldItem != null && heldItem.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaberBase && !entity.func_70093_af()) {
/*     */         
/*  63 */         float f6 = model.field_78095_p;
/*  64 */         float f7 = ((f6 > 0.5F) ? (1.0F - f6) : f6) * 2.0F;
/*     */         
/*  66 */         if (heldItem.func_77973_b() == ModItems.doubleLightsaber) {
/*     */           
/*  68 */           if (model.field_78120_m != 0) {
/*     */             
/*  70 */             float f8 = 1.0F - f1;
/*  71 */             model.field_78112_f.field_78795_f = model.field_78112_f.field_78795_f * f1 - 1.2566371F * model.field_78120_m * f8;
/*  72 */             model.field_78112_f.field_78796_g = model.field_78112_f.field_78796_g * f1 + (model.field_78112_f.field_78796_g * 0.5F - 0.20943952F * model.field_78120_m) * f8;
/*     */           } 
/*     */           
/*  75 */           model.field_78112_f.field_78795_f -= f7;
/*  76 */           model.field_78112_f.field_78796_g += f7;
/*     */         }
/*  78 */         else if (heldItem.func_77973_b() == ModItems.lightsaber) {
/*     */           
/*  80 */           if (model.field_78120_m != 0 && !isDualWielding((Entity)entity)) {
/*     */             
/*  82 */             float f8 = 1.0F - f1;
/*  83 */             model.field_78112_f.field_78795_f = model.field_78112_f.field_78795_f * f1 - 1.0F * model.field_78120_m * f8;
/*  84 */             model.field_78112_f.field_78796_g = model.field_78112_f.field_78796_g * f1 + (model.field_78112_f.field_78796_g * 0.5F - 0.5F * model.field_78120_m) * f8;
/*  85 */             model.field_78112_f.field_78808_h = model.field_78112_f.field_78808_h * f1 + (model.field_78112_f.field_78808_h * 0.5F - 0.2F * model.field_78120_m) * f8;
/*  86 */             model.field_78112_f.field_78800_c += 0.5F * f8;
/*     */             
/*  88 */             float f9 = (f1 > 0.5F) ? 1.0F : (f1 * 2.0F);
/*  89 */             float f10 = 1.0F - f9;
/*  90 */             model.field_78113_g.field_78795_f = model.field_78113_g.field_78795_f * f9 - 1.0F * model.field_78120_m * f10;
/*  91 */             model.field_78113_g.field_78796_g = model.field_78113_g.field_78796_g * f9 + (model.field_78113_g.field_78796_g * 0.5F + 0.75F * model.field_78120_m) * f10;
/*  92 */             model.field_78113_g.field_78808_h = model.field_78113_g.field_78808_h * f9 + (model.field_78113_g.field_78808_h * 0.5F + 0.0F * model.field_78120_m) * f10;
/*  93 */             model.field_78113_g.field_78800_c -= 0.5F * f8;
/*     */           } 
/*     */           
/*  96 */           if (!isDualWielding((Entity)entity)) {
/*     */             
/*  98 */             model.field_78112_f.field_78795_f -= f7;
/*  99 */             model.field_78112_f.field_78796_g -= f7 * 0.4F;
/* 100 */             model.field_78113_g.field_78795_f -= f7 * 1.6F;
/* 101 */             model.field_78113_g.field_78796_g -= f7 * 0.9F;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 106 */       float push = MathHelper.func_76131_a(MathHelper.func_76126_a(((Float)ALData.FORCE_PUSHING_TIMER.interpolate((Entity)entity)).floatValue() * 3.0F) * 1.5F, 0.0F, 1.0F);
/* 107 */       float drain = MathHelper.func_76131_a(MathHelper.func_76126_a(((Float)ALData.DRAIN_LIFE_TIMER.interpolate((Entity)entity)).floatValue() * 3.0F) * 4.0F, 0.0F, 1.0F);
/* 108 */       float right = ((Float)ALData.RIGHT_ARM_TIMER.interpolate((Entity)entity)).floatValue();
/* 109 */       float left = ((Float)ALData.LEFT_ARM_TIMER.interpolate((Entity)entity)).floatValue();
/*     */ 
/*     */       
/* 112 */       model.field_78112_f.field_78795_f = model.field_78112_f.field_78795_f * (1.0F - push) + (f4 / 57.295776F - 1.5707964F) * push;
/* 113 */       model.field_78112_f.field_78796_g = model.field_78112_f.field_78796_g * (1.0F - push) + f3 / 57.295776F * push;
/* 114 */       model.field_78112_f.field_78808_h = model.field_78112_f.field_78808_h * (1.0F - push) + 0.0F * push;
/*     */       
/* 116 */       model.field_78112_f.field_78795_f = model.field_78112_f.field_78795_f * (1.0F - drain) + (f4 / 57.295776F - 1.5707964F) * drain;
/* 117 */       model.field_78112_f.field_78796_g = model.field_78112_f.field_78796_g * (1.0F - drain) + f3 / 57.295776F * drain;
/* 118 */       model.field_78112_f.field_78808_h = model.field_78112_f.field_78808_h * (1.0F - drain) + 0.0F * drain;
/*     */       
/* 120 */       model.field_78112_f.field_78795_f = model.field_78112_f.field_78795_f * (1.0F - right) + (f4 / 57.295776F - 1.5707964F) * right;
/* 121 */       model.field_78112_f.field_78796_g = model.field_78112_f.field_78796_g * (1.0F - right) + f3 / 57.295776F * right;
/* 122 */       model.field_78112_f.field_78808_h = model.field_78112_f.field_78808_h * (1.0F - right) + 0.0F * right;
/* 123 */       model.field_78113_g.field_78795_f = model.field_78113_g.field_78795_f * (1.0F - left) + (f4 / 57.295776F - 1.5707964F) * left;
/* 124 */       model.field_78113_g.field_78796_g = model.field_78113_g.field_78796_g * (1.0F - left) + f3 / 57.295776F * left;
/* 125 */       model.field_78113_g.field_78808_h = model.field_78113_g.field_78808_h * (1.0F - left) + 0.0F * left;
/*     */       
/* 127 */       StatusEffect effectChoke = StatusEffect.get(entity, Effect.CHOKE);
/*     */       
/* 129 */       if (effectChoke != null) {
/*     */         
/* 131 */         int durationMax = 60;
/* 132 */         float duration = effectChoke.duration - ClientEventHandler.renderTick;
/* 133 */         float fade = 3.0F;
/*     */         
/* 135 */         float f6 = (duration > fade) ? ((duration < durationMax - fade) ? 1.0F : (Math.min(durationMax - duration, fade) / fade)) : (Math.min(duration, fade) / fade);
/* 136 */         float f7 = 1.0F - f6;
/* 137 */         float f8 = entity1.field_70173_aa + ClientEventHandler.renderTick;
/*     */         
/* 139 */         if (effectChoke.amplifier > 0) {
/*     */           
/* 141 */           model.field_78116_c.field_78800_c *= f7;
/* 142 */           model.field_78116_c.field_78797_d *= f7;
/* 143 */           model.field_78116_c.field_78798_e *= f7;
/* 144 */           model.field_78114_d.field_78800_c *= f7;
/* 145 */           model.field_78114_d.field_78797_d *= f7;
/* 146 */           model.field_78114_d.field_78798_e *= f7;
/* 147 */           model.field_78115_e.field_78800_c *= f7;
/* 148 */           model.field_78115_e.field_78797_d *= f7;
/* 149 */           model.field_78115_e.field_78798_e *= f7;
/* 150 */           model.field_78115_e.field_78795_f *= f7;
/* 151 */           model.field_78115_e.field_78796_g *= f7;
/* 152 */           model.field_78115_e.field_78808_h *= f7;
/* 153 */           model.field_78123_h.field_78797_d *= f7;
/* 154 */           model.field_78123_h.field_78798_e *= f7;
/* 155 */           model.field_78123_h.field_78795_f *= f7;
/* 156 */           model.field_78123_h.field_78796_g *= f7;
/* 157 */           model.field_78123_h.field_78808_h *= f7;
/* 158 */           model.field_78124_i.field_78797_d *= f7;
/* 159 */           model.field_78124_i.field_78798_e *= f7;
/* 160 */           model.field_78124_i.field_78795_f *= f7;
/* 161 */           model.field_78124_i.field_78796_g *= f7;
/* 162 */           model.field_78124_i.field_78808_h *= f7;
/* 163 */           model.field_78112_f.field_78800_c *= f7;
/* 164 */           model.field_78112_f.field_78797_d *= f7;
/* 165 */           model.field_78112_f.field_78798_e *= f7;
/* 166 */           model.field_78112_f.field_78795_f *= f7;
/* 167 */           model.field_78112_f.field_78796_g *= f7;
/* 168 */           model.field_78112_f.field_78808_h *= f7;
/*     */         } 
/*     */         
/* 171 */         model.field_78113_g.field_78800_c *= f7;
/* 172 */         model.field_78113_g.field_78797_d *= f7;
/* 173 */         model.field_78113_g.field_78798_e *= f7;
/* 174 */         model.field_78113_g.field_78795_f *= f7;
/* 175 */         model.field_78113_g.field_78796_g *= f7;
/* 176 */         model.field_78113_g.field_78808_h *= f7;
/*     */         
/* 178 */         if (effectChoke.amplifier == 0) {
/*     */           
/* 180 */           model.field_78113_g.field_78795_f -= 1.2F * f6;
/* 181 */           model.field_78113_g.field_78796_g += 1.3F * f6;
/* 182 */           model.field_78113_g.field_78800_c += 5.0F * f6;
/* 183 */           model.field_78113_g.field_78797_d += 2.0F * f6;
/*     */         }
/* 185 */         else if (effectChoke.amplifier == 1) {
/*     */           
/* 187 */           model.field_78116_c.field_78795_f -= 0.5F * f6;
/* 188 */           model.field_78114_d.field_78795_f -= 0.5F * f6;
/*     */           
/* 190 */           model.field_78112_f.field_78795_f -= 2.1F * f6;
/* 191 */           model.field_78112_f.field_78796_g -= 1.3F * f6;
/* 192 */           model.field_78112_f.field_78800_c -= 6.0F * f6;
/* 193 */           model.field_78112_f.field_78797_d += 3.5F * f6;
/* 194 */           model.field_78112_f.field_78798_e += 1.0F * f6;
/*     */           
/* 196 */           model.field_78113_g.field_78795_f -= 2.1F * f6;
/* 197 */           model.field_78113_g.field_78796_g += 1.3F * f6;
/* 198 */           model.field_78113_g.field_78800_c += 6.0F * f6;
/* 199 */           model.field_78113_g.field_78797_d += 3.5F * f6;
/* 200 */           model.field_78113_g.field_78798_e += 1.0F * f6;
/*     */           
/* 202 */           model.field_78123_h.field_78797_d += 12.0F * f6;
/* 203 */           model.field_78123_h.field_78795_f = MathHelper.func_76134_b(f8 * 0.6662F) * 1.1F * f6;
/* 204 */           model.field_78124_i.field_78797_d += 12.0F * f6;
/* 205 */           model.field_78124_i.field_78795_f = MathHelper.func_76134_b(f8 * 0.6662F + 3.1415927F) * 1.1F * f6;
/*     */         }
/* 207 */         else if (effectChoke.amplifier == 2) {
/*     */           
/* 209 */           model.field_78116_c.field_78795_f = -0.8F * f6;
/* 210 */           model.field_78114_d.field_78795_f = -0.8F * f6;
/* 211 */           model.field_78116_c.field_78796_g = MathHelper.func_76134_b(f8 * 3.0F) * 0.2F * f6;
/* 212 */           model.field_78114_d.field_78796_g = MathHelper.func_76134_b(f8 * 3.0F) * 0.2F * f6;
/*     */           
/* 214 */           model.field_78112_f.field_78795_f -= 3.5F * f6;
/* 215 */           model.field_78112_f.field_78796_g -= 0.1F * f6;
/* 216 */           model.field_78112_f.field_78808_h += 0.3F * f6;
/* 217 */           model.field_78112_f.field_78800_c -= 5.25F * f6;
/* 218 */           model.field_78112_f.field_78797_d += 3.0F * f6;
/*     */           
/* 220 */           model.field_78113_g.field_78795_f -= 3.5F * f6;
/* 221 */           model.field_78113_g.field_78796_g += 0.1F * f6;
/* 222 */           model.field_78113_g.field_78808_h -= 0.3F * f6;
/* 223 */           model.field_78113_g.field_78800_c += 5.25F * f6;
/* 224 */           model.field_78113_g.field_78797_d += 3.0F * f6;
/*     */           
/* 226 */           model.field_78123_h.field_78797_d += 12.0F * f6;
/* 227 */           model.field_78123_h.field_78795_f = MathHelper.func_76134_b(f8 * 0.8662F) * 1.1F * f6;
/* 228 */           model.field_78124_i.field_78797_d += 12.0F * f6;
/* 229 */           model.field_78124_i.field_78795_f = MathHelper.func_76134_b(f8 * 0.8662F + 3.1415927F) * 1.1F * f6;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void applyLightsaberItemRotation(EntityLivingBase entity, ItemStack heldItem) {
/* 237 */     if (heldItem.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaberBase) {
/*     */       
/* 239 */       float f = entity.field_70722_aY - (entity.field_70722_aY - entity.field_70721_aZ) * ClientEventHandler.renderTick;
/* 240 */       float f1 = MathHelper.func_76134_b((entity.field_70754_ba - entity.field_70721_aZ * (1.0F - ClientEventHandler.renderTick)) * 0.6662F) * 1.4F * f;
/* 241 */       float f2 = entity.func_70678_g(ClientEventHandler.renderTick);
/* 242 */       float f3 = ((f2 > 0.5F) ? (1.0F - f2) : f2) * 2.0F;
/* 243 */       float f4 = 1.0F - f;
/*     */       
/* 245 */       if (heldItem.func_77973_b() == ModItems.doubleLightsaber) {
/*     */         
/* 247 */         GL11.glRotatef(-10.0F * f1 * f, 1.0F, 0.0F, 0.0F);
/* 248 */         GL11.glTranslatef(0.15F * f4, 0.0F, 0.0F);
/* 249 */         GL11.glRotatef(82.0F * f4, 0.0F, 0.0F, 1.0F);
/* 250 */         GL11.glRotatef(-5.0F * f4, 1.0F, 0.0F, 0.0F);
/*     */         
/* 252 */         if (f2 > 0.0F)
/*     */         {
/* 254 */           GL11.glRotatef(-360.0F * f2, 0.0F, 0.0F, 1.0F);
/*     */         }
/*     */         
/* 257 */         LightsaberData[] array = ItemDoubleLightsaber.get(heldItem);
/*     */         
/* 259 */         if (array[0].getPart(PartType.EMITTER).hasCrossguard() || array[1].getPart(PartType.EMITTER).hasCrossguard())
/*     */         {
/* 261 */           GL11.glRotatef(60.0F * f4, 0.0F, 1.0F, 0.0F);
/*     */         }
/*     */       }
/* 264 */       else if (heldItem.func_77973_b() == ModItems.lightsaber) {
/*     */         
/* 266 */         if (!isDualWielding((Entity)entity)) {
/*     */           
/* 268 */           if (!entity.func_70093_af()) {
/*     */             
/* 270 */             GL11.glRotatef(-30.0F * f4, 0.0F, 1.0F, 0.0F);
/* 271 */             GL11.glRotatef(-10.0F * f4, 0.0F, 0.0F, 1.0F);
/* 272 */             GL11.glTranslatef(0.05F * f4, 0.05F * f4, 0.0F);
/* 273 */             GL11.glRotatef(-140.0F * f3, 0.0F, 0.0F, 1.0F);
/* 274 */             GL11.glRotatef(-80.0F * f3, 1.0F, 0.0F, 0.0F);
/*     */             
/* 276 */             if (LightsaberData.getPart(heldItem, PartType.EMITTER).hasCrossguard())
/*     */             {
/* 278 */               GL11.glRotatef(90.0F * f4, 0.0F, 1.0F, 0.0F);
/*     */             }
/*     */           } 
/*     */           
/* 282 */           if (heldItem.func_82837_s() && (heldItem.func_82833_r().equals("Dinnerbone") || heldItem.func_82833_r().equals("Grumm")))
/*     */           {
/* 284 */             GL11.glRotatef(-180.0F * f * (1.0F - f3), 0.0F, 0.0F, 1.0F);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isDualWielding(Entity entity) {
/* 293 */     return (Lightsabers.isBattlegearLoaded && entity instanceof EntityPlayer && BattlegearUtils.isPlayerInBattlemode((EntityPlayer)entity));
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\helper\ModelHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */