/*    */ package com.fiskmods.lightsabers.asm;
/*    */ 
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerColor;
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerEffectRenderer;
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerEntityMob;
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerEntityPlayer;
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerModelBiped;
/*    */ import com.fiskmods.lightsabers.asm.transformers.ClassTransformerModelBipedMultiLayer;
/*    */ import cpw.mods.fml.relauncher.IFMLLoadingPlugin.MCVersion;
/*    */ import cpw.mods.fml.relauncher.IFMLLoadingPlugin.TransformerExclusions;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.asm.AbstractLoadingPlugin;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @MCVersion("1.7.10")
/*    */ @TransformerExclusions({"com.fiskmods.lightsabers.asm"})
/*    */ public class ALLoadingPlugin
/*    */   extends AbstractLoadingPlugin
/*    */ {
/*    */   public void setupTransformers(Side side, List<Class<?>> list) {
/* 24 */     if (side.isClient()) {
/*    */       
/* 26 */       list.add(ClassTransformerModelBiped.class);
/* 27 */       list.add(ClassTransformerModelBipedMultiLayer.class);
/* 28 */       list.add(ClassTransformerEffectRenderer.class);
/* 29 */       list.add(ClassTransformerColor.class);
/*    */     } 
/*    */     
/* 32 */     list.add(ClassTransformerEntityMob.class);
/* 33 */     list.add(ClassTransformerEntityPlayer.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAccessTransformerClass() {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModContainerClass() {
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSetupClass() {
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\ALLoadingPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */