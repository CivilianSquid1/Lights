/*     */ package com.fiskmods.lightsabers.asm;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.sound.MovingSoundHum;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.ITickableSound;
/*     */ import net.minecraft.client.audio.SoundManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASMHooksClient
/*     */ {
/*  19 */   private static Minecraft mc = Minecraft.func_71410_x();
/*  20 */   public static List<String> humSounds = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public static void updateAllSounds(SoundManager soundManager, List<ITickableSound> list) {
/*  24 */     Iterator<ITickableSound> iterator = list.iterator();
/*  25 */     humSounds.clear();
/*     */     
/*  27 */     while (iterator.hasNext()) {
/*     */       
/*  29 */       ITickableSound tickableSound = iterator.next();
/*     */       
/*  31 */       if (tickableSound instanceof MovingSoundHum) {
/*     */         
/*  33 */         MovingSoundHum sound = (MovingSoundHum)tickableSound;
/*  34 */         humSounds.add(sound.theEntity.func_110124_au().toString());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean hasHumSound(Entity entity) {
/*  41 */     return humSounds.contains(entity.func_110124_au().toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor3b(byte r, byte g, byte b) {
/*  46 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  48 */       GL11.glColor3b(r, g, b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor3d(double r, double g, double b) {
/*  54 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  56 */       GL11.glColor3d(r, g, b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor3f(float r, float g, float b) {
/*  62 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  64 */       GL11.glColor3f(r, g, b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor3ub(byte r, byte g, byte b) {
/*  70 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  72 */       GL11.glColor3ub(r, g, b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor4b(byte r, byte g, byte b, byte a) {
/*  78 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  80 */       GL11.glColor4b(r, g, b, a);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor4d(double r, double g, double b, double a) {
/*  86 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  88 */       GL11.glColor4d(r, g, b, a);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor4f(float r, float g, float b, float a) {
/*  94 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/*  96 */       GL11.glColor4f(r, g, b, a);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void glColor4ub(byte r, byte g, byte b, byte a) {
/* 102 */     if (!ALRenderHelper.overrideColor)
/*     */     {
/* 104 */       GL11.glColor4ub(r, g, b, a);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\ASMHooksClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */