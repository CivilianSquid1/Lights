/*    */ package com.fiskmods.lightsabers.asm.transformers;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.tree.FieldNode;
/*    */ import org.objectweb.asm.tree.MethodNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassTransformerMethodProcess
/*    */   extends ClassTransformerBase
/*    */ {
/*    */   private final String methodName;
/*    */   private final String methodNameDev;
/*    */   private final String methodDesc;
/*    */   private final String methodDescDev;
/*    */   private String methName;
/*    */   private String methDesc;
/*    */   public static String varPlayer;
/*    */   
/*    */   public ClassTransformerMethodProcess(String classPath, String methodName, String methodNameDev, String methodDesc, String methodDescDev) {
/* 21 */     super(classPath);
/* 22 */     this.methodName = methodName;
/* 23 */     this.methodNameDev = methodNameDev;
/* 24 */     this.methodDesc = methodDesc;
/* 25 */     this.methodDescDev = methodDescDev;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean processMethods(List<MethodNode> methods) {
/* 31 */     for (MethodNode method : methods) {
/*    */       
/* 33 */       if (method.name.equals(this.methName) && method.desc.equals(this.methDesc)) {
/*    */         
/* 35 */         processMethod(method);
/* 36 */         return true;
/*    */       } 
/*    */     } 
/*    */     
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void processMethod(MethodNode paramMethodNode);
/*    */ 
/*    */   
/*    */   public boolean processFields(List<FieldNode> fields) {
/* 48 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setupMappings() {
/* 54 */     this.methName = getMappedName(this.methodName, this.methodNameDev);
/* 55 */     this.methDesc = getMappedName(this.methodDesc, this.methodDescDev);
/*    */     
/* 57 */     varPlayer = getMappedName("yz", "net/minecraft/entity/player/EntityPlayer");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerMethodProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */