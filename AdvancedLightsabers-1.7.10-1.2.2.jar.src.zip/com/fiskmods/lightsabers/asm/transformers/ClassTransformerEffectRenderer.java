/*     */ package com.fiskmods.lightsabers.asm.transformers;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.particle.ALParticles;
/*     */ import java.util.List;
/*     */ import org.objectweb.asm.Type;
/*     */ import org.objectweb.asm.tree.AbstractInsnNode;
/*     */ import org.objectweb.asm.tree.FieldInsnNode;
/*     */ import org.objectweb.asm.tree.FieldNode;
/*     */ import org.objectweb.asm.tree.IincInsnNode;
/*     */ import org.objectweb.asm.tree.InsnList;
/*     */ import org.objectweb.asm.tree.InsnNode;
/*     */ import org.objectweb.asm.tree.LabelNode;
/*     */ import org.objectweb.asm.tree.LineNumberNode;
/*     */ import org.objectweb.asm.tree.MethodInsnNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ import org.objectweb.asm.tree.TypeInsnNode;
/*     */ import org.objectweb.asm.tree.VarInsnNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassTransformerEffectRenderer
/*     */   extends ClassTransformerBase
/*     */ {
/*     */   public static String varPlayer;
/*     */   public static String varEntity;
/*     */   
/*     */   public ClassTransformerEffectRenderer() {
/*  28 */     super("net.minecraft.client.particle.EffectRenderer");
/*     */   }
/*     */ 
/*     */   
/*     */   public static int plus(int i) {
/*  33 */     i++;
/*     */     
/*  35 */     if (i == 3)
/*     */     {
/*  37 */       i++;
/*     */     }
/*     */     
/*  40 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processMethods(List<MethodNode> methods) {
/*  46 */     String[] names = { "<init>", getMappedName("a", "updateEffects"), getMappedName("a", "renderParticles"), getMappedName("b", "renderLitParticles"), getMappedName("a", "clearEffects") };
/*  47 */     String[] descs = { getMappedName("(Lahb;Lbqf;)V", "(Lnet/minecraft/world/World;Lnet/minecraft/client/renderer/texture/TextureManager;)V"), "()V", getMappedName("(Lsa;F)V", "(Lnet/minecraft/entity/Entity;F)V"), getMappedName("(Lsa;F)V", "(Lnet/minecraft/entity/Entity;F)V"), getMappedName("(Lahb;)V", "(Lnet/minecraft/world/World;)V") };
/*  48 */     boolean flag = false;
/*     */     
/*  50 */     for (MethodNode method : methods) {
/*     */       
/*  52 */       for (int i = 0; i < names.length; i++) {
/*     */         
/*  54 */         String name = names[i];
/*  55 */         String desc = descs[i];
/*     */         
/*  57 */         if (method.name.equals(name) && method.desc.equals(desc)) {
/*     */           
/*  59 */           InsnList list = new InsnList();
/*     */           
/*  61 */           for (int j = 0; j < method.instructions.size(); j++) {
/*     */             
/*  63 */             AbstractInsnNode node = method.instructions.get(j);
/*     */             
/*  65 */             if (node instanceof InsnNode) {
/*     */               
/*  67 */               InsnNode insnNode = (InsnNode)node;
/*     */               
/*  69 */               if (insnNode.getOpcode() == 6) {
/*     */                 
/*  71 */                 if (method.name.equals(names[2]) && method.desc.equals(descs[2])) {
/*     */                   
/*  73 */                   list.add((AbstractInsnNode)new FieldInsnNode(178, Type.getInternalName(ALParticles.class), "fxLayersSize", "I"));
/*     */                   
/*     */                   continue;
/*     */                 } 
/*  77 */               } else if (insnNode.getOpcode() == 7) {
/*     */                 
/*  79 */                 list.add((AbstractInsnNode)new FieldInsnNode(178, Type.getInternalName(ALParticles.class), "fxLayersSize", "I"));
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */             } 
/*  84 */             list.add(node);
/*     */             continue;
/*     */           } 
/*  87 */           method.instructions.clear();
/*  88 */           method.instructions.add(list);
/*  89 */           flag = true;
/*     */         } 
/*     */       } 
/*     */       
/*  93 */       if (method.name.equals(names[2]) && method.desc.equals(descs[2])) {
/*     */         
/*  95 */         InsnList list = new InsnList();
/*  96 */         int line = 0;
/*     */         
/*  98 */         for (int j = 0; j < method.instructions.size(); j++) {
/*     */           
/* 100 */           AbstractInsnNode node = method.instructions.get(j);
/*     */           
/* 102 */           if (node instanceof LineNumberNode) {
/*     */             
/* 104 */             LineNumberNode lineNode = (LineNumberNode)node;
/* 105 */             line = lineNode.line;
/*     */           } 
/*     */           
/* 108 */           if (node instanceof MethodInsnNode) {
/*     */             
/* 110 */             MethodInsnNode methodNode = (MethodInsnNode)node;
/*     */             
/* 112 */             if (node.getOpcode() == 182 && methodNode.owner.equals(getMappedName("bmh", "net/minecraft/client/renderer/Tessellator")) && methodNode.name.equals(getMappedName("b", "startDrawingQuads")) && methodNode.desc.equals("()V")) {
/*     */               
/* 114 */               list.add(node);
/*     */               
/* 116 */               LabelNode labelNode = new LabelNode();
/* 117 */               list.add((AbstractInsnNode)labelNode);
/* 118 */               list.add((AbstractInsnNode)new LineNumberNode(line + 1, labelNode));
/* 119 */               list.add((AbstractInsnNode)new VarInsnNode(21, 9));
/* 120 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ALParticles.class), "bindParticleTextures", "(I)V", false));
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/* 125 */           if (node instanceof IincInsnNode) {
/*     */             
/* 127 */             IincInsnNode iincNode = (IincInsnNode)node;
/*     */             
/* 129 */             if (iincNode.var == 8 && iincNode.incr == 1) {
/*     */               
/* 131 */               list.add((AbstractInsnNode)new VarInsnNode(21, 8));
/* 132 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ClassTransformerEffectRenderer.class), "plus", "(I)I", false));
/* 133 */               list.add((AbstractInsnNode)new VarInsnNode(54, 8));
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/* 138 */           list.add(node);
/*     */           continue;
/*     */         } 
/* 141 */         method.instructions.clear();
/* 142 */         method.instructions.add(list);
/* 143 */         flag = true;
/*     */       } 
/*     */       
/* 146 */       if (method.name.equals(getMappedName("b", "getStatistics")) && method.desc.equals("()Ljava/lang/String;")) {
/*     */         
/* 148 */         InsnList list = new InsnList();
/* 149 */         boolean open = false;
/*     */         
/* 151 */         for (int j = 0; j < method.instructions.size(); j++) {
/*     */           
/* 153 */           AbstractInsnNode node = method.instructions.get(j);
/*     */           
/* 155 */           if (node.getOpcode() == 176)
/*     */           {
/* 157 */             open = false;
/*     */           }
/*     */           
/* 160 */           if (open) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 165 */           if (node instanceof TypeInsnNode) {
/*     */             
/* 167 */             TypeInsnNode typeNode = (TypeInsnNode)node;
/*     */             
/* 169 */             if (node.getOpcode() == 187 && typeNode.desc.equals("java/lang/StringBuilder")) {
/*     */               
/* 171 */               open = true;
/* 172 */               list.add((AbstractInsnNode)new VarInsnNode(25, 0));
/* 173 */               list.add((AbstractInsnNode)new FieldInsnNode(180, getMappedName("bkn", "net/minecraft/client/particle/EffectRenderer"), getMappedName("c", "fxLayers"), "[Ljava/util/List;"));
/* 174 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ALParticles.class), "getParticlesInWorld", "([Ljava/util/List;)I", false));
/* 175 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(String.class), "valueOf", "(I)Ljava/lang/String;", false));
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/* 180 */           list.add(node);
/*     */           continue;
/*     */         } 
/* 183 */         method.instructions.clear();
/* 184 */         method.instructions.add(list);
/* 185 */         method.visitMaxs(1, 1);
/* 186 */         flag = true;
/*     */       } 
/*     */     } 
/*     */     
/* 190 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processFields(List<FieldNode> fields) {
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupMappings() {
/* 202 */     varPlayer = getMappedName("yz", "net/minecraft/entity/player/EntityPlayer");
/* 203 */     varEntity = getMappedName("sa", "net/minecraft/entity/Entity");
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerEffectRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */