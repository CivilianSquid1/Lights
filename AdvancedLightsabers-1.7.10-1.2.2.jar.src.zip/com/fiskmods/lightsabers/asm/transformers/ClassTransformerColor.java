/*     */ package com.fiskmods.lightsabers.asm.transformers;
/*     */ 
/*     */ import com.fiskmods.lightsabers.asm.ASMHooksClient;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.List;
/*     */ import net.minecraft.launchwrapper.IClassTransformer;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassVisitor;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.Opcodes;
/*     */ import org.objectweb.asm.Type;
/*     */ import org.objectweb.asm.tree.AbstractInsnNode;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.objectweb.asm.tree.InsnList;
/*     */ import org.objectweb.asm.tree.MethodInsnNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassTransformerColor
/*     */   implements IClassTransformer, Opcodes
/*     */ {
/*     */   public byte[] transform(String name, String transformedName, byte[] bytes) {
/*     */     try {
/*  29 */       ClassReader cr = new ClassReader(bytes);
/*  30 */       ClassNode cn = new ClassNode();
/*  31 */       cr.accept((ClassVisitor)cn, 0);
/*     */       
/*  33 */       boolean success = processMethods(cn.methods);
/*     */       
/*  35 */       ClassWriter cw = new ClassWriter(1);
/*  36 */       cn.accept((ClassVisitor)cw);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  43 */       return cw.toByteArray();
/*     */     }
/*  45 */     catch (Exception e) {
/*     */       
/*  47 */       if (!(e instanceof NullPointerException))
/*     */       {
/*  49 */         e.printStackTrace();
/*     */       }
/*     */ 
/*     */       
/*  53 */       return bytes;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean processMethods(List<MethodNode> methods) {
/*  58 */     boolean flag = false;
/*     */     
/*  60 */     for (MethodNode method : methods) {
/*     */       
/*  62 */       InsnList list = new InsnList();
/*     */       
/*  64 */       for (int j = 0; j < method.instructions.size(); j++) {
/*     */         
/*  66 */         AbstractInsnNode node = method.instructions.get(j);
/*     */         
/*  68 */         if (node instanceof MethodInsnNode) {
/*     */           
/*  70 */           MethodInsnNode methodNode = (MethodInsnNode)node;
/*     */           
/*  72 */           if (node.getOpcode() == 184 && methodNode.owner.equals("org/lwjgl/opengl/GL11") && (methodNode.name.startsWith("glColor3") || methodNode.name.startsWith("glColor4"))) {
/*     */             
/*  74 */             list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ASMHooksClient.class), methodNode.name, methodNode.desc, false));
/*  75 */             flag = true;
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*  80 */         list.add(node);
/*     */         continue;
/*     */       } 
/*  83 */       method.instructions.clear();
/*  84 */       method.instructions.add(list);
/*     */     } 
/*     */     
/*  87 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeClassFile(ClassWriter cw, String name) {
/*     */     try {
/*  94 */       File outDir = new File("debug/glColor/");
/*  95 */       outDir.mkdirs();
/*  96 */       DataOutputStream dout = new DataOutputStream(new FileOutputStream(new File(outDir, name + ".class")));
/*  97 */       dout.write(cw.toByteArray());
/*  98 */       dout.flush();
/*  99 */       dout.close();
/*     */     }
/* 101 */     catch (Exception e) {
/*     */       
/* 103 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */