/*     */ package com.fiskmods.lightsabers.asm.transformers;
/*     */ 
/*     */ import com.fiskmods.lightsabers.asm.ALLoadingPlugin;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.List;
/*     */ import net.minecraft.launchwrapper.IClassTransformer;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassVisitor;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.Opcodes;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.objectweb.asm.tree.FieldNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClassTransformerBase
/*     */   implements IClassTransformer, Opcodes
/*     */ {
/*  25 */   public static final Logger LOGGER = LogManager.getFormatterLogger("Advanced Lightsabers");
/*     */   
/*     */   protected final String classPath;
/*     */   
/*     */   protected final String unobfClass;
/*     */   
/*     */   public ClassTransformerBase(String path) {
/*  32 */     this.classPath = path;
/*  33 */     this.unobfClass = path.substring(path.lastIndexOf('.') + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] transform(String name, String transformedName, byte[] bytes) {
/*     */     try {
/*  41 */       if (transformedName.equals(this.classPath))
/*     */       {
/*  43 */         LOGGER.info("Patching Class %s (%s)", new Object[] { this.unobfClass, name });
/*     */         
/*  45 */         ClassWriter writer = new ClassWriter(1);
/*  46 */         ClassReader reader = new ClassReader(bytes);
/*  47 */         ClassNode node = new ClassNode();
/*  48 */         reader.accept((ClassVisitor)node, 0);
/*     */         
/*  50 */         setupMappings();
/*  51 */         boolean success = (processFields(node.fields) && processMethods(node.methods));
/*  52 */         addInterface(node.interfaces);
/*  53 */         node.accept((ClassVisitor)writer);
/*     */         
/*  55 */         if (success) {
/*     */           
/*  57 */           LOGGER.debug("Patching Class %s done", new Object[] { this.unobfClass });
/*     */         }
/*     */         else {
/*     */           
/*  61 */           LOGGER.error("Patching Class %s FAILED!", new Object[] { this.unobfClass });
/*     */         } 
/*     */         
/*  64 */         writeClassFile(writer, String.format("%s (%s)", new Object[] { this.unobfClass, name }));
/*     */         
/*  66 */         return writer.toByteArray();
/*     */       }
/*     */     
/*  69 */     } catch (Exception e) {
/*     */       
/*  71 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  74 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInterface(List<String> interfaces) {}
/*     */ 
/*     */   
/*     */   public abstract boolean processMethods(List<MethodNode> paramList);
/*     */ 
/*     */   
/*     */   public abstract boolean processFields(List<FieldNode> paramList);
/*     */   
/*     */   public abstract void setupMappings();
/*     */   
/*     */   public void sendPatchLog(String method) {
/*  89 */     LOGGER.log(Level.INFO, "\tPatching method %s in %s", new Object[] { method, this.unobfClass });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeClassFile(ClassWriter cw, String name) {
/*     */     try {
/*  96 */       File outDir = new File("debug/");
/*  97 */       outDir.mkdirs();
/*  98 */       DataOutputStream dout = new DataOutputStream(new FileOutputStream(new File(outDir, name + ".class")));
/*  99 */       dout.write(cw.toByteArray());
/* 100 */       dout.flush();
/* 101 */       dout.close();
/*     */     }
/* 103 */     catch (Exception e) {
/*     */       
/* 105 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getClassName(String className) {
/* 111 */     return "net/minecraft/" + className.replace(".", "/");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getMappedName(String name, String devName) {
/* 116 */     return ALLoadingPlugin.obfuscatedEnv ? name : devName;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */