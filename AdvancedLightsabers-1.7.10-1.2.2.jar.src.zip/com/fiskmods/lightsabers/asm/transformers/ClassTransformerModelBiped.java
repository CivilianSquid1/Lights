/*     */ package com.fiskmods.lightsabers.asm.transformers;
/*     */ 
/*     */ import com.fiskmods.lightsabers.helper.ModelHelper;
/*     */ import java.util.List;
/*     */ import org.objectweb.asm.Type;
/*     */ import org.objectweb.asm.tree.AbstractInsnNode;
/*     */ import org.objectweb.asm.tree.FieldNode;
/*     */ import org.objectweb.asm.tree.InsnList;
/*     */ import org.objectweb.asm.tree.MethodInsnNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ import org.objectweb.asm.tree.VarInsnNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassTransformerModelBiped
/*     */   extends ClassTransformerBase
/*     */ {
/*     */   public static String varPlayer;
/*     */   public static String varEntity;
/*     */   
/*     */   public ClassTransformerModelBiped() {
/*  22 */     super("net.minecraft.client.model.ModelBiped");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processMethods(List<MethodNode> methods) {
/*  28 */     boolean flag = false;
/*     */     
/*  30 */     for (MethodNode method : methods) {
/*     */       
/*  32 */       if (method.name.equals(getMappedName("a", "render")) && method.desc.equals(getMappedName("(Lsa;FFFFFF)V", "(Lnet/minecraft/entity/Entity;FFFFFF)V"))) {
/*     */         
/*  34 */         InsnList list = new InsnList();
/*     */         
/*  36 */         for (int i = 0; i < method.instructions.size(); i++) {
/*     */           
/*  38 */           AbstractInsnNode node = method.instructions.get(i);
/*     */           
/*  40 */           if (node instanceof MethodInsnNode) {
/*     */             
/*  42 */             MethodInsnNode methodNode = (MethodInsnNode)node;
/*     */             
/*  44 */             if (methodNode.name.equals(getMappedName("a", "setRotationAngles")) && methodNode.desc.equals(getMappedName("(FFFFFFLsa;)V", "(FFFFFFLnet/minecraft/entity/Entity;)V"))) {
/*     */               
/*  46 */               list.add(node);
/*  47 */               list.add((AbstractInsnNode)new VarInsnNode(25, 0));
/*  48 */               list.add((AbstractInsnNode)new VarInsnNode(25, 1));
/*  49 */               list.add((AbstractInsnNode)new VarInsnNode(23, 2));
/*  50 */               list.add((AbstractInsnNode)new VarInsnNode(23, 3));
/*  51 */               list.add((AbstractInsnNode)new VarInsnNode(23, 4));
/*  52 */               list.add((AbstractInsnNode)new VarInsnNode(23, 5));
/*  53 */               list.add((AbstractInsnNode)new VarInsnNode(23, 6));
/*  54 */               list.add((AbstractInsnNode)new VarInsnNode(23, 7));
/*  55 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ModelHelper.class), "renderBipedPre", getMappedName("(Lbhm;Lsa;FFFFFF)V", "(Lnet/minecraft/client/model/ModelBiped;Lnet/minecraft/entity/Entity;FFFFFF)V"), false));
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*  60 */           if (node.getOpcode() == 177) {
/*     */             
/*  62 */             list.add((AbstractInsnNode)new VarInsnNode(25, 0));
/*  63 */             list.add((AbstractInsnNode)new VarInsnNode(25, 1));
/*  64 */             list.add((AbstractInsnNode)new VarInsnNode(23, 2));
/*  65 */             list.add((AbstractInsnNode)new VarInsnNode(23, 3));
/*  66 */             list.add((AbstractInsnNode)new VarInsnNode(23, 4));
/*  67 */             list.add((AbstractInsnNode)new VarInsnNode(23, 5));
/*  68 */             list.add((AbstractInsnNode)new VarInsnNode(23, 6));
/*  69 */             list.add((AbstractInsnNode)new VarInsnNode(23, 7));
/*  70 */             list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ModelHelper.class), "renderBipedPost", getMappedName("(Lbhm;Lsa;FFFFFF)V", "(Lnet/minecraft/client/model/ModelBiped;Lnet/minecraft/entity/Entity;FFFFFF)V"), false));
/*     */           } 
/*     */           
/*  73 */           list.add(node);
/*     */           continue;
/*     */         } 
/*  76 */         method.instructions.clear();
/*  77 */         method.instructions.add(list);
/*  78 */         flag = true; continue;
/*     */       } 
/*  80 */       if (method.name.equals(getMappedName("a", "setRotationAngles")) && method.desc.equals(getMappedName("(FFFFFFLsa;)V", "(FFFFFFLnet/minecraft/entity/Entity;)V"))) {
/*     */         
/*  82 */         InsnList list = new InsnList();
/*     */         
/*  84 */         for (int i = 0; i < method.instructions.size(); i++) {
/*     */           
/*  86 */           AbstractInsnNode node = method.instructions.get(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 101 */           list.add(node);
/*     */         } 
/*     */         
/* 104 */         method.instructions.clear();
/* 105 */         method.instructions.add(list);
/* 106 */         flag = true;
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processFields(List<FieldNode> fields) {
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupMappings() {
/* 122 */     varPlayer = getMappedName("yz", "net/minecraft/entity/player/EntityPlayer");
/* 123 */     varEntity = getMappedName("sa", "net/minecraft/entity/Entity");
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerModelBiped.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */