/*    */ package com.fiskmods.lightsabers.asm.transformers;
/*    */ 
/*    */ import com.fiskmods.lightsabers.asm.ASMHooks;
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.Type;
/*    */ import org.objectweb.asm.tree.AbstractInsnNode;
/*    */ import org.objectweb.asm.tree.FieldNode;
/*    */ import org.objectweb.asm.tree.InsnList;
/*    */ import org.objectweb.asm.tree.MethodInsnNode;
/*    */ import org.objectweb.asm.tree.MethodNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassTransformerEntityMob
/*    */   extends ClassTransformerBase
/*    */ {
/*    */   public static String varPlayer;
/*    */   public static String varEntity;
/*    */   
/*    */   public ClassTransformerEntityMob() {
/* 21 */     super("net.minecraft.entity.monster.EntityMob");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean processMethods(List<MethodNode> methods) {
/* 27 */     boolean flag = false;
/*    */     
/* 29 */     for (MethodNode method : methods) {
/*    */       
/* 31 */       if (method.name.equals(getMappedName("n", "attackEntityAsMob")) && method.desc.equals("(L" + varEntity + ";)Z")) {
/*    */         
/* 33 */         InsnList list = new InsnList();
/*    */         
/* 35 */         for (int i = 0; i < method.instructions.size(); i++) {
/*    */           
/* 37 */           AbstractInsnNode node = method.instructions.get(i);
/*    */           
/* 39 */           if (node instanceof MethodInsnNode) {
/*    */             
/* 41 */             MethodInsnNode methodNode = (MethodInsnNode)node;
/*    */             
/* 43 */             if (methodNode.name.equals(getMappedName("a", "attackEntityFrom")) && methodNode.desc.equals(getMappedName("(Lro;F)Z", "(Lnet/minecraft/util/DamageSource;F)Z"))) {
/*    */               
/* 45 */               list.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName(ASMHooks.class), "attackEntityFrom", getMappedName("(L" + varEntity + ";Lro;F)Z", "(L" + varEntity + ";Lnet/minecraft/util/DamageSource;F)Z"), false));
/*    */               
/*    */               continue;
/*    */             } 
/*    */           } 
/* 50 */           list.add(node);
/*    */           continue;
/*    */         } 
/* 53 */         method.instructions.clear();
/* 54 */         method.instructions.add(list);
/* 55 */         flag = true;
/*    */       } 
/*    */     } 
/*    */     
/* 59 */     return flag;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean processFields(List<FieldNode> fields) {
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setupMappings() {
/* 71 */     varPlayer = getMappedName("yz", "net/minecraft/entity/player/EntityPlayer");
/* 72 */     varEntity = getMappedName("sa", "net/minecraft/entity/Entity");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\transformers\ClassTransformerEntityMob.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */