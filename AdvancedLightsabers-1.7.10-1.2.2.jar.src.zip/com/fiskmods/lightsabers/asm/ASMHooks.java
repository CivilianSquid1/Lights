/*    */ package com.fiskmods.lightsabers.asm;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.DamageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASMHooks
/*    */ {
/*    */   public static boolean attackEntityFrom(Entity entity, DamageSource source, float damage) {
/* 14 */     if (source.func_76346_g() instanceof EntityLivingBase) {
/*    */       
/* 16 */       EntityLivingBase attacker = (EntityLivingBase)source.func_76346_g();
/*    */       
/* 18 */       if (attacker.func_70694_bm() != null && attacker.func_70694_bm().func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaber)
/*    */       {
/* 20 */         return entity.func_70097_a(ALDamageSources.causeLightsaberDamage((Entity)attacker), damage);
/*    */       }
/*    */     } 
/*    */     
/* 24 */     return entity.func_70097_a(source, damage);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\asm\ASMHooks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */