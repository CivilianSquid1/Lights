/*    */ package com.fiskmods.lightsabers.common.keybinds;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ClientRegistry;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ 
/*    */ 
/*    */ public class ALKeyBinds
/*    */ {
/* 10 */   public static final FiskKeyBinding ACTIVATE_LIGHTSABER = new FiskKeyBinding("activateLightsaber", 19);
/* 11 */   public static final FiskKeyBinding ACTIVATE_POWER = new FiskKeyBinding("activatePower", 46);
/* 12 */   public static final FiskKeyBinding SELECT_POWER = new FiskKeyBinding("selectPower", 33);
/*    */ 
/*    */   
/*    */   public static void register() {
/* 16 */     ClientRegistry.registerKeyBinding((KeyBinding)ACTIVATE_LIGHTSABER);
/* 17 */     ClientRegistry.registerKeyBinding((KeyBinding)ACTIVATE_POWER);
/* 18 */     ClientRegistry.registerKeyBinding((KeyBinding)SELECT_POWER);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\keybinds\ALKeyBinds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */