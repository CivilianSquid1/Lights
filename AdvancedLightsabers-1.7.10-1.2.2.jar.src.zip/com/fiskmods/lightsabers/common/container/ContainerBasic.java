/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ContainerBasic<T extends TileEntity>
/*     */   extends Container
/*     */ {
/*     */   protected final T tileentity;
/*     */   protected final World worldObj;
/*     */   
/*     */   public ContainerBasic(T tile) {
/*  19 */     this.tileentity = tile;
/*  20 */     this.worldObj = (tile != null) ? tile.func_145831_w() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPlayerInventory(InventoryPlayer inventoryPlayer, int yOffset) {
/*     */     int i;
/*  28 */     for (i = 0; i < 3; i++) {
/*     */       
/*  30 */       for (int j = 0; j < 9; j++)
/*     */       {
/*  32 */         func_75146_a(makeInventorySlot(inventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + yOffset + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  36 */     for (i = 0; i < 9; i++)
/*     */     {
/*  38 */       func_75146_a(makeInventorySlot(inventoryPlayer, i, 8 + i * 18, 142 + yOffset));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot makeInventorySlot(InventoryPlayer inventoryPlayer, int index, int x, int y) {
/*  44 */     return new Slot((IInventory)inventoryPlayer, index, x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75145_c(EntityPlayer player) {
/*  50 */     if (this.tileentity != null) {
/*     */       
/*  52 */       if (this.tileentity instanceof IInventory)
/*     */       {
/*  54 */         return ((IInventory)this.tileentity).func_70300_a(player);
/*     */       }
/*     */       
/*  57 */       return (player.func_70092_e(((TileEntity)this.tileentity).field_145851_c + 0.5D, ((TileEntity)this.tileentity).field_145848_d + 0.5D, ((TileEntity)this.tileentity).field_145849_e + 0.5D) <= 64.0D);
/*     */     } 
/*     */     
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_75135_a(ItemStack stackToMove, int fromId, int toId, boolean descending) {
/*  66 */     return mergeItemStack(stackToMove, fromId, toId, descending, false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack stackToMove, int fromId, int toId, boolean descending, boolean check) {
/*  71 */     boolean success = false;
/*  72 */     int id = fromId;
/*     */     
/*  74 */     if (descending)
/*     */     {
/*  76 */       id = toId - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     if (stackToMove.func_77985_e())
/*     */     {
/*  84 */       while (stackToMove.field_77994_a > 0 && ((!descending && id < toId) || (descending && id >= fromId))) {
/*     */         
/*  86 */         Slot slot = this.field_75151_b.get(id);
/*  87 */         ItemStack dstStack = slot.func_75211_c();
/*     */         
/*  89 */         if ((!check || slot.func_75214_a(stackToMove)) && dstStack != null && dstStack.func_77973_b() == stackToMove.func_77973_b() && (!stackToMove.func_77981_g() || stackToMove.func_77960_j() == dstStack.func_77960_j()) && ItemStack.func_77970_a(stackToMove, dstStack)) {
/*     */           
/*  91 */           int maxStackSize = Math.min(slot.field_75224_c.func_70297_j_(), Math.min(dstStack.func_77976_d(), slot.func_75219_a()));
/*  92 */           int combinedStackSize = dstStack.field_77994_a + stackToMove.field_77994_a;
/*     */           
/*  94 */           if (combinedStackSize <= maxStackSize) {
/*     */             
/*  96 */             stackToMove.field_77994_a = 0;
/*  97 */             dstStack.field_77994_a = combinedStackSize;
/*  98 */             slot.func_75218_e();
/*  99 */             success = true;
/*     */           }
/* 101 */           else if (dstStack.field_77994_a < maxStackSize) {
/*     */             
/* 103 */             stackToMove.field_77994_a -= maxStackSize - dstStack.field_77994_a;
/* 104 */             dstStack.field_77994_a = maxStackSize;
/* 105 */             slot.func_75218_e();
/* 106 */             success = true;
/*     */           } 
/*     */         } 
/*     */         
/* 110 */         if (descending) {
/*     */           
/* 112 */           id--;
/*     */           
/*     */           continue;
/*     */         } 
/* 116 */         id++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (stackToMove.field_77994_a > 0) {
/*     */       
/* 123 */       if (descending) {
/*     */         
/* 125 */         id = toId - 1;
/*     */       }
/*     */       else {
/*     */         
/* 129 */         id = fromId;
/*     */       } 
/*     */       
/* 132 */       while ((!descending && id < toId) || (descending && id >= fromId)) {
/*     */         
/* 134 */         Slot slot = this.field_75151_b.get(id);
/* 135 */         ItemStack dstStack = slot.func_75211_c();
/*     */         
/* 137 */         if ((!check || slot.func_75214_a(stackToMove)) && dstStack == null) {
/*     */           
/* 139 */           int maxStackSize = Math.min(slot.field_75224_c.func_70297_j_(), Math.min(stackToMove.func_77976_d(), slot.func_75219_a()));
/* 140 */           ItemStack itemstack1 = stackToMove.func_77946_l();
/* 141 */           itemstack1.field_77994_a = Math.min(maxStackSize, itemstack1.field_77994_a);
/* 142 */           slot.func_75215_d(itemstack1);
/*     */           
/* 144 */           maxStackSize = Math.min(slot.field_75224_c.func_70297_j_(), Math.min(slot.func_75211_c().func_77976_d(), slot.func_75219_a()));
/* 145 */           stackToMove.field_77994_a = Math.max(stackToMove.field_77994_a - itemstack1.field_77994_a, 0);
/* 146 */           slot.func_75218_e();
/* 147 */           success = true;
/*     */           
/*     */           break;
/*     */         } 
/* 151 */         if (descending) {
/*     */           
/* 153 */           id--;
/*     */           
/*     */           continue;
/*     */         } 
/* 157 */         id++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 162 */     return success;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\ContainerBasic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */