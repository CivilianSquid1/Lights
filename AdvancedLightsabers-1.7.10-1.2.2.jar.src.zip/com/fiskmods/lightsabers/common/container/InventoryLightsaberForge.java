/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.item.ILightsaberComponent;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class InventoryLightsaberForge
/*     */   implements IInventory
/*     */ {
/*  14 */   private ItemStack[] inventory = new ItemStack[8];
/*     */   
/*     */   private Container eventHandler;
/*     */   
/*     */   public LightsaberData result;
/*     */   
/*     */   public InventoryLightsaberForge(Container container) {
/*  21 */     this.eventHandler = container;
/*     */   }
/*     */ 
/*     */   
/*     */   public LightsaberData updateResult() {
/*  26 */     long hash = 0L;
/*     */     
/*  28 */     for (int slot = 0; slot < func_70302_i_(); slot++) {
/*     */       
/*  30 */       ItemStack stack = func_70301_a(slot);
/*     */       
/*  32 */       if (stack != null && stack.func_77973_b() instanceof ILightsaberComponent) {
/*     */         
/*  34 */         ILightsaberComponent component = (ILightsaberComponent)stack.func_77973_b();
/*  35 */         long fingerprint = component.getFingerprint(stack, slot);
/*     */         
/*  37 */         if (!component.isCompatibleSlot(stack, slot) || (fingerprint != 0L && hash == (hash |= fingerprint)))
/*     */         {
/*  39 */           return null;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  44 */       else if (stack != null || (slot != 6 && slot != 7)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  49 */         if (slot != 5 || stack == null || stack.func_77973_b() != Items.field_151115_aP)
/*     */         {
/*  51 */           return null;
/*     */         }
/*     */       } 
/*     */     } 
/*  55 */     return new LightsaberData(hash);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/*  61 */     return this.inventory.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/*  67 */     return (slot >= func_70302_i_()) ? null : this.inventory[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_145825_b() {
/*  73 */     return "container.crafting";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/*  85 */     if (this.inventory[slot] != null) {
/*     */       
/*  87 */       ItemStack itemstack = this.inventory[slot];
/*  88 */       this.inventory[slot] = null;
/*  89 */       return itemstack;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/* 100 */     if (this.inventory[slot] != null) {
/*     */ 
/*     */ 
/*     */       
/* 104 */       if ((this.inventory[slot]).field_77994_a <= amount) {
/*     */         
/* 106 */         ItemStack itemStack = this.inventory[slot];
/* 107 */         this.inventory[slot] = null;
/* 108 */         this.eventHandler.func_75130_a(this);
/*     */         
/* 110 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/* 114 */       ItemStack itemstack = this.inventory[slot].func_77979_a(amount);
/*     */       
/* 116 */       if ((this.inventory[slot]).field_77994_a == 0)
/*     */       {
/* 118 */         this.inventory[slot] = null;
/*     */       }
/*     */       
/* 121 */       this.eventHandler.func_75130_a(this);
/*     */       
/* 123 */       return itemstack;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack itemstack) {
/* 135 */     this.inventory[slot] = itemstack;
/* 136 */     this.eventHandler.func_75130_a(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/* 142 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70296_d() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer player) {
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70295_k_() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70305_f() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int slot, ItemStack itemstack) {
/* 169 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\InventoryLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */