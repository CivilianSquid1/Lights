/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerDisassemblyStation
/*     */   extends ContainerBasic<TileEntityDisassemblyStation>
/*     */ {
/*     */   private int lastProgress;
/*     */   private int lastFuelTicks;
/*     */   private int lastMaxFuelTicks;
/*     */   
/*     */   public ContainerDisassemblyStation(InventoryPlayer inventoryPlayer, TileEntityDisassemblyStation tile) {
/*  23 */     super(tile);
/*  24 */     func_75146_a(new ValidityChecked(0, 16, 18));
/*  25 */     func_75146_a(new ValidityChecked(1, 16, 54));
/*     */     
/*  27 */     for (int i = 0; i < 15; i++)
/*     */     {
/*  29 */       func_75146_a(new ValidityChecked(i + 2, 72 + 18 * i % 5, 18 + 18 * i / 5));
/*     */     }
/*     */     
/*  32 */     addPlayerInventory(inventoryPlayer, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75132_a(ICrafting icrafting) {
/*  38 */     super.func_75132_a(icrafting);
/*  39 */     icrafting.func_71112_a(this, 0, this.tileentity.progress);
/*  40 */     icrafting.func_71112_a(this, 1, this.tileentity.fuelTicks);
/*  41 */     icrafting.func_71112_a(this, 2, this.tileentity.maxFuelTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75142_b() {
/*  47 */     super.func_75142_b();
/*     */     
/*  49 */     for (int i = 0; i < this.field_75149_d.size(); i++) {
/*     */       
/*  51 */       ICrafting icrafting = this.field_75149_d.get(i);
/*     */       
/*  53 */       if (this.lastProgress != this.tileentity.progress)
/*     */       {
/*  55 */         icrafting.func_71112_a(this, 0, this.tileentity.progress);
/*     */       }
/*     */       
/*  58 */       if (this.lastFuelTicks != this.tileentity.fuelTicks)
/*     */       {
/*  60 */         icrafting.func_71112_a(this, 1, this.tileentity.fuelTicks);
/*     */       }
/*     */       
/*  63 */       if (this.lastMaxFuelTicks != this.tileentity.maxFuelTicks)
/*     */       {
/*  65 */         icrafting.func_71112_a(this, 2, this.tileentity.maxFuelTicks);
/*     */       }
/*     */     } 
/*     */     
/*  69 */     this.lastProgress = this.tileentity.progress;
/*  70 */     this.lastFuelTicks = this.tileentity.fuelTicks;
/*  71 */     this.lastMaxFuelTicks = this.tileentity.maxFuelTicks;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_75137_b(int index, int value) {
/*  78 */     if (index == 0) {
/*     */       
/*  80 */       this.tileentity.progress = value;
/*     */     }
/*  82 */     else if (index == 1) {
/*     */       
/*  84 */       this.tileentity.fuelTicks = value;
/*     */     }
/*  86 */     else if (index == 2) {
/*     */       
/*  88 */       this.tileentity.maxFuelTicks = value;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_82846_b(EntityPlayer player, int slotId) {
/*  95 */     ItemStack itemstack = null;
/*  96 */     Slot slot = this.field_75151_b.get(slotId);
/*  97 */     int OUTPUT_MIN = 2;
/*  98 */     int OUTPUT_MAX = 16;
/*     */     
/* 100 */     if (slot != null && slot.func_75216_d()) {
/*     */       
/* 102 */       ItemStack stack = slot.func_75211_c();
/* 103 */       itemstack = stack.func_77946_l();
/*     */       
/* 105 */       if (slotId >= OUTPUT_MIN && slotId <= OUTPUT_MAX) {
/*     */         
/* 107 */         if (!func_75135_a(stack, OUTPUT_MAX + 1, OUTPUT_MAX + 36 + 1, true))
/*     */         {
/* 109 */           return null;
/*     */         }
/*     */         
/* 112 */         slot.func_75220_a(stack, itemstack);
/*     */       }
/* 114 */       else if (slotId > OUTPUT_MAX) {
/*     */         
/* 116 */         if (TileEntityDisassemblyStation.canDisassemble(stack))
/*     */         {
/* 118 */           if (!func_75135_a(stack, 0, 1, false))
/*     */           {
/* 120 */             return null;
/*     */           }
/*     */         }
/* 123 */         else if (TileEntityDisassemblyStation.isItemFuel(stack))
/*     */         {
/* 125 */           if (!func_75135_a(stack, 1, 2, false))
/*     */           {
/* 127 */             return null;
/*     */           }
/*     */         }
/* 130 */         else if (slotId >= OUTPUT_MAX + 1 && slotId < OUTPUT_MAX + 28)
/*     */         {
/* 132 */           if (!func_75135_a(stack, OUTPUT_MAX + 28, OUTPUT_MAX + 37, false))
/*     */           {
/* 134 */             return null;
/*     */           }
/*     */         }
/* 137 */         else if (slotId >= OUTPUT_MAX + 28 && slotId < OUTPUT_MAX + 37 && !func_75135_a(stack, OUTPUT_MAX + 1, OUTPUT_MAX + 28, false))
/*     */         {
/* 139 */           return null;
/*     */         }
/*     */       
/* 142 */       } else if (!func_75135_a(stack, OUTPUT_MAX + 1, OUTPUT_MAX + 37, false)) {
/*     */         
/* 144 */         return null;
/*     */       } 
/*     */       
/* 147 */       if (stack.field_77994_a == 0) {
/*     */         
/* 149 */         slot.func_75215_d((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 153 */         slot.func_75218_e();
/*     */       } 
/*     */       
/* 156 */       if (stack.field_77994_a == itemstack.field_77994_a)
/*     */       {
/* 158 */         return null;
/*     */       }
/*     */       
/* 161 */       slot.func_82870_a(player, stack);
/*     */     } 
/*     */     
/* 164 */     return itemstack;
/*     */   }
/*     */   
/*     */   private class ValidityChecked
/*     */     extends Slot
/*     */   {
/*     */     public ValidityChecked(int id, int x, int y) {
/* 171 */       super((IInventory)ContainerDisassemblyStation.this.tileentity, id, x, y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_75214_a(ItemStack itemstack) {
/* 177 */       return ContainerDisassemblyStation.this.tileentity.func_94041_b(getSlotIndex(), itemstack);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\ContainerDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */