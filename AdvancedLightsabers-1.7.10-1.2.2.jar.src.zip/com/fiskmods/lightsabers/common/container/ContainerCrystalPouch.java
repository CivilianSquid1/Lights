/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystalPouch;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ContainerCrystalPouch
/*     */   extends ContainerBasic
/*     */ {
/*     */   public InventoryCrystalPouch inventory;
/*     */   
/*     */   public ContainerCrystalPouch(InventoryPlayer inventoryPlayer, InventoryCrystalPouch inventoryPouch) {
/*  20 */     super((T)null);
/*  21 */     this.inventory = inventoryPouch;
/*     */     
/*  23 */     for (int i = 0; i < inventoryPouch.func_70302_i_(); i++) {
/*     */       
/*  25 */       final int slot = i;
/*  26 */       func_75146_a(new Slot(inventoryPouch, i, 8 + i % 9 * 18, 18 + i / 9 * 18)
/*     */           {
/*     */             
/*     */             public boolean func_75214_a(ItemStack itemstack)
/*     */             {
/*  31 */               return this.field_75224_c.func_94041_b(slot, itemstack);
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/*  36 */     addPlayerInventory(inventoryPlayer, -16);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Slot makeInventorySlot(InventoryPlayer inventoryPlayer, int index, int x, int y) {
/*  42 */     if (index == this.inventory.itemSlot)
/*     */     {
/*  44 */       return new SlotFrozen((IInventory)inventoryPlayer, index, x, y);
/*     */     }
/*     */     
/*  47 */     return new SlotExclusive((IInventory)inventoryPlayer, index, x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75145_c(EntityPlayer player) {
/*  53 */     return this.inventory.func_70300_a(player);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_82846_b(EntityPlayer player, int slotId) {
/*  59 */     ItemStack itemstack = null;
/*  60 */     Slot slot = this.field_75151_b.get(slotId);
/*     */     
/*  62 */     if (slot != null && slot.func_75216_d()) {
/*     */       
/*  64 */       ItemStack itemstack1 = slot.func_75211_c();
/*  65 */       itemstack = itemstack1.func_77946_l();
/*     */       
/*  67 */       if (itemstack != null && itemstack.func_77973_b() instanceof ItemCrystalPouch)
/*     */       {
/*  69 */         return null;
/*     */       }
/*     */       
/*  72 */       if (slotId < this.inventory.func_70302_i_()) {
/*     */         
/*  74 */         if (!func_75135_a(itemstack1, this.inventory.func_70302_i_(), this.field_75151_b.size(), true))
/*     */         {
/*  76 */           return null;
/*     */         }
/*     */       }
/*  79 */       else if (itemstack1.func_77973_b() == Item.func_150898_a(ModBlocks.lightsaberCrystal)) {
/*     */         
/*  81 */         int id = ItemCrystal.getId(itemstack1);
/*     */         
/*  83 */         if (!func_75135_a(itemstack1, id, id + 1, false))
/*     */         {
/*  85 */           return null;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/*  90 */         return null;
/*     */       } 
/*     */       
/*  93 */       if (itemstack1.field_77994_a == 0) {
/*     */         
/*  95 */         slot.func_75215_d(null);
/*     */       }
/*     */       else {
/*     */         
/*  99 */         slot.func_75218_e();
/*     */       } 
/*     */     } 
/*     */     
/* 103 */     return itemstack;
/*     */   }
/*     */   
/*     */   private class SlotFrozen
/*     */     extends Slot
/*     */   {
/*     */     private SlotFrozen(IInventory inventory, int index, int x, int y) {
/* 110 */       super(inventory, index, x, y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_75214_a(ItemStack stack) {
/* 116 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_82869_a(EntityPlayer player) {
/* 122 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private class SlotExclusive
/*     */     extends Slot
/*     */   {
/*     */     private SlotExclusive(IInventory inventory, int index, int x, int y) {
/* 130 */       super(inventory, index, x, y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_75214_a(ItemStack stack) {
/* 136 */       return !ItemCrystalPouch.getUUID(stack).equals(ContainerCrystalPouch.this.inventory.uuid);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\ContainerCrystalPouch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */