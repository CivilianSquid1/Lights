/*    */ package com.fiskmods.lightsabers.common.container;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerSithCoffin
/*    */   extends ContainerBasic
/*    */ {
/*    */   private int numRows;
/*    */   
/*    */   public ContainerSithCoffin(InventoryPlayer inventoryPlayer, TileEntitySithCoffin tile) {
/* 16 */     super((T)tile);
/* 17 */     this.numRows = tile.func_70302_i_() / 9;
/*    */     
/* 19 */     for (int i = 0; i < this.numRows; i++) {
/*    */       
/* 21 */       for (int j = 0; j < 9; j++)
/*    */       {
/* 23 */         func_75146_a(new Slot((IInventory)tile, j + i * 9, 8 + j * 18, 18 + i * 18));
/*    */       }
/*    */     } 
/*    */     
/* 27 */     addPlayerInventory(inventoryPlayer, 2 + (this.numRows - 3) * 18);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack func_82846_b(EntityPlayer player, int id) {
/* 33 */     ItemStack itemstack = null;
/* 34 */     Slot slot = this.field_75151_b.get(id);
/*    */     
/* 36 */     if (slot != null && slot.func_75216_d()) {
/*    */       
/* 38 */       ItemStack itemstack1 = slot.func_75211_c();
/* 39 */       itemstack = itemstack1.func_77946_l();
/*    */       
/* 41 */       if (id < this.numRows * 9) {
/*    */         
/* 43 */         if (!func_75135_a(itemstack1, this.numRows * 9, this.field_75151_b.size(), true))
/*    */         {
/* 45 */           return null;
/*    */         }
/*    */       }
/* 48 */       else if (!func_75135_a(itemstack1, 0, this.numRows * 9, false)) {
/*    */         
/* 50 */         return null;
/*    */       } 
/*    */       
/* 53 */       if (itemstack1.field_77994_a == 0) {
/*    */         
/* 55 */         slot.func_75215_d((ItemStack)null);
/*    */       }
/*    */       else {
/*    */         
/* 59 */         slot.func_75218_e();
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     return itemstack;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\ContainerSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */