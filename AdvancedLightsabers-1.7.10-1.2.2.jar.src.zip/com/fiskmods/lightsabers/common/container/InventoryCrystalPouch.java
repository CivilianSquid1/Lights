/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystalPouch;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import fiskfille.utils.helper.FiskServerUtils;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.crash.CrashReportCategory;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.ReportedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryCrystalPouch
/*     */   implements IInventory
/*     */ {
/*     */   public final EntityPlayer thePlayer;
/*     */   public final UUID uuid;
/*     */   public final int itemSlot;
/*  30 */   private ItemStack[] itemstacks = new ItemStack[(CrystalColor.values()).length];
/*     */ 
/*     */   
/*     */   public InventoryCrystalPouch(EntityPlayer player, int slot) {
/*  34 */     this.thePlayer = player;
/*  35 */     this.itemSlot = slot;
/*     */     
/*  37 */     ItemStack stack = getPouchStack();
/*  38 */     this.uuid = ItemCrystalPouch.getUUID(stack);
/*     */     
/*  40 */     if (!stack.func_77942_o())
/*     */     {
/*  42 */       stack.func_77982_d(new NBTTagCompound());
/*     */     }
/*     */     
/*  45 */     readFromNBT(stack.func_77978_p());
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack getPouchStack() {
/*  50 */     return FiskServerUtils.getStackInSlot(this.thePlayer, this.itemSlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addItemStackToInventory(ItemStack itemstack) {
/*  55 */     if (addItemStackToInventoryTemp(itemstack)) {
/*     */       
/*  57 */       func_70296_d();
/*  58 */       return true;
/*     */     } 
/*     */     
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean addItemStackToInventoryTemp(final ItemStack itemstack) {
/*  66 */     if (itemstack != null && itemstack.field_77994_a != 0 && itemstack.func_77973_b() != null) {
/*     */       try {
/*     */         int stackSize;
/*     */         
/*  70 */         if (itemstack.func_77951_h()) {
/*     */           
/*  72 */           int slot = getFirstEmptyStack(itemstack);
/*     */           
/*  74 */           if (slot >= 0) {
/*     */             
/*  76 */             this.itemstacks[slot] = ItemStack.func_77944_b(itemstack);
/*  77 */             (this.itemstacks[slot]).field_77992_b = 5;
/*  78 */             itemstack.field_77994_a = 0;
/*  79 */             return true;
/*     */           } 
/*     */           
/*  82 */           return false;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         do {
/*  89 */           stackSize = itemstack.field_77994_a;
/*  90 */           itemstack.field_77994_a = storePartialItemStack(itemstack);
/*     */         }
/*  92 */         while (itemstack.field_77994_a > 0 && itemstack.field_77994_a < stackSize);
/*     */         
/*  94 */         return (itemstack.field_77994_a < stackSize);
/*     */       }
/*  96 */       catch (Throwable throwable) {
/*     */         
/*  98 */         CrashReport crash = CrashReport.func_85055_a(throwable, "Adding item to quiver");
/*  99 */         CrashReportCategory category = crash.func_85058_a("Item being added");
/* 100 */         category.func_71507_a("Item ID", Integer.valueOf(Item.func_150891_b(itemstack.func_77973_b())));
/* 101 */         category.func_71507_a("Item data", Integer.valueOf(itemstack.func_77960_j()));
/* 102 */         category.func_71500_a("Item name", new Callable()
/*     */             {
/*     */               
/*     */               public String call()
/*     */               {
/* 107 */                 return itemstack.func_82833_r();
/*     */               }
/*     */             });
/* 110 */         throw new ReportedException(crash);
/*     */       } 
/*     */     }
/*     */     
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFirstEmptyStack(ItemStack itemstack) {
/* 119 */     for (int i = 0; i < this.itemstacks.length; i++) {
/*     */       
/* 121 */       if (this.itemstacks[i] == null && func_94041_b(i, itemstack))
/*     */       {
/* 123 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int storePartialItemStack(ItemStack itemstack) {
/* 132 */     Item item = itemstack.func_77973_b();
/* 133 */     int toAdd = itemstack.field_77994_a;
/*     */ 
/*     */     
/* 136 */     if (itemstack.func_77976_d() == 1) {
/*     */       
/* 138 */       int j = getFirstEmptyStack(itemstack);
/*     */       
/* 140 */       if (j < 0)
/*     */       {
/* 142 */         return toAdd;
/*     */       }
/*     */       
/* 145 */       if (this.itemstacks[j] == null)
/*     */       {
/* 147 */         this.itemstacks[j] = ItemStack.func_77944_b(itemstack);
/*     */       }
/*     */       
/* 150 */       return 0;
/*     */     } 
/*     */     
/* 153 */     int slot = storeItemStack(itemstack);
/*     */     
/* 155 */     if (slot < 0)
/*     */     {
/* 157 */       slot = getFirstEmptyStack(itemstack);
/*     */     }
/*     */     
/* 160 */     if (slot < 0)
/*     */     {
/* 162 */       return toAdd;
/*     */     }
/*     */     
/* 165 */     if (this.itemstacks[slot] == null) {
/*     */       
/* 167 */       this.itemstacks[slot] = new ItemStack(item, 0, itemstack.func_77960_j());
/*     */       
/* 169 */       if (itemstack.func_77942_o())
/*     */       {
/* 171 */         this.itemstacks[slot].func_77982_d((NBTTagCompound)itemstack.func_77978_p().func_74737_b());
/*     */       }
/*     */     } 
/*     */     
/* 175 */     int i = toAdd;
/*     */     
/* 177 */     if (toAdd > this.itemstacks[slot].func_77976_d() - (this.itemstacks[slot]).field_77994_a)
/*     */     {
/* 179 */       i = this.itemstacks[slot].func_77976_d() - (this.itemstacks[slot]).field_77994_a;
/*     */     }
/*     */     
/* 182 */     if (i > func_70297_j_() - (this.itemstacks[slot]).field_77994_a)
/*     */     {
/* 184 */       i = func_70297_j_() - (this.itemstacks[slot]).field_77994_a;
/*     */     }
/*     */     
/* 187 */     if (i == 0)
/*     */     {
/* 189 */       return toAdd;
/*     */     }
/*     */     
/* 192 */     (this.itemstacks[slot]).field_77994_a += i;
/* 193 */     (this.itemstacks[slot]).field_77992_b = 5;
/*     */     
/* 195 */     return toAdd - i;
/*     */   }
/*     */ 
/*     */   
/*     */   private int storeItemStack(ItemStack itemstack) {
/* 200 */     for (int i = 0; i < this.itemstacks.length; i++) {
/*     */       
/* 202 */       if (this.itemstacks[i] != null && this.itemstacks[i].func_77973_b() == itemstack.func_77973_b() && this.itemstacks[i].func_77985_e() && (this.itemstacks[i]).field_77994_a < this.itemstacks[i].func_77976_d() && (this.itemstacks[i]).field_77994_a < func_70297_j_() && (!this.itemstacks[i].func_77981_g() || this.itemstacks[i].func_77960_j() == itemstack.func_77960_j()) && ItemStack.func_77970_a(this.itemstacks[i], itemstack))
/*     */       {
/* 204 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 208 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFromNBT(NBTTagCompound nbt) {
/* 213 */     NBTTagList list = nbt.func_150295_c("Slots", 10);
/* 214 */     this.itemstacks = new ItemStack[func_70302_i_()];
/*     */     
/* 216 */     for (int i = 0; i < Math.min(list.func_74745_c(), func_70302_i_()); i++) {
/*     */       
/* 218 */       NBTTagCompound tag = list.func_150305_b(i);
/* 219 */       this.itemstacks[tag.func_74771_c("Slot")] = ItemStack.func_77949_a(tag);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
/* 225 */     NBTTagList list = new NBTTagList();
/*     */     
/* 227 */     for (int i = 0; i < func_70302_i_(); i++) {
/*     */       
/* 229 */       if (this.itemstacks[i] != null) {
/*     */         
/* 231 */         NBTTagCompound tag = this.itemstacks[i].func_77955_b(new NBTTagCompound());
/* 232 */         tag.func_74774_a("Slot", (byte)i);
/*     */         
/* 234 */         list.func_74742_a((NBTBase)tag);
/*     */       } 
/*     */     } 
/*     */     
/* 238 */     nbt.func_74782_a("Slots", (NBTBase)list);
/*     */     
/* 240 */     return nbt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/* 246 */     return this.itemstacks.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/* 252 */     return this.itemstacks[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/* 258 */     ItemStack stack = func_70301_a(slot);
/*     */     
/* 260 */     if (stack != null)
/*     */     {
/* 262 */       if (stack.field_77994_a > amount) {
/*     */         
/* 264 */         stack = stack.func_77979_a(amount);
/* 265 */         func_70296_d();
/*     */       }
/*     */       else {
/*     */         
/* 269 */         func_70299_a(slot, null);
/*     */       } 
/*     */     }
/*     */     
/* 273 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/* 279 */     ItemStack stack = func_70301_a(slot);
/* 280 */     func_70299_a(slot, null);
/*     */     
/* 282 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack stack) {
/* 288 */     this.itemstacks[slot] = stack;
/*     */     
/* 290 */     if (stack != null && stack.field_77994_a > func_70297_j_())
/*     */     {
/* 292 */       stack.field_77994_a = func_70297_j_();
/*     */     }
/*     */     
/* 295 */     func_70296_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_145825_b() {
/* 301 */     return "Crystal Pouch";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/* 307 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/* 313 */     return 16;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70296_d() {
/* 319 */     if (!this.thePlayer.field_70170_p.field_72995_K && func_70300_a(this.thePlayer))
/*     */     {
/* 321 */       writeToNBT(getPouchStack().func_77978_p());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer player) {
/* 328 */     return ItemCrystalPouch.getUUID(getPouchStack()).equals(this.uuid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70295_k_() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70305_f() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int slot, ItemStack stack) {
/* 344 */     return (stack.func_77973_b() == Item.func_150898_a(ModBlocks.lightsaberCrystal) && slot == ItemCrystal.getId(stack));
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\InventoryCrystalPouch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */