/*     */ package com.fiskmods.lightsabers.common.container;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.item.ILightsaberComponent;
/*     */ import com.fiskmods.lightsabers.common.item.ItemFocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.InventoryCraftResult;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ 
/*     */ 
/*     */ public class ContainerLightsaberForge
/*     */   extends ContainerBasic<TileEntityLightsaberForge>
/*     */ {
/*  24 */   public InventoryLightsaberForge craftMatrix = new InventoryLightsaberForge(this);
/*  25 */   public IInventory craftResult = (IInventory)new InventoryCraftResult();
/*     */   
/*  27 */   public static final int[][] SLOTS = new int[][] { { 20, 17 }, { 20, 35 }, { 20, 53 }, { 20, 71 }, { 43, 71 }, { 66, 71 }, { 89, 71 }, { 107, 71 } };
/*     */ 
/*     */   
/*     */   public ContainerLightsaberForge(InventoryPlayer inventoryPlayer, TileEntityLightsaberForge tile) {
/*  31 */     super(tile);
/*     */     
/*  33 */     for (int slot = 0; slot < SLOTS.length; slot++)
/*     */     {
/*  35 */       func_75146_a(new Input(slot, SLOTS[slot][0], SLOTS[slot][1]));
/*     */     }
/*     */     
/*  38 */     func_75146_a(new Output(0, 136, 87));
/*  39 */     addPlayerInventory(inventoryPlayer, 30);
/*  40 */     func_75130_a(this.craftMatrix);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75130_a(IInventory inventory) {
/*  46 */     this.craftMatrix.result = this.craftMatrix.updateResult();
/*  47 */     ItemStack result = (this.craftMatrix.result == null) ? null : ItemLightsaberBase.setActive(this.craftMatrix.result.create(), true);
/*     */     
/*  49 */     if (result != null) {
/*     */       
/*  51 */       ItemStack itemstack = this.craftMatrix.func_70301_a(5);
/*     */       
/*  53 */       if (itemstack != null && itemstack.func_77973_b() == Items.field_151115_aP)
/*     */       {
/*  55 */         result.func_77978_p().func_74778_a("Special", Item.field_150901_e.func_148750_c(itemstack.func_77973_b()));
/*     */       }
/*     */     } 
/*     */     
/*  59 */     this.craftResult.func_70299_a(0, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75134_a(EntityPlayer player) {
/*  65 */     super.func_75134_a(player);
/*     */     
/*  67 */     if (!this.worldObj.field_72995_K)
/*     */     {
/*  69 */       for (int i = 0; i < this.craftMatrix.func_70302_i_(); i++) {
/*     */         
/*  71 */         ItemStack itemstack = this.craftMatrix.func_70304_b(i);
/*     */         
/*  73 */         if (itemstack != null)
/*     */         {
/*  75 */           player.func_71019_a(itemstack, false);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_82846_b(EntityPlayer player, int slotId) {
/*  84 */     ItemStack itemstack = null;
/*  85 */     Slot slot = this.field_75151_b.get(slotId);
/*  86 */     int OUTPUT = 8;
/*     */     
/*  88 */     if (slot != null && slot.func_75216_d()) {
/*     */       
/*  90 */       ItemStack itemstack1 = slot.func_75211_c();
/*  91 */       itemstack = itemstack1.func_77946_l();
/*     */       
/*  93 */       if (slotId == OUTPUT) {
/*     */         
/*  95 */         if (!func_75135_a(itemstack1, OUTPUT + 1, OUTPUT + 36 + 1, true))
/*     */         {
/*  97 */           return null;
/*     */         }
/*     */         
/* 100 */         slot.func_75220_a(itemstack1, itemstack);
/*     */       }
/* 102 */       else if (slotId > OUTPUT) {
/*     */         
/* 104 */         boolean flag = true;
/*     */         
/* 106 */         for (int i = 0; i < OUTPUT; i++) {
/*     */           
/* 108 */           Slot slot1 = this.field_75151_b.get(i);
/* 109 */           Item item = itemstack1.func_77973_b();
/*     */           
/* 111 */           if (item instanceof ILightsaberComponent && ((ILightsaberComponent)item).isCompatibleSlot(itemstack, i)) {
/*     */             
/* 113 */             if (!slot1.func_75216_d() && !mergeItemStack(itemstack1, i, i + 1, false, true))
/*     */             {
/* 115 */               return null;
/*     */             }
/*     */             
/* 118 */             flag = false;
/*     */           } 
/*     */         } 
/*     */         
/* 122 */         if (flag)
/*     */         {
/* 124 */           if (slotId >= OUTPUT + 1 && slotId < OUTPUT + 28)
/*     */           {
/* 126 */             if (!func_75135_a(itemstack1, OUTPUT + 28, OUTPUT + 37, false))
/*     */             {
/* 128 */               return null;
/*     */             }
/*     */           }
/* 131 */           else if (slotId >= OUTPUT + 28 && slotId < OUTPUT + 37 && !func_75135_a(itemstack1, OUTPUT + 1, OUTPUT + 28, false))
/*     */           {
/* 133 */             return null;
/*     */           }
/*     */         
/*     */         }
/* 137 */       } else if (!func_75135_a(itemstack1, OUTPUT + 1, OUTPUT + 37, false)) {
/*     */         
/* 139 */         return null;
/*     */       } 
/*     */       
/* 142 */       if (itemstack1.field_77994_a == 0) {
/*     */         
/* 144 */         slot.func_75215_d((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 148 */         slot.func_75218_e();
/*     */       } 
/*     */       
/* 151 */       if (itemstack1.field_77994_a == itemstack.field_77994_a)
/*     */       {
/* 153 */         return null;
/*     */       }
/*     */       
/* 156 */       slot.func_82870_a(player, itemstack1);
/*     */     } 
/*     */     
/* 159 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94530_a(ItemStack itemstack, Slot slot) {
/* 165 */     return (slot.field_75224_c != this.craftResult && super.func_94530_a(itemstack, slot));
/*     */   }
/*     */   
/*     */   private class Input
/*     */     extends Slot
/*     */   {
/*     */     public Input(int id, int x, int y) {
/* 172 */       super(ContainerLightsaberForge.this.craftMatrix, id, x, y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int func_75219_a() {
/* 178 */       return 1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_75214_a(ItemStack itemstack) {
/* 184 */       Item item = itemstack.func_77973_b();
/*     */       
/* 186 */       if (!(item instanceof ILightsaberComponent) || !((ILightsaberComponent)item).isCompatibleSlot(itemstack, getSlotIndex()))
/*     */       {
/* 188 */         if (getSlotIndex() != 5 || item != Items.field_151115_aP)
/*     */         {
/* 190 */           return false;
/*     */         }
/*     */       }
/*     */       
/* 194 */       for (int slot = 0; slot < this.field_75224_c.func_70302_i_(); slot++) {
/*     */         
/* 196 */         ItemStack stack = this.field_75224_c.func_70301_a(slot);
/*     */         
/* 198 */         if (stack != null && stack.func_77973_b() == item && (stack.func_77984_f() || stack.func_77960_j() == itemstack.func_77960_j()))
/*     */         {
/* 200 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 204 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public IIcon func_75212_b() {
/* 211 */       return (getSlotIndex() == 6 || getSlotIndex() == 7) ? ItemFocusingCrystal.outlineIcon : null;
/*     */     }
/*     */   }
/*     */   
/*     */   private class Output
/*     */     extends Slot
/*     */   {
/*     */     public Output(int id, int x, int y) {
/* 219 */       super(ContainerLightsaberForge.this.craftResult, id, x, y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_82869_a(EntityPlayer player) {
/* 225 */       return (ContainerLightsaberForge.this.craftMatrix.result != null && !ContainerLightsaberForge.this.craftMatrix.result.isTooShort());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean func_75214_a(ItemStack itemstack) {
/* 231 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void func_82870_a(EntityPlayer player, ItemStack itemstack) {
/* 237 */       FMLCommonHandler.instance().firePlayerCraftingEvent(player, itemstack, ContainerLightsaberForge.this.craftMatrix);
/* 238 */       func_75208_c(itemstack);
/*     */       
/* 240 */       for (int i = 0; i < ContainerLightsaberForge.this.craftMatrix.func_70302_i_(); i++) {
/*     */         
/* 242 */         ItemStack itemstack1 = ContainerLightsaberForge.this.craftMatrix.func_70301_a(i);
/*     */         
/* 244 */         if (itemstack1 != null)
/*     */         {
/* 246 */           ContainerLightsaberForge.this.craftMatrix.func_70298_a(i, 1);
/*     */         }
/*     */       } 
/*     */       
/* 250 */       ItemLightsaberBase.setActive(itemstack, false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\container\ContainerLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */