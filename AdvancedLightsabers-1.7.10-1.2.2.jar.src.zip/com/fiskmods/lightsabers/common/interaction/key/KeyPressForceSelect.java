/*    */ package com.fiskmods.lightsabers.common.interaction.key;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.gui.GuiSelectPowers;
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*    */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.interaction.key.KeyPressBase;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class KeyPressForceSelect
/*    */   extends KeyPressBase {
/*    */   public KeyPressForceSelect() {
/* 21 */     super(new InteractionHandler.InteractionType[] { InteractionHandler.InteractionType.KEY_HOLD });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean serverRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 27 */     return PowerManager.hasPowerUnlocked(player, Power.FORCE_SENSITIVITY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public FiskKeyBinding getKey(EntityPlayer player) {
/* 34 */     return ALKeyBinds.SELECT_POWER;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z, Integer[] args) {
/* 40 */     if (side.isClient())
/*    */     {
/* 42 */       receive(sender);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void receive(EntityPlayer sender) {
/* 49 */     Minecraft.func_71410_x().func_147108_a((GuiScreen)new GuiSelectPowers());
/*    */     
/* 51 */     if (((Byte)ALData.SELECTED_POWER.get((Entity)sender)).byteValue() > 0) {
/*    */       
/* 53 */       ALData.SELECTED_POWER.incr(sender, Byte.valueOf((byte)-1));
/*    */     }
/*    */     else {
/*    */       
/* 57 */       ALData.SELECTED_POWER.set(sender, Byte.valueOf((byte)2));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\interaction\key\KeyPressForceSelect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */