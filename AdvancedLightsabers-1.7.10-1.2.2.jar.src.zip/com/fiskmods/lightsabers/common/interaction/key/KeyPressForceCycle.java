/*    */ package com.fiskmods.lightsabers.common.interaction.key;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*    */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.interaction.key.KeyPressBase;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class KeyPressForceCycle
/*    */   extends KeyPressBase
/*    */ {
/*    */   public KeyPressForceCycle() {
/* 19 */     super(new InteractionHandler.InteractionType[] { InteractionHandler.InteractionType.KEY_PRESS });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean serverRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 25 */     return PowerManager.hasPowerUnlocked(player, Power.FORCE_SENSITIVITY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public FiskKeyBinding getKey(EntityPlayer player) {
/* 32 */     return ALKeyBinds.SELECT_POWER;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z, Integer[] args) {
/* 38 */     if (side.isClient())
/*    */     {
/* 40 */       if (((Byte)ALData.SELECTED_POWER.get((Entity)sender)).byteValue() < 2) {
/*    */         
/* 42 */         ALData.SELECTED_POWER.incr(sender, Byte.valueOf((byte)1));
/*    */       }
/*    */       else {
/*    */         
/* 46 */         ALData.SELECTED_POWER.set(sender, Byte.valueOf((byte)0));
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\interaction\key\KeyPressForceCycle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */