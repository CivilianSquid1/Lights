/*    */ package com.fiskmods.lightsabers.common.interaction.key;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*    */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.interaction.key.KeyPressBase;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class KeyPressLightsaber
/*    */   extends KeyPressBase
/*    */ {
/*    */   public boolean serverRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 19 */     return (player.func_70694_bm() != null && player.func_70694_bm().func_77973_b() instanceof ItemLightsaberBase);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public FiskKeyBinding getKey(EntityPlayer player) {
/* 26 */     return ALKeyBinds.ACTIVATE_LIGHTSABER;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z, Integer[] args) {
/* 32 */     if (side.isServer())
/*    */     {
/* 34 */       ItemLightsaberBase.ignite((EntityLivingBase)sender, !ItemLightsaberBase.isActive(sender.func_70694_bm()));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean syncWithServer() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public NetworkRegistry.TargetPoint getTargetPoint(EntityPlayer player, int x, int y, int z) {
/* 47 */     return TARGET_NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\interaction\key\KeyPressLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */