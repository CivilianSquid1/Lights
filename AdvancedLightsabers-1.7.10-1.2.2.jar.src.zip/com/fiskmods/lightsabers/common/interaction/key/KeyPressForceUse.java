/*    */ package com.fiskmods.lightsabers.common.interaction.key;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*    */ import com.fiskmods.lightsabers.common.force.PowerType;
/*    */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*    */ import com.fiskmods.lightsabers.helper.ALHelper;
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.interaction.key.KeyPressBase;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyPressForceUse
/*    */   extends KeyPressBase
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   public FiskKeyBinding getKey(EntityPlayer player) {
/* 27 */     return ALKeyBinds.ACTIVATE_POWER;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean clientRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 33 */     return (super.clientRequirements(player, type, x, y, z) && execute(player, Side.CLIENT));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z, Integer[] args) {
/* 39 */     if (side.isServer())
/*    */     {
/* 41 */       execute(sender, side);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 47 */     Power power = PowerManager.getSelectedPower(player);
/*    */     
/* 49 */     if (power != null && ((Integer)ALData.USE_POWER_COOLDOWN.get((Entity)player)).intValue() == 0 && ALHelper.getForcePowerMax(player) > 0 && power.powerStats.powerType == PowerType.PER_USE) {
/*    */       
/* 51 */       if (((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue() >= power.getUseCost(player) && power.powerEffect.execute(player, side)) {
/*    */         
/* 53 */         if (side.isServer()) {
/*    */           
/* 55 */           String sound = power.powerEffect.getCastSound(power.getSide());
/*    */           
/* 57 */           if (!StringUtils.func_151246_b(sound))
/*    */           {
/* 59 */             player.field_70170_p.func_72956_a((Entity)player, sound, power.powerEffect.getCastSoundVolume(power.getSide()), power.powerEffect.getCastSoundPitch(power.getSide()));
/*    */           }
/*    */           
/* 62 */           ALData.FORCE_POWER.incr(player, Float.valueOf(-power.getUseCost(player)));
/* 63 */           ALData.USE_POWER_COOLDOWN.set(player, Integer.valueOf(20));
/*    */         } 
/*    */         
/* 66 */         return true;
/*    */       } 
/* 68 */       if (side.isClient())
/*    */       {
/* 70 */         player.func_85030_a(ALSounds.player_force_fail, 1.0F, 1.0F);
/*    */       }
/*    */     } 
/*    */     
/* 74 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean syncWithServer() {
/* 80 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public NetworkRegistry.TargetPoint getTargetPoint(EntityPlayer player, int x, int y, int z) {
/* 86 */     return TARGET_NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\interaction\key\KeyPressForceUse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */