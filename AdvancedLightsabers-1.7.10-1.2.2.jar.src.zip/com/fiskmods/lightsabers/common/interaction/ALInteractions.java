/*    */ package com.fiskmods.lightsabers.common.interaction;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.interaction.key.KeyPressForceCycle;
/*    */ import com.fiskmods.lightsabers.common.interaction.key.KeyPressForceSelect;
/*    */ import com.fiskmods.lightsabers.common.interaction.key.KeyPressForceUse;
/*    */ import com.fiskmods.lightsabers.common.interaction.key.KeyPressLightsaber;
/*    */ import fiskfille.utils.common.interaction.Interaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALInteractions
/*    */ {
/*    */   public static void register() {
/* 15 */     register("activate_lightsaber", (Interaction)new KeyPressLightsaber());
/* 16 */     register("activate_force_power", (Interaction)new KeyPressForceUse());
/* 17 */     register("select_force_power", (Interaction)new KeyPressForceSelect());
/* 18 */     register("cycle_force_power", (Interaction)new KeyPressForceCycle());
/*    */   }
/*    */ 
/*    */   
/*    */   private static void register(String key, Interaction value) {
/* 23 */     Interaction.register("lightsabers:" + key, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\interaction\ALInteractions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */