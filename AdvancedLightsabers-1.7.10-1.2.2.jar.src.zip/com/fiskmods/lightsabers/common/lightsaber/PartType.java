/*    */ package com.fiskmods.lightsabers.common.lightsaber;
/*    */ 
/*    */ public enum PartType
/*    */ {
/*  5 */   EMITTER("emitter"),
/*  6 */   SWITCH_SECTION("switch_section"),
/*  7 */   BODY("body"),
/*  8 */   POMMEL("pommel");
/*    */   
/*    */   public final String textureName;
/*    */ 
/*    */   
/*    */   PartType(String name) {
/* 14 */     this.textureName = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLowerPart() {
/* 19 */     return (this == BODY || this == POMMEL);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\lightsaber\PartType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */