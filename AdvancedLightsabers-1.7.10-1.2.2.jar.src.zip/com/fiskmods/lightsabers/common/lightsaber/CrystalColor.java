/*    */ package com.fiskmods.lightsabers.common.lightsaber;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Random;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ public enum CrystalColor
/*    */ {
/* 10 */   DEEP_BLUE(0, 255),
/* 11 */   MEDIUM_BLUE(1, 27647),
/* 12 */   LIGHT_BLUE(2, 5880319),
/* 13 */   ARCTIC_BLUE(3, 14546687),
/* 14 */   WHITE(4, 16777215),
/* 15 */   INDIGO(5, 6095103),
/* 16 */   PURPLE(6, 11337901),
/* 17 */   MAGENTA(7, 16711935),
/* 18 */   PINK(8, 16748474),
/* 19 */   RED(9, 16711680),
/* 20 */   BLOOD_ORANGE(10, 16744448),
/* 21 */   AMBER(11, 16758272),
/* 22 */   YELLOW(12, 16776960),
/* 23 */   GOLD(13, 16777018),
/* 24 */   LIME_GREEN(14, 12582656),
/* 25 */   GREEN(15, 65280),
/* 26 */   MINT_GREEN(16, 65435),
/* 27 */   CYAN(17, 65535);
/*    */   static {
/* 29 */     COLOR_VALUES = new float[(values()).length][3];
/*    */     
/* 31 */     GROUP_BLUE = new CrystalColor[] { DEEP_BLUE, MEDIUM_BLUE, LIGHT_BLUE, ARCTIC_BLUE, CYAN, INDIGO };
/* 32 */     GROUP_PURPLE = new CrystalColor[] { INDIGO, PURPLE, MAGENTA, PINK };
/* 33 */     GROUP_RED = new CrystalColor[] { PINK, RED, BLOOD_ORANGE };
/* 34 */     GROUP_ORANGE = new CrystalColor[] { BLOOD_ORANGE, AMBER };
/* 35 */     GROUP_YELLOW = new CrystalColor[] { AMBER, YELLOW, GOLD };
/* 36 */     GROUP_GREEN = new CrystalColor[] { LIME_GREEN, GREEN, MINT_GREEN, CYAN };
/*    */     
/* 38 */     GROUP_COLD = new CrystalColor[] { DEEP_BLUE, MEDIUM_BLUE, LIGHT_BLUE, ARCTIC_BLUE, WHITE, INDIGO, PURPLE, CYAN };
/* 39 */     GROUP_HOT = new CrystalColor[] { MAGENTA, PINK, RED, BLOOD_ORANGE, AMBER, YELLOW, GOLD };
/* 40 */     GROUP_NEUTRAL = new CrystalColor[] { PINK, LIME_GREEN, GREEN, MINT_GREEN, CYAN };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 91 */     for (CrystalColor color : values())
/*    */     {
/* 93 */       COLOR_VALUES[color.ordinal()] = getRGB(color.color); } 
/*    */   }
/*    */   
/*    */   public static final float[][] COLOR_VALUES;
/*    */   public static final CrystalColor[] GROUP_BLUE;
/*    */   public static final CrystalColor[] GROUP_PURPLE;
/*    */   public static final CrystalColor[] GROUP_RED;
/*    */   public static final CrystalColor[] GROUP_ORANGE;
/*    */   public static final CrystalColor[] GROUP_YELLOW;
/*    */   public static final CrystalColor[] GROUP_GREEN;
/*    */   public static final CrystalColor[] GROUP_COLD;
/*    */   public static final CrystalColor[] GROUP_HOT;
/*    */   public static final CrystalColor[] GROUP_NEUTRAL;
/*    */   public final int id;
/*    */   public final int color;
/*    */   
/*    */   CrystalColor(int id, int color) {
/*    */     this.id = id;
/*    */     this.color = color;
/*    */   }
/*    */   
/*    */   public String getUnlocalizedName() {
/*    */     return "lightsaber.color." + name().toLowerCase(Locale.ROOT);
/*    */   }
/*    */   
/*    */   public String getLocalizedName() {
/*    */     return StatCollector.func_74838_a(getUnlocalizedName()).trim();
/*    */   }
/*    */   
/*    */   public float[] getRGB() {
/*    */     return COLOR_VALUES[ordinal()];
/*    */   }
/*    */   
/*    */   private static float[] getRGB(int hex) {
/*    */     float r = ((hex & 0xFF0000) >> 16) / 255.0F;
/*    */     float g = ((hex & 0xFF00) >> 8) / 255.0F;
/*    */     float b = (hex & 0xFF) / 255.0F;
/*    */     return new float[] { r, g, b };
/*    */   }
/*    */   
/*    */   public static CrystalColor get(int id) {
/*    */     return values()[Math.abs(id) % (values()).length];
/*    */   }
/*    */   
/*    */   public static CrystalColor getRandom(Random rand) {
/*    */     return values()[rand.nextInt((values()).length)];
/*    */   }
/*    */   
/*    */   public static CrystalColor getRandom() {
/*    */     return getRandom(new Random());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\lightsaber\CrystalColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */