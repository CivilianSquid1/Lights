/*     */ package com.fiskmods.lightsabers.common.lightsaber;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ItemFocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.saberbuilder.AbstractLightsaberData;
/*     */ import com.google.common.collect.Lists;
/*     */ import fiskfille.utils.helper.FiskComparators;
/*     */ import fiskfille.utils.helper.NBTHelper;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightsaberData
/*     */   extends AbstractLightsaberData
/*     */   implements NBTHelper.ISerializableObject<LightsaberData>
/*     */ {
/*  32 */   public static final LightsaberData EMPTY = new LightsaberData();
/*     */   
/*     */   public static final float MIN_LENGTH_CM = 19.0F;
/*     */   
/*     */   public LightsaberData() {
/*  37 */     this(0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public LightsaberData(long hashCode) {
/*  42 */     this.hash = hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getIDForObject(Hilt hilt) {
/*  48 */     return Hilt.REGISTRY.getIDForObject((FiskRegistryEntry)hilt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Hilt getObjectById(int id) {
/*  54 */     return (Hilt)Hilt.REGISTRY.getObjectById(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LightsaberData createNew(long hashCode) {
/*  60 */     return new LightsaberData(hashCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData copy() {
/*  71 */     return (LightsaberData)super.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData strip() {
/*  82 */     return (LightsaberData)super.strip();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTooShort() {
/*  90 */     return (getHeightCm() < 19.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getRGB(ItemStack itemstack) {
/*  99 */     if (itemstack.func_82833_r().equals("jeb_")) {
/*     */       
/* 101 */       EntityPlayer player = Lightsabers.proxy.getPlayer();
/* 102 */       int time = 25;
/*     */       
/* 104 */       float[][] rgb = CrystalColor.COLOR_VALUES;
/* 105 */       float f = ((player.field_70173_aa % time) + Lightsabers.proxy.getRenderTick()) / time;
/* 106 */       int i = player.field_70173_aa / time;
/* 107 */       int j = i % rgb.length;
/* 108 */       int k = (i + 1) % rgb.length;
/*     */       
/* 110 */       return new float[] { rgb[j][0] * (1.0F - f) + rgb[k][0] * f, rgb[j][1] * (1.0F - f) + rgb[k][1] * f, rgb[j][2] * (1.0F - f) + rgb[k][2] * f };
/*     */     } 
/*     */     
/* 113 */     return getColor().getRGB();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData set(PartType type, Hilt hilt) {
/* 126 */     return (LightsaberData)super.set(type, hilt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData set(Hilt... hilt) {
/* 144 */     return (LightsaberData)super.set(hilt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData set(Hilt hilt) {
/* 157 */     return (LightsaberData)super.set(hilt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData set(CrystalColor color) {
/* 169 */     return (LightsaberData)super.set(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData set(FocusingCrystal... crystals) {
/* 183 */     return (LightsaberData)super.set(crystals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData add(FocusingCrystal crystal) {
/* 195 */     return (LightsaberData)super.add(crystal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LightsaberData remove(FocusingCrystal crystal) {
/* 207 */     return (LightsaberData)super.remove(crystal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack create() {
/* 217 */     ItemStack itemstack = new ItemStack(ModItems.lightsaber);
/* 218 */     itemstack.func_77982_d(new NBTTagCompound());
/* 219 */     itemstack.func_77978_p().func_74772_a("Lightsaber", (strip()).hash);
/*     */     
/* 221 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTBase writeToNBT() {
/* 227 */     return (NBTBase)new NBTTagLong(this.hash);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/* 233 */     buf.writeLong(this.hash);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Adapter
/*     */     implements NBTHelper.ISaveAdapter<LightsaberData>
/*     */   {
/*     */     public LightsaberData readFromNBT(NBTBase tag) {
/* 241 */       if (tag instanceof NBTBase.NBTPrimitive)
/*     */       {
/* 243 */         return new LightsaberData(((NBTBase.NBTPrimitive)tag).func_150291_c());
/*     */       }
/*     */       
/* 246 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LightsaberData fromBytes(ByteBuf buf) {
/* 252 */       return new LightsaberData(buf.readLong());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LightsaberData readFromNBT(NBTTagCompound nbt) {
/* 266 */     if (nbt.func_150297_b("Lightsaber", 10)) {
/*     */       
/* 268 */       NBTTagCompound compound = nbt.func_74775_l("Lightsaber");
/* 269 */       LightsaberData data = (new LightsaberData()).set(CrystalColor.get(compound.func_74762_e("color")));
/*     */       
/* 271 */       if (compound.func_150297_b("FocusingCrystals", 11))
/*     */       {
/* 273 */         for (int id : compound.func_74759_k("FocusingCrystals"))
/*     */         {
/* 275 */           data.add(ItemFocusingCrystal.get(id));
/*     */         }
/*     */       }
/*     */       
/* 279 */       for (PartType type : PartType.values())
/*     */       {
/* 281 */         data.set(type, (Hilt)Hilt.REGISTRY.getObject((String)Hilt.LEGACY_MAPPINGS.get(compound.func_74779_i(type.name().toLowerCase(Locale.ROOT)))));
/*     */       }
/*     */       
/* 284 */       nbt.func_82580_o("Lightsaber");
/* 285 */       nbt.func_74772_a("Lightsaber", data.hash);
/*     */       
/* 287 */       return data;
/*     */     } 
/* 289 */     if (nbt.func_150297_b("Lightsaber", 99))
/*     */     {
/* 291 */       return (new LightsaberData(nbt.func_74763_f("Lightsaber"))).strip();
/*     */     }
/* 293 */     if (nbt.func_150297_b("Lightsaber", 8)) {
/*     */       
/*     */       try {
/*     */         
/* 297 */         return (new LightsaberData(Long.decode(nbt.func_74779_i("Lightsaber")).longValue())).strip();
/*     */       }
/* 299 */       catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 304 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LightsaberData get(ItemStack itemstack) {
/* 316 */     if (itemstack != null && itemstack.func_77942_o())
/*     */     {
/* 318 */       return readFromNBT(itemstack.func_77978_p());
/*     */     }
/*     */     
/* 321 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hilt get(ItemStack itemstack, PartType type) {
/* 330 */     return get(itemstack).get(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hilt[] getHilt(ItemStack itemstack) {
/* 339 */     return get(itemstack).getHilt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hilt.Part getPart(ItemStack itemstack, PartType type) {
/* 348 */     return get(itemstack).getPart(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getHeight(ItemStack itemstack) {
/* 357 */     if (itemstack.func_77973_b() == ModItems.doubleLightsaber) {
/*     */       
/* 359 */       LightsaberData[] array = ItemDoubleLightsaber.get(itemstack);
/* 360 */       return array[0].getHeight() + array[1].getHeight();
/*     */     } 
/*     */     
/* 363 */     return get(itemstack).getHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getHeightCm(ItemStack itemstack) {
/* 372 */     return getHeight(itemstack) * 0.575F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CrystalColor getColor(ItemStack itemstack) {
/* 381 */     return get(itemstack).getColor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FocusingCrystal[] getFocusingCrystals(ItemStack itemstack) {
/* 390 */     return get(itemstack).getFocusingCrystals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasFocusingCrystal(ItemStack itemstack, FocusingCrystal crystal) {
/* 399 */     return get(itemstack).hasFocusingCrystal(crystal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ItemStack createRandom(Random rand, CrystalColor color) {
/* 411 */     Hilt[] hilt = new Hilt[4];
/*     */     
/* 413 */     for (int i = 0; i < 4; i++)
/*     */     {
/* 415 */       hilt[i] = (Hilt)Hilt.REGISTRY.getRandom(rand);
/*     */     }
/*     */     
/* 418 */     LightsaberData data = (new LightsaberData()).set(hilt);
/*     */     
/* 420 */     if (data.isTooShort())
/*     */     {
/* 422 */       return createRandom(rand, color);
/*     */     }
/*     */     
/* 425 */     if (color == null)
/*     */     {
/* 427 */       color = CrystalColor.getRandom(rand);
/*     */     }
/*     */     
/* 430 */     data.set(color);
/*     */     
/* 432 */     if (rand.nextInt(10) == 0) {
/*     */       
/* 434 */       List<FocusingCrystal> crystals = Lists.newArrayList((Object[])FocusingCrystal.values());
/* 435 */       Collections.sort(crystals, FiskComparators.random(rand));
/*     */       
/* 437 */       data.add(crystals.get(0));
/*     */       
/* 439 */       if (rand.nextInt(20) == 0)
/*     */       {
/* 441 */         data.add(crystals.get(1));
/*     */       }
/*     */     } 
/*     */     
/* 445 */     return data.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ItemStack createRandom(Random rand) {
/* 457 */     return createRandom(rand, (CrystalColor)null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\lightsaber\LightsaberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */