/*    */ package com.fiskmods.lightsabers.common.lightsaber;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ public enum FocusingCrystal
/*    */ {
/*  9 */   COMPRESSED,
/* 10 */   CRACKED,
/* 11 */   INVERTING,
/* 12 */   FINE_CUT,
/*    */   
/* 14 */   PRISMATIC;
/*    */ 
/*    */   
/*    */   public long getCode() {
/* 18 */     return (1 << ordinal() & 0xFFFF);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName() {
/* 23 */     return "lightsaber.focusingCrystal." + name().toLowerCase(Locale.ROOT);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLocalizedName() {
/* 28 */     return StatCollector.func_74838_a(getUnlocalizedName()).trim();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\lightsaber\FocusingCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */