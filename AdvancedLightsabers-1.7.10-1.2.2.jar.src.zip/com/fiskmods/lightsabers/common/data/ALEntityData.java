/*    */ package com.fiskmods.lightsabers.common.data;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.nbt.NBTBase;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.IExtendedEntityProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALEntityData
/*    */   implements IExtendedEntityProperties
/*    */ {
/*    */   public static final String IDENTIFIER = "ALEntity";
/* 20 */   public List<StatusEffect> activeEffects = Lists.newArrayList();
/*    */   
/*    */   public boolean forcePushed;
/*    */   
/*    */   public static ALEntityData getData(EntityLivingBase entity) {
/* 25 */     return (ALEntityData)entity.getExtendedProperties("ALEntity");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void saveNBTData(NBTTagCompound nbt) {
/* 31 */     NBTTagCompound compound = new NBTTagCompound();
/* 32 */     compound.func_74757_a("Saved", true);
/* 33 */     compound.func_74757_a("ForcePushed", this.forcePushed);
/*    */     
/* 35 */     if (!this.activeEffects.isEmpty()) {
/*    */       
/* 37 */       NBTTagList nbttaglist = new NBTTagList();
/*    */       
/* 39 */       for (StatusEffect effect : this.activeEffects)
/*    */       {
/* 41 */         nbttaglist.func_74742_a((NBTBase)effect.writeToNBT(new NBTTagCompound()));
/*    */       }
/*    */       
/* 44 */       compound.func_74782_a("Effects", (NBTBase)nbttaglist);
/*    */     } 
/*    */     
/* 47 */     nbt.func_74782_a("ALEntity", (NBTBase)compound);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadNBTData(NBTTagCompound nbt) {
/* 53 */     NBTTagCompound compound = nbt.func_74775_l("ALEntity");
/*    */     
/* 55 */     if (compound.func_74767_n("Saved")) {
/*    */       
/* 57 */       this.forcePushed = compound.func_74767_n("ForcePushed");
/*    */       
/* 59 */       if (compound.func_150297_b("Effects", 9)) {
/*    */         
/* 61 */         NBTTagList nbttaglist = compound.func_150295_c("Effects", 10);
/* 62 */         this.activeEffects.clear();
/*    */         
/* 64 */         for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
/*    */           
/* 66 */           StatusEffect effect = StatusEffect.readFromNBT(nbttaglist.func_150305_b(i));
/*    */           
/* 68 */           if (effect != null)
/*    */           {
/* 70 */             this.activeEffects.add(effect);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void init(Entity entity, World world) {}
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\ALEntityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */