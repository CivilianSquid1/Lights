/*    */ package com.fiskmods.lightsabers.common.data;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.force.PowerData;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALDataPowers
/*    */   extends ALData<PowerData.Container>
/*    */ {
/*    */   public ALDataPowers() {
/* 12 */     super(PowerData.Container.factory());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void update(Entity entity) {
/* 18 */     PowerData.Container value = get(entity);
/*    */     
/* 20 */     if (value != null)
/*    */     {
/* 22 */       value.update(entity);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onValueChanged(Entity entity, PowerData.Container value) {
/* 29 */     if (value != null)
/*    */     {
/* 31 */       value.markDirty(entity);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\ALDataPowers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */