/*    */ package com.fiskmods.lightsabers.common.data;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.google.common.base.Predicate;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ import java.lang.reflect.Field;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALDataInterp<T>
/*    */   extends ALData<T>
/*    */ {
/*    */   protected final ALData<T> prevData;
/*    */   
/*    */   protected ALDataInterp(T defaultValue) {
/* 19 */     super(defaultValue);
/* 20 */     this.prevData = (new ALData(defaultValue)).setExempt(3);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ALDataInterp(T defaultValue, Predicate<Entity> canSet) {
/* 25 */     super(defaultValue, canSet);
/* 26 */     this.prevData = (new ALData(defaultValue, canSet)).setExempt(3);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ALDataInterp setExempt(int exempt) {
/* 32 */     this.prevData.setExempt(exempt);
/* 33 */     return (ALDataInterp)super.setExempt(exempt);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ALDataInterp revokePerms(Side side) {
/* 39 */     this.prevData.revokePerms(side);
/* 40 */     return (ALDataInterp)super.revokePerms(side);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void update(Entity entity) {
/* 46 */     this.prevData.setWithoutNotify(entity, get(entity));
/*    */   }
/*    */ 
/*    */   
/*    */   public ALData<T> getPrevData() {
/* 51 */     return this.prevData;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getPrev(EntityPlayer player) {
/* 56 */     return this.prevData.get((Entity)player);
/*    */   }
/*    */ 
/*    */   
/*    */   public T getPrev(Entity entity) {
/* 61 */     return this.prevData.get(entity);
/*    */   }
/*    */ 
/*    */   
/*    */   public T interpolate(Entity entity, float progress) {
/* 66 */     if (progress == 1.0F)
/*    */     {
/* 68 */       return get(entity);
/*    */     }
/* 70 */     if (ofType(Float.class))
/*    */     {
/* 72 */       return (T)Float.valueOf(FiskServerUtils.interpolate(((Float)getPrev(entity)).floatValue(), ((Float)get(entity)).floatValue(), progress));
/*    */     }
/* 74 */     if (ofType(Double.class))
/*    */     {
/* 76 */       return (T)Double.valueOf(FiskServerUtils.interpolate(((Double)getPrev(entity)).doubleValue(), ((Double)get(entity)).doubleValue(), progress));
/*    */     }
/*    */ 
/*    */     
/* 80 */     throw new RuntimeException("Cannot interpolate a non-decimal data type!");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T interpolate(Entity entity) {
/* 86 */     return interpolate(entity, Lightsabers.proxy.getRenderTick());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void init(Field field, String name) throws ClassNotFoundException {
/* 92 */     super.init(field, name);
/* 93 */     this.prevData.init(field, "PREV_" + name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\ALDataInterp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */