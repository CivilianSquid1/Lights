package com.fiskmods.lightsabers.common.data;

public interface IDataHolder {
  <T> void set(ALData<T> paramALData, T paramT);
  
  <T> T get(ALData<T> paramALData);
}


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\IDataHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */