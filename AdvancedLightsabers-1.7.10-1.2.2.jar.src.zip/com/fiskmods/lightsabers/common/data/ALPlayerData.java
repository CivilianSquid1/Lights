/*    */ package com.fiskmods.lightsabers.common.data;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Map;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.nbt.NBTBase;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.IExtendedEntityProperties;
/*    */ 
/*    */ 
/*    */ public class ALPlayerData
/*    */   implements IExtendedEntityProperties
/*    */ {
/*    */   public static final String IDENTIFIER = "ALPlayer";
/* 17 */   public Map<ALData, Object> data = Maps.newHashMap();
/*    */ 
/*    */   
/*    */   public static ALPlayerData getData(EntityPlayer player) {
/* 21 */     return (ALPlayerData)player.getExtendedProperties("ALPlayer");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void saveNBTData(NBTTagCompound nbt) {
/* 27 */     NBTTagCompound compound = new NBTTagCompound();
/*    */     
/* 29 */     compound.func_74757_a("Saved", true);
/* 30 */     ALData.writeToNBT(compound, this.data);
/*    */     
/* 32 */     nbt.func_74782_a("ALPlayer", (NBTBase)compound);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadNBTData(NBTTagCompound nbt) {
/* 38 */     NBTTagCompound compound = nbt.func_74775_l("ALPlayer");
/*    */     
/* 40 */     if (compound.func_74767_n("Saved"))
/*    */     {
/* 42 */       this.data = ALData.readFromNBT(compound, this.data);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(Entity entity, World world) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void copy(ALPlayerData props) {
/* 53 */     this.data = props.data;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> void putData(ALData<T> type, T value) {
/* 58 */     this.data.put(type, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T getData(ALData<T> type) {
/* 63 */     if (this.data.containsKey(type))
/*    */     {
/* 65 */       return (T)this.data.get(type);
/*    */     }
/* 67 */     if (!type.defaultValue.canEqual()) {
/*    */       
/* 69 */       putData(type, type.getDefault());
/*    */       
/* 71 */       return getData(type);
/*    */     } 
/*    */     
/* 74 */     return type.getDefault();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\ALPlayerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */