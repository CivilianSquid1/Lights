/*     */ package com.fiskmods.lightsabers.common.data.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.MessageUpdateEffects;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.primitives.Doubles;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusEffect
/*     */   implements Comparable<StatusEffect>
/*     */ {
/*     */   public Effect effect;
/*     */   public short duration;
/*     */   public byte amplifier;
/*     */   public UUID casterUUID;
/*     */   
/*     */   public StatusEffect(Effect effect, int duration, int amplifier) {
/*  31 */     this.effect = effect;
/*  32 */     this.duration = (short)duration;
/*  33 */     this.amplifier = (byte)amplifier;
/*     */   }
/*     */ 
/*     */   
/*     */   public StatusEffect(Effect effect, int duration, int amplifier, UUID uuid) {
/*  38 */     this(effect, duration, amplifier);
/*  39 */     this.casterUUID = uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public StatusEffect(Effect effect, int duration, int amplifier, EntityLivingBase entity) {
/*  44 */     this(effect, duration, amplifier, (entity != null) ? entity.func_110124_au() : null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static StatusEffect fromBytes(ByteBuf buf) {
/*  49 */     Effect e = Effect.getEffectById(buf.readByte());
/*     */     
/*  51 */     if (e != null) {
/*     */       
/*  53 */       StatusEffect effect = new StatusEffect(e, buf.readShort(), buf.readByte());
/*     */       
/*  55 */       if (buf.readBoolean()) {
/*     */         
/*  57 */         UUID uuid = new UUID(buf.readLong(), buf.readLong());
/*  58 */         effect.casterUUID = uuid;
/*     */       } 
/*     */       
/*  61 */       return effect;
/*     */     } 
/*     */     
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/*  69 */     buf.writeByte((byte)Effect.getIdFromEffect(this.effect));
/*  70 */     buf.writeShort(this.duration);
/*  71 */     buf.writeByte(this.amplifier);
/*     */     
/*  73 */     if (this.casterUUID != null) {
/*     */       
/*  75 */       buf.writeBoolean(true);
/*  76 */       buf.writeLong(this.casterUUID.getMostSignificantBits());
/*  77 */       buf.writeLong(this.casterUUID.getLeastSignificantBits());
/*     */     }
/*     */     else {
/*     */       
/*  81 */       buf.writeBoolean(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static StatusEffect readFromNBT(NBTTagCompound tag) {
/*  87 */     Effect effect = Effect.getEffectFromName(tag.func_74779_i("Id"));
/*     */     
/*  89 */     if (effect != null) {
/*     */       
/*  91 */       UUID uuid = null;
/*     */       
/*  93 */       if (tag.func_150297_b("CasterUUIDMost", 99) && tag.func_150297_b("CasterUUIDLeast", 99))
/*     */       {
/*  95 */         uuid = new UUID(tag.func_74763_f("CasterUUIDMost"), tag.func_74763_f("CasterUUIDLeast"));
/*     */       }
/*     */       
/*  98 */       return new StatusEffect(effect, tag.func_74762_e("Duration"), tag.func_74762_e("Amplifier"), uuid);
/*     */     } 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public NBTTagCompound writeToNBT(NBTTagCompound tag) {
/* 106 */     tag.func_74778_a("Id", this.effect.delegate.name());
/* 107 */     tag.func_74768_a("Duration", this.duration);
/* 108 */     tag.func_74768_a("Amplifier", this.amplifier);
/*     */     
/* 110 */     if (this.casterUUID != null) {
/*     */       
/* 112 */       tag.func_74772_a("CasterUUIDMost", this.casterUUID.getMostSignificantBits());
/* 113 */       tag.func_74772_a("CasterUUIDLeast", this.casterUUID.getLeastSignificantBits());
/*     */     } 
/*     */     
/* 116 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMaxDuration() {
/* 121 */     return (this.duration >= Short.MAX_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void add(EntityLivingBase entity, Effect effect, int duration, int amplifier) {
/* 126 */     add(entity, (EntityLivingBase)null, effect, duration, amplifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void add(EntityLivingBase entity, Entity caster, Effect effect, int duration, int amplifier) {
/* 131 */     add(entity, (caster instanceof EntityLivingBase) ? (EntityLivingBase)caster : null, effect, duration, amplifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void add(EntityLivingBase entity, EntityLivingBase caster, Effect effect, int duration, int amplifier) {
/* 136 */     List<StatusEffect> list = get(entity);
/* 137 */     duration = MathHelper.func_76125_a(duration, -32768, 32767);
/*     */     
/* 139 */     for (StatusEffect status : list) {
/*     */       
/* 141 */       if (status.effect == effect) {
/*     */         
/* 143 */         short prevDuration = status.duration;
/* 144 */         byte prevAmplifier = status.amplifier;
/*     */         
/* 146 */         status.duration = (short)Math.max(status.duration, duration);
/* 147 */         status.amplifier = (byte)Math.max(status.amplifier, amplifier);
/*     */         
/* 149 */         if (caster != null)
/*     */         {
/* 151 */           status.casterUUID = caster.func_110124_au();
/*     */         }
/*     */         
/* 154 */         if (prevDuration != status.duration || prevAmplifier != status.amplifier) {
/*     */           
/* 156 */           if (!entity.field_70170_p.field_72995_K)
/*     */           {
/* 158 */             ALNetworkManager.wrapper.sendToDimension((IMessage)new MessageUpdateEffects(entity, list), entity.field_71093_bK);
/*     */           }
/*     */           
/* 161 */           Collections.sort(list);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 168 */     list.add(new StatusEffect(effect, duration, amplifier, caster));
/* 169 */     Collections.sort(list);
/*     */     
/* 171 */     if (!entity.field_70170_p.field_72995_K)
/*     */     {
/* 173 */       ALNetworkManager.wrapper.sendToDimension((IMessage)new MessageUpdateEffects(entity, list), entity.field_71093_bK);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<StatusEffect> get(EntityLivingBase entity) {
/* 179 */     return (ALEntityData.getData(entity)).activeEffects;
/*     */   }
/*     */ 
/*     */   
/*     */   public static StatusEffect get(EntityLivingBase entity, Effect effect) {
/* 184 */     for (StatusEffect status : get(entity)) {
/*     */       
/* 186 */       if (status.effect == effect)
/*     */       {
/* 188 */         return status;
/*     */       }
/*     */     } 
/*     */     
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean has(EntityLivingBase entity, Effect effect) {
/* 197 */     return (get(entity, effect) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clear(EntityLivingBase entity) {
/* 202 */     if (!entity.field_70170_p.field_72995_K) {
/*     */       
/* 204 */       List<StatusEffect> list = get(entity);
/*     */       
/* 206 */       if (!list.isEmpty()) {
/*     */         
/* 208 */         list.clear();
/* 209 */         ALNetworkManager.wrapper.sendToDimension((IMessage)new MessageUpdateEffects(entity, list), entity.field_71093_bK);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clear(EntityLivingBase entity, Effect effect) {
/* 216 */     if (!entity.field_70170_p.field_72995_K && has(entity, effect)) {
/*     */       
/* 218 */       List<StatusEffect> list = get(entity);
/* 219 */       Iterator<StatusEffect> iter = list.iterator();
/*     */       
/* 221 */       while (iter.hasNext()) {
/*     */         
/* 223 */         if (((StatusEffect)iter.next()).effect == effect)
/*     */         {
/* 225 */           iter.remove();
/*     */         }
/*     */       } 
/*     */       
/* 229 */       ALNetworkManager.wrapper.sendToDimension((IMessage)new MessageUpdateEffects(entity, list), entity.field_71093_bK);
/*     */       
/* 231 */       if (!list.isEmpty())
/*     */       {
/* 233 */         Collections.sort(list);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<EntityLivingBase> getTargets(EntityLivingBase caster, Effect effect, int amplifier) {
/* 240 */     List<EntityLivingBase> targets = Lists.newArrayList();
/*     */     
/* 242 */     for (EntityLivingBase entity : Iterables.filter(caster.field_70170_p.field_72996_f, EntityLivingBase.class)) {
/*     */       
/* 244 */       StatusEffect status = get(entity, effect);
/*     */       
/* 246 */       if (status != null && (amplifier < 0 || amplifier == status.amplifier) && status.casterUUID != null && status.casterUUID.equals(caster.func_110124_au()))
/*     */       {
/* 248 */         targets.add(entity);
/*     */       }
/*     */     } 
/*     */     
/* 252 */     return targets;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<EntityLivingBase> getTargets(EntityLivingBase caster, Effect effect) {
/* 257 */     return getTargets(caster, effect, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 263 */     return String.format("Effect[id=%s,d=%s,a=%s]", new Object[] { this.effect, Short.valueOf(this.duration), Byte.valueOf(this.amplifier) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(StatusEffect o) {
/* 269 */     return Doubles.compare(o.duration, this.duration);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\effect\StatusEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */