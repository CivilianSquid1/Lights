/*     */ package com.fiskmods.lightsabers.common.data.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.google.common.collect.Lists;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import fiskfille.utils.registry.FiskRegistryNamespaced;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Effect
/*     */   extends FiskRegistryEntry<Effect>
/*     */ {
/*  19 */   public static final FiskRegistryNamespaced<Effect> REGISTRY = new FiskRegistryNamespaced("lightsabers", null);
/*     */ 
/*     */   
/*     */   public static void register(int id, String key, Effect value) {
/*  23 */     REGISTRY.addObject(id, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void register(String key, Effect value) {
/*  28 */     REGISTRY.putObject(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Effect getEffectFromName(String key) {
/*  33 */     return (Effect)REGISTRY.getObject(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNameForEffect(Effect value) {
/*  38 */     return REGISTRY.getNameForObject(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getIdFromEffect(Effect value) {
/*  43 */     return (value == null) ? 0 : REGISTRY.getIDForObject(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Effect getEffectById(int id) {
/*  48 */     return (Effect)REGISTRY.getObjectById(id);
/*     */   }
/*     */   
/*  51 */   public static final Effect FORTIFY = new Effect(false);
/*  52 */   public static final Effect STUN = new Effect(false);
/*     */   
/*  54 */   public static final Effect DRAIN = new Effect(true);
/*  55 */   public static final Effect LIGHTNING = new Effect(false);
/*  56 */   public static final Effect CHOKE = new Effect(true);
/*     */   
/*  58 */   public static final Effect STEALTH = new Effect(false);
/*  59 */   public static final Effect SPEED = new Effect(false);
/*  60 */   public static final Effect GAZE = new Effect(false);
/*  61 */   public static final Effect MEDITATION = new Effect(false);
/*  62 */   public static final Effect RESIST = new Effect(false);
/*     */   
/*     */   private final boolean negativeEffect;
/*  65 */   public List<Power> powers = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public Effect(boolean negative) {
/*  69 */     this.negativeEffect = negative;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNegative() {
/*  74 */     return this.negativeEffect;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName() {
/*  79 */     return "statusEffect." + this.delegate.name().replace(':', '.');
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalizedName() {
/*  84 */     return StatCollector.func_74838_a(getUnlocalizedName());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormattedString(StatusEffect effect) {
/*  89 */     String s = getLocalizedName();
/*     */     
/*  91 */     if (effect.amplifier > 0 && effect.amplifier < 10)
/*     */     {
/*  93 */       s = s + " " + StatCollector.func_74838_a("enchantment.level." + (effect.amplifier + 1));
/*     */     }
/*     */     
/*  96 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDurationString(StatusEffect effect) {
/* 101 */     if (effect.isMaxDuration())
/*     */     {
/* 103 */       return "**:**";
/*     */     }
/*     */     
/* 106 */     return StringUtils.func_76337_a(effect.duration);
/*     */   }
/*     */ 
/*     */   
/*     */   public Power getPower(int i) {
/* 111 */     return !this.powers.isEmpty() ? this.powers.get(MathHelper.func_76125_a(i, 0, this.powers.size() - 1)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void register() {
/* 116 */     for (Field field : Effect.class.getFields()) {
/*     */       
/* 118 */       if (Effect.class.isAssignableFrom(field.getType())) {
/*     */         
/*     */         try {
/*     */           
/* 122 */           register(field.getName().toLowerCase(Locale.ROOT), (Effect)field.get(null));
/*     */         }
/* 124 */         catch (Exception e) {
/*     */           
/* 126 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Effect> getEffectsForPower(Power power) {
/* 134 */     List<Effect> list = Lists.newArrayList();
/*     */     
/* 136 */     for (Effect effect : REGISTRY) {
/*     */       
/* 138 */       if (effect.powers.contains(power))
/*     */       {
/* 140 */         list.add(effect);
/*     */       }
/*     */     } 
/*     */     
/* 144 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\effect\Effect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */