/*     */ package com.fiskmods.lightsabers.common.data;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.MessagePlayerData;
/*     */ import com.fiskmods.lightsabers.helper.ALFormatHelper;
/*     */ import com.google.common.base.Objects;
/*     */ import com.google.common.base.Predicate;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fiskfille.utils.helper.NBTHelper;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import fiskfille.utils.registry.FiskRegistryNamespaced;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ public class ALData<T>
/*     */   extends FiskRegistryEntry<ALData<?>>
/*     */ {
/*  32 */   public static final FiskRegistryNamespaced<ALData<?>> REGISTRY = new FiskRegistryNamespaced("lightsabers", null); protected static final int SAVE_NBT = 1;
/*     */   protected static final int SYNC_BYTES = 2;
/*     */   
/*     */   public static void register(String key, ALData value) {
/*  36 */     REGISTRY.putObject(key, value);
/*     */   }
/*     */   protected static final int RESET_ON_DEATH = 4; protected static final int RESET_WO_PRED = 8;
/*     */   
/*     */   public static ALData getDataFromName(String key) {
/*  41 */     return (ALData)REGISTRY.getObject(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNameForData(ALData value) {
/*  46 */     return REGISTRY.getNameForObject(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final ALData<Float> FORCE_XP = (new ALData((T)Float.valueOf(0.0F))).setExempt(4);
/*  55 */   public static final ALData<Byte> BASE_POWER = (new ALData((T)Byte.valueOf((byte)-1))).setExempt(4);
/*  56 */   public static final ALData<String> DRAINING_XP_TO = (new ALData((T)"")).setExempt(1);
/*  57 */   public static final ALData<Integer> PREV_XP = (new ALData((T)Integer.valueOf(0))).setExempt(4);
/*  58 */   public static final ALData<Byte> SELECTED_POWER = (new ALData((T)Byte.valueOf((byte)0))).setExempt(4);
/*  59 */   public static final ALData<Boolean> USING_POWER = new ALData((T)Boolean.valueOf(false));
/*  60 */   public static final ALData<Boolean> PREV_USING_POWER = new ALData((T)Boolean.valueOf(false));
/*  61 */   public static final ALData<Integer> TICKS_USING_POWER = new ALData((T)Integer.valueOf(0));
/*  62 */   public static final ALData<Integer> USE_POWER_COOLDOWN = new ALData((T)Integer.valueOf(0));
/*  63 */   public static final ALData<PowerData.Container> POWERS = (new ALDataPowers()).setExempt(4);
/*  64 */   public static final ALData<List<Power>> SELECTED_POWERS = (new ALData(Power.factory())).setExempt(4);
/*  65 */   public static final ALData<LightsaberData> LIGHTSABER = (new ALData()).setExempt(1);
/*     */   
/*  67 */   public static final ALDataInterp<Float> FORCE_POWER = new ALDataInterp<>(Float.valueOf(0.0F));
/*  68 */   public static final ALDataInterp<Float> FORCE_POWER_DIFF = (new ALDataInterp(Float.valueOf(0.0F))).setExempt(1);
/*  69 */   public static final ALDataInterp<Float> FORCE_PUSHING_TIMER = new ALDataInterp<>(Float.valueOf(0.0F));
/*  70 */   public static final ALDataInterp<Float> DRAIN_LIFE_TIMER = new ALDataInterp<>(Float.valueOf(0.0F));
/*  71 */   public static final ALDataInterp<Float> RIGHT_ARM_TIMER = new ALDataInterp<>(Float.valueOf(0.0F));
/*  72 */   public static final ALDataInterp<Float> LEFT_ARM_TIMER = new ALDataInterp<>(Float.valueOf(0.0F));
/*     */   
/*     */   final DataFactory<T> defaultValue;
/*     */   
/*     */   public final Predicate<Entity> canSet;
/*     */   public String id;
/*     */   public ClassType<T> typeClass;
/*  79 */   protected int flags = -1;
/*  80 */   protected int permissions = -1;
/*     */ 
/*     */   
/*     */   protected ALData(DataFactory<T> defaultVal, Predicate<Entity> p) {
/*  84 */     this.defaultValue = defaultVal;
/*  85 */     this.canSet = p;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData(T defaultVal, Predicate<Entity> p) {
/*  90 */     this(new DataFactory<T>(defaultVal)
/*     */         {
/*     */           
/*     */           public T construct()
/*     */           {
/*  95 */             return (T)defaultVal;
/*     */           }
/*     */         },  p);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData(DataFactory<T> defaultVal) {
/* 102 */     this(defaultVal, (Predicate<Entity>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData(T defaultVal) {
/* 107 */     this(defaultVal, (Predicate<Entity>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData(Predicate<Entity> p) {
/* 112 */     this((T)null, p);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData() {
/* 117 */     this((T)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData setExempt(int exempt) {
/* 122 */     this.flags &= exempt ^ 0xFFFFFFFF;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData revokePerms(Side side) {
/* 128 */     this.permissions &= 1 << side.ordinal() ^ 0xFFFFFFFF;
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ALData revokePerms() {
/* 134 */     revokePerms(Side.CLIENT);
/* 135 */     revokePerms(Side.SERVER);
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasFlag(int flags, int flag) {
/* 141 */     return ((flags & flag) == flag);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldSaveNBT() {
/* 146 */     return hasFlag(this.flags, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldSyncBytes() {
/* 151 */     return hasFlag(this.flags, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldResetOnDeath() {
/* 156 */     return hasFlag(this.flags, 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldResetWithoutPredicate() {
/* 161 */     return hasFlag(this.flags, 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPerms(Side side) {
/* 166 */     return hasFlag(this.permissions, 1 << side.ordinal());
/*     */   }
/*     */ 
/*     */   
/*     */   public Predicate<Entity> isValue(final T value) {
/* 171 */     return new Predicate<Entity>()
/*     */       {
/*     */         
/*     */         public boolean apply(Entity input)
/*     */         {
/* 176 */           return Objects.equal(value, ALData.this.get(input));
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean ofType(Class<C> clazz) {
/* 183 */     return (this.typeClass.getType() == clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean validUpdate(Entity entity, T value) {
/* 188 */     if (ofType(ItemStack.class))
/*     */     {
/* 190 */       return !ItemStack.func_77989_b((ItemStack)get(entity), (ItemStack)value);
/*     */     }
/*     */     
/* 193 */     return !Objects.equal(value, get(entity));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean legalUpdate(Entity entity) {
/* 198 */     return (this.canSet == null || this.canSet.apply(entity));
/*     */   }
/*     */ 
/*     */   
/*     */   public T getDefault() {
/* 203 */     return this.defaultValue.construct();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean set(Entity entity, T value) {
/* 208 */     if (entity instanceof IDataHolder)
/*     */     {
/* 210 */       return setWithoutNotify(entity, value);
/*     */     }
/* 212 */     if (entity instanceof EntityPlayer)
/*     */     {
/* 214 */       return set((EntityPlayer)entity, value);
/*     */     }
/*     */     
/* 217 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setWithoutNotify(Entity entity, T value) {
/* 222 */     return (legalUpdate(entity) && setWithBypass(entity, value));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean setWithBypass(Entity entity, T value) {
/* 227 */     if (validUpdate(entity, value)) {
/*     */       
/* 229 */       if (entity instanceof IDataHolder) {
/*     */         
/* 231 */         ((IDataHolder)entity).set(this, value);
/* 232 */         onValueChanged(entity, value);
/*     */       }
/* 234 */       else if (entity instanceof EntityPlayer) {
/*     */         
/* 236 */         ALPlayerData.getData((EntityPlayer)entity).putData(this, value);
/* 237 */         onValueChanged(entity, value);
/*     */       } 
/*     */       
/* 240 */       return true;
/*     */     } 
/*     */     
/* 243 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean reset(Entity entity) {
/* 248 */     return setWithBypass(entity, getDefault());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean incr(Entity entity, T value) {
/* 253 */     if (entity instanceof IDataHolder)
/*     */     {
/* 255 */       return incrWithoutNotify(entity, value);
/*     */     }
/* 257 */     if (entity instanceof EntityPlayer)
/*     */     {
/* 259 */       return incr((EntityPlayer)entity, value);
/*     */     }
/*     */     
/* 262 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean incrWithoutNotify(Entity entity, T value) {
/* 267 */     if (value instanceof Byte)
/*     */     {
/* 269 */       return setWithoutNotify(entity, (T)Byte.valueOf((byte)(((Byte)get(entity)).byteValue() + ((Byte)value).byteValue())));
/*     */     }
/* 271 */     if (value instanceof Short)
/*     */     {
/* 273 */       return setWithoutNotify(entity, (T)Short.valueOf((short)(((Short)get(entity)).shortValue() + ((Short)value).shortValue())));
/*     */     }
/* 275 */     if (value instanceof Integer)
/*     */     {
/* 277 */       return setWithoutNotify(entity, (T)Integer.valueOf(((Integer)get(entity)).intValue() + ((Integer)value).intValue()));
/*     */     }
/* 279 */     if (value instanceof Long)
/*     */     {
/* 281 */       return setWithoutNotify(entity, (T)Long.valueOf(((Long)get(entity)).longValue() + ((Long)value).longValue()));
/*     */     }
/* 283 */     if (value instanceof Float)
/*     */     {
/* 285 */       return setWithoutNotify(entity, (T)Float.valueOf(((Float)get(entity)).floatValue() + ((Float)value).floatValue()));
/*     */     }
/* 287 */     if (value instanceof Double)
/*     */     {
/* 289 */       return setWithoutNotify(entity, (T)Double.valueOf(((Double)get(entity)).doubleValue() + ((Double)value).doubleValue()));
/*     */     }
/* 291 */     if (value instanceof String)
/*     */     {
/* 293 */       return setWithoutNotify(entity, (T)String.valueOf((String)get(entity) + (String)value));
/*     */     }
/*     */     
/* 296 */     throw new RuntimeException("Cannot increment a non-numerical data type unless a String!");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clamp(Entity entity, T min, T max) {
/* 301 */     if (entity instanceof IDataHolder)
/*     */     {
/* 303 */       return clampWithoutNotify(entity, min, max);
/*     */     }
/* 305 */     if (entity instanceof EntityPlayer)
/*     */     {
/* 307 */       return clamp((EntityPlayer)entity, min, max);
/*     */     }
/*     */     
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clampWithoutNotify(Entity entity, T min, T max) {
/* 315 */     if (min instanceof Byte)
/*     */     {
/* 317 */       return setWithoutNotify(entity, (T)Byte.valueOf((byte)MathHelper.func_76125_a(((Byte)get(entity)).byteValue(), ((Byte)min).byteValue(), ((Byte)max).byteValue())));
/*     */     }
/* 319 */     if (min instanceof Short)
/*     */     {
/* 321 */       return setWithoutNotify(entity, (T)Short.valueOf((short)MathHelper.func_76125_a(((Short)get(entity)).shortValue(), ((Short)min).shortValue(), ((Short)max).shortValue())));
/*     */     }
/* 323 */     if (min instanceof Integer)
/*     */     {
/* 325 */       return setWithoutNotify(entity, (T)Integer.valueOf(MathHelper.func_76125_a(((Integer)get(entity)).intValue(), ((Integer)min).intValue(), ((Integer)max).intValue())));
/*     */     }
/* 327 */     if (min instanceof Long) {
/*     */       
/* 329 */       long l = ((Long)get(entity)).longValue();
/* 330 */       return setWithoutNotify(entity, (T)Long.valueOf((l < ((Long)min).longValue()) ? ((Long)min).longValue() : ((l > ((Long)max).longValue()) ? ((Long)max).longValue() : l)));
/*     */     } 
/* 332 */     if (min instanceof Float)
/*     */     {
/* 334 */       return setWithoutNotify(entity, (T)Float.valueOf(MathHelper.func_76131_a(((Float)get(entity)).floatValue(), ((Float)min).floatValue(), ((Float)max).floatValue())));
/*     */     }
/* 336 */     if (min instanceof Double)
/*     */     {
/* 338 */       return setWithoutNotify(entity, (T)Double.valueOf(MathHelper.func_151237_a(((Double)get(entity)).doubleValue(), ((Double)min).doubleValue(), ((Double)max).doubleValue())));
/*     */     }
/*     */     
/* 341 */     throw new RuntimeException("Cannot clamp a non-numerical data type!");
/*     */   }
/*     */ 
/*     */   
/*     */   public T get(Entity entity) {
/* 346 */     if (entity instanceof IDataHolder)
/*     */     {
/* 348 */       return ((IDataHolder)entity).get(this);
/*     */     }
/* 350 */     if (entity instanceof EntityPlayer)
/*     */     {
/* 352 */       return ALPlayerData.getData((EntityPlayer)entity).getData(this);
/*     */     }
/*     */     
/* 355 */     return getDefault();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean sync(EntityPlayer player) {
/* 360 */     if (hasPerms(player.field_70170_p.field_72995_K ? Side.CLIENT : Side.SERVER) && legalUpdate((Entity)player)) {
/*     */       
/* 362 */       if (player.field_70170_p.field_72995_K) {
/*     */         
/* 364 */         ALNetworkManager.wrapper.sendToServer((IMessage)new MessagePlayerData(player, this, get((Entity)player)));
/*     */       }
/*     */       else {
/*     */         
/* 368 */         ALNetworkManager.wrapper.sendToDimension((IMessage)new MessagePlayerData(player, this, get((Entity)player)), player.field_71093_bK);
/*     */       } 
/*     */       
/* 371 */       return true;
/*     */     } 
/*     */     
/* 374 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean set(EntityPlayer player, T value) {
/* 379 */     return (setWithoutNotify((Entity)player, value) && sync(player));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean incr(EntityPlayer player, T value) {
/* 384 */     return (incrWithoutNotify((Entity)player, value) && sync(player));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clamp(EntityPlayer player, T min, T max) {
/* 389 */     return (clampWithoutNotify((Entity)player, min, max) && sync(player));
/*     */   }
/*     */ 
/*     */   
/*     */   public static NBTTagCompound writeToNBT(NBTTagCompound nbt, Map<ALData, Object> data) {
/* 394 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/*     */     
/* 396 */     for (Map.Entry<ALData, Object> e : data.entrySet()) {
/*     */       
/* 398 */       if (((ALData)e.getKey()).shouldSaveNBT()) {
/*     */         
/* 400 */         NBTBase nbtbase = NBTHelper.writeToNBT(e.getValue());
/*     */         
/* 402 */         if (nbtbase != null)
/*     */         {
/* 404 */           nbttagcompound.func_74782_a(((ALData)e.getKey()).id, nbtbase);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 409 */     nbt.func_74782_a("DataArray", (NBTBase)nbttagcompound);
/*     */     
/* 411 */     return nbt;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<ALData, Object> readFromNBT(NBTTagCompound nbt, Map<ALData, Object> data) {
/* 416 */     NBTTagCompound nbttagcompound = nbt.func_74775_l("DataArray");
/*     */     
/* 418 */     for (ALData<?> type : REGISTRY) {
/*     */       
/* 420 */       if (type.shouldSaveNBT()) {
/*     */         
/* 422 */         NBTBase tag = nbttagcompound.func_74781_a(type.id);
/* 423 */         Object obj = null;
/*     */         
/* 425 */         if (tag != null) {
/*     */           
/* 427 */           obj = NBTHelper.readFromNBT(tag, type.typeClass);
/*     */         }
/*     */         else {
/*     */           
/* 431 */           tag = nbt.func_74781_a(type.id);
/*     */           
/* 433 */           if (tag != null) {
/*     */             
/* 435 */             obj = NBTHelper.readFromNBT(tag, type.typeClass);
/*     */           } else {
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 443 */         data.put(type, obj);
/*     */       } 
/*     */     } 
/*     */     
/* 447 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void toBytes(ByteBuf buf, Map<ALData, Object> data) {
/* 452 */     buf.writeInt(REGISTRY.func_148742_b().size());
/*     */     
/* 454 */     for (ALData<?> type : REGISTRY) {
/*     */       
/* 456 */       if (type.shouldSyncBytes()) {
/*     */         
/* 458 */         boolean flag = data.containsKey(type);
/*     */         
/* 460 */         if (flag && type.defaultValue.canEqual()) {
/*     */           
/* 462 */           Object a = type.getDefault();
/* 463 */           Object b = data.get(type);
/*     */           
/* 465 */           flag = !Objects.equal(a, b);
/*     */         } 
/*     */         
/* 468 */         buf.writeBoolean(flag);
/*     */         
/* 470 */         if (flag)
/*     */         {
/* 472 */           NBTHelper.toBytes(buf, data.get(type));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<ALData, Object> fromBytes(ByteBuf buf, Map<ALData, Object> data) {
/* 480 */     int size = buf.readInt();
/*     */     
/* 482 */     if (size != REGISTRY.func_148742_b().size())
/*     */     {
/* 484 */       throw new RuntimeException(String.format("Incompatible data registries - this is really bad! Received %s, expected: %s", new Object[] { Integer.valueOf(size), Integer.valueOf(REGISTRY.func_148742_b().size()) }));
/*     */     }
/*     */     
/* 487 */     for (ALData<?> type : REGISTRY) {
/*     */       
/* 489 */       if (type.shouldSyncBytes() && buf.readBoolean())
/*     */       {
/* 491 */         data.put(type, NBTHelper.fromBytes(buf, type.typeClass));
/*     */       }
/*     */     } 
/*     */     
/* 495 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void onUpdate(Entity entity) {
/* 500 */     for (ALData<?> data : REGISTRY) {
/*     */       
/* 502 */       data.update(entity);
/*     */       
/* 504 */       if (data.shouldResetWithoutPredicate() && !data.legalUpdate(entity))
/*     */       {
/* 506 */         data.reset(entity);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void onDeath(Entity entity) {
/* 513 */     for (ALData<?> data : REGISTRY) {
/*     */       
/* 515 */       if (data.shouldResetOnDeath())
/*     */       {
/* 517 */         data.reset(entity);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init(Field field, String name) throws ClassNotFoundException {
/* 524 */     this.id = ALFormatHelper.getUnconventionalName(name);
/* 525 */     this.typeClass = ClassType.construct(field.getGenericType().getTypeName()).getParam();
/*     */     
/* 527 */     register(name.toLowerCase(Locale.ROOT), this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void update(Entity entity) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onValueChanged(Entity entity, T value) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 541 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init() {
/* 546 */     for (Field field : ALData.class.getFields()) {
/*     */       
/* 548 */       if (ALData.class.isAssignableFrom(field.getType())) {
/*     */         
/*     */         try {
/*     */           
/* 552 */           ((ALData)field.get(null)).init(field, field.getName());
/*     */         }
/* 554 */         catch (Exception e) {
/*     */           
/* 556 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ClassType<C>
/*     */   {
/*     */     private final Class<C> type;
/*     */     private ClassType param;
/*     */     
/*     */     public ClassType(Class<C> c) {
/* 569 */       this.type = c;
/*     */     }
/*     */ 
/*     */     
/*     */     private ClassType<C> setParam(ClassType type) {
/* 574 */       this.param = type;
/* 575 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassType getParam() {
/* 580 */       return this.param;
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassType getParamSafe() {
/* 585 */       return (this.param == null) ? new ClassType((Class)Object.class) : this.param;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<C> getType() {
/* 590 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 596 */       String s = getType().getCanonicalName();
/*     */       
/* 598 */       if (getParam() != null)
/*     */       {
/* 600 */         return s + "<" + getParam() + ">";
/*     */       }
/*     */       
/* 603 */       return s;
/*     */     }
/*     */ 
/*     */     
/*     */     private static ClassType construct(String typeName) throws ClassNotFoundException {
/* 608 */       if (typeName.contains("<")) {
/*     */         
/* 610 */         ClassType type = new ClassType(Class.forName(typeName.substring(0, typeName.indexOf('<'))));
/* 611 */         ClassType type1 = construct(typeName.substring(typeName.indexOf('<') + 1, typeName.length() - 1));
/*     */         
/* 613 */         return type.setParam(type1);
/*     */       } 
/*     */       
/* 616 */       return new ClassType(Class.forName(typeName));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static abstract class DataFactory<T>
/*     */   {
/*     */     public abstract T construct();
/*     */     
/*     */     public boolean canEqual() {
/* 626 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\data\ALData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */