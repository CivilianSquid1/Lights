/*   */ package com.fiskmods.lightsabers.common.damage;
/*   */ 
/*   */ import fiskfille.utils.common.damage.IExtendedDamage;
/*   */ import fiskfille.utils.helper.FiskEnumHelper;
/*   */ 
/*   */ public class ALDamageTypes
/*   */ {
/* 8 */   public static final IExtendedDamage.DamageType FORCE = FiskEnumHelper.addDamageType("FORCE");
/* 9 */   public static final IExtendedDamage.DamageType LIGHTSABER = FiskEnumHelper.addDamageType("LIGHTSABER");
/*   */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\damage\ALDamageTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */