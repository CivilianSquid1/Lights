/*    */ package com.fiskmods.lightsabers.common.damage;
/*    */ 
/*    */ import fiskfille.utils.common.damage.FiskDamageSource;
/*    */ import fiskfille.utils.common.damage.FiskEntityDamageSource;
/*    */ import fiskfille.utils.common.damage.IExtendedDamage;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.DamageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALDamageSources
/*    */ {
/* 13 */   public static final DamageSource INTO_WALL = (new FiskDamageSource("lightsabers", "intoWall")).with(new IExtendedDamage.DamageType[] { IExtendedDamage.DamageType.KINETIC }).func_76348_h();
/*    */ 
/*    */   
/*    */   public static DamageSource causeLightsaberDamage(Entity entity) {
/* 17 */     return (DamageSource)(new FiskEntityDamageSource("lightsabers", "lightsaber", entity)).with(new IExtendedDamage.DamageType[] { ALDamageTypes.LIGHTSABER, IExtendedDamage.DamageType.ENERGY });
/*    */   }
/*    */ 
/*    */   
/*    */   public static DamageSource causeForceDamage(Entity entity) {
/* 22 */     return (new FiskEntityDamageSource("lightsabers", "force", entity)).with(new IExtendedDamage.DamageType[] { ALDamageTypes.FORCE }).func_82726_p().func_76348_h();
/*    */   }
/*    */ 
/*    */   
/*    */   public static DamageSource causeForceLightningDamage(Entity entity) {
/* 27 */     return (new FiskEntityDamageSource("lightsabers", "lightning", entity)).with(new IExtendedDamage.DamageType[] { ALDamageTypes.FORCE, IExtendedDamage.DamageType.LIGHTNING }).func_82726_p();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\damage\ALDamageSources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */