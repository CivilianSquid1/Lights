/*     */ package com.fiskmods.lightsabers.common.command;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*     */ import com.fiskmods.lightsabers.common.generator.WorldGeneratorStructures;
/*     */ import com.fiskmods.lightsabers.common.generator.structure.EnumStructure;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldType;
/*     */ import net.minecraft.world.storage.WorldInfo;
/*     */ 
/*     */ public class CommandForce
/*     */   extends CommandBase {
/*     */   public String func_71517_b() {
/*  30 */     return "force";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  36 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  42 */     return "commands.force.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) {
/*  48 */     World world = sender.func_130014_f_();
/*  49 */     String usage = func_71518_a(sender);
/*     */     
/*  51 */     if (args.length > 0) {
/*     */       
/*  53 */       String func = args[0];
/*  54 */       String arg = "";
/*     */       
/*  56 */       if (args.length > 1)
/*     */       {
/*  58 */         arg = args[1];
/*     */       }
/*     */       
/*  61 */       if (func.equals("xp") || func.equals("base")) {
/*     */         
/*  63 */         if (func.equals("base") && arg.equals("reset") && (args.length == 2 || args.length == 3)) {
/*     */           EntityPlayerMP player;
/*     */ 
/*     */           
/*  67 */           if (args.length == 3) {
/*     */             
/*  69 */             player = func_82359_c(sender, args[2]);
/*     */           }
/*     */           else {
/*     */             
/*  73 */             player = func_71521_c(sender);
/*     */           } 
/*     */           
/*  76 */           if (ALData.BASE_POWER.set((EntityPlayer)player, Byte.valueOf(ALHelper.getBasePower((EntityPlayer)player)))) {
/*     */             
/*  78 */             func_152373_a(sender, (ICommand)this, String.format("commands.force.%s.%s.success", new Object[] { func, arg }), new Object[] { player.func_70005_c_() });
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*  83 */         if (args.length == 3 || args.length == 4) {
/*     */           EntityPlayerMP player;
/*     */ 
/*     */           
/*  87 */           if (args.length == 4) {
/*     */             
/*  89 */             player = func_82359_c(sender, args[3]);
/*     */           }
/*     */           else {
/*     */             
/*  93 */             player = func_71521_c(sender);
/*     */           } 
/*     */           
/*  96 */           float amount = func_71528_a(sender, args[2], 0);
/*  97 */           float f = func.equals("xp") ? ((Float)ALData.FORCE_XP.get((Entity)player)).floatValue() : 0.0F;
/*     */           
/*  99 */           if (arg.equals("give")) {
/*     */             
/* 101 */             f += amount;
/*     */           }
/* 103 */           else if (arg.equals("take")) {
/*     */             
/* 105 */             f -= amount;
/*     */           }
/* 107 */           else if (arg.equals("set")) {
/*     */             
/* 109 */             f = amount;
/*     */           } 
/*     */           
/* 112 */           f = Math.max(f, 0.0F);
/*     */           
/* 114 */           List translationKeys = arg.equals("set") ? Lists.newArrayList((Object[])new Serializable[] { player.func_70005_c_(), Integer.valueOf(MathHelper.func_76141_d(amount)) }) : Lists.newArrayList((Object[])new Serializable[] { Integer.valueOf(MathHelper.func_76141_d(amount)), player.func_70005_c_() });
/*     */           
/* 116 */           if (func.equals("xp")) {
/*     */             
/* 118 */             ALData.FORCE_XP.set((EntityPlayer)player, Float.valueOf(f));
/*     */           }
/*     */           else {
/*     */             
/* 122 */             ALData.BASE_POWER.set((EntityPlayer)player, Byte.valueOf((byte)MathHelper.func_76141_d(f)));
/*     */           } 
/*     */           
/* 125 */           func_152373_a(sender, (ICommand)this, String.format("commands.force.%s.%s.success", new Object[] { func, arg }), translationKeys.toArray());
/*     */           
/*     */           return;
/*     */         } 
/* 129 */         throw new WrongUsageException(String.format("commands.force.%s.usage", new Object[] { func }), new Object[0]);
/*     */       } 
/* 131 */       if (func.equals("power")) {
/*     */         
/* 133 */         if (args.length == 3 || args.length == 4) {
/*     */           EntityPlayerMP player;
/*     */ 
/*     */           
/* 137 */           if (args.length == 4) {
/*     */             
/* 139 */             player = func_82359_c(sender, args[3]);
/*     */           }
/*     */           else {
/*     */             
/* 143 */             player = func_71521_c(sender);
/*     */           } 
/*     */           
/* 146 */           Power power = Power.getPowerFromName(args[2]);
/* 147 */           boolean targetAll = args[2].equals("*");
/*     */           
/* 149 */           if (power == null && !targetAll)
/*     */           {
/* 151 */             throw new CommandException("commands.force.power.unknown", new Object[] { args[2] });
/*     */           }
/*     */           
/* 154 */           if (arg.equals("give")) {
/*     */             
/* 156 */             if (targetAll) {
/*     */               
/* 158 */               for (PowerData data : ALData.POWERS.get((Entity)player)) {
/*     */                 
/* 160 */                 if (!data.isUnlocked())
/*     */                 {
/* 162 */                   PowerManager.unlockPower((EntityPlayer)player, data.power);
/*     */                 }
/*     */               } 
/*     */               
/* 166 */               func_152373_a(sender, (ICommand)this, "commands.force.power.give.success.all", new Object[] { player.func_70005_c_() });
/*     */             }
/*     */             else {
/*     */               
/* 170 */               if (!PowerManager.unlockPower((EntityPlayer)player, power))
/*     */               {
/* 172 */                 throw new CommandException("commands.force.power.alreadyHave", new Object[] { player.func_70005_c_(), args[2] });
/*     */               }
/*     */ 
/*     */               
/* 176 */               func_152373_a(sender, (ICommand)this, "commands.force.power.give.success.one", new Object[] { player.func_70005_c_(), power.getChatFormattedName() });
/*     */             } 
/*     */ 
/*     */             
/* 180 */             ALData.POWERS.sync((EntityPlayer)player);
/* 181 */             ALData.BASE_POWER.sync((EntityPlayer)player);
/*     */             return;
/*     */           } 
/* 184 */           if (arg.equals("take")) {
/*     */             
/* 186 */             if (targetAll) {
/*     */               
/* 188 */               for (PowerData data : ALData.POWERS.get((Entity)player)) {
/*     */                 
/* 190 */                 if (data.isUnlocked())
/*     */                 {
/* 192 */                   PowerManager.removePower((EntityPlayer)player, data.power);
/*     */                 }
/*     */               } 
/*     */               
/* 196 */               func_152373_a(sender, (ICommand)this, "commands.force.power.take.success.all", new Object[] { player.func_70005_c_() });
/*     */             }
/*     */             else {
/*     */               
/* 200 */               if (!PowerManager.removePower((EntityPlayer)player, power))
/*     */               {
/* 202 */                 throw new CommandException("commands.force.power.dontHave", new Object[] { player.func_70005_c_(), args[2] });
/*     */               }
/*     */ 
/*     */               
/* 206 */               func_152373_a(sender, (ICommand)this, "commands.force.power.take.success.one", new Object[] { power.getChatFormattedName(), player.func_70005_c_() });
/*     */             } 
/*     */ 
/*     */             
/* 210 */             ALData.POWERS.sync((EntityPlayer)player);
/* 211 */             ALData.BASE_POWER.sync((EntityPlayer)player);
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 216 */         throw new WrongUsageException("commands.force.power.usage", new Object[0]);
/*     */       } 
/* 218 */       if (func.equals("structure")) {
/*     */         
/* 220 */         if (sender.func_70003_b(3, func_71517_b())) {
/*     */           
/* 222 */           if (arg.equals("locate") ? (args.length == 4 || args.length == 6) : (args.length == 3 || args.length == 5)) {
/*     */             
/* 224 */             EnumStructure structure = null;
/*     */             
/* 226 */             for (EnumStructure structure1 : EnumStructure.values()) {
/*     */               
/* 228 */               if (ALHelper.getUnconventionalName(structure1.name()).equals(args[2])) {
/*     */                 
/* 230 */                 structure = structure1;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 235 */             boolean targetAll = (arg.equals("locate") && args[2].equals("*"));
/* 236 */             int x = (sender.func_82114_b()).field_71574_a;
/* 237 */             int z = (sender.func_82114_b()).field_71573_c;
/*     */             
/* 239 */             if (arg.equals("locate") ? (args.length == 6) : (args.length == 5)) {
/*     */               
/* 241 */               x = MathHelper.func_76128_c(func_110666_a(sender, x, arg.equals("locate") ? args[4] : args[3]));
/* 242 */               z = MathHelper.func_76128_c(func_110666_a(sender, z, arg.equals("locate") ? args[5] : args[4]));
/*     */             } 
/*     */             
/* 245 */             if (structure == null && !targetAll)
/*     */             {
/* 247 */               throw new CommandException("commands.force.structure.unknown", new Object[] { args[2] });
/*     */             }
/*     */             
/* 250 */             if (arg.equals("locate")) {
/*     */               
/* 252 */               WorldInfo info = world.func_72912_H();
/*     */               
/* 254 */               if (info.func_76067_t() == WorldType.field_77138_c || !info.func_76089_r() || world.field_73011_w.field_76574_g != 0)
/*     */               {
/* 256 */                 throw new CommandException("commands.force.structure.locate.doesNotGenerate", new Object[] { args[2] });
/*     */               }
/*     */               
/* 259 */               (new Thread(new StructureLocator(this, sender, structure, targetAll, func_71528_a(sender, args[3], 0), x, z))).start();
/*     */               return;
/*     */             } 
/* 262 */             if (arg.equals("generate")) {
/*     */               
/* 264 */               if (!world.func_72899_e(x, 64, z))
/*     */               {
/* 266 */                 throw new CommandException("commands.force.structure.generate.outOfWorld", new Object[] { arg });
/*     */               }
/*     */ 
/*     */               
/*     */               try {
/* 271 */                 WorldGeneratorStructures.generateStructure(world, x, z, structure);
/* 272 */                 func_152373_a(sender, (ICommand)this, "commands.force.structure.generate.success", new Object[] { ALHelper.getUnconventionalName(structure.name()), Integer.valueOf(x), Integer.valueOf(z) });
/*     */ 
/*     */                 
/*     */                 return;
/* 276 */               } catch (Exception e) {
/*     */                 
/* 278 */                 throw new CommandException("commands.force.structure.generate.failure", new Object[0]);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 283 */           if (arg.equals("locate") || arg.equals("generate"))
/*     */           {
/* 285 */             throw new WrongUsageException(String.format("commands.force.structure.%s.usage", new Object[] { arg }), new Object[0]);
/*     */           }
/*     */           
/* 288 */           throw new WrongUsageException("commands.force.structure.usage", new Object[0]);
/*     */         } 
/*     */ 
/*     */         
/* 292 */         throw new CommandException("commands.generic.permission", new Object[0]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 297 */     throw new WrongUsageException(usage, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_71516_a(ICommandSender sender, String[] args) {
/* 303 */     World world = sender.func_130014_f_();
/*     */     
/* 305 */     if (args.length > 0) {
/*     */       
/* 307 */       if (args.length == 1)
/*     */       {
/* 309 */         return func_71530_a(args, new String[] { "xp", "base", "power", "structure" });
/*     */       }
/*     */ 
/*     */       
/* 313 */       if (args[0].equals("xp")) {
/*     */         
/* 315 */         if (args.length == 2)
/*     */         {
/* 317 */           return func_71530_a(args, new String[] { "give", "take", "set" });
/*     */         }
/* 319 */         if (args.length == 4)
/*     */         {
/* 321 */           return func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z());
/*     */         }
/*     */       }
/* 324 */       else if (args[0].equals("base")) {
/*     */         
/* 326 */         if (args.length == 2)
/*     */         {
/* 328 */           return func_71530_a(args, new String[] { "give", "take", "set", "reset" });
/*     */         }
/* 330 */         if (args.length == 4 || (args.length == 3 && args[1].equals("reset")))
/*     */         {
/* 332 */           return func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z());
/*     */         }
/*     */       }
/* 335 */       else if (args[0].equals("power")) {
/*     */         
/* 337 */         if (args.length == 2)
/*     */         {
/* 339 */           return func_71530_a(args, new String[] { "give", "take" });
/*     */         }
/* 341 */         if (args.length == 3) {
/*     */           
/* 343 */           List<String> list = Lists.newArrayList();
/*     */           
/* 345 */           for (Power power : Power.POWERS)
/*     */           {
/* 347 */             list.add(power.getName());
/*     */           }
/*     */           
/* 350 */           return func_71530_a(args, list.<String>toArray(new String[list.size()]));
/*     */         } 
/* 352 */         if (args.length == 4)
/*     */         {
/* 354 */           return func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z());
/*     */         }
/*     */       }
/* 357 */       else if (args[0].equals("structure")) {
/*     */         
/* 359 */         if (args.length == 2)
/*     */         {
/* 361 */           return func_71530_a(args, new String[] { "locate", "generate" });
/*     */         }
/* 363 */         if (args.length == 3) {
/*     */           
/* 365 */           List<String> list = Lists.newArrayList();
/*     */           
/* 367 */           for (EnumStructure structure : EnumStructure.values())
/*     */           {
/* 369 */             list.add(ALHelper.getUnconventionalName(structure.name()));
/*     */           }
/*     */           
/* 372 */           return func_71530_a(args, list.<String>toArray(new String[list.size()]));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 378 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\command\CommandForce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */