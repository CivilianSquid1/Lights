/*     */ package com.fiskmods.lightsabers.common.command;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.generator.WorldGeneratorStructures;
/*     */ import com.fiskmods.lightsabers.common.generator.structure.EnumStructure;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.ChunkCoordIntPair;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class StructureLocator
/*     */   implements Runnable {
/*  26 */   public static WeakHashMap<World, Map<EnumStructure, List<ChunkCoordIntPair>>> cachedStructurePos = new WeakHashMap<>();
/*  27 */   public static WeakHashMap<World, List<ChunkCoordIntPair>> chunksSearched = new WeakHashMap<>();
/*     */   
/*     */   private final CommandBase command;
/*     */   
/*     */   private final ICommandSender sender;
/*     */   private final EnumStructure structure;
/*     */   private final boolean targetAll;
/*     */   private final int maxRange;
/*     */   private final int startX;
/*     */   private final int startZ;
/*     */   
/*     */   public StructureLocator(CommandBase commandBase, ICommandSender commandSender, EnumStructure enumStructure, boolean all, int range, int x, int z) {
/*  39 */     this.command = commandBase;
/*  40 */     this.sender = commandSender;
/*  41 */     this.structure = enumStructure;
/*  42 */     this.targetAll = all;
/*  43 */     this.maxRange = range;
/*  44 */     this.startX = x;
/*  45 */     this.startZ = z;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  51 */     World world = this.sender.func_130014_f_();
/*     */     
/*  53 */     List<ChunkCoordIntPair> searched = getChunksSearched(world);
/*  54 */     boolean flag = (this.structure == null || getStructures(world, this.structure).isEmpty());
/*  55 */     int range = 0;
/*     */     
/*  57 */     searched.clear();
/*     */     
/*  59 */     while (++range < this.maxRange && flag) {
/*     */       
/*  61 */       for (int i = -range; i <= range; i++) {
/*     */         
/*  63 */         for (int j = -range; j <= range; j++) {
/*     */           
/*  65 */           int chunkX = (this.startX >> 4) + i;
/*  66 */           int chunkZ = (this.startZ >> 4) + j;
/*  67 */           ChunkCoordIntPair chunk = new ChunkCoordIntPair(chunkX, chunkZ);
/*     */           
/*  69 */           if (!searched.contains(chunk)) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  74 */             for (EnumStructure structure1 : EnumStructure.values()) {
/*     */               
/*  76 */               if (WorldGeneratorStructures.canSpawnStructureAtCoords(world, chunk.func_77273_a(), chunk.func_77274_b(), structure1)) {
/*     */                 
/*  78 */                 getStructures(world, structure1).add(chunk);
/*     */                 
/*  80 */                 if (this.structure == structure1 || this.targetAll)
/*     */                 {
/*  82 */                   flag = false;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */             
/*  87 */             searched.add(chunk);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  92 */     final Vec3 vec = Vec3.func_72443_a((this.startX >> 4), 0.0D, (this.startZ >> 4));
/*  93 */     Comparator<ChunkCoordIntPair> coordComparator = new Comparator<ChunkCoordIntPair>()
/*     */       {
/*     */         
/*     */         public int compare(ChunkCoordIntPair arg0, ChunkCoordIntPair arg1)
/*     */         {
/*  98 */           return Double.valueOf(Vec3.func_72443_a(arg0.field_77276_a, 0.0D, arg0.field_77275_b).func_72438_d(vec)).compareTo(Double.valueOf(Vec3.func_72443_a(arg1.field_77276_a, 0.0D, arg1.field_77275_b).func_72438_d(vec)));
/*     */         }
/*     */       };
/*     */     
/* 102 */     for (EnumStructure structure1 : EnumStructure.values())
/*     */     {
/* 104 */       Collections.sort(getStructures(world, structure1), coordComparator);
/*     */     }
/*     */     
/* 107 */     if (this.targetAll) {
/*     */       
/* 109 */       List<ChunkCoordIntPair> structures = Lists.newArrayList();
/*     */       
/* 111 */       for (EnumStructure structure1 : EnumStructure.values()) {
/*     */         
/* 113 */         if (!getStructures(world, structure1).isEmpty())
/*     */         {
/* 115 */           structures.add(getStructures(world, structure1).get(0));
/*     */         }
/*     */       } 
/*     */       
/* 119 */       if (structures.isEmpty()) {
/*     */         
/* 121 */         ChatComponentTranslation message = new ChatComponentTranslation("commands.force.structure.locate.failure", new Object[0]);
/* 122 */         message.func_150256_b().func_150238_a(EnumChatFormatting.RED);
/*     */         
/* 124 */         this.sender.func_145747_a((IChatComponent)message);
/*     */       }
/*     */       else {
/*     */         
/* 128 */         Collections.sort(structures, coordComparator);
/*     */         
/* 130 */         for (EnumStructure structure1 : EnumStructure.values()) {
/*     */           
/* 132 */           if (!getStructures(world, structure1).isEmpty() && ((ChunkCoordIntPair)structures.get(0)).equals(getStructures(world, structure1).get(0))) {
/*     */             
/* 134 */             ChunkCoordIntPair chunk = structures.get(0);
/* 135 */             CommandBase.func_152373_a(this.sender, (ICommand)this.command, "commands.force.structure.locate.success", new Object[] { ALHelper.getUnconventionalName(structure1.name()), Integer.valueOf(chunk.func_77273_a()), Integer.valueOf(chunk.func_77274_b()) });
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 143 */       List<ChunkCoordIntPair> structures = getStructures(world, this.structure);
/*     */       
/* 145 */       if (structures.isEmpty()) {
/*     */         
/* 147 */         ChatComponentTranslation message = new ChatComponentTranslation("commands.force.structure.locate.failure", new Object[0]);
/* 148 */         message.func_150256_b().func_150238_a(EnumChatFormatting.RED);
/*     */         
/* 150 */         this.sender.func_145747_a((IChatComponent)message);
/*     */       }
/*     */       else {
/*     */         
/* 154 */         ChunkCoordIntPair chunk = structures.get(0);
/* 155 */         CommandBase.func_152373_a(this.sender, (ICommand)this.command, "commands.force.structure.locate.success", new Object[] { ALHelper.getUnconventionalName(this.structure.name()), Integer.valueOf(chunk.func_77273_a()), Integer.valueOf(chunk.func_77274_b()) });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<ChunkCoordIntPair> getChunksSearched(World world) {
/* 162 */     if (chunksSearched.get(world) == null)
/*     */     {
/* 164 */       chunksSearched.put(world, new ArrayList<>());
/*     */     }
/*     */     
/* 167 */     return chunksSearched.get(world);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<EnumStructure, List<ChunkCoordIntPair>> getStructures(World world) {
/* 172 */     if (cachedStructurePos.get(world) == null)
/*     */     {
/* 174 */       cachedStructurePos.put(world, new HashMap<>());
/*     */     }
/*     */     
/* 177 */     return cachedStructurePos.get(world);
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<ChunkCoordIntPair> getStructures(World world, EnumStructure structure) {
/* 182 */     Map<EnumStructure, List<ChunkCoordIntPair>> map = getStructures(world);
/*     */     
/* 184 */     if (map.get(structure) == null)
/*     */     {
/* 186 */       map.put(structure, new ArrayList<>());
/*     */     }
/*     */     
/* 189 */     return map.get(structure);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\command\StructureLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */