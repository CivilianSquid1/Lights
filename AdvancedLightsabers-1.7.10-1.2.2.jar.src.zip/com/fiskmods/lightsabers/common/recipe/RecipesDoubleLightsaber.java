/*    */ package com.fiskmods.lightsabers.common.recipe;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import net.minecraft.inventory.InventoryCrafting;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.crafting.IRecipe;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecipesDoubleLightsaber
/*    */   implements IRecipe
/*    */ {
/*    */   public boolean func_77569_a(InventoryCrafting crafting, World world) {
/* 16 */     ItemStack upper = null;
/* 17 */     ItemStack lower = null;
/*    */     
/* 19 */     int width = (int)Math.sqrt(crafting.func_70302_i_());
/* 20 */     int filledSlots = 0;
/*    */     
/* 22 */     for (int i = 0; i < crafting.func_70302_i_(); i++) {
/*    */       
/* 24 */       ItemStack itemstack = crafting.func_70301_a(i);
/*    */       
/* 26 */       if (itemstack != null) {
/*    */         
/* 28 */         if (itemstack.func_77973_b() == ModItems.lightsaber && i + width <= crafting.func_70302_i_()) {
/*    */           
/* 30 */           ItemStack itemstack1 = crafting.func_70301_a(i + width);
/*    */           
/* 32 */           if (itemstack1 != null && itemstack1.func_77973_b() == ModItems.lightsaber) {
/*    */             
/* 34 */             upper = itemstack;
/* 35 */             lower = itemstack1;
/*    */           } 
/*    */         } 
/*    */         
/* 39 */         filledSlots++;
/*    */       } 
/*    */     } 
/*    */     
/* 43 */     return (filledSlots == 2 && upper != null && lower != null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack func_77572_b(InventoryCrafting crafting) {
/* 49 */     int width = (int)Math.sqrt(crafting.func_70302_i_());
/*    */     
/* 51 */     for (int i = 0; i < crafting.func_70302_i_(); i++) {
/*    */       
/* 53 */       ItemStack upper = crafting.func_70301_a(i);
/*    */       
/* 55 */       if (upper != null)
/*    */       {
/* 57 */         return ItemDoubleLightsaber.create(upper, crafting.func_70301_a(i + width));
/*    */       }
/*    */     } 
/*    */     
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_77570_a() {
/* 67 */     return 10;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack func_77571_b() {
/* 73 */     return new ItemStack(ModItems.doubleLightsaber);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\recipe\RecipesDoubleLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */