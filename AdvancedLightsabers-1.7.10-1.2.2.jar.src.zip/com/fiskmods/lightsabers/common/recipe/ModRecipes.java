/*    */ package com.fiskmods.lightsabers.common.recipe;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ModRecipes
/*    */ {
/*    */   public static void register() {
/* 17 */     GameRegistry.addRecipe(new RecipesDoubleLightsaber());
/*    */     
/* 19 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightForcestone, 4, 0), new Object[] { "###", "#-#", "###", Character.valueOf('#'), new ItemStack(Blocks.field_150322_A, 1, 2), Character.valueOf('-'), ModBlocks.lightsaberCrystal });
/* 20 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightForcestone, 1, 1), new Object[] { "#", "#", Character.valueOf('#'), new ItemStack((Block)ModBlocks.forcestoneSlab, 1, 0) });
/* 21 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightForcestone, 2, 2), new Object[] { "#", "#", Character.valueOf('#'), new ItemStack(ModBlocks.lightForcestone, 1, 0) });
/* 22 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.darkForcestone, 4, 0), new Object[] { "###", "#-#", "###", Character.valueOf('#'), Blocks.field_150405_ch, Character.valueOf('-'), ModBlocks.lightsaberCrystal });
/* 23 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.darkForcestone, 1, 1), new Object[] { "#", "#", Character.valueOf('#'), new ItemStack((Block)ModBlocks.forcestoneSlab, 1, 1) });
/* 24 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.darkForcestone, 2, 2), new Object[] { "#", "#", Character.valueOf('#'), new ItemStack(ModBlocks.darkForcestone, 1, 0) });
/* 25 */     GameRegistry.addRecipe(new ItemStack((Block)ModBlocks.forcestoneSlab, 6, 0), new Object[] { "###", Character.valueOf('#'), new ItemStack(ModBlocks.lightForcestone, 1, 0) });
/* 26 */     GameRegistry.addRecipe(new ItemStack((Block)ModBlocks.forcestoneSlab, 6, 1), new Object[] { "###", Character.valueOf('#'), new ItemStack(ModBlocks.darkForcestone, 1, 0) });
/* 27 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightForcestoneStairs, 4), new Object[] { "#  ", "## ", "###", Character.valueOf('#'), new ItemStack(ModBlocks.lightForcestone, 1, 0) });
/* 28 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.darkForcestoneStairs, 4), new Object[] { "#  ", "## ", "###", Character.valueOf('#'), new ItemStack(ModBlocks.darkForcestone, 1, 0) });
/* 29 */     GameRegistry.addShapelessRecipe(new ItemStack(ModBlocks.lightActivatedForcestone, 1), new Object[] { new ItemStack(ModBlocks.lightForcestone, 1, 2), Items.field_151137_ax });
/* 30 */     GameRegistry.addShapelessRecipe(new ItemStack(ModBlocks.darkActivatedForcestone, 1), new Object[] { new ItemStack(ModBlocks.darkForcestone, 1, 2), Items.field_151137_ax });
/* 31 */     GameRegistry.addSmelting(new ItemStack(ModBlocks.lightForcestone), new ItemStack(ModBlocks.lightForcestone, 1, 3), 0.1F);
/* 32 */     GameRegistry.addSmelting(new ItemStack(ModBlocks.darkForcestone), new ItemStack(ModBlocks.darkForcestone, 1, 3), 0.1F);
/*    */     
/* 34 */     GameRegistry.addRecipe(new ItemStack(ModItems.circuitry, 1), new Object[] { "IDI", "BDS", "TDR", Character.valueOf('I'), Items.field_151042_j, Character.valueOf('D'), Items.field_151045_i, Character.valueOf('B'), Blocks.field_150339_S, Character.valueOf('S'), Blocks.field_150430_aB, Character.valueOf('T'), Blocks.field_150429_aA, Character.valueOf('R'), Items.field_151137_ax });
/* 35 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightsaberForgeLight, 1), new Object[] { "*-*", "#O#", Character.valueOf('#'), new ItemStack(ModBlocks.lightForcestone, 1, 0), Character.valueOf('O'), Blocks.field_150339_S, Character.valueOf('*'), ModBlocks.lightForcestoneStairs, Character.valueOf('-'), new ItemStack((Block)ModBlocks.forcestoneSlab, 1, 0) });
/* 36 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightsaberForgeDark, 1), new Object[] { "*-*", "#O#", Character.valueOf('#'), new ItemStack(ModBlocks.darkForcestone, 1, 0), Character.valueOf('O'), Blocks.field_150339_S, Character.valueOf('*'), ModBlocks.darkForcestoneStairs, Character.valueOf('-'), new ItemStack((Block)ModBlocks.forcestoneSlab, 1, 1) });
/* 37 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.lightsaberStand, 1), new Object[] { "IFI", Character.valueOf('I'), Items.field_151042_j, Character.valueOf('F'), Items.field_151160_bD });
/* 38 */     GameRegistry.addRecipe(new ItemStack(ModBlocks.disassemblyStation, 1), new Object[] { "RRR", "BCB", "IAI", Character.valueOf('R'), Items.field_151137_ax, Character.valueOf('B'), Items.field_151072_bj, Character.valueOf('C'), ModItems.circuitry, Character.valueOf('I'), Blocks.field_150339_S, Character.valueOf('A'), Blocks.field_150467_bQ });
/*    */     
/* 40 */     for (CrystalColor color : CrystalColor.values()) {
/*    */       
/* 42 */       GameRegistry.addRecipe(ItemCrystal.create(color, ModItems.crystalPouch), new Object[] { " LS", "LCL", " L ", Character.valueOf('L'), Items.field_151116_aA, Character.valueOf('S'), Items.field_151007_F, Character.valueOf('C'), ItemCrystal.create(color) });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\recipe\ModRecipes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */