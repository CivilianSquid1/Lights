/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ public class HiltKnighted
/*    */   extends Hilt
/*    */ {
/* 13 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 17 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 18 */     parts[0] = (new Hilt.Part(PartType.EMITTER, 12.6F, new float[0])).addCrossguard(0.0F, 0.083F, 0.23F);
/* 19 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 8.4F, new float[0]);
/* 20 */     parts[2] = new Hilt.Part(PartType.BODY, 20.0F, new float[0]);
/* 21 */     parts[3] = new Hilt.Part(PartType.POMMEL, 13.3F, new float[0]);
/*    */     
/* 23 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 29 */     return CrystalColor.RED;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<FocusingCrystal> getFocusingCrystals() {
/* 35 */     return Arrays.asList(new FocusingCrystal[] { FocusingCrystal.CRACKED });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 41 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltKnighted.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */