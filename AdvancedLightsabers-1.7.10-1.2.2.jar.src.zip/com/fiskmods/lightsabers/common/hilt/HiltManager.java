/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class HiltManager
/*    */ {
/*  8 */   public static final Hilt GRAFLEX = new HiltGraflex();
/*  9 */   public static final Hilt REDEEMER = new HiltRedeemer();
/* 10 */   public static final Hilt MAULER = new HiltMauler();
/* 11 */   public static final Hilt PRODIGAL_SON = new HiltProdigalSon();
/* 12 */   public static final Hilt KNIGHTED = new HiltKnighted();
/* 13 */   public static final Hilt VAID_ANCIENT = new HiltVaid();
/* 14 */   public static final Hilt VAID_MODERN = new HiltVaid();
/* 15 */   public static final Hilt DROIDEKA = new HiltDroideka();
/* 16 */   public static final Hilt FULCRUM = new HiltFulcrum();
/* 17 */   public static final Hilt JUGGERNAUT = new HiltJuggernaut();
/* 18 */   public static final Hilt MECHANICAL = new HiltMechanical();
/* 19 */   public static final Hilt MANDALORIAN = new HiltMandalorian();
/* 20 */   public static final Hilt FURY = new HiltFury();
/* 21 */   public static final Hilt REBEL = new HiltRebel();
/* 22 */   public static final Hilt IMPERIAL = new HiltImperial();
/* 23 */   public static final Hilt REBORN = new HiltReborn();
/*    */ 
/*    */   
/*    */   public static void register() {
/* 27 */     for (Field field : HiltManager.class.getFields()) {
/*    */       
/* 29 */       if (Hilt.class.isAssignableFrom(field.getType())) {
/*    */         
/*    */         try {
/*    */           
/* 33 */           Hilt.register(field.getName().toLowerCase(Locale.ROOT), (Hilt)field.get(null));
/*    */         }
/* 35 */         catch (Exception e) {
/*    */           
/* 37 */           e.printStackTrace();
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 42 */     map(GRAFLEX, "Graflex");
/* 43 */     map(REDEEMER, "Redeemer");
/* 44 */     map(MAULER, "Mauler");
/* 45 */     map(PRODIGAL_SON, "Prodigal Son");
/* 46 */     map(KNIGHTED, "Knighted");
/* 47 */     map(VAID_ANCIENT, "Vaid (Ancient)");
/* 48 */     map(VAID_MODERN, "Vaid (Modern)");
/* 49 */     map(DROIDEKA, "Droideka");
/* 50 */     map(FULCRUM, "Fulcrum");
/* 51 */     map(JUGGERNAUT, "Juggernaut");
/* 52 */     map(MECHANICAL, "Mechanical");
/* 53 */     map(MANDALORIAN, "Mandalorian");
/* 54 */     map(FURY, "Fury");
/*    */   }
/*    */ 
/*    */   
/*    */   private static void map(Hilt value, String legacy) {
/* 59 */     Hilt.LEGACY_MAPPINGS.put(legacy, value.delegate.name());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */