/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiltMandalorian
/*    */   extends Hilt
/*    */ {
/* 14 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 18 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 19 */     parts[0] = new Hilt.Part(PartType.EMITTER, 12.55F, new float[0]);
/* 20 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 2.87F, new float[0]);
/* 21 */     parts[2] = new Hilt.Part(PartType.BODY, 26.0F, new float[0]);
/* 22 */     parts[3] = new Hilt.Part(PartType.POMMEL, 7.45F, new float[0]);
/*    */     
/* 24 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 30 */     return CrystalColor.WHITE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<FocusingCrystal> getFocusingCrystals() {
/* 36 */     return Arrays.asList(new FocusingCrystal[] { FocusingCrystal.INVERTING, FocusingCrystal.FINE_CUT });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 42 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltMandalorian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */