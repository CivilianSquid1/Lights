/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ 
/*    */ public class HiltJuggernaut
/*    */   extends Hilt {
/*  8 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 12 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 13 */     parts[0] = new Hilt.Part(PartType.EMITTER, 14.7F, new float[0]);
/* 14 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 12.4F, new float[0]);
/* 15 */     parts[2] = new Hilt.Part(PartType.BODY, 16.0F, new float[0]);
/* 16 */     parts[3] = new Hilt.Part(PartType.POMMEL, 7.0F, new float[0]);
/*    */     
/* 18 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 24 */     return CrystalColor.RED;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 30 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltJuggernaut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */