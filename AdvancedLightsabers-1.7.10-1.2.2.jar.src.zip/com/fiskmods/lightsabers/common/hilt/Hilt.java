/*     */ package com.fiskmods.lightsabers.common.hilt;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import fiskfille.utils.registry.FiskRegistryNamespaced;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Hilt
/*     */   extends FiskRegistryEntry<Hilt>
/*     */ {
/*     */   public static final int MAX_ID = 63;
/*  21 */   public static final FiskRegistryNamespaced<Hilt> REGISTRY = (new FiskRegistryNamespaced("lightsabers", "graflex")).setMaxId(63);
/*     */   
/*  23 */   public static final Map<String, String> LEGACY_MAPPINGS = new HashMap<>();
/*     */ 
/*     */   
/*     */   public static void register(int id, String key, Hilt value) {
/*  27 */     REGISTRY.addObject(id, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void register(String key, Hilt value) {
/*  32 */     REGISTRY.putObject(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Hilt getHiltFromName(String key) {
/*  37 */     return (Hilt)REGISTRY.getObject(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNameForHilt(Hilt value) {
/*  42 */     return REGISTRY.getNameForObject(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getIdFromHilt(Hilt value) {
/*  47 */     return (value == null) ? 0 : REGISTRY.getIDForObject(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Hilt getHiltById(int id) {
/*  52 */     return (Hilt)REGISTRY.getObjectById(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract Part[] getParts();
/*     */   
/*     */   public abstract CrystalColor getColor();
/*     */   
/*     */   public Type getType() {
/*  61 */     return Type.SINGLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<FocusingCrystal> getFocusingCrystals() {
/*  66 */     return Arrays.asList(new FocusingCrystal[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName() {
/*  71 */     return "hilt." + this.delegate.name().replace(':', '.') + ".name";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalizedName() {
/*  76 */     return I18n.func_135052_a(getUnlocalizedName(), new Object[0]).trim();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Part getPart(PartType type) {
/*  81 */     return getParts()[type.ordinal()];
/*     */   }
/*     */ 
/*     */   
/*     */   public final LightsaberData createDefault() {
/*  86 */     return (new LightsaberData()).set(this).set(getColor()).set(getFocusingCrystals().<FocusingCrystal>toArray(new FocusingCrystal[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Part
/*     */   {
/*     */     public PartType type;
/*     */     
/*     */     public float height;
/*     */     public float[] glInstructions;
/*     */     public float[] crossguard;
/*     */     
/*     */     public Part(PartType type, float height, float... instructions) {
/*  99 */       this.type = type;
/* 100 */       this.height = height;
/* 101 */       this.glInstructions = instructions;
/*     */     }
/*     */ 
/*     */     
/*     */     public Part addCrossguard(float x, float y, float z) {
/* 106 */       this.crossguard = new float[] { x, y, z };
/* 107 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasCrossguard() {
/* 112 */       return (this.crossguard != null);
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Type
/*     */   {
/* 118 */     SINGLE,
/* 119 */     DOUBLE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\Hilt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */