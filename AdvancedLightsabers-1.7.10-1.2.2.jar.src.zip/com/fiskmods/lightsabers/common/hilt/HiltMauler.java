/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ 
/*    */ public class HiltMauler
/*    */   extends Hilt {
/*  8 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 12 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 13 */     parts[0] = new Hilt.Part(PartType.EMITTER, 18.0F, new float[0]);
/* 14 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 12.0F, new float[0]);
/* 15 */     parts[2] = new Hilt.Part(PartType.BODY, 21.6F, new float[0]);
/* 16 */     parts[3] = new Hilt.Part(PartType.POMMEL, 0.25F, new float[0]);
/*    */     
/* 18 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 24 */     return CrystalColor.RED;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Type getType() {
/* 30 */     return Hilt.Type.DOUBLE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 36 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltMauler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */