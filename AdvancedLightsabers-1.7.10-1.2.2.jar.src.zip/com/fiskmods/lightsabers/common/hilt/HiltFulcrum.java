/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ public class HiltFulcrum
/*    */   extends Hilt
/*    */ {
/* 13 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 17 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 18 */     parts[0] = new Hilt.Part(PartType.EMITTER, 19.0F, new float[0]);
/* 19 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 10.0F, new float[0]);
/* 20 */     parts[2] = new Hilt.Part(PartType.BODY, 30.0F, new float[] { 11.7F, 2.0F, 9.8F, 3.0F, 9.0F });
/* 21 */     parts[3] = new Hilt.Part(PartType.POMMEL, 7.0F, new float[0]);
/*    */     
/* 23 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 29 */     return CrystalColor.WHITE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<FocusingCrystal> getFocusingCrystals() {
/* 35 */     return Arrays.asList(new FocusingCrystal[] { FocusingCrystal.COMPRESSED });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 41 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltFulcrum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */