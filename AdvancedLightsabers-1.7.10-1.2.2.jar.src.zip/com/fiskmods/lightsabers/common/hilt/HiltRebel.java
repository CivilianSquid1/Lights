/*    */ package com.fiskmods.lightsabers.common.hilt;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class HiltRebel
/*    */   extends Hilt
/*    */ {
/* 12 */   public Hilt.Part[] parts = makeParts();
/*    */ 
/*    */   
/*    */   private Hilt.Part[] makeParts() {
/* 16 */     Hilt.Part[] parts = new Hilt.Part[4];
/* 17 */     parts[0] = new Hilt.Part(PartType.EMITTER, 12.9F, new float[0]);
/* 18 */     parts[1] = new Hilt.Part(PartType.SWITCH_SECTION, 7.0F, new float[0]);
/* 19 */     parts[2] = new Hilt.Part(PartType.BODY, 20.0F, new float[0]);
/* 20 */     parts[3] = new Hilt.Part(PartType.POMMEL, 6.0F, new float[0]);
/*    */     
/* 22 */     return parts;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 28 */     return CrystalColor.MEDIUM_BLUE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<FocusingCrystal> getFocusingCrystals() {
/* 34 */     return Arrays.asList(new FocusingCrystal[] { FocusingCrystal.COMPRESSED });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Hilt.Part[] getParts() {
/* 40 */     return this.parts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\hilt\HiltRebel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */