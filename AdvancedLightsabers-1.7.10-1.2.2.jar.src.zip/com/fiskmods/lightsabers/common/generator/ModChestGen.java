/*    */ package com.fiskmods.lightsabers.common.generator;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import java.util.Map;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.WeightedRandomChestContent;
/*    */ import net.minecraftforge.common.ChestGenHooks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModChestGen
/*    */ {
/*    */   public static final String SITH_TOMB_ANNEX = "sithTombAnnex";
/*    */   public static final String SITH_TOMB_TREASURY = "sithTombTreasury";
/*    */   public static final String SITH_TOMB_COFFIN = "sithTombCoffin";
/*    */   public static final String JEDI_TEMPLE = "jediTemple";
/*    */   
/*    */   public static void register() {
/* 26 */     addInfo("sithTombAnnex", new WeightedRandomChestContent[] { new WeightedRandomChestContent(Items.field_151103_aS, 0, 4, 6, 4), new WeightedRandomChestContent(Items.field_151078_bh, 0, 3, 7, 3), new WeightedRandomChestContent(Items.field_151042_j, 0, 2, 7, 3), new WeightedRandomChestContent(ModItems.circuitry, 0, 1, 1, 2), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombAnnex"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombAnnex"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombAnnex") }3, 7);
/*    */     
/* 28 */     addInfo("sithTombTreasury", new WeightedRandomChestContent[] { new WeightedRandomChestContent(Items.field_151103_aS, 0, 4, 6, 14), new WeightedRandomChestContent(Items.field_151078_bh, 0, 3, 7, 12), new WeightedRandomChestContent(Items.field_151043_k, 0, 2, 7, 12), new WeightedRandomChestContent(Items.field_151045_i, 0, 1, 2, 5), new WeightedRandomChestContent((Item)Items.field_151134_bR, 0, 1, 1, 5), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), 
/* 29 */           createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 4, "sithTombTreasury"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 4, "sithTombTreasury"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 4, "sithTombTreasury") }5, 7);
/*    */     
/* 31 */     addInfo("sithTombCoffin", new WeightedRandomChestContent[] { new WeightedRandomChestContent(Items.field_151103_aS, 0, 4, 6, 14), new WeightedRandomChestContent(Items.field_151078_bh, 0, 3, 7, 12), new WeightedRandomChestContent(Items.field_151043_k, 0, 2, 7, 12), new WeightedRandomChestContent(Items.field_151045_i, 0, 1, 2, 5), new WeightedRandomChestContent((Item)Items.field_151134_bR, 0, 1, 1, 5), new WeightedRandomChestContent(ModItems.circuitry, 0, 1, 1, 3), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.focusingCrystal, 0, 1, 1, 1), 
/* 32 */           createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombCoffin"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombCoffin"), createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, "sithTombCoffin"), createSithLightsaber(ModItems.lightsaber, 0, 1, 1, 6) }6, 14);
/*    */     
/* 34 */     addInfo("jediTemple", new WeightedRandomChestContent[] { new WeightedRandomChestContent(Items.field_151077_bg, 0, 1, 4, 4), new WeightedRandomChestContent(Items.field_151168_bH, 0, 2, 6, 5), new WeightedRandomChestContent(Items.field_151057_cb, 0, 1, 2, 2), new WeightedRandomChestContent(Items.field_151116_aA, 0, 1, 8, 4), new WeightedRandomChestContent(Item.func_150898_a(Blocks.field_150325_L), 0, 1, 9, 10), new WeightedRandomChestContent(ModItems.circuitry, 0, 1, 2, 3), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 1), 
/* 35 */           createJediLightsaber(ModItems.lightsaber, 0, 1, 1, 1) }4, 8);
/*    */     
/* 37 */     for (Map.Entry<CrystalColor, String[]> e : (Iterable<Map.Entry<CrystalColor, String[]>>)ItemCrystal.chestMap.entrySet()) {
/*    */       
/* 39 */       for (String chest : (String[])e.getValue()) {
/*    */         
/* 41 */         if (!chest.equals("sithTombAnnex") && !chest.equals("sithTombTreasury") && !chest.equals("sithTombCoffin"))
/*    */         {
/* 43 */           ChestGenHooks.addItem(chest, createColorCrystal(Item.func_150898_a(ModBlocks.lightsaberCrystal), 0, 1, 1, 1, chest));
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 48 */     ChestGenHooks.addItem("villageBlacksmith", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/* 49 */     ChestGenHooks.addItem("villageBlacksmith", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/* 50 */     ChestGenHooks.addItem("villageBlacksmith", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/* 51 */     ChestGenHooks.addItem("dungeonChest", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/* 52 */     ChestGenHooks.addItem("dungeonChest", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/* 53 */     ChestGenHooks.addItem("dungeonChest", new WeightedRandomChestContent(ModItems.emitter, 0, 1, 1, 2));
/*    */   }
/*    */ 
/*    */   
/*    */   private static void addInfo(String category, WeightedRandomChestContent[] items, int min, int max) {
/* 58 */     ChestGenHooks chest = ChestGenHooks.getInfo(category);
/*    */     
/* 60 */     for (WeightedRandomChestContent item : items)
/*    */     {
/* 62 */       chest.addItem(item);
/*    */     }
/*    */     
/* 65 */     chest.setMin(min);
/* 66 */     chest.setMax(max);
/*    */   }
/*    */ 
/*    */   
/*    */   private static WeightedRandomChestContent createSithLightsaber(Item item, int metadata, int min, int max, int weight) {
/* 71 */     WeightedRandomChestContent chest = new WeightedRandomChestContent(item, metadata, min, max, weight);
/* 72 */     chest.field_76297_b.func_77982_d(new NBTTagCompound());
/* 73 */     chest.field_76297_b.func_77978_p().func_74757_a("SithTombLoot", true);
/* 74 */     return chest;
/*    */   }
/*    */ 
/*    */   
/*    */   private static WeightedRandomChestContent createJediLightsaber(Item item, int metadata, int min, int max, int weight) {
/* 79 */     WeightedRandomChestContent chest = new WeightedRandomChestContent(item, metadata, min, max, weight);
/* 80 */     chest.field_76297_b.func_77982_d(new NBTTagCompound());
/* 81 */     chest.field_76297_b.func_77978_p().func_74757_a("JediTempleLoot", true);
/* 82 */     return chest;
/*    */   }
/*    */ 
/*    */   
/*    */   private static WeightedRandomChestContent createColorCrystal(Item item, int metadata, int min, int max, int weight, String category) {
/* 87 */     WeightedRandomChestContent chest = new WeightedRandomChestContent(item, metadata, min, max, weight);
/* 88 */     chest.field_76297_b.func_77982_d(new NBTTagCompound());
/* 89 */     chest.field_76297_b.func_77978_p().func_74778_a("ChestGenCategory", category);
/* 90 */     return chest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\ModChestGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */