/*     */ package com.fiskmods.lightsabers.common.generator.structure;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Structure
/*     */ {
/*     */   protected final World worldObj;
/*     */   protected int xCoord;
/*     */   protected int yCoord;
/*     */   protected int zCoord;
/*     */   protected boolean mirrorX;
/*     */   protected boolean mirrorZ;
/*     */   protected int maxY;
/*     */   protected boolean simulate = false;
/*  27 */   protected List<StructurePoint> coverage = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public Structure(World world, int x, int y, int z) {
/*  31 */     this.worldObj = world;
/*  32 */     this.xCoord = x;
/*  33 */     this.yCoord = y;
/*  34 */     this.zCoord = z;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void spawnStructure(Random paramRandom);
/*     */   
/*     */   public void setBlock(Block block, int metadata, int x, int y, int z) {
/*  41 */     if (this.mirrorX && x > 0)
/*     */     {
/*  43 */       setBlock(this.xCoord - x, this.yCoord + y, this.zCoord + z, block, StructureHelper.mirrorMetadata(block, metadata));
/*     */     }
/*     */     
/*  46 */     if (this.mirrorZ && z > 0)
/*     */     {
/*  48 */       setBlock(this.xCoord + x, this.yCoord + y, this.zCoord - z, block, StructureHelper.mirrorMetadata(block, metadata));
/*     */     }
/*     */     
/*  51 */     setBlock(this.xCoord + x, this.yCoord + y, this.zCoord + z, block, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setBlock(int x, int y, int z, Block block, int metadata) {
/*  56 */     Block block1 = null;
/*     */     
/*  58 */     if (this.simulate || (((block1 = this.worldObj.func_147439_a(x, y, z)) != block || this.worldObj.func_72805_g(x, y, z) != metadata) && block1.func_149712_f(this.worldObj, x, y, z) != -1.0F))
/*     */     {
/*  60 */       if (this.simulate) {
/*     */         
/*  62 */         this.maxY = Math.max(this.maxY, y);
/*     */         
/*  64 */         StructurePoint p = new StructurePoint(x, y, z);
/*     */         
/*  66 */         if (this.coverage.contains(p)) {
/*     */           
/*  68 */           for (int i = 0; i < this.coverage.size(); i++) {
/*     */             
/*  70 */             StructurePoint p1 = this.coverage.get(i);
/*     */             
/*  72 */             if (p.equals(p1)) {
/*     */               
/*  74 */               p1.field_71572_b = Math.min(p1.field_71572_b, y);
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } else {
/*  81 */           this.coverage.add(p);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  86 */         placeBlock(x, y, z, block, metadata, 2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void placeBlock(int x, int y, int z, Block block, int metadata, int flags) {
/*  93 */     this.worldObj.func_147465_d(x, y, z, block, metadata, flags);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean generateStructureChestContents(Random random, int x, int y, int z, WeightedRandomChestContent[] chestContent, int itemsToGenerate) {
/*  98 */     int i = this.xCoord + x;
/*  99 */     int j = this.yCoord + y;
/* 100 */     int k = this.zCoord + z;
/*     */     
/* 102 */     if (this.worldObj.func_147439_a(i, j, k) != Blocks.field_150486_ae) {
/*     */       
/* 104 */       this.worldObj.func_147465_d(i, j, k, (Block)Blocks.field_150486_ae, 0, 2);
/* 105 */       TileEntityChest tile = (TileEntityChest)this.worldObj.func_147438_o(i, j, k);
/*     */       
/* 107 */       if (tile != null)
/*     */       {
/* 109 */         WeightedRandomChestContent.func_76293_a(random, chestContent, (IInventory)tile, itemsToGenerate);
/*     */       }
/*     */       
/* 112 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fillStructureInventory(Block block, Random random, int x, int y, int z, WeightedRandomChestContent[] chestContent, int itemsToGenerate) {
/* 122 */     int i = this.xCoord + x;
/* 123 */     int j = this.yCoord + y;
/* 124 */     int k = this.zCoord + z;
/*     */     
/* 126 */     if (this.worldObj.func_147439_a(i, j, k) == block) {
/*     */       
/* 128 */       IInventory inventory = (IInventory)this.worldObj.func_147438_o(i, j, k);
/*     */       
/* 130 */       if (inventory != null)
/*     */       {
/* 132 */         WeightedRandomChestContent.func_76293_a(random, chestContent, inventory, itemsToGenerate);
/*     */       }
/*     */       
/* 135 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 139 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\Structure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */