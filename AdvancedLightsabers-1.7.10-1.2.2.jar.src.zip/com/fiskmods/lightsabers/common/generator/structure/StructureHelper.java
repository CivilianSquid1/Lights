/*    */ package com.fiskmods.lightsabers.common.generator.structure;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructureHelper
/*    */ {
/*    */   public static int mirrorMetadata(Block block, int metadata) {
/* 11 */     if (block instanceof net.minecraft.block.BlockStairs) {
/*    */       
/* 13 */       switch (metadata % 8) {
/*    */         
/*    */         case 0:
/* 16 */           return 1;
/*    */         case 1:
/* 18 */           return 0;
/*    */ 
/*    */ 
/*    */ 
/*    */         
/*    */         case 4:
/* 24 */           return 5;
/*    */         case 5:
/* 26 */           return 4;
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 33 */     } else if (block instanceof net.minecraft.block.BlockButton) {
/*    */       
/* 35 */       switch (metadata) {
/*    */         
/*    */         case 1:
/* 38 */           return 2;
/*    */         case 2:
/* 40 */           return 1;
/*    */       } 
/*    */     
/*    */     } 
/* 44 */     return metadata;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int rotateMetadata(Block block, int metadata) {
/* 49 */     if (block instanceof net.minecraft.block.BlockStairs) {
/*    */       
/* 51 */       switch (metadata % 8) {
/*    */         
/*    */         case 0:
/* 54 */           return 3;
/*    */         case 1:
/* 56 */           return 2;
/*    */         case 2:
/* 58 */           return 1;
/*    */         case 3:
/* 60 */           return 0;
/*    */         case 4:
/* 62 */           return 7;
/*    */         case 5:
/* 64 */           return 6;
/*    */         case 6:
/* 66 */           return 5;
/*    */         case 7:
/* 68 */           return 4;
/*    */       } 
/*    */     
/* 71 */     } else if (block instanceof net.minecraft.block.BlockButton) {
/*    */       
/* 73 */       return (metadata + 1) % 4;
/*    */     } 
/*    */     
/* 76 */     return metadata;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\StructureHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */