/*    */ package com.fiskmods.lightsabers.common.generator.structure;
/*    */ 
/*    */ import net.minecraft.util.ChunkCoordinates;
/*    */ 
/*    */ public class StructurePoint
/*    */   extends ChunkCoordinates
/*    */ {
/*    */   public StructurePoint(int x, int y, int z) {
/*  9 */     super(x, y, z);
/*    */   }
/*    */ 
/*    */   
/*    */   public StructurePoint(StructurePoint p) {
/* 14 */     super(p);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 20 */     if (!(obj instanceof StructurePoint))
/*    */     {
/* 22 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 26 */     StructurePoint chunkcoordinates = (StructurePoint)obj;
/* 27 */     return (this.field_71574_a == chunkcoordinates.field_71574_a && this.field_71573_c == chunkcoordinates.field_71573_c);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\StructurePoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */