/*    */ package com.fiskmods.lightsabers.common.generator.structure;
/*    */ 
/*    */ import com.google.common.base.Predicate;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.biome.BiomeGenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumStructure
/*    */ {
/* 14 */   SITH_TOMB(new Constructor()
/*    */     {
/*    */       
/*    */       public Structure construct(World world, int x, int y, int z, Random rand)
/*    */       {
/* 19 */         return new StructureSithTomb(world, x, y, z);
/*    */       }
/*    */     }8, 32, new BiomeGenBase[] { BiomeGenBase.field_76769_d, BiomeGenBase.field_76786_s, BiomeGenBase.field_150589_Z, BiomeGenBase.field_150608_ab, BiomeGenBase.field_150607_aa }),
/* 22 */   JEDI_TEMPLE(new Constructor()
/*    */     {
/*    */       
/*    */       public Structure construct(World world, int x, int y, int z, Random rand)
/*    */       {
/* 27 */         return new StructureJediTemple(0.0F, world, x, y, z);
/*    */       }
/*    */     }24, 64, new TemplePredicate());
/*    */ 
/*    */   
/*    */   public final Predicate<BiomeGenBase> biomePredicate;
/*    */   private final Constructor constructor;
/*    */   public int minDistance;
/*    */   public int maxDistance;
/*    */   
/*    */   EnumStructure(Constructor c, int min, int max, Predicate<BiomeGenBase> predicate) {
/* 38 */     this.biomePredicate = predicate;
/* 39 */     this.minDistance = min;
/* 40 */     this.maxDistance = max;
/* 41 */     this.constructor = c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Structure construct(World world, int x, int y, int z, Random rand) {
/* 60 */     return this.constructor.construct(world, x, y, z, rand);
/*    */   }
/*    */   
/*    */   private static interface Constructor
/*    */   {
/*    */     Structure construct(World param1World, int param1Int1, int param1Int2, int param1Int3, Random param1Random);
/*    */   }
/*    */   
/*    */   private static class TemplePredicate
/*    */     implements Predicate<BiomeGenBase> {
/*    */     private TemplePredicate() {}
/*    */     
/*    */     public boolean apply(BiomeGenBase biome) {
/* 73 */       return (biome.field_76748_D > 0.0F && biome.field_76750_F < 1.5F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\EnumStructure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */