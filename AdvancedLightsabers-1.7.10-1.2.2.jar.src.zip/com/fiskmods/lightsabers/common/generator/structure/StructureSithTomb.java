/*      */ package com.fiskmods.lightsabers.common.generator.structure;
/*      */ 
/*      */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*      */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*      */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*      */ import java.util.Random;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.world.World;
/*      */ import net.minecraft.world.biome.BiomeGenBase;
/*      */ import net.minecraftforge.common.ChestGenHooks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StructureSithTomb
/*      */   extends Structure
/*      */ {
/*      */   public StructureSithTomb(World world, int x, int y, int z) {
/*   20 */     super(world, x, y, z);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void spawnStructure(Random random) {
/*   26 */     generateEntrance(random);
/*   27 */     int stairLength = 5;
/*      */     
/*      */     int k;
/*      */     
/*   31 */     for (k = 63; !this.worldObj.func_147437_c(this.xCoord, k + 1, this.zCoord + 17 + stairLength); k++);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   36 */     while (this.yCoord - stairLength + 5 > k)
/*      */     {
/*   38 */       stairLength++;
/*      */     }
/*      */     
/*   41 */     generateStairway(random, stairLength);
/*   42 */     generateAntechamber(random);
/*   43 */     generateAnnex(random);
/*   44 */     this.xCoord -= 17;
/*   45 */     this.zCoord -= 5;
/*   46 */     generateBurialChamber(random);
/*   47 */     generateTreasury(random);
/*      */     
/*   49 */     int coffinX = -1;
/*   50 */     int coffinY = 0;
/*   51 */     int coffinZ = 6;
/*   52 */     generateCoffin(20, -1, 10, 2, coffinX, coffinY, coffinZ);
/*   53 */     generateCoffin(23, -1, 10, 2, coffinX, coffinY, coffinZ);
/*   54 */     generateCoffin(26, -1, 10, 2, coffinX, coffinY, coffinZ);
/*   55 */     generateCoffin(20, -1, 2, 0, coffinX, coffinY, coffinZ);
/*      */   }
/*      */   
/*      */   private void generateEntrance(Random random) {
/*      */     int i;
/*   60 */     for (i = 0; i < 9; i++) {
/*      */       
/*   62 */       for (int j = 0; j < 11; j++) {
/*      */         
/*   64 */         for (int k = 0; k < 16; k++)
/*      */         {
/*   66 */           setBlock(Blocks.field_150350_a, 0, 4 - i, j, 1 + k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*   71 */     for (i = 0; i < 16; i++) {
/*      */       
/*   73 */       for (int j = 0; j < 9; j++) {
/*      */         
/*   75 */         setBlock(ModBlocks.darkForcestone, 0, 4 - j, 0, 1 + i);
/*      */         
/*   77 */         int k = 0;
/*      */         
/*   79 */         while (k > 0 && this.worldObj.func_147437_c(this.xCoord + 4 - j, this.yCoord - 1 + k, this.zCoord + 1 + i)) {
/*      */           
/*   81 */           k--;
/*   82 */           BiomeGenBase biome = this.worldObj.func_72807_a(this.xCoord + 4 - j, this.zCoord + 1 + i);
/*   83 */           setBlock(biome.field_76753_B, biome.field_150604_aj, 4 - j, k, 1 + i);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*   88 */     for (i = 0; i < 5; i++) {
/*      */       
/*   90 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 0 : ((i == 4) ? 1 : 2), 2 - i, 0, 1);
/*   91 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 0 : ((i == 4) ? 1 : 3), 2 - i, 0, 16);
/*   92 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 4 : ((i == 4) ? 5 : 1), 2 - i, (i == 0 || i == 4) ? 4 : 5, 1);
/*   93 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 4 : ((i == 4) ? 5 : 1), 2 - i, 4, 16);
/*   94 */       setBlock(ModBlocks.darkForcestone, (i == 0 || i == 4) ? 0 : 1, 2 - i, 4, 2);
/*   95 */       setBlock(ModBlocks.darkForcestoneStairs, 2, 2 - i, 5, 2);
/*   96 */       setBlock(ModBlocks.darkForcestoneStairs, 3, 2 - i, 5, 15);
/*      */       
/*   98 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 1), 4, 0, 3 + i);
/*   99 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 7 : ((i == 4) ? 6 : 1), 4, (i == 0 || i == 4) ? 4 : 5, 3 + i);
/*  100 */       setBlock(ModBlocks.darkForcestone, (i == 0 || i == 4) ? 0 : 1, 3, 4, 3 + i);
/*  101 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 1), 4, 0, 10 + i);
/*  102 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 7 : ((i == 4) ? 6 : 1), 4, 4, 10 + i);
/*  103 */       setBlock(ModBlocks.darkForcestoneStairs, 1, 3, 5, 3 + i);
/*  104 */       setBlock(ModBlocks.darkForcestoneStairs, 1, 3, 5, 10 + i);
/*  105 */       setBlock((Block)Blocks.field_150399_cn, 14, 2, 5, 3 + i);
/*  106 */       setBlock(ModBlocks.darkForcestoneStairs, 4, 2, 4, 9 + i);
/*  107 */       setBlock((i == 0) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 3 : 1, 2, 1, 9 + i);
/*      */       
/*  109 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 0), -4, 0, 3 + i);
/*  110 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 7 : ((i == 4) ? 6 : 1), -4, (i == 0 || i == 4) ? 4 : 5, 3 + i);
/*  111 */       setBlock(ModBlocks.darkForcestone, (i == 0 || i == 4) ? 0 : 1, -3, 4, 3 + i);
/*  112 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 0), -4, 0, 10 + i);
/*  113 */       setBlock((i == 0 || i == 4) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 7 : ((i == 4) ? 6 : 1), -4, 4, 10 + i);
/*  114 */       setBlock(ModBlocks.darkForcestoneStairs, 0, -3, 5, 3 + i);
/*  115 */       setBlock(ModBlocks.darkForcestoneStairs, 0, -3, 5, 10 + i);
/*  116 */       setBlock((Block)Blocks.field_150399_cn, 14, -2, 5, 3 + i);
/*  117 */       setBlock(ModBlocks.darkForcestoneStairs, 5, -2, 4, 9 + i);
/*  118 */       setBlock((i == 0) ? ModBlocks.darkForcestoneStairs : (Block)ModBlocks.forcestoneSlab, (i == 0) ? 3 : 1, -2, 1, 9 + i);
/*      */       
/*  120 */       if (i < 3) {
/*      */         
/*  122 */         setBlock(ModBlocks.darkActivatedForcestone, 0, 2, 1 + i, 2);
/*  123 */         setBlock(ModBlocks.darkActivatedForcestone, 0, -2, 1 + i, 2);
/*  124 */         setBlock(ModBlocks.darkActivatedForcestone, 0, 2, 6 + i, 10);
/*  125 */         setBlock(ModBlocks.darkActivatedForcestone, 0, -2, 6 + i, 10);
/*  126 */         setBlock(ModBlocks.darkActivatedForcestone, 0, 2, 6 + i, 14);
/*  127 */         setBlock(ModBlocks.darkActivatedForcestone, 0, -2, 6 + i, 14);
/*  128 */         setBlock((Block)Blocks.field_150399_cn, 14, -1 + i, 5, 3);
/*  129 */         setBlock(ModBlocks.darkForcestoneStairs, 3, -1 + i, 0, 10);
/*  130 */         setBlock(ModBlocks.darkForcestoneStairs, 6, -1 + i, 0, 14);
/*  131 */         setBlock(ModBlocks.darkForcestoneStairs, 2, -1 + i, 6, 10);
/*  132 */         setBlock(ModBlocks.darkForcestoneStairs, 3, -1 + i, 6, 14);
/*  133 */         setBlock(ModBlocks.darkForcestoneStairs, 1, 2, 6, 11 + i);
/*  134 */         setBlock(ModBlocks.darkForcestoneStairs, 0, -2, 6, 11 + i);
/*  135 */         setBlock(ModBlocks.darkForcestoneStairs, 2, -1 + i, 9, 10);
/*  136 */         setBlock(ModBlocks.darkForcestoneStairs, 3, -1 + i, 9, 14);
/*  137 */         setBlock(ModBlocks.darkForcestoneStairs, 7, -1 + i, 9, 11);
/*  138 */         setBlock(ModBlocks.darkForcestoneStairs, 6, -1 + i, 9, 13);
/*  139 */         setBlock(ModBlocks.darkForcestoneStairs, 2, -1 + i, 10, 11);
/*  140 */         setBlock(ModBlocks.darkForcestoneStairs, 3, -1 + i, 10, 13);
/*      */       } 
/*      */       
/*  143 */       if (i < 4) {
/*      */         
/*  145 */         setBlock(ModBlocks.darkActivatedForcestone, 0, 2, 1 + i, 8);
/*  146 */         setBlock(ModBlocks.darkActivatedForcestone, 0, -2, 1 + i, 8);
/*  147 */         setBlock(ModBlocks.darkForcestone, 2, 2, 1 + i, 14);
/*  148 */         setBlock(ModBlocks.darkForcestone, 2, -2, 1 + i, 14);
/*      */       } 
/*      */       
/*  151 */       setBlock((Block)ModBlocks.forcestoneSlab, 1, 2 - i, 6, 9);
/*  152 */       setBlock(ModBlocks.darkForcestoneStairs, 1, 2, 9, 10 + i);
/*  153 */       setBlock(ModBlocks.darkForcestoneStairs, 0, -2, 9, 10 + i);
/*      */     } 
/*      */     
/*  156 */     for (i = 0; i < 2; i++) {
/*      */       
/*  158 */       for (int j = 0; j < 4; j++) {
/*      */         
/*  160 */         for (int k = 0; k < 2; k++) {
/*      */           
/*  162 */           setBlock(ModBlocks.darkForcestone, (i == 1 && k == 1) ? 0 : 2, 4 - i, 1 + j, 1 + k);
/*  163 */           setBlock(ModBlocks.darkForcestone, (i == 1 && k == 1) ? 0 : 2, -4 + i, 1 + j, 1 + k);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  168 */     for (i = 0; i < 2; i++) {
/*      */       
/*  170 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  172 */         for (int k = 0; k < 2; k++) {
/*      */           
/*  174 */           setBlock(ModBlocks.darkForcestone, 2, 4, 1 + j, 8 + k);
/*  175 */           setBlock(ModBlocks.darkForcestone, 2, -4, 1 + j, 8 + k);
/*  176 */           setBlock(ModBlocks.darkForcestone, (i == 1 && k == 0) ? 0 : 2, 4 - i, 1 + j, 15 + k);
/*  177 */           setBlock(ModBlocks.darkForcestone, (i == 1 && k == 0) ? 0 : 2, -4 + i, 1 + j, 15 + k);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  182 */     for (i = 0; i < 4; i++) {
/*      */       
/*  184 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  186 */         setBlock(ModBlocks.darkForcestone, (j > 0 && i == 1) ? 1 : 0, 3, 1 + i, 8 + j);
/*  187 */         setBlock(ModBlocks.darkForcestone, (j > 0 && i == 1) ? 1 : 0, -3, 1 + i, 8 + j);
/*      */       } 
/*      */     } 
/*      */     
/*  191 */     for (i = 0; i < 5; i++) {
/*      */       
/*  193 */       for (int j = 0; j < 4; j++)
/*      */       {
/*  195 */         setBlock(ModBlocks.darkForcestone, (j == 1) ? 1 : 0, -2 + i, 1 + j, 15);
/*      */       }
/*      */     } 
/*      */     
/*  199 */     for (i = 0; i < 7; i++) {
/*      */       
/*  201 */       for (int j = 0; j < 6; j++) {
/*      */         
/*  203 */         if (j > 3 || (i > 1 && i < 5))
/*      */         {
/*  205 */           setBlock(ModBlocks.darkForcestone, 0, 3 - i, 5, 4 + j);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  210 */     for (i = 0; i < 5; i++) {
/*      */       
/*  212 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  214 */         if (i == 0 || i == 4 || j == 0 || j == 4)
/*      */         {
/*  216 */           setBlock(ModBlocks.darkForcestone, 0, -2 + i, 5, 10 + j);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  221 */     for (i = 0; i < 2; i++) {
/*      */       
/*  223 */       int j = (i == 0) ? 0 : 6;
/*  224 */       setBlock(ModBlocks.darkForcestoneStairs, 3, 3 - j, 1, 3);
/*  225 */       setBlock(ModBlocks.darkForcestoneStairs, 2, 3 - j, 1, 7);
/*  226 */       setBlock(ModBlocks.darkForcestoneStairs, 7, 3 - j, 3, 3);
/*  227 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 3 - j, 3, 7);
/*      */     } 
/*      */     
/*  230 */     for (i = 0; i < 4; i++) {
/*      */       
/*  232 */       int x = (i % 2 == 0) ? -4 : 3;
/*  233 */       int y = 6;
/*  234 */       int z = 8 + i / 2 * 7;
/*      */       
/*  236 */       for (int j = 0; j < 4; j++) {
/*      */         
/*  238 */         int k = (j == 0) ? 0 : ((j == 1) ? 2 : ((j == 2) ? 3 : 1));
/*  239 */         setBlock(ModBlocks.darkForcestoneStairs, k, x + j % 2, y, z + j / 2);
/*      */       } 
/*      */     } 
/*      */     
/*  243 */     for (i = 0; i < 3; i++) {
/*      */       
/*  245 */       for (int j = 0; j < 3; j++)
/*      */       {
/*  247 */         setBlock(Blocks.field_150350_a, 0, -1 + i, 0, 11 + j);
/*      */       }
/*      */     } 
/*      */     
/*  251 */     setBlock(ModBlocks.darkForcestoneStairs, 1, 1, 10, 12);
/*  252 */     setBlock(ModBlocks.darkForcestoneStairs, 0, -1, 10, 12);
/*  253 */     setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 9, 12);
/*  254 */     setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 9, 12);
/*  255 */     setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 3, 2);
/*  256 */     setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 3, 2);
/*  257 */     setBlock((Block)Blocks.field_150399_cn, 14, 0, 10, 12);
/*  258 */     setBlock(ModBlocks.darkForcestone, 0, 3, 5, 2);
/*  259 */     setBlock(ModBlocks.darkForcestoneStairs, 2, 3, 5, 1);
/*  260 */     setBlock(ModBlocks.darkForcestoneStairs, 2, 4, 5, 1);
/*  261 */     setBlock(ModBlocks.darkForcestoneStairs, 1, 4, 5, 2);
/*  262 */     setBlock(ModBlocks.darkForcestone, 0, -3, 5, 2);
/*  263 */     setBlock(ModBlocks.darkForcestoneStairs, 2, -3, 5, 1);
/*  264 */     setBlock(ModBlocks.darkForcestoneStairs, 2, -4, 5, 1);
/*  265 */     setBlock(ModBlocks.darkForcestoneStairs, 0, -4, 5, 2);
/*      */     
/*  267 */     setBlock(Blocks.field_150406_ce, 14, 0, 0, 3);
/*  268 */     setBlock(Blocks.field_150406_ce, 14, 1, 0, 4);
/*  269 */     setBlock(Blocks.field_150406_ce, 14, -1, 0, 4);
/*  270 */     setBlock(Blocks.field_150406_ce, 14, 0, 0, 5);
/*  271 */     setBlock(Blocks.field_150406_ce, 14, 1, 0, 6);
/*  272 */     setBlock(Blocks.field_150406_ce, 14, -1, 0, 6);
/*  273 */     setBlock(Blocks.field_150406_ce, 14, 0, 0, 7);
/*  274 */     setBlock(Blocks.field_150406_ce, 14, 0, 0, 8);
/*      */     
/*  276 */     generateStatue(0, 1, 14, 2, false);
/*      */     
/*  278 */     this.zCoord += 12;
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateStairway(Random random, int stairLength) {
/*  283 */     int i1 = 0;
/*      */     int i;
/*  285 */     for (i = 0; i < 6; i++) {
/*      */       
/*  287 */       for (int j = 0; j <= i1; j++) {
/*      */         
/*  289 */         setBlock(ModBlocks.darkForcestone, 0, 2, -6 + i, 4 - j);
/*  290 */         setBlock(ModBlocks.darkForcestone, 0, -2, -6 + i, 4 - j);
/*      */         
/*  292 */         if (j != i1)
/*      */         {
/*  294 */           for (int k = 0; k < 3; k++)
/*      */           {
/*  296 */             setBlock(Blocks.field_150350_a, 0, 1 - k, -6 + i, 4 - j);
/*      */           }
/*      */         }
/*      */       } 
/*      */       
/*  301 */       i1++;
/*      */     } 
/*      */     
/*  304 */     for (i = 0; i < 3; i++) {
/*      */       int j;
/*  306 */       for (j = 0; j < 7; j++) {
/*      */         
/*  308 */         setBlock(ModBlocks.darkForcestone, 0, 1 - i, -1 - j, -2 + j);
/*      */         
/*  310 */         if (j > 0)
/*      */         {
/*  312 */           setBlock(ModBlocks.darkForcestoneStairs, 3, 1 - i, -j, -2 + j);
/*      */         }
/*      */       } 
/*      */       
/*  316 */       setBlock(ModBlocks.darkForcestone, 0, 1 - i, -1, 4);
/*  317 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, -1, 3);
/*  318 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, -2, 4);
/*      */       
/*  320 */       for (j = 0; j < stairLength; j++) {
/*      */         
/*  322 */         setBlock(ModBlocks.darkForcestone, 0, 1 - i, -8 - j, 5 + j);
/*  323 */         setBlock(ModBlocks.darkForcestoneStairs, 3, 1 - i, -7 - j, 5 + j);
/*  324 */         setBlock(ModBlocks.darkForcestone, 0, 1 - i, -2 - j, 5 + j);
/*  325 */         setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, -3 - j, 5 + j);
/*  326 */         setBlock(Blocks.field_150350_a, 6, 1 - i, -4 - j, 5 + j);
/*  327 */         setBlock(Blocks.field_150350_a, 6, 1 - i, -5 - j, 5 + j);
/*  328 */         setBlock(Blocks.field_150350_a, 6, 1 - i, -6 - j, 5 + j);
/*      */       } 
/*      */     } 
/*      */     
/*  332 */     for (i = 0; i < 5; i++) {
/*      */       
/*  334 */       for (int j = 0; j < stairLength; j++) {
/*      */         
/*  336 */         if ((i + j + 1) % 5 == 0) {
/*      */           
/*  338 */           setBlock(ModBlocks.darkActivatedForcestone, 8, 2, -3 - i - j, 5 + j);
/*  339 */           setBlock(ModBlocks.darkActivatedForcestone, 8, -2, -3 - i - j, 5 + j);
/*      */         }
/*      */         else {
/*      */           
/*  343 */           setBlock(ModBlocks.darkForcestone, 0, 2, -3 - i - j, 5 + j);
/*  344 */           setBlock(ModBlocks.darkForcestone, 0, -2, -3 - i - j, 5 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  349 */     this.zCoord += 5 + stairLength;
/*  350 */     this.yCoord -= 7 + stairLength;
/*      */     
/*  352 */     for (i = 0; i < 9; i++) {
/*      */       
/*  354 */       for (int j = 0; j < 10; j++) {
/*      */         
/*  356 */         for (int k = 0; k < 10; k++)
/*      */         {
/*  358 */           setBlock(Blocks.field_150348_b, 0, 4 - i, j - 3, k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  363 */     for (i = 0; i < 7; i++) {
/*      */       
/*  365 */       for (int j = 0; j < 8; j++) {
/*      */         
/*  367 */         for (int k = 0; k < 8; k++)
/*      */         {
/*  369 */           setBlock(Blocks.field_150350_a, 0, 3 - i, j - 2, k + 1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  374 */     for (i = 0; i < 3; i++) {
/*      */       
/*  376 */       for (int j = 0; j < 3; j++) {
/*      */         
/*  378 */         for (int k = 0; k < 11; k++)
/*      */         {
/*  380 */           setBlock(Blocks.field_150350_a, 0, 1 - i, j + 1, k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  385 */     for (i = 0; i < 5; i++) {
/*      */       
/*  387 */       for (int j = 0; j < 11; j++) {
/*      */         
/*  389 */         setBlock(ModBlocks.darkForcestone, 0, 2 - i, 0, j);
/*      */         
/*  391 */         if (j < 10)
/*      */         {
/*  393 */           setBlock(ModBlocks.darkForcestone, 0, 2 - i, 4, j + 1);
/*      */         }
/*      */         
/*  396 */         if (i < 4) {
/*      */           
/*  398 */           setBlock(ModBlocks.darkForcestone, (i == 1) ? 1 : 0, 2, 1 + i, j);
/*  399 */           setBlock(ModBlocks.darkForcestone, (i == 1) ? 1 : 0, -2, 1 + i, j);
/*  400 */           setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 3, 7 + i);
/*  401 */           setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 3, 7 + i);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  406 */     for (i = 0; i < 2; i++) {
/*      */       
/*  408 */       setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 4, 1 + i);
/*  409 */       setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 4, 1 + i);
/*      */     } 
/*      */     
/*  412 */     for (i = 0; i < 3; i++) {
/*      */       
/*  414 */       setBlock(ModBlocks.darkForcestone, 0, 1 - i, 5, 0);
/*  415 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, 4, 0);
/*  416 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 2, i + 1, 4);
/*  417 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -2, i + 1, 4);
/*  418 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 2, i + 1, 6);
/*  419 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -2, i + 1, 6);
/*  420 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, 3, 4);
/*  421 */       setBlock(ModBlocks.darkForcestoneStairs, 6, 1 - i, 4, 3);
/*  422 */       setBlock(ModBlocks.darkForcestoneStairs, 7, 1 - i, 3, 6);
/*      */     } 
/*      */ 
/*      */     
/*  426 */     setBlock((Block)Blocks.field_150320_F, 0, 0, 4, 5);
/*  427 */     setBlock((Block)Blocks.field_150320_F, 1, 0, -1, 5);
/*      */     
/*  429 */     setBlock(ModBlocks.darkForcestone, 2, 0, 3, 5);
/*  430 */     setBlock(ModBlocks.darkForcestone, 2, 0, 0, 5);
/*      */     
/*  432 */     for (i = 0; i < 2; i++) {
/*      */       
/*  434 */       setBlock((Block)Blocks.field_150320_F, 4, 3, 1 + i, 5);
/*  435 */       setBlock((Block)Blocks.field_150320_F, 5, -3, 1 + i, 5);
/*  436 */       setBlock(ModBlocks.darkForcestone, 3, 2, 1 + i, 5);
/*  437 */       setBlock(ModBlocks.darkForcestone, 3, -2, 1 + i, 5);
/*      */       
/*  439 */       int j = (i == 0) ? 3 : -3;
/*  440 */       setBlock(Blocks.field_150348_b, 0, j, 2, 3);
/*  441 */       setBlock((Block)Blocks.field_150488_af, 0, j, 3, 3);
/*  442 */       setBlock(Blocks.field_150429_aA, 3, j, 2, 4);
/*      */     } 
/*      */     
/*  445 */     for (i = 0; i < 3; i++) {
/*      */       
/*  447 */       setBlock(Blocks.field_150452_aw, 0, 1 - i, 1, 3);
/*  448 */       setBlock(Blocks.field_150452_aw, 0, 1 - i, 1, 7);
/*      */     } 
/*      */     
/*  451 */     for (i = 0; i < 7; i++) {
/*      */       
/*  453 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  455 */         if (i == 0 || i == 6 || j == 0 || j == 4) {
/*      */           
/*  457 */           setBlock(Blocks.field_150348_b, 0, 3 - i, -2, 3 + j);
/*  458 */           setBlock((Block)Blocks.field_150488_af, 0, 3 - i, -1, 3 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  463 */     setBlock(Blocks.field_150348_b, 0, 1, -2, 5);
/*  464 */     setBlock(Blocks.field_150429_aA, 2, 0, -2, 5);
/*  465 */     setBlock((Block)Blocks.field_150488_af, 0, 1, -2, 6);
/*  466 */     setBlock((Block)Blocks.field_150488_af, 0, 1, -2, 4);
/*  467 */     setBlock((Block)Blocks.field_150333_U, 8, -3, 3, 4);
/*  468 */     setBlock((Block)Blocks.field_150488_af, 0, -3, 4, 4);
/*  469 */     setBlock(Blocks.field_150429_aA, 1, -1, 4, 5);
/*      */     
/*  471 */     for (i = 0; i < 5; i++) {
/*      */       
/*  473 */       setBlock((Block)Blocks.field_150333_U, 8, -3, -2 + i, 2 - i % 2);
/*  474 */       setBlock((Block)Blocks.field_150333_U, 8, 3, -2 + i, 2 - i % 2);
/*  475 */       setBlock((Block)Blocks.field_150488_af, 0, -3, -1 + i, 2 - i % 2);
/*  476 */       setBlock((Block)Blocks.field_150488_af, 0, 3, -1 + i, 2 - i % 2);
/*      */       
/*  478 */       if (i < 4) {
/*      */         
/*  480 */         setBlock((Block)Blocks.field_150333_U, 8, -3, -1 + i, 8 - i % 2);
/*  481 */         setBlock((Block)Blocks.field_150488_af, 0, -3, i, 8 - i % 2);
/*  482 */         setBlock((Block)Blocks.field_150488_af, 0, -2, (i == 2) ? 5 : 4, 7 - i);
/*      */       } 
/*      */     } 
/*      */     
/*  486 */     this.zCoord += 10;
/*      */   }
/*      */   
/*      */   private void generateAntechamber(Random random) {
/*      */     int i;
/*  491 */     for (i = 0; i < 23; i++) {
/*      */       
/*  493 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  495 */         for (int k = 0; k < 11; k++)
/*      */         {
/*  497 */           setBlock(ModBlocks.darkForcestone, (j == 2) ? 1 : 0, 11 - i, j - 1, 1 + k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  502 */     for (i = 0; i < 21; i++) {
/*      */       
/*  504 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  506 */         for (int k = 0; k < 9; k++)
/*      */         {
/*  508 */           setBlock(Blocks.field_150350_a, 0, 10 - i, j, 2 + k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  513 */     for (i = 0; i < 21; i++) {
/*      */       
/*  515 */       for (int j = 0; j < 9; j++) {
/*      */         
/*  517 */         if (i == 0 || i == 20 || j == 0 || j == 8) {
/*      */           
/*  519 */           int k = (i == 0) ? 0 : ((i == 20) ? 1 : ((j == 0) ? 3 : 2));
/*  520 */           setBlock(ModBlocks.darkForcestoneStairs, k, 10 - i, 0, 2 + j);
/*  521 */           setBlock(ModBlocks.darkForcestoneStairs, k + 4, 10 - i, 3, 2 + j);
/*  522 */           setBlock(ModBlocks.darkForcestone, 0, 10 - i, 4, 2 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  527 */     for (i = 0; i < 19; i++) {
/*      */       
/*  529 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  531 */         if (i == 0 || i == 18 || j == 0 || j == 6) {
/*      */           
/*  533 */           int k = (i == 0) ? 0 : ((i == 18) ? 1 : ((j == 0) ? 3 : 2));
/*  534 */           setBlock(ModBlocks.darkForcestoneStairs, k + 4, 9 - i, 4, 3 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  539 */     for (i = 0; i < 17; i++) {
/*      */       
/*  541 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  543 */         if (i == 0 || i == 16 || j == 0 || j == 4) {
/*      */           
/*  545 */           int k = (i == 0) ? 0 : ((i == 16) ? 1 : ((j == 0) ? 3 : 2));
/*  546 */           setBlock(ModBlocks.darkForcestoneStairs, k, 8 - i, -1, 4 + j);
/*      */         }
/*      */         else {
/*      */           
/*  550 */           setBlock((Block)ModBlocks.forcestoneSlab, 1, 8 - i, -1, 4 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  555 */     for (i = 0; i < 15; i++) {
/*      */       
/*  557 */       boolean flag = (i == 1 || i == 4 || i == 10 || i == 13);
/*      */       
/*  559 */       if (flag || i == 7) {
/*      */         
/*  561 */         setBlock(Blocks.field_150406_ce, 14, 7 - i, -1, 5);
/*  562 */         setBlock(Blocks.field_150406_ce, 14, 7 - i, -1, 7);
/*      */       } 
/*      */       
/*  565 */       if (!flag || i == 7)
/*      */       {
/*  567 */         setBlock(Blocks.field_150406_ce, 14, 7 - i, -1, 6);
/*      */       }
/*      */     } 
/*      */     
/*  571 */     for (i = 0; i < 2; i++) {
/*      */       
/*  573 */       setBlock(ModBlocks.darkForcestone, 2, 8, i, 11);
/*  574 */       setBlock(ModBlocks.darkForcestone, 2, 4, i, 11);
/*  575 */       setBlock(ModBlocks.darkForcestone, 2, -11, i, 8);
/*  576 */       setBlock(ModBlocks.darkForcestone, 2, -11, i, 4);
/*      */     } 
/*      */     
/*  579 */     for (i = 0; i < 3; i++) {
/*      */       
/*  581 */       setBlock((Block)ModBlocks.forcestoneSlab, 1, 1 - i, 3, 1);
/*  582 */       setBlock(Blocks.field_150350_a, 0, 1 - i, 2, 1);
/*  583 */       setBlock(Blocks.field_150350_a, 0, 1 - i, 1, 1);
/*  584 */       setBlock(Blocks.field_150350_a, 0, 1 - i, 0, 2);
/*  585 */       setBlock(ModBlocks.darkForcestoneStairs, 3, 1 - i, 0, 1);
/*      */       
/*  587 */       for (int j = 0; j < 3; j++) {
/*      */         
/*  589 */         setBlock(Blocks.field_150350_a, 0, 5 + i, j, 11);
/*  590 */         setBlock(Blocks.field_150350_a, 0, -11, j, 7 - i);
/*      */       } 
/*      */       
/*  593 */       setBlock(Blocks.field_150350_a, 0, 5 + i, 0, 10);
/*  594 */       setBlock(Blocks.field_150350_a, 0, -10, 0, 7 - i);
/*      */     } 
/*      */     
/*  597 */     for (i = 0; i < 4; i++) {
/*      */       
/*  599 */       setBlock(ModBlocks.darkForcestone, 2, 2, 1 + i, 1);
/*  600 */       setBlock(ModBlocks.darkForcestone, 2, -2, 1 + i, 1);
/*  601 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 2, i, 2);
/*  602 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -2, i, 2);
/*  603 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 8, i, 10);
/*  604 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 4, i, 10);
/*  605 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -10, i, 8);
/*  606 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -10, i, 4);
/*      */     } 
/*      */     
/*  609 */     generateStatue(10, 0, 6, 1, true);
/*  610 */     generateStatue(-8, 0, 10, 2, true);
/*  611 */     generateStatue(-8, 0, 2, 0, true);
/*      */     
/*  613 */     setBlock(ModBlocks.darkForcestoneStairs, 4, -7, 3, 2);
/*  614 */     setBlock(ModBlocks.darkForcestoneStairs, 5, -9, 3, 2);
/*  615 */     setBlock(ModBlocks.darkForcestoneStairs, 7, -10, 3, 2);
/*  616 */     setBlock(ModBlocks.darkForcestoneStairs, 4, -7, 3, 10);
/*  617 */     setBlock(ModBlocks.darkForcestoneStairs, 5, -9, 3, 10);
/*  618 */     setBlock(ModBlocks.darkForcestoneStairs, 6, -10, 3, 10);
/*  619 */     setBlock(ModBlocks.darkForcestoneStairs, 7, 10, 3, 5);
/*  620 */     setBlock(ModBlocks.darkForcestoneStairs, 6, 10, 3, 7);
/*  621 */     setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 3, 2);
/*  622 */     setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 3, 2);
/*  623 */     setBlock(ModBlocks.darkForcestoneStairs, 1, 3, 0, 2);
/*  624 */     setBlock(ModBlocks.darkForcestoneStairs, 0, -3, 0, 2);
/*  625 */     setBlock(ModBlocks.darkForcestoneStairs, 4, 7, 3, 10);
/*  626 */     setBlock(ModBlocks.darkForcestoneStairs, 5, 5, 3, 10);
/*  627 */     setBlock(ModBlocks.darkForcestoneStairs, 4, 7, 2, 11);
/*  628 */     setBlock(ModBlocks.darkForcestoneStairs, 5, 5, 2, 11);
/*  629 */     setBlock(ModBlocks.darkForcestoneStairs, 6, -10, 3, 7);
/*  630 */     setBlock(ModBlocks.darkForcestoneStairs, 7, -10, 3, 5);
/*  631 */     setBlock(ModBlocks.darkForcestoneStairs, 6, -11, 2, 7);
/*  632 */     setBlock(ModBlocks.darkForcestoneStairs, 7, -11, 2, 5);
/*      */     
/*  634 */     this.xCoord += 6;
/*  635 */     this.zCoord += 11;
/*      */   }
/*      */   
/*      */   private void generateAnnex(Random random) {
/*      */     int i;
/*  640 */     for (i = 0; i < 15; i++) {
/*      */       
/*  642 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  644 */         for (int k = 0; k < 9; k++) {
/*      */           
/*  646 */           if (j == 6) {
/*      */             
/*  648 */             setBlock(ModBlocks.darkForcestone, 0, i - 9, j - 1, 2 + k);
/*      */           }
/*      */           else {
/*      */             
/*  652 */             setBlock((i == 0 || i == 14 || j == 0 || j == 5 || k == 0 || k == 8) ? ModBlocks.darkForcestone : Blocks.field_150350_a, (j == 2) ? 1 : 0, i - 9, j - 1, 2 + k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  658 */     for (i = 0; i < 5; i++) {
/*      */       
/*  660 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  662 */         for (int k = 0; k < 2; k++)
/*      */         {
/*  664 */           setBlock((i == 0 || i == 4 || j == 0 || j == 4) ? ModBlocks.darkForcestone : Blocks.field_150350_a, 0, 2 - i, j - 1, k + 1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  669 */     for (i = 0; i < 13; i++) {
/*      */       
/*  671 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  673 */         if (i == 0 || i == 12 || j == 0 || j == 6) {
/*      */           
/*  675 */           int k = (i == 0) ? 1 : ((i == 12) ? 0 : ((j == 0) ? 3 : 2));
/*  676 */           setBlock((i == 0 || i == 12 || j == 0 || j == 6) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k, i - 8, 0, 3 + j);
/*  677 */           setBlock((i == 0 || i == 12 || j == 0 || j == 6) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k - 4, i - 8, 3, 3 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  682 */     for (i = 0; i < 11; i++) {
/*      */       
/*  684 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  686 */         if (i == 0 || i == 10 || j == 0 || j == 4) {
/*      */           
/*  688 */           int k = (i == 0) ? 1 : ((i == 10) ? 0 : ((j == 0) ? 3 : 2));
/*  689 */           setBlock((i == 0 || i == 10 || j == 0 || j == 4) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k - 4, i - 7, 4, 4 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  694 */     for (i = 0; i < 9; i++) {
/*      */       
/*  696 */       for (int j = 0; j < 3; j++) {
/*      */         
/*  698 */         if (i == 0 || i == 8 || j == 0 || j == 2) {
/*      */           
/*  700 */           int k = (i == 0) ? 0 : ((i == 8) ? 1 : ((j == 0) ? 2 : 3));
/*  701 */           setBlock((i == 0 || i == 8 || j == 0 || j == 2) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k - 4, i - 6, 4, 5 + j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  706 */     for (i = 0; i < 2; i++) {
/*      */       
/*  708 */       setBlock(ModBlocks.darkForcestone, 2, 2, i, 2);
/*  709 */       setBlock(ModBlocks.darkForcestone, 2, -2, i, 2);
/*  710 */       setBlock(ModBlocks.darkForcestoneStairs, 4, 1, 2, 1 + i);
/*  711 */       setBlock(ModBlocks.darkForcestoneStairs, 5, -1, 2, 1 + i);
/*      */     } 
/*      */     
/*  714 */     for (i = 0; i < 3; i++) {
/*      */       
/*  716 */       setBlock(Blocks.field_150350_a, 0, 1 - i, 0, 3);
/*  717 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 2, i, 3);
/*  718 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -2, i, 3);
/*  719 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 4, i, 5);
/*  720 */       setBlock(ModBlocks.darkActivatedForcestone, 0, 4, i, 7);
/*  721 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -8, i, 5);
/*  722 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -8, i, 7);
/*      */       
/*  724 */       setBlock(ModBlocks.darkForcestone, 1, 4, 3, 5 + i);
/*  725 */       setBlock(ModBlocks.darkForcestone, 1, -8, 3, 5 + i);
/*      */     } 
/*      */     
/*  728 */     for (i = 0; i < 5; i++)
/*      */     {
/*  730 */       setBlock(ModBlocks.darkForcestone, 0, 2 - i, 3, 3);
/*      */     }
/*      */     
/*  733 */     setBlock(ModBlocks.darkForcestoneStairs, 6, 4, 3, 4);
/*  734 */     setBlock(ModBlocks.darkForcestoneStairs, 7, 4, 3, 8);
/*  735 */     setBlock(ModBlocks.darkForcestoneStairs, 6, -8, 3, 4);
/*  736 */     setBlock(ModBlocks.darkForcestoneStairs, 7, -8, 3, 8);
/*      */     
/*  738 */     generateStructureChestContents(random, 4, 0, 6, ChestGenHooks.getItems("sithTombAnnex", random), ChestGenHooks.getCount("sithTombAnnex", random));
/*  739 */     generateStructureChestContents(random, -8, 0, 6, ChestGenHooks.getItems("sithTombAnnex", random), ChestGenHooks.getCount("sithTombAnnex", random));
/*      */   }
/*      */   
/*      */   private void generateBurialChamber(Random random) {
/*      */     int i;
/*  744 */     for (i = 0; i < 5; i++) {
/*      */       
/*  746 */       for (int j = 0; j < 5; j++)
/*      */       {
/*  748 */         setBlock((i == 0 || i == 4 || j == 0 || j == 4) ? ModBlocks.darkForcestone : Blocks.field_150350_a, 0, -1, i - 1, 2 - j);
/*      */       }
/*      */     } 
/*      */     
/*  752 */     for (i = 0; i < 19; i++) {
/*      */       
/*  754 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  756 */         for (int k = 0; k < 13; k++)
/*      */         {
/*  758 */           setBlock((i == 0 || i == 18 || j == 0 || j == 6 || k == 0 || k == 12) ? ModBlocks.darkForcestone : Blocks.field_150350_a, (j == 2) ? 1 : 0, -i - 2, j - 1, 6 - k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  763 */     for (i = 0; i < 17; i++) {
/*      */       
/*  765 */       for (int j = 0; j < 11; j++) {
/*      */         
/*  767 */         if (i == 0 || i == 16 || j == 0 || j == 10) {
/*      */           
/*  769 */           int k = (i == 0) ? 0 : ((i == 16) ? 1 : ((j == 0) ? 2 : 3));
/*  770 */           setBlock((i == 0 || i == 16 || j == 0 || j == 10) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k, -i - 3, 0, 5 - j);
/*  771 */           setBlock((i == 0 || i == 16 || j == 0 || j == 10) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k + 4, -i - 3, 5, 5 - j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  776 */     for (i = 0; i < 7; i++) {
/*      */       
/*  778 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  780 */         if (i == 0 || i == 6 || j == 0 || j == 4) {
/*      */           
/*  782 */           int k = (i == 0) ? 1 : ((i == 6) ? 0 : ((j == 0) ? 3 : 2));
/*  783 */           setBlock((i == 0 || i == 6 || j == 0 || j == 4) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k, -i - 5, -1, 2 - j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  788 */     for (i = 0; i < 12; i++) {
/*      */       
/*  790 */       for (int j = 0; j < 7; j++) {
/*      */         
/*  792 */         if (i == 0 || i == 11 || j == 0 || j == 6) {
/*      */           
/*  794 */           int k = (i == 0) ? 1 : ((i == 11) ? 0 : ((j == 0) ? 3 : 2));
/*  795 */           setBlock((i == 0 || i == 11 || j == 0 || j == 6) ? ModBlocks.darkForcestoneStairs : Blocks.field_150350_a, k + 4, -i - 6, 5, 3 - j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  800 */     for (i = 0; i < 3; i++) {
/*      */       
/*  802 */       setBlock(ModBlocks.darkForcestone, 1, -3, 4, 1 - i);
/*  803 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 6 : ((i == 2) ? 7 : 4), -3, 3, 1 - i);
/*  804 */       setBlock(ModBlocks.darkForcestone, 0, -14, 0, 1 - i);
/*  805 */       setBlock((Block)ModBlocks.forcestoneSlab, 1, -18 + i, 0, 4);
/*  806 */       setBlock((Block)ModBlocks.forcestoneSlab, 1, -18 + i, 0, -4);
/*  807 */       setBlock((Block)ModBlocks.forcestoneSlab, 1, -13, 0, 1 - i);
/*      */       int j;
/*  809 */       for (j = 0; j < 2; j++) {
/*      */         
/*  811 */         setBlock(ModBlocks.darkForcestone, 1, -2, 2 + i, 3 + j);
/*  812 */         setBlock(ModBlocks.darkForcestone, 1, -2, 2 + i, -4 + j);
/*  813 */         setBlock(ModBlocks.darkForcestone, 1, -15 + i, 2 + j, -6);
/*      */       } 
/*      */       
/*  816 */       for (j = 0; j < 3; j++)
/*      */       {
/*  818 */         setBlock(Blocks.field_150350_a, 0, -2, i, 1 - j);
/*      */       }
/*      */       
/*  821 */       setBlock(Blocks.field_150350_a, 0, -3, 0, 1 - i);
/*      */     } 
/*      */     
/*  824 */     for (i = 0; i < 4; i++) {
/*      */       
/*  826 */       for (int j = 0; j < 7; j++)
/*      */       {
/*  828 */         setBlock(ModBlocks.darkForcestone, 0, -19 + i, 0, 3 - j);
/*      */       }
/*      */     } 
/*      */     
/*  832 */     for (i = 0; i < 5; i++) {
/*      */       
/*  834 */       setBlock(ModBlocks.darkForcestone, 0, -3, 5, 2 - i);
/*  835 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -3, i, 2);
/*  836 */       setBlock(ModBlocks.darkActivatedForcestone, 0, -3, i, -2);
/*  837 */       setBlock(ModBlocks.darkForcestoneStairs, 4, -4, 5, 2 - i);
/*  838 */       setBlock(ModBlocks.darkForcestone, 0, -15, 0, 2 - i);
/*  839 */       setBlock((i == 4) ? ModBlocks.darkForcestone : ModBlocks.darkActivatedForcestone, 0, -19, 1 + i, 3);
/*  840 */       setBlock((i == 4) ? ModBlocks.darkForcestone : ModBlocks.darkActivatedForcestone, 0, -19, 1 + i, -3);
/*      */       
/*  842 */       for (int j = 0; j < 3; j++)
/*      */       {
/*  844 */         setBlock(ModBlocks.darkForcestone, 1, -20, 2 + j, 2 - i);
/*      */       }
/*      */     } 
/*      */     
/*  848 */     for (i = 0; i < 6; i++) {
/*      */       
/*  850 */       setBlock(ModBlocks.darkForcestone, 2, -3, i, 5);
/*  851 */       setBlock(ModBlocks.darkForcestone, 2, -3, i, -5);
/*  852 */       setBlock(ModBlocks.darkForcestone, 2, -19, i, 5);
/*  853 */       setBlock(ModBlocks.darkForcestone, 2, -19, i, -5);
/*      */     } 
/*      */     
/*  856 */     for (i = 0; i < 2; i++) {
/*      */       
/*  858 */       setBlock(ModBlocks.darkForcestoneStairs, 6, -1 - i, 2, 1);
/*  859 */       setBlock(ModBlocks.darkForcestoneStairs, 7, -1 - i, 2, -1);
/*      */     } 
/*      */     
/*  862 */     generateStatue(-6, 0, 5, 2, true);
/*  863 */     generateStatue(-10, 0, 5, 2, true);
/*  864 */     generateStatue(-14, 0, 5, 2, true);
/*  865 */     generateStatue(-6, 0, -5, 0, true);
/*  866 */     generateStatue(-10, 0, -5, 0, true);
/*  867 */     generateStatue(-14, 0, -5, 0, true);
/*  868 */     generateStatue(-19, 1, 0, 3, true);
/*      */     
/*  870 */     setBlock(ModBlocks.darkForcestoneStairs, 6, -19, 5, 2);
/*  871 */     setBlock(ModBlocks.darkForcestoneStairs, 7, -19, 5, -2);
/*  872 */     setBlock((Block)ModBlocks.forcestoneSlab, 1, -15, 0, 3);
/*  873 */     setBlock((Block)ModBlocks.forcestoneSlab, 1, -14, 0, 2);
/*  874 */     setBlock((Block)ModBlocks.forcestoneSlab, 1, -15, 0, -3);
/*  875 */     setBlock((Block)ModBlocks.forcestoneSlab, 1, -14, 0, -2);
/*      */     
/*  877 */     for (i = 0; i < 5; i++) {
/*      */       
/*  879 */       if (i == 0 || i == 3) {
/*      */         
/*  881 */         setBlock(Blocks.field_150406_ce, 14, -6 - i, -1, 0);
/*      */       }
/*      */       else {
/*      */         
/*  885 */         setBlock(Blocks.field_150406_ce, 14, -6 - i, -1, 1);
/*  886 */         setBlock(Blocks.field_150406_ce, 14, -6 - i, -1, -1);
/*      */       } 
/*      */     } 
/*      */     
/*  890 */     setBlock(ModBlocks.sithCoffin, 1, -15, 1, 0);
/*  891 */     setBlock(ModBlocks.sithCoffin, 9, -16, 1, 0);
/*  892 */     fillStructureInventory(ModBlocks.sithCoffin, random, -15, 1, 0, ChestGenHooks.getItems("sithTombCoffin", random), ChestGenHooks.getCount("sithTombCoffin", random));
/*      */     
/*  894 */     this.xCoord -= 14;
/*  895 */     this.yCoord++;
/*  896 */     this.zCoord -= 6;
/*      */   }
/*      */   
/*      */   private void generateTreasury(Random random) {
/*      */     int i;
/*  901 */     for (i = 0; i < 5; i++) {
/*      */       
/*  903 */       for (int j = 0; j < 5; j++) {
/*      */         
/*  905 */         for (int k = 0; k < 3; k++)
/*      */         {
/*  907 */           setBlock((i == 0 || i == 4 || j == 0 || j == 4) ? ModBlocks.darkForcestone : Blocks.field_150350_a, (i == 0 || i == 4) ? ((k == 1) ? 0 : 2) : 0, 2 - i, j - 1, -k - 1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  912 */     for (i = 0; i < 11; i++) {
/*      */       
/*  914 */       for (int j = 0; j < 6; j++) {
/*      */         
/*  916 */         for (int k = 0; k < 9; k++)
/*      */         {
/*  918 */           setBlock(ModBlocks.darkForcestone, 0, 5 - i, j - 1, -4 - k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  923 */     for (i = 0; i < 5; i++) {
/*      */       
/*  925 */       for (int j = 0; j < 4; j++) {
/*      */         
/*  927 */         for (int k = 0; k < 7; k++)
/*      */         {
/*  929 */           setBlock(Blocks.field_150350_a, 0, 2 - i, j, -4 - k);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  934 */     for (i = 0; i < 3; i++) {
/*      */       
/*  936 */       setBlock(ModBlocks.darkForcestoneStairs, 1, 1, 0, -6 - i);
/*  937 */       setBlock(ModBlocks.darkForcestoneStairs, 0, -1, 0, -6 - i);
/*  938 */       setBlock(ModBlocks.darkForcestoneStairs, 4, 4, 4, -6 - i);
/*  939 */       setBlock(ModBlocks.darkForcestoneStairs, 5, -4, 4, -6 - i);
/*  940 */       setBlock(ModBlocks.darkForcestoneStairs, 7, 1 - i, 4, -11);
/*      */       
/*  942 */       for (int j = 0; j < 4; j++) {
/*      */         
/*  944 */         setBlock(Blocks.field_150350_a, 0, 1 - i, j, -11);
/*      */         
/*  946 */         for (int k = 0; k < 2; k++) {
/*      */           
/*  948 */           setBlock(Blocks.field_150350_a, 0, 3 + k, j, -6 - i);
/*  949 */           setBlock(Blocks.field_150350_a, 0, -3 - k, j, -6 - i);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  954 */     for (i = 0; i < 2; i++) {
/*      */       
/*  956 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : 2, 3, 0, -6 - i * 2);
/*  957 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 3 : 2, -3, 0, -6 - i * 2);
/*  958 */       setBlock(ModBlocks.darkForcestoneStairs, (i == 0) ? 1 : 0, 1 - i * 2, 0, -10);
/*      */     } 
/*      */     
/*  961 */     for (i = 0; i < 4; i++) {
/*      */       
/*  963 */       setBlock(ModBlocks.darkActivatedForcestone, 2, 2, i, -4);
/*  964 */       setBlock(ModBlocks.darkActivatedForcestone, 2, -2, i, -4);
/*  965 */       setBlock(ModBlocks.darkActivatedForcestone, 2, 2, i, -10);
/*  966 */       setBlock(ModBlocks.darkActivatedForcestone, 2, -2, i, -10);
/*  967 */       setBlock(ModBlocks.darkActivatedForcestone, 2, 3, i, -5);
/*  968 */       setBlock(ModBlocks.darkActivatedForcestone, 2, -3, i, -5);
/*  969 */       setBlock(ModBlocks.darkActivatedForcestone, 2, 3, i, -9);
/*  970 */       setBlock(ModBlocks.darkActivatedForcestone, 2, -3, i, -9);
/*      */     } 
/*      */     
/*  973 */     generateStatue(0, 0, -11, 0, false);
/*  974 */     generateStatue(4, 0, -7, 1, false);
/*  975 */     generateStatue(-4, 0, -7, 3, false);
/*      */     
/*  977 */     setBlock(ModBlocks.darkForcestoneStairs, 3, 0, 0, -6);
/*  978 */     setBlock(ModBlocks.darkForcestoneStairs, 2, 0, 0, -8);
/*  979 */     setBlock(Blocks.field_150451_bX, 0, 0, 0, -7);
/*      */     
/*  981 */     if (random.nextBoolean())
/*      */     {
/*  983 */       setBlock(ModBlocks.holocron, 1, 0, 1, -7);
/*      */     }
/*      */     
/*  986 */     generateStructureChestContents(random, 0, 0, -10, ChestGenHooks.getItems("sithTombTreasury", random), ChestGenHooks.getCount("sithTombTreasury", random));
/*  987 */     generateStructureChestContents(random, 3, 0, -7, ChestGenHooks.getItems("sithTombTreasury", random), ChestGenHooks.getCount("sithTombTreasury", random));
/*  988 */     generateStructureChestContents(random, -3, 0, -7, ChestGenHooks.getItems("sithTombTreasury", random), ChestGenHooks.getCount("sithTombTreasury", random));
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateStatue(int x, int y, int z, int rotation, boolean foot) {
/*  993 */     if (rotation % 2 == 0) {
/*      */       
/*  995 */       setBlock(ModBlocks.darkForcestone, 2, x, y + 1, z);
/*  996 */       setBlock(ModBlocks.darkForcestone, 1, x, y + 2, z);
/*  997 */       setBlock(ModBlocks.darkForcestoneStairs, 5, x + 1, y + 2, z);
/*  998 */       setBlock(ModBlocks.darkForcestoneStairs, 4, x - 1, y + 2, z);
/*  999 */       setBlock(Blocks.field_150451_bX, 0, x, y + 3, z);
/*      */       
/* 1001 */       if (foot) {
/*      */         
/* 1003 */         setBlock(ModBlocks.darkForcestone, 0, x, y, z);
/*      */         
/* 1005 */         if (rotation == 2)
/*      */         {
/* 1007 */           setBlock(ModBlocks.darkForcestoneStairs, 2, x, y, z - 1);
/*      */         }
/*      */         else
/*      */         {
/* 1011 */           setBlock(ModBlocks.darkForcestoneStairs, 3, x, y, z + 1);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1016 */         setBlock(ModBlocks.darkForcestone, 2, x, y, z);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1021 */       setBlock(ModBlocks.darkForcestone, 2, x, y + 1, z);
/* 1022 */       setBlock(ModBlocks.darkForcestone, 1, x, y + 2, z);
/* 1023 */       setBlock(ModBlocks.darkForcestoneStairs, 7, x, y + 2, z + 1);
/* 1024 */       setBlock(ModBlocks.darkForcestoneStairs, 6, x, y + 2, z - 1);
/* 1025 */       setBlock(Blocks.field_150451_bX, 0, x, y + 3, z);
/*      */       
/* 1027 */       if (foot) {
/*      */         
/* 1029 */         setBlock(ModBlocks.darkForcestone, 0, x, y, z);
/*      */         
/* 1031 */         if (rotation == 1)
/*      */         {
/* 1033 */           setBlock(ModBlocks.darkForcestoneStairs, 0, x - 1, y, z);
/*      */         }
/*      */         else
/*      */         {
/* 1037 */           setBlock(ModBlocks.darkForcestoneStairs, 1, x + 1, y, z);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1042 */         setBlock(ModBlocks.darkForcestone, 2, x, y, z);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateCoffin(int x, int y, int z, int rotation, int coffinX, int coffinY, int coffinZ) {
/* 1049 */     setBlock(ModBlocks.sithStoneCoffin, rotation, x, y, z);
/* 1050 */     setBlock(ModBlocks.sithStoneCoffin, rotation + 8, x, y + 1, z);
/*      */     
/* 1052 */     TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)this.worldObj.func_147438_o(this.xCoord + x, this.yCoord + y, this.zCoord + z);
/* 1053 */     TileEntitySithCoffin tile1 = (TileEntitySithCoffin)this.worldObj.func_147438_o(this.xCoord + coffinX, this.yCoord + coffinY, this.zCoord + coffinZ);
/*      */     
/* 1055 */     if (tile != null && tile1 != null)
/*      */     {
/* 1057 */       tile.mainCoffin = tile1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\StructureSithTomb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */