/*     */ package com.fiskmods.lightsabers.common.generator.structure;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.BiomeGenBase;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructureJediTemple
/*     */   extends Structure
/*     */ {
/*     */   private final float ruination;
/*     */   private Random rand;
/*     */   
/*     */   public StructureJediTemple(float ruin, World world, int x, int y, int z) {
/*  26 */     super(world, x, y, z);
/*  27 */     this.ruination = ruin;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void placeBlock(int x, int y, int z, Block block, int metadata, int flags) {
/*  33 */     if (this.ruination > 0.0F) {
/*     */       
/*  35 */       if (block == Blocks.field_150362_t || block == Blocks.field_150355_j) {
/*     */         return;
/*     */       }
/*     */       
/*  39 */       if (block.func_149688_o() == Material.field_151592_s && this.rand.nextFloat() * this.rand.nextFloat() <= this.ruination) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  44 */       if (block == ModBlocks.lightForcestone && metadata == 0 && this.rand.nextFloat() < this.ruination) {
/*     */         
/*  46 */         if (this.rand.nextBoolean())
/*     */         {
/*  48 */           super.placeBlock(x, y, z, (Block)ModBlocks.forcestoneSlab, this.rand.nextBoolean() ? 0 : 8, flags);
/*     */         }
/*     */         else
/*     */         {
/*  52 */           super.placeBlock(x, y, z, ModBlocks.lightForcestoneStairs, this.rand.nextInt(8), flags);
/*     */         }
/*     */       
/*  55 */       } else if (block == ModBlocks.lightForcestoneStairs && this.rand.nextFloat() < this.ruination) {
/*     */         
/*  57 */         super.placeBlock(x, y, z, (Block)ModBlocks.forcestoneSlab, ((metadata & 0x4) == 0) ? 0 : 8, flags);
/*     */       }
/*  59 */       else if (block == Blocks.field_150344_f && metadata == 4 && this.rand.nextFloat() < this.ruination) {
/*     */         
/*  61 */         if (this.rand.nextBoolean())
/*     */         {
/*  63 */           super.placeBlock(x, y, z, (Block)Blocks.field_150376_bx, this.rand.nextBoolean() ? 4 : 12, flags);
/*     */         }
/*     */         else
/*     */         {
/*  67 */           super.placeBlock(x, y, z, Blocks.field_150400_ck, this.rand.nextInt(8), flags);
/*     */         }
/*     */       
/*  70 */       } else if (block == Blocks.field_150355_j || block == Blocks.field_150406_ce || block.hasTileEntity(metadata) || this.rand.nextFloat() * 4.0F >= this.ruination * this.ruination) {
/*     */         
/*  72 */         super.placeBlock(x, y, z, block, metadata, flags);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  77 */       super.placeBlock(x, y, z, block, metadata, flags);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void spawnStructure(Random random) {
/*  84 */     BiomeGenBase biome = this.worldObj.func_72807_a(this.xCoord, this.zCoord);
/*  85 */     Block topBlock = biome.field_76752_A;
/*  86 */     Block fillerBlock = biome.field_76753_B;
/*  87 */     int topBlockMeta = biome.field_150604_aj;
/*     */     
/*  89 */     this.mirrorX = true;
/*  90 */     this.rand = random;
/*     */     
/*  92 */     for (int layer = 0; layer < 2; layer++) {
/*     */       
/*  94 */       this.simulate = (layer == 0);
/*     */       
/*  96 */       setBlock(Blocks.field_150344_f, 4, 5, 0, 13);
/*  97 */       setBlock(Blocks.field_150344_f, 4, 5, 0, 21);
/*  98 */       setBlock(ModBlocks.lightForcestoneStairs, 2, 3, 8, 7);
/*  99 */       setBlock(ModBlocks.lightForcestone, 0, 2, 1, 26);
/* 100 */       setBlock((Block)ModBlocks.forcestoneSlab, 0, 2, 3, 26);
/* 101 */       setBlock(ModBlocks.lightForcestone, 0, 2, 3, 28);
/*     */       int i;
/* 103 */       for (i = 0; i < 2; i++) {
/*     */         
/* 105 */         setBlock(ModBlocks.lightForcestone, 0, i, 0, 3);
/* 106 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 2 + i, 0, 3 + i);
/* 107 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 3 + i, 0, 3 + i);
/* 108 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 3 + i, 0, 2 + i);
/* 109 */         setBlock(ModBlocks.lightForcestone, 0, i, 5, 7);
/* 110 */         setBlock(Blocks.field_150344_f, 4, 4 + i, 0, 12);
/* 111 */         setBlock(Blocks.field_150344_f, 4, 4 + i, 0, 22);
/* 112 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 3 + i, 1, 24);
/* 113 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 2, 3 + i, 27 + i);
/* 114 */         setBlock(ModBlocks.lightForcestone, 4, 2, 1, 27 + i);
/* 115 */         setBlock(ModBlocks.lightForcestone, 0, 3 + i, 3, 29);
/* 116 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, i, 5, 29);
/* 117 */         setBlock(ModBlocks.lightForcestoneStairs, 2, i, 4, 31);
/*     */         int j;
/* 119 */         for (j = 0; j < 2; j++) {
/*     */           
/* 121 */           setBlock(ModBlocks.lightForcestone, 0, 3 + i, 2, 28 + j);
/* 122 */           setBlock((Block)ModBlocks.forcestoneSlab, 0, i, 4, 29 + j);
/*     */         } 
/*     */         
/* 125 */         for (j = 0; j < 3; j++) {
/*     */           
/* 127 */           setBlock((Block)Blocks.field_150397_co, 3, i, 6 + j, 7);
/* 128 */           setBlock(ModBlocks.lightForcestone, 0, 3 + i, 1, 27 + j);
/*     */         } 
/*     */       } 
/*     */       
/* 132 */       for (i = 0; i < 3; i++) {
/*     */         
/* 134 */         setBlock(ModBlocks.lightForcestone, 0, i, 0, 4);
/* 135 */         setBlock(ModBlocks.lightForcestone, 1, i, 4, 7);
/* 136 */         setBlock(ModBlocks.lightForcestoneStairs, 2, i, 0, 2);
/* 137 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 4, 0, 5 + i);
/* 138 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, i, 0, 1);
/* 139 */         setBlock(ModBlocks.lightActivatedForcestone, 0, 3, 1 + i, 7);
/* 140 */         setBlock((Block)Blocks.field_150397_co, 3, 2, 1 + i, 7);
/* 141 */         setBlock((Block)Blocks.field_150397_co, 3, 0, 9 + i, 7);
/* 142 */         setBlock(Blocks.field_150344_f, 4, 3 + i, 0, 11);
/* 143 */         setBlock(Blocks.field_150344_f, 4, 2 + i, 0, 23);
/* 144 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 2 + i, 1, 25);
/* 145 */         setBlock(ModBlocks.lightForcestone, 1, 2, 2, 26 + i);
/*     */       } 
/*     */       
/* 148 */       for (i = 0; i < 4; i++) {
/*     */         
/* 150 */         setBlock(ModBlocks.lightForcestone, 0, 3, 4 + i, 7);
/* 151 */         setBlock(ModBlocks.lightForcestone, 0, 2, 5 + i, 7);
/* 152 */         setBlock(ModBlocks.lightActivatedForcestone, 0, 6, 1 + i, 11);
/* 153 */         setBlock(ModBlocks.lightActivatedForcestone, 0, 6, 1 + i, 22);
/*     */         int j;
/* 155 */         for (j = 0; j < 2; j++)
/*     */         {
/* 157 */           setBlock(ModBlocks.lightForcestoneStairs, 2, 3 + j, 1 + i, 26 + i);
/*     */         }
/*     */         
/* 160 */         for (j = 0; j < 3; j++) {
/*     */           
/* 162 */           setBlock(ModBlocks.lightForcestone, 0, i, 0, 5 + j);
/* 163 */           setBlock(ModBlocks.lightForcestone, 0, 2 + j, 0, 26 + i);
/*     */         } 
/*     */       } 
/*     */       
/* 167 */       for (i = 0; i < 5; i++) {
/*     */         
/* 169 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 5, 0, 4 + i);
/* 170 */         setBlock(Blocks.field_150344_f, 4, i, 0, 8);
/*     */         
/* 172 */         for (int j = 0; j < 2; j++)
/*     */         {
/* 174 */           setBlock(Blocks.field_150344_f, 4, i, 0, 24 + j);
/*     */         }
/*     */       } 
/*     */       
/* 178 */       for (i = 0; i < 6; i++) {
/*     */         
/* 180 */         for (int j = 0; j < 2; j++)
/*     */         {
/* 182 */           setBlock(Blocks.field_150344_f, 4, i, 0, 9 + j);
/*     */         }
/*     */       } 
/*     */       
/* 186 */       for (i = 0; i < 7; i++)
/*     */       {
/* 188 */         setBlock((i % 2 == 0) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, (i % 2 == 0) ? 0 : 3, 5, 0, 14 + i);
/*     */       }
/*     */       
/* 191 */       for (i = 0; i < 8; i++) {
/*     */         
/* 193 */         setBlock(ModBlocks.lightForcestone, (i == 0) ? 0 : 2, 5, i, 23);
/* 194 */         setBlock(ModBlocks.lightForcestone, 0, 2, 0, 30 + i);
/* 195 */         setBlock((i == 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 2, 1 + i, 29);
/*     */         int j;
/* 197 */         for (j = 0; j < 2; j++)
/*     */         {
/* 199 */           setBlock(ModBlocks.lightForcestone, 0, 5, i, 9 + j);
/*     */         }
/*     */         
/* 202 */         for (j = 0; j < 5; j++) {
/*     */           
/* 204 */           if (j == 4) {
/*     */             
/* 206 */             setBlock(ModBlocks.lightForcestone, 0, 5, i, 24 + j);
/*     */           }
/* 208 */           else if (j == 3) {
/*     */             
/* 210 */             setBlock((i == 3) ? Blocks.field_150344_f : ModBlocks.lightForcestone, (i == 3) ? 4 : 0, 5, i, 24 + j);
/*     */           }
/*     */           else {
/*     */             
/* 214 */             setBlock((i == 2 || i == 3) ? Blocks.field_150344_f : ModBlocks.lightForcestone, (i == 2 || i == 3) ? 4 : 0, 5, i, 24 + j);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 219 */       for (i = 0; i < 9; i++) {
/*     */         
/* 221 */         setBlock(ModBlocks.lightForcestone, 0, 4, i, 8);
/* 222 */         setBlock((i < 3 || i > 5) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, (i < 3 || i > 5) ? 0 : 3, 4, 0, 13 + i);
/* 223 */         setBlock(ModBlocks.lightForcestone, (i > 4 && i < 8) ? 2 : 0, 5, i, 29);
/* 224 */         setBlock((i == 8) ? ModBlocks.lightForcestoneStairs : ((i > 4 && i < 8) ? ModBlocks.lightActivatedForcestone : ModBlocks.lightForcestone), (i == 8) ? 2 : 0, 6, i, 29);
/*     */       } 
/*     */       
/* 227 */       for (i = 0; i < 10; i++) {
/*     */         
/* 229 */         setBlock(ModBlocks.lightForcestone, 4, 6, 1, 12 + i);
/* 230 */         setBlock(Blocks.field_150344_f, 4, 6, 2, 12 + i);
/* 231 */         setBlock(Blocks.field_150344_f, 4, 6, 3, 12 + i);
/* 232 */         setBlock(ModBlocks.lightForcestone, 0, 6, 4, 12 + i);
/*     */       } 
/*     */       
/* 235 */       for (i = 0; i < 11; i++)
/*     */       {
/* 237 */         setBlock((i < 2 || i > 8 || i == 5) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, (i < 2 || i > 8 || i == 5) ? 0 : 3, 3, 0, 12 + i);
/*     */       }
/*     */       
/* 240 */       for (i = 0; i < 12; i++) {
/*     */         
/* 242 */         setBlock(ModBlocks.lightForcestone, 0, 6, 0, 11 + i);
/* 243 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 6, 5, 11 + i);
/* 244 */         setBlock(ModBlocks.lightForcestoneStairs, 4, 5, 5, 11 + i);
/* 245 */         setBlock((Block)Blocks.field_150397_co, 3, 5, 6, 11 + i);
/* 246 */         setBlock((Block)Blocks.field_150397_co, 3, 5, 7, 11 + i);
/* 247 */         setBlock((i < 2 || i > 3) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, (i < 2 || i > 3) ? 0 : 3, 2, 0, 11 + i);
/*     */         
/* 249 */         for (int j = 0; j < 2; j++)
/*     */         {
/* 251 */           setBlock(Blocks.field_150344_f, 4, j, 0, 26 + i);
/*     */         }
/*     */       } 
/*     */       
/* 255 */       for (i = 0; i < 13; i++) {
/*     */         
/* 257 */         setBlock(((i < 1 || i > 2) && i != 5) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, ((i < 1 || i > 2) && i != 5) ? 0 : 3, 1, 0, 11 + i);
/* 258 */         setBlock((i == 0 || i == 12) ? ModBlocks.lightForcestone : Blocks.field_150406_ce, (i == 0 || i == 12) ? 0 : 3, 0, 0, 11 + i);
/*     */       } 
/*     */       
/* 261 */       for (i = 0; i < 20; i++)
/*     */       {
/* 263 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 5, 8, 9 + i);
/*     */       }
/*     */       
/* 266 */       for (i = 0; i < 21; i++)
/*     */       {
/* 268 */         setBlock(ModBlocks.lightForcestone, 0, 4, 8, 9 + i);
/*     */       }
/*     */       
/* 271 */       for (i = 0; i < 25; i++)
/*     */       {
/* 273 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, 3, 8, 8 + i);
/*     */       }
/*     */       
/* 276 */       for (i = 0; i < 28; i++) {
/*     */         
/* 278 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 0, 13, 7 + i);
/* 279 */         setBlock((i == 0 || i == 27) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, (i == 0 || i == 27) ? 0 : 8, 0, 12, 7 + i);
/* 280 */         setBlock((i == 0 || i == 27) ? ModBlocks.lightForcestone : ModBlocks.lightForcestoneStairs, (i == 0 || i == 27) ? 0 : 4, 1, 9, 7 + i);
/* 281 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 1, 12, 7 + i);
/* 282 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 2, 9, 7 + i);
/*     */         
/* 284 */         for (int j = 0; j < 2; j++)
/*     */         {
/* 286 */           setBlock(ModBlocks.lightForcestone, 0, 1, 10 + j, 7 + i);
/*     */         }
/*     */       } 
/*     */       
/* 290 */       this.zCoord += 30;
/*     */       
/* 292 */       setBlock(ModBlocks.lightForcestone, 0, 2, 0, 12);
/* 293 */       setBlock(ModBlocks.lightForcestone, 0, 2, 0, 16);
/* 294 */       setBlock((Block)ModBlocks.forcestoneSlab, 0, 2, 1, 12);
/* 295 */       setBlock((Block)ModBlocks.forcestoneSlab, 0, 2, 1, 16);
/* 296 */       setBlock(ModBlocks.lightActivatedForcestone, 0, 0, 1, 11);
/* 297 */       setBlock(ModBlocks.lightActivatedForcestone, 0, 0, 1, 17);
/* 298 */       setBlock(ModBlocks.lightActivatedForcestone, 0, 3, 1, 14);
/* 299 */       setBlock(ModBlocks.lightForcestoneStairs, 7, 2, 4, 4);
/* 300 */       setBlock(ModBlocks.lightForcestoneStairs, 6, 2, 4, 24);
/* 301 */       setBlock(ModBlocks.lightForcestoneStairs, 5, 1, 8, 28);
/* 302 */       setBlock((Block)ModBlocks.forcestoneSlab, 8, 0, 7, 28);
/* 303 */       setBlock(ModBlocks.lightForcestoneStairs, 6, 14, 8, 13);
/* 304 */       setBlock(ModBlocks.lightForcestoneStairs, 7, 14, 8, 15);
/* 305 */       setBlock((Block)ModBlocks.forcestoneSlab, 8, 14, 7, 14);
/*     */       
/* 307 */       for (i = 0; i < 2; i++) {
/*     */         
/* 309 */         int y = i * 4;
/*     */         int j;
/* 311 */         for (j = 0; j < 2; j++) {
/*     */           
/* 313 */           setBlock(ModBlocks.lightForcestone, j, i, 4, 2 + j);
/* 314 */           setBlock((Block)ModBlocks.forcestoneSlab, 0, 2, 1, 4 + i * 3 + j * 17);
/* 315 */           setBlock((Block)ModBlocks.forcestoneSlab, 0, 7 + i * 3, 1, 12 + j * 4);
/* 316 */           setBlock(ModBlocks.lightForcestone, 1, 13 + i, 3, 12 + j * 4);
/* 317 */           setBlock(ModBlocks.lightActivatedForcestone, 0, 16 + i * 10, 1 + j, 9);
/* 318 */           setBlock(ModBlocks.lightActivatedForcestone, 0, 16 + i * 10, 1 + j, 19);
/* 319 */           setBlock(ModBlocks.lightActivatedForcestone, 0, 5, 1 + i, 30 + j * 10);
/* 320 */           setBlock(fillerBlock, 0, 6 + i, -2, 7 + j);
/* 321 */           setBlock(fillerBlock, 0, 6 + i, -2, 20 + j);
/* 322 */           setBlock(Blocks.field_150355_j, 0, 6 + i, -1, 7 + j);
/* 323 */           setBlock(Blocks.field_150355_j, 0, 6 + i, -1, 20 + j);
/* 324 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 10 + i, 8, 3 + j);
/* 325 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 10 + i, 8, 24 + j);
/*     */         } 
/*     */         
/* 328 */         for (j = 0; j < 3; j++) {
/*     */           
/* 330 */           setBlock(Blocks.field_150344_f, 4, 6, y, j);
/* 331 */           setBlock(Blocks.field_150344_f, 4, 7, y, 1 + j);
/* 332 */           setBlock(Blocks.field_150344_f, 4, 8, y, 1 + j);
/* 333 */           setBlock(Blocks.field_150344_f, 4, 9, y, 2 + j);
/* 334 */           setBlock(Blocks.field_150344_f, 4, 10, y, 3 + j);
/* 335 */           setBlock(Blocks.field_150344_f, 4, 6, y, -j + 28);
/* 336 */           setBlock(Blocks.field_150344_f, 4, 7, y, -(1 + j) + 28);
/* 337 */           setBlock(Blocks.field_150344_f, 4, 8, y, -(1 + j) + 28);
/* 338 */           setBlock(Blocks.field_150344_f, 4, 9, y, -(2 + j) + 28);
/* 339 */           setBlock(Blocks.field_150344_f, 4, 10, y, -(3 + j) + 28);
/* 340 */           setBlock(Blocks.field_150344_f, 4, 14 + i, 0, 13 + j);
/* 341 */           setBlock(ModBlocks.lightForcestone, 0, 12, 1 + j, 12 + i * 4);
/* 342 */           setBlock((Block)Blocks.field_150397_co, 3, i, 6 + j, 4);
/* 343 */           setBlock((Block)Blocks.field_150397_co, 3, i, 6 + j, 24);
/* 344 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 7 + i, 8, 1 + j);
/* 345 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 7 + i, 8, 25 + j);
/* 346 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 11 + j, 8, 6 + i);
/* 347 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 11 + j, 8, 21 + i);
/*     */         } 
/*     */         
/* 350 */         for (j = 0; j < 4; j++) {
/*     */           
/* 352 */           setBlock(Blocks.field_150344_f, 4, 14, y, 8 + j);
/* 353 */           setBlock(Blocks.field_150344_f, 4, 14, y, 17 + j);
/* 354 */           setBlock(ModBlocks.lightForcestone, 0, 7 + j, 0, 12 + i * 4);
/* 355 */           setBlock(ModBlocks.lightForcestone, 0, 27, j, 8 + i);
/* 356 */           setBlock(ModBlocks.lightForcestone, 0, 27, j, 19 + i);
/* 357 */           setBlock(ModBlocks.lightForcestone, 0, 5 + i, j, 41);
/* 358 */           setBlock(ModBlocks.lightForcestone, 0, 10, 5 + j, 12 + i * 4);
/*     */         } 
/*     */         
/* 361 */         for (j = 0; j < 5; j++) {
/*     */           
/* 363 */           setBlock(Blocks.field_150344_f, 4, 11, y, 3 + j);
/* 364 */           setBlock(Blocks.field_150344_f, 4, 11, y, -(3 + j) + 28);
/* 365 */           setBlock(Blocks.field_150344_f, 4, i, 0, 21 + j);
/*     */         } 
/*     */         
/* 368 */         for (j = 0; j < 6; j++)
/*     */         {
/* 370 */           setBlock(Blocks.field_150344_f, 4, j, 4, 26 + i);
/*     */         }
/*     */         
/* 373 */         for (j = 0; j < 17; j++)
/*     */         {
/* 375 */           setBlock(Blocks.field_150344_f, 4, 13, y, 6 + j);
/*     */         }
/*     */         
/* 378 */         for (j = 0; j < 19; j++)
/*     */         {
/* 380 */           setBlock(Blocks.field_150344_f, 4, 12, y, 5 + j);
/*     */         }
/*     */         
/* 383 */         setBlock(ModBlocks.lightForcestone, 1, 2, 3, i);
/* 384 */         setBlock((Block)Blocks.field_150349_c, 0, i, 0, 12);
/* 385 */         setBlock((Block)Blocks.field_150349_c, 0, i, 0, 16);
/* 386 */         setBlock(ModBlocks.lightForcestone, 0, i, 0, 11);
/* 387 */         setBlock(ModBlocks.lightForcestone, 0, i, 0, 17);
/* 388 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, i, (i == 0) ? 2 : 1, 11);
/* 389 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, i, (i == 0) ? 2 : 1, 17);
/* 390 */         setBlock(Blocks.field_150344_f, 4, 2 + i, 0, 11 + i);
/* 391 */         setBlock(Blocks.field_150344_f, 4, 2 + i, 0, 17 - i);
/* 392 */         setBlock(Blocks.field_150344_f, 4, 4, 0, 10 + i);
/* 393 */         setBlock(Blocks.field_150344_f, 4, 4, 0, 17 + i);
/* 394 */         setBlock(Blocks.field_150344_f, 4, 5, 0, 11 + i * 6);
/* 395 */         setBlock(ModBlocks.lightForcestone, 1, i, 4, 25);
/* 396 */         setBlock((Block)Blocks.field_150399_cn, 3, i, 4, 29);
/* 397 */         setBlock(Blocks.field_150344_f, 4, i, 0, 29);
/* 398 */         setBlock(ModBlocks.lightForcestone, 1, 2, 3, 27 + i);
/* 399 */         setBlock(ModBlocks.lightForcestoneStairs, 2, i * 2, 1, 40);
/* 400 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 8, 0, 6 + i * 16);
/* 401 */         setBlock(fillerBlock, 0, 5 + i, -2, 6);
/* 402 */         setBlock(fillerBlock, 0, 8, -2, 8 + i);
/* 403 */         setBlock(fillerBlock, 0, 5 + i, -2, 22);
/* 404 */         setBlock(fillerBlock, 0, 8, -2, 19 + i);
/* 405 */         setBlock(Blocks.field_150355_j, 0, 5 + i, -1, 6);
/* 406 */         setBlock(Blocks.field_150355_j, 0, 8, -1, 8 + i);
/* 407 */         setBlock(Blocks.field_150355_j, 0, 5 + i, -1, 22);
/* 408 */         setBlock(Blocks.field_150355_j, 0, 8, -1, 19 + i);
/* 409 */         setBlock(ModBlocks.lightForcestone, 0, i, 5, 4);
/* 410 */         setBlock(ModBlocks.lightForcestone, 0, i, 5, 24);
/* 411 */         setBlock(ModBlocks.lightForcestoneStairs, 4, 10, 4, 12 + i * 4);
/* 412 */         setBlock(topBlock, topBlockMeta, 4 + i, -1, 5);
/* 413 */         setBlock(topBlock, topBlockMeta, 4, -1, 6 + i);
/* 414 */         setBlock(topBlock, topBlockMeta, 5, -1, 7 + i);
/* 415 */         setBlock(topBlock, topBlockMeta, 6 + i, -1, 9);
/* 416 */         setBlock(topBlock, topBlockMeta, 7 + i, -1, 10);
/* 417 */         setBlock(topBlock, topBlockMeta, 9, -1, 10 - i);
/* 418 */         setBlock(topBlock, topBlockMeta, 4 + i, -1, 23);
/* 419 */         setBlock(topBlock, topBlockMeta, 4, -1, 21 + i);
/* 420 */         setBlock(topBlock, topBlockMeta, 5, -1, 20 + i);
/* 421 */         setBlock(topBlock, topBlockMeta, 6 + i, -1, 19);
/* 422 */         setBlock(topBlock, topBlockMeta, 7 + i, -1, 18);
/* 423 */         setBlock(topBlock, topBlockMeta, 9, -1, 18 + i);
/* 424 */         setBlock((Block)Blocks.field_150397_co, 3, 8 + i, 5, 1);
/* 425 */         setBlock((Block)Blocks.field_150397_co, 3, 13, 5, 5 + i);
/* 426 */         setBlock((Block)Blocks.field_150397_co, 3, 8 + i, 5, 27);
/* 427 */         setBlock((Block)Blocks.field_150397_co, 3, 13, 5, 22 + i);
/* 428 */         setBlock((Block)Blocks.field_150397_co, 3, 11, 5, 3 + i * 22);
/* 429 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 9, 8, 5 + i * 18);
/* 430 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, 9, 8, 2 + i);
/* 431 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, 11 + i, 8, 5);
/* 432 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, 11 + i, 8, 23);
/* 433 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, 9, 8, 25 + i);
/*     */       } 
/*     */       
/* 436 */       for (i = 0; i < 3; i++) {
/*     */         
/* 438 */         setBlock((Block)Blocks.field_150399_cn, 3, 15, 4, 13 + i);
/* 439 */         setBlock(ModBlocks.lightForcestone, 0, 2, 1 + i, 2);
/* 440 */         setBlock(ModBlocks.lightForcestone, 0, 3, 0, 13 + i);
/* 441 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 3, (i == 1) ? 2 : 1, 13 + i);
/* 442 */         setBlock(Blocks.field_150344_f, 4, 3, 0, 9 + i);
/* 443 */         setBlock(Blocks.field_150344_f, 4, 3, 0, 17 + i);
/* 444 */         setBlock(ModBlocks.lightForcestone, 0, i, 4, 28);
/* 445 */         setBlock(Blocks.field_150344_f, 4, 3 + i, 4, 28);
/* 446 */         setBlock(ModBlocks.lightForcestone, 0, 2, 1 + i, 26);
/* 447 */         setBlock(ModBlocks.lightForcestone, 1, 11, 4, 13 + i);
/* 448 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 19 + i * 2, 1, 9);
/* 449 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 19 + i * 2, 1, 19);
/* 450 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 26, 1, 12 + i * 2);
/* 451 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 5, 1, 33 + i * 2);
/* 452 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 4 + i, 0, 4);
/* 453 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 7 + i, 0, 11);
/* 454 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 0 : 3, 6 + i, 0, 5);
/* 455 */         setBlock(ModBlocks.lightForcestoneStairs, (i != 1) ? 3 : 0, 9, 0, 6 + i);
/* 456 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 4 + i, 0, 24);
/* 457 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 7 + i, 0, 17);
/* 458 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 0 : 2, 6 + i, 0, 23);
/* 459 */         setBlock(ModBlocks.lightForcestoneStairs, (i != 1) ? 2 : 0, 9, 0, 20 + i);
/* 460 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 4 + i, 0, 8 + i);
/* 461 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 4 + i, 0, 20 - i);
/* 462 */         setBlock((Block)Blocks.field_150397_co, 3, 0, 9 + i, 4);
/* 463 */         setBlock((Block)Blocks.field_150397_co, 3, 0, 9 + i, 24);
/* 464 */         setBlock(ModBlocks.lightForcestone, 0, 10, 5, 13 + i);
/* 465 */         setBlock((Block)Blocks.field_150397_co, 3, 10, 9 + i, 14);
/* 466 */         setBlock((Block)Blocks.field_150397_co, 3, 6 + i, 5, 0);
/* 467 */         setBlock((Block)Blocks.field_150397_co, 3, 9 + i, 5, 2);
/* 468 */         setBlock((Block)Blocks.field_150397_co, 3, 12, 5, 3 + i);
/* 469 */         setBlock((Block)Blocks.field_150397_co, 3, 14, 5, 6 + i);
/* 470 */         setBlock((Block)Blocks.field_150397_co, 3, 14, 5, 20 + i);
/* 471 */         setBlock((Block)Blocks.field_150397_co, 3, 12, 5, 23 + i);
/* 472 */         setBlock((Block)Blocks.field_150397_co, 3, 9 + i, 5, 26);
/* 473 */         setBlock((Block)Blocks.field_150397_co, 3, 6 + i, 5, 28);
/* 474 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 2) ? 0 : 3, 7 + i, 8, 4);
/* 475 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 3 : 0, 10, 8, 5 + i);
/* 476 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 2) ? 2 : 0, 10, 8, 21 + i);
/* 477 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 2) ? 0 : 2, 7 + i, 8, 24);
/*     */         int j;
/* 479 */         for (j = 0; j < 3; j++) {
/*     */           
/* 481 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 15, 5, 9 + i + j * 4);
/* 482 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 15, 5, 9 + i + j * 4);
/* 483 */           setBlock(Blocks.field_150344_f, 4, 3 + i, 0, j);
/* 484 */           setBlock(Blocks.field_150344_f, 4, i, 0, 8 + j);
/* 485 */           setBlock(Blocks.field_150344_f, 4, i, 0, 18 + j);
/* 486 */           setBlock((Block)Blocks.field_150349_c, 0, i, 0, 13 + j);
/* 487 */           setBlock((Block)Blocks.field_150397_co, 3, 10, 6 + i, 13 + j);
/* 488 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 4 + i, 8, j);
/*     */         } 
/*     */         
/* 491 */         for (j = 0; j < 4; j++) {
/*     */           
/* 493 */           setBlock(ModBlocks.lightForcestone, 0, 2 + j, 4, i);
/* 494 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 12 + i, 8, 8 + j);
/* 495 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 12 + i, 8, 17 + j);
/* 496 */           setBlock((Block)ModBlocks.forcestoneSlab, 8, 3 + j, 8, 26 + i);
/*     */         } 
/*     */         
/* 499 */         for (j = 0; j < 5; j++) {
/*     */           
/* 501 */           setBlock(Blocks.field_150344_f, 4, 4 + i, 0, 12 + j);
/* 502 */           setBlock(Blocks.field_150344_f, 4, 7 + j, 0, 13 + i);
/* 503 */           setBlock((i > 0 || j == 0 || j == 4) ? ModBlocks.lightForcestone : ModBlocks.lightForcestoneStairs, (i > 0 || j == 0 || j == 4) ? 0 : 7, 10 + j, 9 + i, 13);
/* 504 */           setBlock((i > 0 || j == 0 || j == 4) ? ModBlocks.lightForcestone : ModBlocks.lightForcestoneStairs, (i > 0 || j == 0 || j == 4) ? 0 : 6, 10 + j, 9 + i, 15);
/*     */         } 
/*     */         
/* 507 */         for (j = 0; j < 6; j++)
/*     */         {
/* 509 */           setBlock(Blocks.field_150344_f, 4, j, 0, 26 + i);
/*     */         }
/*     */       } 
/*     */       
/* 513 */       for (i = 0; i < 4; i++) {
/*     */         
/* 515 */         setBlock((i > 2) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 2, 1 + i, 3);
/* 516 */         setBlock(ModBlocks.lightForcestone, 0, 3 + i, 0, 8 + i);
/* 517 */         setBlock(ModBlocks.lightForcestone, 0, 3 + i, 0, 20 - i);
/* 518 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 3 + i, 1, 8 + i);
/* 519 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 3 + i, 1, 20 - i);
/* 520 */         setBlock((i == 3) ? ModBlocks.lightForcestoneStairs : ModBlocks.lightActivatedForcestone, (i == 3) ? 1 : 0, 15, 5 + i, 8);
/* 521 */         setBlock((i == 3) ? ModBlocks.lightForcestoneStairs : ModBlocks.lightActivatedForcestone, (i == 3) ? 1 : 0, 15, 5 + i, 20);
/* 522 */         setBlock((i == 3) ? ModBlocks.lightForcestoneStairs : ModBlocks.lightActivatedForcestone, (i == 3) ? 3 : 0, 6, 5 + i, 29);
/* 523 */         setBlock(ModBlocks.lightForcestone, 0, 2, 0, 21 + i);
/* 524 */         setBlock(ModBlocks.lightForcestone, 0, 16, i, 8);
/* 525 */         setBlock(ModBlocks.lightForcestone, 0, 16, i, 20);
/* 526 */         setBlock(ModBlocks.lightForcestone, 0, 26, i, 8);
/* 527 */         setBlock(ModBlocks.lightForcestone, 0, 26, i, 20);
/* 528 */         setBlock(ModBlocks.lightForcestone, 0, 6, i, 30);
/* 529 */         setBlock(ModBlocks.lightForcestone, 0, 6, i, 40);
/* 530 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 3, 0, 4 + i);
/* 531 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 10, 0, 8 + i);
/* 532 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 3, 0, 21 + i);
/* 533 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 10, 0, 17 + i);
/* 534 */         setBlock(ModBlocks.lightForcestone, 0, 2, 5 + i, 4);
/* 535 */         setBlock(ModBlocks.lightForcestone, 0, 2, 5 + i, 24);
/* 536 */         setBlock((Block)Blocks.field_150397_co, 3, 0, 8 + i, 28);
/* 537 */         setBlock((Block)Blocks.field_150397_co, 3, 14, 8 + i, 14);
/* 538 */         setBlock(topBlock, topBlockMeta, 6 + i, -1, 5 + i);
/* 539 */         setBlock(topBlock, topBlockMeta, 9 - i, -1, 20 + i);
/* 540 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 1 : 3, 3 + i, 8, 3);
/* 541 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 3) ? 2 : 0, 11, 8, 8 + i);
/* 542 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 3 : 0, 11, 8, 17 + i);
/* 543 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 1 : 2, 3 + i, 8, 25);
/*     */         
/* 545 */         for (int j = 0; j < 9; j++) {
/*     */           
/* 547 */           setBlock(Blocks.field_150344_f, 4, 17 + j, i, 8);
/* 548 */           setBlock(Blocks.field_150344_f, 4, 17 + j, i, 20);
/* 549 */           setBlock(Blocks.field_150344_f, 4, 27, i, 10 + j);
/* 550 */           setBlock(Blocks.field_150344_f, 4, 6, i, 31 + j);
/*     */         } 
/*     */       } 
/*     */       
/* 554 */       for (i = 0; i < 5; i++) {
/*     */         
/* 556 */         setBlock(ModBlocks.lightForcestone, 0, 9, i, 1);
/* 557 */         setBlock(ModBlocks.lightForcestone, 0, 13, i, 5);
/* 558 */         setBlock(ModBlocks.lightForcestone, 0, 13, i, 23);
/* 559 */         setBlock(ModBlocks.lightForcestone, 0, 9, i, 27);
/* 560 */         setBlock(ModBlocks.lightForcestone, 0, 14, 4, 12 + i);
/* 561 */         setBlock(Blocks.field_150344_f, 4, 14, 0, 12 + i);
/* 562 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 11, i, 12);
/* 563 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 11, i, 16);
/* 564 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 2, i, 25);
/* 565 */         setBlock((Block)ModBlocks.forcestoneSlab, 8, (i > 1) ? (i + 1) : i, 5, 29);
/* 566 */         setBlock(ModBlocks.lightForcestone, 1, i, 3, 40);
/* 567 */         setBlock(ModBlocks.lightForcestoneStairs, 3, i, 4, 40);
/* 568 */         setBlock((i == 0 || i == 4) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, (i == 0 || i == 4) ? 0 : 8, 0, 12, 24 + i);
/* 569 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 0, 13, 24 + i);
/* 570 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 1, 12, 24 + i);
/* 571 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 2, 9, 24 + i);
/* 572 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 10 + i, 9, 12);
/* 573 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 10 + i, 9, 16);
/* 574 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 10 + i, 12, 13);
/* 575 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 10 + i, 12, 15);
/* 576 */         setBlock((i == 0 || i == 4) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, (i == 0 || i == 4) ? 0 : 4, 10 + i, 12, 14);
/* 577 */         setBlock((Block)ModBlocks.forcestoneSlab, 0, 10 + i, 13, 14);
/*     */         int j;
/* 579 */         for (j = 0; j < 2; j++) {
/*     */           
/* 581 */           setBlock(ModBlocks.lightForcestone, 0, 7 + j, i, 0);
/* 582 */           setBlock(ModBlocks.lightForcestone, 0, 10 + j, i, 2);
/* 583 */           setBlock(ModBlocks.lightForcestone, 0, 12, i, 3 + j);
/* 584 */           setBlock(ModBlocks.lightForcestone, 0, 14, i, 6 + j);
/* 585 */           setBlock(ModBlocks.lightForcestone, 0, 14, i, 21 + j);
/* 586 */           setBlock(ModBlocks.lightForcestone, 0, 12, i, 24 + j);
/* 587 */           setBlock(ModBlocks.lightForcestone, 0, 10 + j, i, 26);
/* 588 */           setBlock(ModBlocks.lightForcestone, 0, 7 + j, i, 28);
/*     */         } 
/*     */         
/* 591 */         for (j = 0; j < 3; j++)
/*     */         {
/* 593 */           setBlock((j > 0 || i == 0 || i == 4) ? ModBlocks.lightForcestone : ModBlocks.lightForcestoneStairs, (j > 0 || i == 0 || i == 4) ? 0 : 4, 1, 9 + j, 24 + i);
/*     */         }
/*     */         
/* 596 */         for (j = 0; j < 4; j++) {
/*     */           
/* 598 */           setBlock(ModBlocks.lightForcestone, 0, 15, i, 8 + j);
/* 599 */           setBlock(ModBlocks.lightForcestone, 0, 15, i, 17 + j);
/* 600 */           setBlock(ModBlocks.lightForcestone, 0, 3 + j, i, 29);
/* 601 */           setBlock(Blocks.field_150344_f, 4, i, j, 41);
/*     */         } 
/*     */         
/* 604 */         for (j = 0; j < 10; j++)
/*     */         {
/* 606 */           setBlock((Block)Blocks.field_150399_cn, 3, i, 4, 30 + j);
/*     */         }
/*     */       } 
/*     */       
/* 610 */       for (i = 0; i < 6; i++) {
/*     */         
/* 612 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 15, i, 12);
/* 613 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 15, i, 16);
/* 614 */         setBlock((i == 0 || i > 3) ? ModBlocks.lightForcestone : ModBlocks.lightActivatedForcestone, 0, 2, i, 29);
/* 615 */         setBlock(ModBlocks.lightForcestone, 0, i, 4, 41);
/*     */       } 
/*     */       
/* 618 */       for (i = 0; i < 8; i++) {
/*     */         
/* 620 */         Block block = ModBlocks.lightForcestone;
/* 621 */         int metadata = (block == Blocks.field_150399_cn) ? 3 : 0;
/*     */         int j;
/* 623 */         for (j = 0; j < 4; j++) {
/*     */           
/* 625 */           if (j > 0 || i > 4) {
/*     */             
/* 627 */             block = (i < 2) ? ModBlocks.lightForcestone : ((i < 4 || i == 6) ? (Block)Blocks.field_150399_cn : ModBlocks.lightForcestone);
/* 628 */             metadata = (block == Blocks.field_150399_cn) ? 3 : 0;
/*     */           } 
/*     */           
/* 631 */           setBlock(block, metadata, 3 + j, i, 3);
/* 632 */           setBlock(block, metadata, 3 + j, i, 25);
/*     */           
/* 634 */           setBlock(block, metadata, 11, i, 11 - j);
/* 635 */           setBlock(block, metadata, 11, i, 17 + j);
/*     */         } 
/*     */         
/* 638 */         for (j = 0; j < 2; j++) {
/*     */           
/* 640 */           setBlock(block, metadata, 7 + j, i, 4);
/* 641 */           setBlock(block, metadata, 7 + j, i, 24);
/* 642 */           setBlock(block, metadata, 10, i, 6 + j);
/* 643 */           setBlock(block, metadata, 10, i, 21 + j);
/*     */         } 
/*     */         
/* 646 */         setBlock(block, metadata, 9, i, 5);
/* 647 */         setBlock(block, metadata, 9, i, 23);
/*     */       } 
/*     */       
/* 650 */       for (i = 0; i < 9; i++) {
/*     */         
/* 652 */         setBlock(ModBlocks.lightForcestone, 1, 26, 3, 10 + i);
/* 653 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 26, 4, 10 + i);
/*     */         
/* 655 */         for (int j = 0; j < 10; j++)
/*     */         {
/* 657 */           setBlock((Block)Blocks.field_150399_cn, 3, 16 + j, 4, 10 + i);
/*     */         }
/*     */       } 
/*     */       
/* 661 */       for (i = 0; i < 11; i++) {
/*     */         
/* 663 */         setBlock(ModBlocks.lightForcestone, 0, 27, 4, 9 + i);
/* 664 */         setBlock(ModBlocks.lightForcestone, 1, 16 + i, 3, 9);
/* 665 */         setBlock(ModBlocks.lightForcestone, 1, 16 + i, 3, 19);
/* 666 */         setBlock(ModBlocks.lightForcestoneStairs, 2, 16 + i, 4, 9);
/* 667 */         setBlock(ModBlocks.lightForcestoneStairs, 3, 16 + i, 4, 19);
/* 668 */         setBlock(ModBlocks.lightForcestone, 1, 5, 3, 30 + i);
/* 669 */         setBlock(ModBlocks.lightForcestoneStairs, 1, 5, 4, 30 + i);
/*     */         int j;
/* 671 */         for (j = 0; j < 6; j++)
/*     */         {
/* 673 */           setBlock(Blocks.field_150344_f, 4, j, 0, 30 + i);
/*     */         }
/*     */         
/* 676 */         for (j = 0; j < 11; j++)
/*     */         {
/* 678 */           setBlock(Blocks.field_150344_f, 4, 16 + i, 0, 9 + j);
/*     */         }
/*     */       } 
/*     */       
/* 682 */       for (i = 0; i < 12; i++) {
/*     */         
/* 684 */         setBlock(ModBlocks.lightForcestone, 0, 16 + i, 4, 8);
/* 685 */         setBlock(ModBlocks.lightForcestone, 0, 16 + i, 4, 20);
/* 686 */         setBlock(ModBlocks.lightForcestone, 0, 6, 4, 30 + i);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 693 */       for (i = 0; i < 3; i++) {
/*     */         
/* 695 */         setBlock((Block)Blocks.field_150376_bx, 4, 20 + i, 0, 12);
/* 696 */         setBlock((Block)Blocks.field_150376_bx, 4, 20 + i, 0, 16);
/* 697 */         setBlock((Block)Blocks.field_150376_bx, 4, 2, 0, 34 + i);
/* 698 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 2) ? 0 : 3, i, 0, 32);
/* 699 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 2) ? 0 : 2, i, 0, 38);
/*     */         
/* 701 */         for (int j = 0; j < 5; j++) {
/*     */           
/* 703 */           setBlock((Block)Blocks.field_150376_bx, 4, 19 + j, 0, 13 + i);
/*     */           
/* 705 */           if (i < 2)
/*     */           {
/* 707 */             setBlock((Block)Blocks.field_150376_bx, 4, i, 0, 33 + j);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 712 */       for (i = 0; i < 2; i++) {
/*     */         
/* 714 */         setBlock(ModBlocks.lightForcestone, 0, 3, 0, 32 + i * 6);
/* 715 */         setBlock(ModBlocks.lightForcestoneStairs, 0, 2, 0, 33 + i * 4);
/*     */         
/* 717 */         for (int j = 0; j < 2; j++) {
/*     */           
/* 719 */           setBlock(ModBlocks.lightForcestone, 0, 18 + i * 6, 0, 11 + j * 6);
/* 720 */           setBlock(ModBlocks.lightForcestoneStairs, 1 - i, 19 + i * 4, 0, 12 + j * 4);
/*     */         } 
/*     */       } 
/*     */       
/* 724 */       for (i = 0; i < 5; i++) {
/*     */         
/* 726 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 1 : ((i == 4) ? 0 : 3), 19 + i, 0, 11);
/* 727 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 1 : ((i == 4) ? 0 : 2), 19 + i, 0, 17);
/* 728 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 1), 18, 0, 12 + i);
/* 729 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 0), 24, 0, 12 + i);
/* 730 */         setBlock(ModBlocks.lightForcestoneStairs, (i == 0) ? 3 : ((i == 4) ? 2 : 0), 3, 0, 33 + i);
/*     */       } 
/*     */       
/* 733 */       setBlock(ModBlocks.lightActivatedForcestone, 0, 21, 0, 14);
/* 734 */       setBlock(ModBlocks.lightActivatedForcestone, 0, 0, 0, 35);
/* 735 */       setBlock(ModBlocks.holocron, 0, 21, 1, 14);
/* 736 */       setBlock(ModBlocks.holocron, 0, 0, 1, 35);
/*     */       
/* 738 */       boolean prevMirrorX = this.mirrorX;
/* 739 */       this.mirrorX = false;
/*     */       
/* 741 */       generateTree(random);
/* 742 */       this.zCoord -= 30;
/*     */       
/* 744 */       if (this.simulate) {
/*     */         
/* 746 */         for (int j = 0; j < this.coverage.size(); j++) {
/*     */           
/* 748 */           StructurePoint p = this.coverage.get(j);
/* 749 */           int y = p.field_71572_b;
/*     */           
/* 751 */           int clearance = this.maxY + 8 - (int)(8.0D * random.nextDouble() * random.nextDouble() * random.nextDouble());
/*     */           
/* 753 */           while (y > 0 && !this.worldObj.func_147439_a(p.field_71574_a, y - 1, p.field_71573_c).isSideSolid((IBlockAccess)this.worldObj, p.field_71574_a, y - 1, p.field_71573_c, ForgeDirection.UP))
/*     */           {
/* 755 */             this.worldObj.func_147449_b(p.field_71574_a, --y, p.field_71573_c, fillerBlock);
/*     */           }
/*     */           
/* 758 */           for (y = p.field_71572_b; y < clearance; y++) {
/*     */             
/* 760 */             if (!this.worldObj.func_147437_c(p.field_71574_a, y, p.field_71573_c))
/*     */             {
/* 762 */               this.worldObj.func_147449_b(p.field_71574_a, y, p.field_71573_c, Blocks.field_150350_a);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 767 */         this.mirrorX = prevMirrorX;
/*     */       }
/*     */       else {
/*     */         
/* 771 */         generateStructureChestContents(random, (int)(6.0F * (random.nextFloat() - 0.5F) * 2.0F), -1, 11 + random.nextInt(12), ChestGenHooks.getItems("jediTemple", random), ChestGenHooks.getCount("jediTemple", random));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateTree(Random random) {
/* 778 */     this.zCoord += 14;
/* 779 */     int height = 7;
/* 780 */     float leafCoverage = 1.5F;
/* 781 */     int leafCoverageI = MathHelper.func_76123_f(leafCoverage);
/*     */     
/* 783 */     for (int x = -1; x < 2; x++) {
/*     */       
/* 785 */       for (int z = -1; z < 2; z++) {
/*     */         
/* 787 */         for (int y = 0; y < height; y++) {
/*     */           
/* 789 */           if (y < 2 || x == 0 || z == 0 || random.nextFloat() > 0.2F + y / height) {
/*     */             
/* 791 */             setBlock(Blocks.field_150364_r, 0, x, y + 1, z);
/*     */           }
/*     */           else {
/*     */             
/* 795 */             y = height;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 801 */     setBlock(Blocks.field_150364_r, 0, 0, 1 + height, 0);
/*     */     
/* 803 */     for (int i = 0; i < MathHelper.func_76136_a(random, 18, 20); i++) {
/*     */       
/* 805 */       float rotX = random.nextFloat() * 120.0F;
/* 806 */       float rotY = random.nextFloat() * 360.0F;
/* 807 */       int branchMin = 4;
/* 808 */       int branchMax = 6;
/*     */       
/* 810 */       for (int j = 0; j < (MathHelper.func_76136_a(random, branchMin, branchMax) + MathHelper.func_76136_a(random, branchMin, branchMax)) / 2; j++) {
/*     */         
/* 812 */         Vec3 vec3 = Vec3.func_72443_a(0.0D, j, 0.0D);
/* 813 */         vec3.func_72440_a(rotX * 3.1415927F / 180.0F);
/* 814 */         vec3.func_72442_b(rotY * 3.1415927F / 180.0F);
/*     */         
/* 816 */         setBlock(Blocks.field_150364_r, 0, MathHelper.func_76128_c(vec3.field_72450_a), 1 + height + MathHelper.func_76128_c(vec3.field_72448_b), MathHelper.func_76128_c(vec3.field_72449_c));
/*     */         
/* 818 */         for (int k = -leafCoverageI; k <= leafCoverageI; k++) {
/*     */           
/* 820 */           for (int y = -leafCoverageI; y <= leafCoverageI; y++) {
/*     */             
/* 822 */             for (int z = -leafCoverageI; z <= leafCoverageI; z++) {
/*     */               
/* 824 */               Block block = this.worldObj.func_147439_a(this.xCoord + MathHelper.func_76128_c(vec3.field_72450_a) + k, this.yCoord + 1 + height + MathHelper.func_76128_c(vec3.field_72448_b) + y, this.zCoord + MathHelper.func_76128_c(vec3.field_72449_c) + z);
/*     */               
/* 826 */               if (block != Blocks.field_150364_r) {
/*     */                 
/* 828 */                 Vec3 src = Vec3.func_72443_a((MathHelper.func_76128_c(vec3.field_72450_a) + 0.5F), ((1 + height + MathHelper.func_76128_c(vec3.field_72448_b)) + 0.5F), (MathHelper.func_76128_c(vec3.field_72449_c) + 0.5F));
/* 829 */                 Vec3 dst = src.func_72441_c(k, y, z);
/*     */                 
/* 831 */                 if (src.func_72438_d(dst) <= leafCoverage)
/*     */                 {
/* 833 */                   setBlock((Block)Blocks.field_150362_t, 0, MathHelper.func_76128_c(vec3.field_72450_a) + k, 1 + height + MathHelper.func_76128_c(vec3.field_72448_b) + y, MathHelper.func_76128_c(vec3.field_72449_c) + z);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 842 */     this.zCoord -= 14;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\structure\StructureJediTemple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */