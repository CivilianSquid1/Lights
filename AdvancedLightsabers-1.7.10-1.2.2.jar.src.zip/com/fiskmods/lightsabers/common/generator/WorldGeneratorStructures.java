/*    */ package com.fiskmods.lightsabers.common.generator;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.generator.structure.EnumStructure;
/*    */ import cpw.mods.fml.common.IWorldGenerator;
/*    */ import java.util.Random;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.WorldType;
/*    */ import net.minecraft.world.chunk.IChunkProvider;
/*    */ import net.minecraft.world.storage.WorldInfo;
/*    */ 
/*    */ 
/*    */ public enum WorldGeneratorStructures
/*    */   implements IWorldGenerator
/*    */ {
/* 15 */   INSTANCE;
/*    */ 
/*    */ 
/*    */   
/*    */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
/* 20 */     switch (world.field_73011_w.field_76574_g) {
/*    */       
/*    */       case 0:
/* 23 */         generateOverworld(world, random, chunkX * 16 + 8, chunkZ * 16 + 8);
/*    */         break;
/*    */       case -1:
/* 26 */         generateNether(world, random, chunkX * 16 + 8, chunkZ * 16 + 8);
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Random getRandomForCoords(World world, int x, int z) {
/* 33 */     return new Random(x * 341873128712L + z * 132897987541L + world.func_72905_C() + 235785655L);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean canSpawnStructureAtCoords(World world, int x, int z, EnumStructure structure) {
/* 38 */     int xOriginal = x;
/* 39 */     int zOriginal = z;
/*    */     
/* 41 */     if (x < 0)
/*    */     {
/* 43 */       x -= structure.maxDistance - 1;
/*    */     }
/*    */     
/* 46 */     if (z < 0)
/*    */     {
/* 48 */       z -= structure.maxDistance - 1;
/*    */     }
/*    */     
/* 51 */     int x2 = x / structure.maxDistance;
/* 52 */     int z2 = z / structure.maxDistance;
/*    */ 
/*    */     
/* 55 */     Random random = getRandomForCoords(world, x2, z2);
/*    */     
/* 57 */     x2 *= structure.maxDistance;
/* 58 */     z2 *= structure.maxDistance;
/* 59 */     x2 += random.nextInt(structure.maxDistance - structure.minDistance);
/* 60 */     z2 += random.nextInt(structure.maxDistance - structure.minDistance);
/*    */     
/* 62 */     if (xOriginal == x2 && zOriginal == z2)
/*    */     {
/* 64 */       return structure.biomePredicate.apply(world.func_72959_q().func_76935_a(xOriginal, zOriginal));
/*    */     }
/*    */     
/* 67 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void generateStructure(World world, int x, int z, EnumStructure structure) throws Exception {
/* 72 */     Random rand = getRandomForCoords(world, x, z);
/* 73 */     int y = Math.max(world.func_72825_h(x, z), world.field_73011_w.func_76557_i());
/*    */     
/* 75 */     structure.construct(world, x, y, z, rand).spawnStructure(rand);
/*    */   }
/*    */ 
/*    */   
/*    */   public void generateOverworld(World world, Random random, int x, int z) {
/* 80 */     WorldInfo info = world.func_72912_H();
/*    */     
/* 82 */     if (info.func_76067_t() != WorldType.field_77138_c && info.func_76089_r())
/*    */     {
/* 84 */       for (EnumStructure enumStructure : EnumStructure.values()) {
/*    */         
/* 86 */         if (canSpawnStructureAtCoords(world, x, z, enumStructure))
/*    */           
/*    */           try {
/*    */             
/* 90 */             generateStructure(world, x, z, enumStructure);
/*    */           }
/* 92 */           catch (Exception e) {
/*    */             
/* 94 */             e.printStackTrace();
/*    */           }  
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void generateNether(World world, Random random, int chunkX, int chunkZ) {}
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\WorldGeneratorStructures.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */