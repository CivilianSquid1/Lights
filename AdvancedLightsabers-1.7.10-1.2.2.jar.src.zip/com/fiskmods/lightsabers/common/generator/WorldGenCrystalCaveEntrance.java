/*    */ package com.fiskmods.lightsabers.common.generator;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.feature.WorldGenerator;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ 
/*    */ public class WorldGenCrystalCaveEntrance
/*    */   extends WorldGenerator
/*    */ {
/*    */   private int numberOfBlocks;
/*    */   
/*    */   public WorldGenCrystalCaveEntrance(int blocks) {
/* 18 */     this.numberOfBlocks = blocks;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_76484_a(World world, Random random, int x, int y, int z) {
/* 24 */     float f = random.nextFloat() * 3.1415927F;
/* 25 */     double d0 = (x + random.nextInt(3) - 2);
/* 26 */     double d1 = (x + random.nextInt(3) - 2);
/* 27 */     double d2 = (z + random.nextInt(3) - 2);
/* 28 */     double d3 = (z + random.nextInt(3) - 2);
/* 29 */     double d4 = (y + random.nextInt(3) - 2);
/* 30 */     double d5 = (y + random.nextInt(3) - 2);
/*    */     
/* 32 */     for (int l = 0; l <= this.numberOfBlocks; l++) {
/*    */       
/* 34 */       double d6 = d0 + (d1 - d0) * l / this.numberOfBlocks;
/* 35 */       double d7 = d4 + (d5 - d4) * l / this.numberOfBlocks;
/* 36 */       double d8 = d2 + (d3 - d2) * l / this.numberOfBlocks;
/* 37 */       double d9 = random.nextDouble() * this.numberOfBlocks / 16.0D;
/* 38 */       double d10 = (MathHelper.func_76126_a(l * 3.1415927F / this.numberOfBlocks) + 1.0F) * d9 + 1.0D;
/* 39 */       double d11 = (MathHelper.func_76126_a(l * 3.1415927F / this.numberOfBlocks) + 1.0F) * d9 + 1.0D;
/* 40 */       int i1 = MathHelper.func_76128_c(d6 - d10 / 2.0D);
/* 41 */       int j1 = MathHelper.func_76128_c(d7 - d11 / 2.0D);
/* 42 */       int k1 = MathHelper.func_76128_c(d8 - d10 / 2.0D);
/* 43 */       int l1 = MathHelper.func_76128_c(d6 + d10 / 2.0D);
/* 44 */       int i2 = MathHelper.func_76128_c(d7 + d11 / 2.0D);
/* 45 */       int j2 = MathHelper.func_76128_c(d8 + d10 / 2.0D);
/*    */       
/* 47 */       for (int k2 = i1; k2 <= l1; k2++) {
/*    */         
/* 49 */         double d12 = (k2 + 0.5D - d6) / d10 / 2.0D;
/*    */         
/* 51 */         if (d12 * d12 < 1.0D)
/*    */         {
/* 53 */           for (int l2 = j1; l2 <= i2; l2++) {
/*    */             
/* 55 */             double d13 = (l2 + 0.5D - d7) / d11 / 2.0D;
/*    */             
/* 57 */             if (d12 * d12 + d13 * d13 < 1.0D)
/*    */             {
/* 59 */               for (int i3 = k1; i3 <= j2; i3++) {
/*    */                 
/* 61 */                 double d14 = (i3 + 0.5D - d8) / d10 / 2.0D;
/* 62 */                 Block block1 = world.func_147439_a(k2, l2 + 1, i3);
/*    */                 
/* 64 */                 if (d12 * d12 + d13 * d13 + d14 * d14 < 1.0D && world.func_147439_a(k2, l2, i3) != Blocks.field_150486_ae) {
/*    */                   
/* 66 */                   if (world.func_147439_a(k2 + 1, l2, i3) != Blocks.field_150350_a || world.func_147439_a(k2 - 1, l2, i3) != Blocks.field_150350_a || world.func_147439_a(k2, l2 + 1, i3) != Blocks.field_150350_a || world.func_147439_a(k2, l2 - 1, i3) != Blocks.field_150350_a || world.func_147439_a(k2, l2, i3 + 1) != Blocks.field_150350_a || world.func_147439_a(k2, l2, i3 - 1) != Blocks.field_150350_a)
/*    */                   {
/* 68 */                     world.func_147449_b(k2, l2, i3, Blocks.field_150350_a);
/*    */                   }
/*    */                   
/* 71 */                   Block block = Blocks.field_150348_b;
/* 72 */                   createWalls(world, k2 + 1, l2, i3, block);
/* 73 */                   createWalls(world, k2 - 1, l2, i3, block);
/* 74 */                   createWalls(world, k2, l2 + 1, i3, block);
/* 75 */                   createWalls(world, k2, l2 - 1, i3, block);
/* 76 */                   createWalls(world, k2, l2, i3 + 1, block);
/* 77 */                   createWalls(world, k2, l2, i3 - 1, block);
/*    */                 } 
/*    */               } 
/*    */             }
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 86 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void createWalls(World world, int x, int y, int z, Block block) {
/* 91 */     if (world.func_147439_a(x, y, z).isSideSolid((IBlockAccess)world, x, y, z, ForgeDirection.UP))
/*    */     {
/* 93 */       world.func_147465_d(x, y, z, block, 0, 2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\WorldGenCrystalCaveEntrance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */