/*    */ package com.fiskmods.lightsabers.common.generator;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.feature.WorldGenerator;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ 
/*    */ 
/*    */ public class WorldGenCrystal
/*    */   extends WorldGenerator
/*    */ {
/*    */   private Block target;
/*    */   private Material growthMaterial;
/*    */   
/*    */   public WorldGenCrystal(Block block, Material material) {
/* 19 */     this.target = block;
/* 20 */     this.growthMaterial = material;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_76484_a(World world, Random rand, int x, int y, int z) {
/* 26 */     boolean flag = false;
/* 27 */     int range = 3;
/*    */     
/* 29 */     for (int i = -range; i <= range && !flag; i++) {
/*    */       
/* 31 */       for (int j = -range; j <= range; j++) {
/*    */         
/* 33 */         int xPosition = x >> 4 + i;
/* 34 */         int zPosition = z >> 4 + j;
/* 35 */         Random random = new Random(world.func_72905_C() + (xPosition * xPosition * 4987142) + (xPosition * 5947611) + (zPosition * zPosition) * 4392871L + (zPosition * 389711) ^ 0x3AD8025FL);
/*    */         
/* 37 */         if (random.nextInt(300) == 0) {
/*    */           
/* 39 */           flag = true;
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     } 
/* 45 */     if (flag && world.func_147439_a(x, y, z) == Blocks.field_150350_a)
/*    */     {
/* 47 */       for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
/*    */         
/* 49 */         if (world.func_147439_a(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ).func_149688_o() == this.growthMaterial)
/*    */         {
/* 51 */           return world.func_147465_d(x, y, z, this.target, dir.getOpposite().ordinal(), 2);
/*    */         }
/*    */       } 
/*    */     }
/*    */     
/* 56 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\WorldGenCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */