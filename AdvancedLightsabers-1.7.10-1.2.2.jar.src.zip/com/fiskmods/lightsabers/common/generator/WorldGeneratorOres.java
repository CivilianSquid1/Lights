/*     */ package com.fiskmods.lightsabers.common.generator;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.BlockCrystalGen;
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.common.IWorldGenerator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldType;
/*     */ import net.minecraft.world.biome.BiomeGenBase;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum WorldGeneratorOres
/*     */   implements IWorldGenerator
/*     */ {
/*  26 */   INSTANCE;
/*     */   WorldGeneratorOres() {
/*  28 */     this.entrance = new WorldGenCrystalCaveEntrance(32);
/*     */   }
/*     */   private WorldGenCrystalCaveEntrance entrance;
/*     */   
/*     */   public void generate(Random rand, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
/*  33 */     switch (world.field_73011_w.field_76574_g) {
/*     */       
/*     */       case 0:
/*  36 */         generateOverworld(world, rand, chunkX * 16, chunkZ * 16);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCrystalCaveChunk(World world, int x, int z) {
/*  43 */     Random rand = new Random(world.func_72905_C() + (x * x * 4987142) + (x * 5947611) + (z * z) * 4392871L + (z * 389711) ^ 0x3AD8025FL);
/*  44 */     return (rand.nextInt(33) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCrystalCaveChunk(World world, Chunk chunk) {
/*  49 */     return isCrystalCaveChunk(world, chunk.field_76635_g, chunk.field_76647_h);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateOverworld(World world, Random rand, int x, int z) {
/*  54 */     if (world.func_72912_H().func_76067_t() != WorldType.field_77138_c) {
/*     */       
/*  56 */       Chunk chunk = world.func_72938_d(x, z);
/*     */       
/*  58 */       if (isCrystalCaveChunk(world, chunk) && world.func_72807_a(x, z) != BiomeGenBase.field_76771_b) {
/*     */         
/*  60 */         List<int[]> airBlocks = Lists.newArrayList();
/*     */         
/*  62 */         for (int i = 0; i < 16; i++) {
/*     */           
/*  64 */           for (int j = 0; j < 16; j++) {
/*     */             
/*  66 */             int topBlock = 128;
/*     */             
/*  68 */             while (world.func_147439_a(x + i, topBlock, z + j) == Blocks.field_150350_a && topBlock > 0)
/*     */             {
/*  70 */               topBlock--;
/*     */             }
/*     */             
/*  73 */             for (int y = 0; y < topBlock - 10; y++) {
/*     */               
/*  75 */               if (world.func_147439_a(x + i, y, z + j) == Blocks.field_150350_a)
/*     */               {
/*  77 */                 airBlocks.add(new int[] { x + i, y, z + j });
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*  83 */         if (airBlocks.size() > 1024) {
/*     */           
/*  85 */           int[] aint = airBlocks.get(rand.nextInt(airBlocks.size()));
/*  86 */           int x1 = aint[0];
/*  87 */           int y1 = aint[1];
/*  88 */           int z1 = aint[2];
/*  89 */           int count = 0;
/*     */           
/*  91 */           while (y1 < world.func_72825_h(x1, z1)) {
/*     */             
/*  93 */             if (count < 10 + rand.nextInt(10)) {
/*     */               
/*  95 */               y1++;
/*     */             }
/*     */             else {
/*     */               
/*  99 */               if (rand.nextInt(3) == 0)
/*     */               {
/* 101 */                 x1 += (rand.nextInt(3) - 1) * 2;
/*     */               }
/*     */               
/* 104 */               if (rand.nextInt(9) == 0)
/*     */               {
/* 106 */                 y1++;
/*     */               }
/*     */               
/* 109 */               if (rand.nextInt(3) == 0)
/*     */               {
/* 111 */                 z1 += (rand.nextInt(3) - 1) * 2;
/*     */               }
/*     */             } 
/*     */             
/* 115 */             this.entrance.func_76484_a(world, rand, x1, y1, z1);
/* 116 */             count++;
/*     */           } 
/*     */           
/* 119 */           int radius = 1;
/*     */           
/* 121 */           for (int j = -radius; j <= radius; j++) {
/*     */             
/* 123 */             for (int k = -radius; k <= radius; k++)
/*     */             {
/* 125 */               generateCrystal(100, ModBlocks.lightsaberCrystal, 64, world, rand, x + j * 16, z + k * 16);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCrystal(int attempts, Block block, int minY, World world, Random rand, int chunkX, int chunkZ) {
/* 135 */     for (int i = 0; i < attempts; i++) {
/*     */       
/* 137 */       int x = chunkX + rand.nextInt(16);
/* 138 */       int y = rand.nextInt(minY);
/* 139 */       int z = chunkZ + rand.nextInt(16);
/*     */       
/* 141 */       if (world.func_147439_a(x, y, z) == Blocks.field_150350_a)
/*     */       {
/* 143 */         BlockCrystalGen.replace(world, x, y, z);
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\generator\WorldGeneratorOres.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */