/*     */ package com.fiskmods.lightsabers.common.entity.ai;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.pathfinding.PathEntity;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ public abstract class EntityAIBlockInteract
/*     */   extends EntityAIBase
/*     */ {
/*     */   protected EntityLiving theEntity;
/*     */   protected int entityPosX;
/*     */   protected int entityPosY;
/*     */   protected int entityPosZ;
/*     */   protected Block field_151504_e;
/*     */   boolean hasStoppedBlockInteraction;
/*     */   float entityPositionX;
/*     */   float entityPositionZ;
/*     */   
/*     */   public EntityAIBlockInteract(EntityLiving entity) {
/*  25 */     this.theEntity = entity;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  31 */     if (!this.theEntity.field_70123_F)
/*     */     {
/*  33 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  37 */     PathNavigate pathnavigate = this.theEntity.func_70661_as();
/*  38 */     PathEntity pathentity = pathnavigate.func_75505_d();
/*     */     
/*  40 */     if (pathentity != null && !pathentity.func_75879_b() && pathnavigate.func_75507_c()) {
/*     */       
/*  42 */       for (int i = 0; i < Math.min(pathentity.func_75873_e() + 2, pathentity.func_75874_d()); i++) {
/*     */         
/*  44 */         PathPoint pathpoint = pathentity.func_75877_a(i);
/*  45 */         this.entityPosX = pathpoint.field_75839_a;
/*  46 */         this.entityPosY = pathpoint.field_75837_b + 1;
/*  47 */         this.entityPosZ = pathpoint.field_75838_c;
/*     */         
/*  49 */         if (this.theEntity.func_70092_e(this.entityPosX, this.theEntity.field_70163_u, this.entityPosZ) <= 2.25D) {
/*     */           
/*  51 */           this.field_151504_e = func_151503_a(this.entityPosX, this.entityPosY, this.entityPosZ);
/*     */           
/*  53 */           if (this.field_151504_e != null)
/*     */           {
/*  55 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  60 */       this.entityPosX = MathHelper.func_76128_c(this.theEntity.field_70165_t);
/*  61 */       this.entityPosY = MathHelper.func_76128_c(this.theEntity.field_70163_u + 1.0D);
/*  62 */       this.entityPosZ = MathHelper.func_76128_c(this.theEntity.field_70161_v);
/*  63 */       this.field_151504_e = func_151503_a(this.entityPosX, this.entityPosY, this.entityPosZ);
/*  64 */       return (this.field_151504_e != null);
/*     */     } 
/*     */ 
/*     */     
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  76 */     return !this.hasStoppedBlockInteraction;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  82 */     this.hasStoppedBlockInteraction = false;
/*  83 */     this.entityPositionX = (float)((this.entityPosX + 0.5F) - this.theEntity.field_70165_t);
/*  84 */     this.entityPositionZ = (float)((this.entityPosZ + 0.5F) - this.theEntity.field_70161_v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  90 */     float f = (float)((this.entityPosX + 0.5F) - this.theEntity.field_70165_t);
/*  91 */     float f1 = (float)((this.entityPosZ + 0.5F) - this.theEntity.field_70161_v);
/*  92 */     float f2 = this.entityPositionX * f + this.entityPositionZ * f1;
/*     */     
/*  94 */     if (f2 < 0.0F)
/*     */     {
/*  96 */       this.hasStoppedBlockInteraction = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Block func_151503_a(int x, int y, int z) {
/* 102 */     Block block = this.theEntity.field_70170_p.func_147439_a(x, y, z);
/* 103 */     return (block.func_149712_f(this.theEntity.field_70170_p, x, y, z) < 0.0F) ? null : block;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\ai\EntityAIBlockInteract.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */