/*    */ package com.fiskmods.lightsabers.common.entity.ai;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.entity.EntitySithGhost;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ 
/*    */ 
/*    */ public class EntityAIRest
/*    */   extends EntityAIBase
/*    */ {
/*    */   private EntitySithGhost entity;
/*    */   private double speed;
/*    */   
/*    */   public EntityAIRest(EntitySithGhost entity, double speed) {
/* 14 */     this.entity = entity;
/* 15 */     this.speed = speed;
/* 16 */     func_75248_a(1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 22 */     return func_75253_b();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 28 */     return (this.entity.taskFinished == 2 && this.entity.hasRestingPlace);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 34 */     this.entity.func_70661_as().func_75492_a(this.entity.restingPlaceX, this.entity.restingPlaceY, this.entity.restingPlaceZ, this.speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\ai\EntityAIRest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */