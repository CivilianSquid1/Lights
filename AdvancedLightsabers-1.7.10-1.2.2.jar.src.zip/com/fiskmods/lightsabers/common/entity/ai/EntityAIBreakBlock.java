/*    */ package com.fiskmods.lightsabers.common.entity.ai;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.world.EnumDifficulty;
/*    */ 
/*    */ public class EntityAIBreakBlock
/*    */   extends EntityAIBlockInteract {
/*    */   private int breakingTime;
/* 10 */   private int field_75358_j = -1;
/*    */ 
/*    */   
/*    */   public EntityAIBreakBlock(EntityLiving entity) {
/* 14 */     super(entity);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 20 */     return (super.func_75250_a() && this.theEntity.field_70170_p.func_82736_K().func_82766_b("mobGriefing"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 26 */     super.func_75249_e();
/* 27 */     this.breakingTime = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 33 */     double d0 = this.theEntity.func_70092_e(this.entityPosX, this.entityPosY, this.entityPosZ);
/* 34 */     return (this.breakingTime <= 60);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75251_c() {
/* 40 */     super.func_75251_c();
/* 41 */     this.theEntity.field_70170_p.func_147443_d(this.theEntity.func_145782_y(), this.entityPosX, this.entityPosY, this.entityPosZ, -1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75246_d() {
/* 47 */     super.func_75246_d();
/* 48 */     this.breakingTime++;
/* 49 */     int i = (int)(this.breakingTime / 60.0F * 10.0F);
/*    */     
/* 51 */     if (i != this.field_75358_j) {
/*    */       
/* 53 */       this.theEntity.field_70170_p.func_147443_d(this.theEntity.func_145782_y(), this.entityPosX, this.entityPosY, this.entityPosZ, i);
/* 54 */       this.field_75358_j = i;
/*    */     } 
/*    */     
/* 57 */     if (this.breakingTime == 60 && this.theEntity.field_70170_p.field_73013_u == EnumDifficulty.HARD) {
/*    */       
/* 59 */       this.theEntity.field_70170_p.func_147468_f(this.entityPosX, this.entityPosY, this.entityPosZ);
/* 60 */       this.theEntity.field_70170_p.func_72926_e(2001, this.entityPosX, this.entityPosY, this.entityPosZ, Block.func_149682_b(this.field_151504_e));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\ai\EntityAIBreakBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */