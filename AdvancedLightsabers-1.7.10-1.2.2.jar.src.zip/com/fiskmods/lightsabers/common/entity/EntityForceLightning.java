/*    */ package com.fiskmods.lightsabers.common.entity;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityForceLightning
/*    */   extends Entity
/*    */ {
/*    */   public EntityLivingBase entity;
/*    */   
/*    */   public EntityForceLightning(World world) {
/* 14 */     super(world);
/* 15 */     func_70105_a(0.1F, 0.1F);
/* 16 */     this.field_70158_ak = true;
/* 17 */     this.field_70155_l = 100.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityForceLightning(World world, EntityLivingBase entity) {
/* 22 */     this(world);
/* 23 */     this.entity = entity;
/* 24 */     func_70012_b(entity.field_70165_t, entity.field_70163_u + (entity.field_70131_O / 2.0F), entity.field_70161_v, entity.field_70177_z, entity.field_70125_A);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 30 */     if (++this.field_70173_aa > 2)
/*    */     {
/* 32 */       func_70106_y();
/*    */     }
/*    */   }
/*    */   
/*    */   public void func_70037_a(NBTTagCompound nbt) {}
/*    */   
/*    */   public void func_70014_b(NBTTagCompound nbt) {}
/*    */   
/*    */   protected void func_70088_a() {}
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\EntityForceLightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */