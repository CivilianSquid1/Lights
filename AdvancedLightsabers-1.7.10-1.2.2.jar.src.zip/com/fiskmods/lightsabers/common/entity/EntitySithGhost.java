/*     */ package com.fiskmods.lightsabers.common.entity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.entity.ai.EntityAIBreakBlock;
/*     */ import com.fiskmods.lightsabers.common.entity.ai.EntityAIRest;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.PacketThrowLightsaber;
/*     */ import com.fiskmods.lightsabers.common.network.PacketTileAction;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackOnCollide;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAIHurtByTarget;
/*     */ import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAIOpenDoor;
/*     */ import net.minecraft.entity.ai.EntityAIRestrictOpenDoor;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class EntitySithGhost
/*     */   extends EntityMob {
/*     */   public boolean hasRestingPlace;
/*     */   public int restingPlaceX;
/*     */   public int restingPlaceY;
/*     */   public int restingPlaceZ;
/*     */   public int throwLightsaberCooldown;
/*     */   public int swingItemCooldown;
/*     */   public int strafeTimer;
/*  50 */   public int strafe = 1;
/*     */   
/*     */   public int taskFinished;
/*     */   
/*     */   public EntitySithGhost(World world) {
/*  55 */     super(world);
/*  56 */     func_70661_as().func_75491_a(true);
/*  57 */     func_70661_as().func_75498_b(true);
/*  58 */     func_70661_as().func_75490_c(true);
/*  59 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*  60 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAIBreakBlock((EntityLiving)this));
/*  61 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIAttackOnCollide((EntityCreature)this, 0.5D, true));
/*  62 */     this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIRest(this, 0.4D));
/*  63 */     this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 4.0F, 10.0F));
/*  64 */     this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAIRestrictOpenDoor((EntityCreature)this));
/*  65 */     this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAIOpenDoor((EntityLiving)this, true));
/*  66 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIMoveTowardsRestriction((EntityCreature)this, 0.6D));
/*  67 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget((EntityCreature)this, true));
/*  68 */     this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityPlayer.class, 0, false));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70652_k(Entity entity) {
/*  74 */     if (entity instanceof EntitySithGhost)
/*     */     {
/*  76 */       return false;
/*     */     }
/*     */     
/*  79 */     boolean flag = super.func_70652_k(entity);
/*     */     
/*  81 */     if (flag)
/*     */     {
/*  83 */       func_71038_i();
/*     */     }
/*     */     
/*  86 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource damageSource, float damage) {
/*  92 */     if (damageSource == DamageSource.field_76368_d)
/*     */     {
/*  94 */       return false;
/*     */     }
/*     */     
/*  97 */     return super.func_70097_a(damageSource, Math.min(damage, 10.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71038_i() {
/* 103 */     if (this.swingItemCooldown == 0) {
/*     */       
/* 105 */       this.swingItemCooldown = 5;
/* 106 */       super.func_71038_i();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/* 113 */     super.func_110147_ax();
/* 114 */     func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(60.0D);
/* 115 */     func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(4.0D);
/* 116 */     func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.6D);
/* 117 */     func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0D);
/* 118 */     func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(32.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70650_aV() {
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected float func_70647_i() {
/* 130 */     return super.func_70647_i();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String func_70639_aQ() {
/* 136 */     return "lightsabers:mob.sith_ghost.idle";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String func_70621_aR() {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String func_70673_aS() {
/* 148 */     return "lightsabers:mob.sith_ghost.death";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 154 */     super.func_70071_h_();
/* 155 */     EntityLivingBase target = func_70638_az();
/* 156 */     ItemStack heldItem = func_70694_bm();
/*     */     
/* 158 */     if (this.throwLightsaberCooldown > 0)
/*     */     {
/* 160 */       this.throwLightsaberCooldown--;
/*     */     }
/*     */     
/* 163 */     if (this.swingItemCooldown > 0)
/*     */     {
/* 165 */       this.swingItemCooldown--;
/*     */     }
/*     */     
/* 168 */     if (--this.strafeTimer <= 0) {
/*     */       
/* 170 */       this.strafe *= -1;
/* 171 */       this.strafeTimer = 100 + this.field_70146_Z.nextInt(1000);
/*     */     } 
/*     */     
/* 174 */     if (heldItem != null) {
/*     */       
/* 176 */       if (this.field_70173_aa > 5 && !this.field_70170_p.field_72995_K && !ItemLightsaberBase.isActive(heldItem))
/*     */       {
/* 178 */         ItemLightsaberBase.ignite((EntityLivingBase)this, true);
/*     */       }
/*     */       
/* 181 */       if (target != null && target.func_70089_S()) {
/*     */         
/* 183 */         func_70625_a((Entity)target, 100.0F, 100.0F);
/*     */         
/* 185 */         if (ItemLightsaberBase.isActive(heldItem) && func_70032_d((Entity)target) > 5.0F && func_70685_l((Entity)target) && this.throwLightsaberCooldown == 0) {
/*     */           
/* 187 */           this.throwLightsaberCooldown = 40 + this.field_70146_Z.nextInt(60);
/* 188 */           func_71038_i();
/* 189 */           ALNetworkManager.wrapper.sendToServer((IMessage)new PacketThrowLightsaber((EntityLivingBase)this, heldItem));
/*     */         } 
/*     */         
/* 192 */         if (func_70032_d((Entity)target) < 5.0F && func_70685_l((Entity)target))
/*     */         {
/* 194 */           func_70612_e(0.3F * this.strafe, 0.0F);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     if (target instanceof EntitySithGhost)
/*     */     {
/* 201 */       func_70624_b((EntityLivingBase)this.field_70170_p.func_72856_b((Entity)this, 32.0D));
/*     */     }
/*     */     
/* 204 */     if (target != null) {
/*     */       
/* 206 */       this.taskFinished = 1;
/*     */     }
/* 208 */     else if (this.taskFinished == 1) {
/*     */       
/* 210 */       this.taskFinished = 2;
/*     */     } 
/*     */     
/* 213 */     if (this.taskFinished == 2) {
/*     */       
/* 215 */       int x = MathHelper.func_76128_c(this.field_70165_t);
/* 216 */       int y = MathHelper.func_76128_c(this.field_70163_u);
/* 217 */       int z = MathHelper.func_76128_c(this.field_70161_v);
/*     */       
/* 219 */       if (func_70011_f(this.restingPlaceX, this.restingPlaceY, this.restingPlaceZ) <= 2.0D) {
/*     */         
/* 221 */         this.taskFinished = 3;
/*     */         
/* 223 */         if (this.field_70170_p.func_147438_o(this.restingPlaceX, this.restingPlaceY, this.restingPlaceZ) instanceof TileEntitySithStoneCoffin) {
/*     */           
/* 225 */           TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)this.field_70170_p.func_147438_o(this.restingPlaceX, this.restingPlaceY, this.restingPlaceZ);
/* 226 */           tile.equipment = func_71124_b(0);
/* 227 */           this.field_70170_p.func_72889_a(null, 1017, x, y, z, 0);
/* 228 */           func_70106_y();
/* 229 */           ALNetworkManager.wrapper.sendToServer((IMessage)new PacketTileAction((Entity)this, this.restingPlaceX, this.restingPlaceY, this.restingPlaceZ, 0));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70106_y() {
/* 238 */     super.func_70106_y();
/*     */     
/* 240 */     if (this.field_70170_p.field_72995_K)
/*     */     {
/* 242 */       for (int i = 0; i < 128; i++) {
/*     */         
/* 244 */         double d0 = (this.field_70146_Z.nextFloat() * 2.0F - 1.0F) * 1.2D;
/* 245 */         double d1 = this.field_70146_Z.nextFloat() * 2.4D - 1.0D;
/* 246 */         double d2 = (this.field_70146_Z.nextFloat() * 2.0F - 1.0F) * 1.2D;
/* 247 */         double d3 = this.field_70165_t + d0 * this.field_70130_N;
/* 248 */         double d4 = this.field_70121_D.field_72338_b + d1 * this.field_70131_O;
/* 249 */         double d5 = this.field_70161_v + d2 * this.field_70130_N;
/* 250 */         this.field_70170_p.func_72869_a("largesmoke", d3, d4, d5, 0.0D, 0.0D, 0.0D);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound nbt) {
/* 258 */     super.func_70037_a(nbt);
/* 259 */     this.hasRestingPlace = nbt.func_74767_n("HasRestingPlace");
/* 260 */     this.restingPlaceX = nbt.func_74762_e("RestX");
/* 261 */     this.restingPlaceY = nbt.func_74762_e("RestY");
/* 262 */     this.restingPlaceZ = nbt.func_74762_e("RestZ");
/* 263 */     this.throwLightsaberCooldown = nbt.func_74762_e("ThrowCooldown");
/* 264 */     this.swingItemCooldown = nbt.func_74762_e("SwingCooldown");
/* 265 */     this.strafeTimer = nbt.func_74762_e("StrafeTimer");
/* 266 */     this.strafe = nbt.func_74762_e("Strafe");
/* 267 */     this.taskFinished = nbt.func_74762_e("TaskFinished");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound nbt) {
/* 273 */     super.func_70014_b(nbt);
/* 274 */     nbt.func_74757_a("HasRestingPlace", this.hasRestingPlace);
/* 275 */     nbt.func_74768_a("RestX", this.restingPlaceX);
/* 276 */     nbt.func_74768_a("RestY", this.restingPlaceY);
/* 277 */     nbt.func_74768_a("RestZ", this.restingPlaceZ);
/* 278 */     nbt.func_74768_a("ThrowCooldown", this.throwLightsaberCooldown);
/* 279 */     nbt.func_74768_a("SwingCooldown", this.swingItemCooldown);
/* 280 */     nbt.func_74768_a("StrafeTimer", this.strafeTimer);
/* 281 */     nbt.func_74768_a("Strafe", this.strafe);
/* 282 */     nbt.func_74768_a("TaskFinished", this.taskFinished);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_70041_e_() {
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IEntityLivingData func_110161_a(IEntityLivingData entityData) {
/* 294 */     if (func_71124_b(0) == null)
/*     */     {
/* 296 */       func_70062_b(0, LightsaberData.createRandom(this.field_70146_Z, CrystalColor.RED));
/*     */     }
/*     */     
/* 299 */     for (int i = 0; i < this.field_82174_bp.length; i++)
/*     */     {
/* 301 */       this.field_82174_bp[i] = 0.0F;
/*     */     }
/*     */     
/* 304 */     return super.func_110161_a(entityData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70091_d(double offsetX, double offsetY, double offsetZ) {
/* 310 */     if (this.field_70145_X) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 321 */       this.field_70170_p.field_72984_F.func_76320_a("move");
/* 322 */       this.field_70139_V *= 0.4F;
/* 323 */       double d3 = this.field_70165_t;
/* 324 */       double d4 = this.field_70163_u;
/* 325 */       double d5 = this.field_70161_v;
/* 326 */       double d6 = offsetX;
/* 327 */       double d7 = offsetY;
/* 328 */       double d8 = offsetZ;
/* 329 */       AxisAlignedBB axisalignedbb = this.field_70121_D.func_72329_c();
/* 330 */       boolean flag1 = false;
/*     */       
/* 332 */       List<AxisAlignedBB> list = getCollidingBoundingBoxes(this.field_70121_D.func_72321_a(offsetX, offsetY, offsetZ));
/*     */       
/* 334 */       for (Object aList : list)
/*     */       {
/* 336 */         offsetY = ((AxisAlignedBB)aList).func_72323_b(this.field_70121_D, offsetY);
/*     */       }
/*     */       
/* 339 */       this.field_70121_D.func_72317_d(0.0D, offsetY, 0.0D);
/*     */       
/* 341 */       if (!this.field_70135_K && d7 != offsetY) {
/*     */         
/* 343 */         offsetZ = 0.0D;
/* 344 */         offsetY = 0.0D;
/* 345 */         offsetX = 0.0D;
/*     */       } 
/*     */       
/* 348 */       boolean flag2 = (this.field_70122_E || (d7 != offsetY && d7 < 0.0D));
/*     */       
/*     */       int j;
/* 351 */       for (j = 0; j < list.size(); j++)
/*     */       {
/* 353 */         offsetX = ((AxisAlignedBB)list.get(j)).func_72316_a(this.field_70121_D, offsetX);
/*     */       }
/*     */       
/* 356 */       this.field_70121_D.func_72317_d(offsetX, 0.0D, 0.0D);
/*     */       
/* 358 */       if (!this.field_70135_K && d6 != offsetX) {
/*     */         
/* 360 */         offsetZ = 0.0D;
/* 361 */         offsetY = 0.0D;
/* 362 */         offsetX = 0.0D;
/*     */       } 
/*     */       
/* 365 */       for (j = 0; j < list.size(); j++)
/*     */       {
/* 367 */         offsetZ = ((AxisAlignedBB)list.get(j)).func_72322_c(this.field_70121_D, offsetZ);
/*     */       }
/*     */       
/* 370 */       this.field_70121_D.func_72317_d(0.0D, 0.0D, offsetZ);
/*     */       
/* 372 */       if (!this.field_70135_K && d8 != offsetZ) {
/*     */         
/* 374 */         offsetZ = 0.0D;
/* 375 */         offsetY = 0.0D;
/* 376 */         offsetX = 0.0D;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 384 */       if (this.field_70138_W > 0.0F && flag2 && (flag1 || this.field_70139_V < 0.05F) && (d6 != offsetX || d8 != offsetZ)) {
/*     */         
/* 386 */         double d9 = offsetX;
/* 387 */         double d1 = offsetY;
/* 388 */         double d2 = offsetZ;
/* 389 */         offsetX = d6;
/* 390 */         offsetY = this.field_70138_W;
/* 391 */         offsetZ = d8;
/* 392 */         AxisAlignedBB axisalignedbb1 = this.field_70121_D.func_72329_c();
/* 393 */         this.field_70121_D.func_72328_c(axisalignedbb);
/* 394 */         list = getCollidingBoundingBoxes(this.field_70121_D.func_72321_a(d6, offsetY, d8));
/*     */         int k;
/* 396 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 398 */           offsetY = ((AxisAlignedBB)list.get(k)).func_72323_b(this.field_70121_D, offsetY);
/*     */         }
/*     */         
/* 401 */         this.field_70121_D.func_72317_d(0.0D, offsetY, 0.0D);
/*     */         
/* 403 */         if (!this.field_70135_K && d7 != offsetY) {
/*     */           
/* 405 */           offsetZ = 0.0D;
/* 406 */           offsetY = 0.0D;
/* 407 */           offsetX = 0.0D;
/*     */         } 
/*     */         
/* 410 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 412 */           offsetX = ((AxisAlignedBB)list.get(k)).func_72316_a(this.field_70121_D, offsetX);
/*     */         }
/*     */         
/* 415 */         this.field_70121_D.func_72317_d(offsetX, 0.0D, 0.0D);
/*     */         
/* 417 */         if (!this.field_70135_K && d6 != offsetX) {
/*     */           
/* 419 */           offsetZ = 0.0D;
/* 420 */           offsetY = 0.0D;
/* 421 */           offsetX = 0.0D;
/*     */         } 
/*     */         
/* 424 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 426 */           offsetZ = ((AxisAlignedBB)list.get(k)).func_72322_c(this.field_70121_D, offsetZ);
/*     */         }
/*     */         
/* 429 */         this.field_70121_D.func_72317_d(0.0D, 0.0D, offsetZ);
/*     */         
/* 431 */         if (!this.field_70135_K && d8 != offsetZ) {
/*     */           
/* 433 */           offsetZ = 0.0D;
/* 434 */           offsetY = 0.0D;
/* 435 */           offsetX = 0.0D;
/*     */         } 
/*     */         
/* 438 */         if (!this.field_70135_K && d7 != offsetY) {
/*     */           
/* 440 */           offsetZ = 0.0D;
/* 441 */           offsetY = 0.0D;
/* 442 */           offsetX = 0.0D;
/*     */         }
/*     */         else {
/*     */           
/* 446 */           offsetY = -this.field_70138_W;
/*     */           
/* 448 */           for (k = 0; k < list.size(); k++)
/*     */           {
/* 450 */             offsetY = ((AxisAlignedBB)list.get(k)).func_72323_b(this.field_70121_D, offsetY);
/*     */           }
/*     */           
/* 453 */           this.field_70121_D.func_72317_d(0.0D, offsetY, 0.0D);
/*     */         } 
/*     */         
/* 456 */         if (d9 * d9 + d2 * d2 >= offsetX * offsetX + offsetZ * offsetZ) {
/*     */           
/* 458 */           offsetX = d9;
/* 459 */           offsetY = d1;
/* 460 */           offsetZ = d2;
/* 461 */           this.field_70121_D.func_72328_c(axisalignedbb1);
/*     */         } 
/*     */       } 
/*     */       
/* 465 */       this.field_70170_p.field_72984_F.func_76319_b();
/* 466 */       this.field_70170_p.field_72984_F.func_76320_a("rest");
/* 467 */       this.field_70165_t = (this.field_70121_D.field_72340_a + this.field_70121_D.field_72336_d) / 2.0D;
/* 468 */       this.field_70163_u = this.field_70121_D.field_72338_b + this.field_70129_M - this.field_70139_V;
/* 469 */       this.field_70161_v = (this.field_70121_D.field_72339_c + this.field_70121_D.field_72334_f) / 2.0D;
/* 470 */       this.field_70123_F = (d6 != offsetX || d8 != offsetZ);
/* 471 */       this.field_70124_G = (d7 != offsetY);
/* 472 */       this.field_70122_E = (d7 != offsetY && d7 < 0.0D);
/* 473 */       this.field_70132_H = (this.field_70123_F || this.field_70124_G);
/*     */       
/* 475 */       if (d6 != offsetX)
/*     */       {
/* 477 */         this.field_70159_w = 0.0D;
/*     */       }
/*     */       
/* 480 */       if (d7 != offsetY)
/*     */       {
/* 482 */         this.field_70181_x = 0.0D;
/*     */       }
/*     */       
/* 485 */       if (d8 != offsetZ)
/*     */       {
/* 487 */         this.field_70179_y = 0.0D;
/*     */       }
/*     */       
/* 490 */       double d12 = this.field_70165_t - d3;
/* 491 */       double d10 = this.field_70163_u - d4;
/* 492 */       double d11 = this.field_70161_v - d5;
/*     */       
/* 494 */       this.field_70170_p.field_72984_F.func_76319_b();
/*     */     }
/*     */     else {
/*     */       
/* 498 */       super.func_70091_d(offsetX, offsetY, offsetZ);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List getCollidingBoundingBoxes(AxisAlignedBB aabb) {
/* 504 */     World world = this.field_70170_p;
/* 505 */     List<AxisAlignedBB> collidingBoundingBoxes = Lists.newArrayList();
/*     */     
/* 507 */     int minX = MathHelper.func_76128_c(aabb.field_72340_a);
/* 508 */     int maxX = MathHelper.func_76128_c(aabb.field_72336_d + 1.0D);
/* 509 */     int minY = MathHelper.func_76128_c(aabb.field_72338_b);
/* 510 */     int maxY = MathHelper.func_76128_c(aabb.field_72337_e + 1.0D);
/* 511 */     int minZ = MathHelper.func_76128_c(aabb.field_72339_c);
/* 512 */     int maxZ = MathHelper.func_76128_c(aabb.field_72334_f + 1.0D);
/*     */     
/* 514 */     for (int x = minX; x < maxX; x++) {
/*     */       
/* 516 */       for (int z = minZ; z < maxZ; z++) {
/*     */         
/* 518 */         if (world.func_72899_e(x, 64, z))
/*     */         {
/* 520 */           for (int y = minY - 1; y < maxY; y++) {
/*     */             Block block;
/*     */ 
/*     */             
/* 524 */             if (x >= -30000000 && x < 30000000 && z >= -30000000 && z < 30000000) {
/*     */               
/* 526 */               block = world.func_147439_a(x, y, z);
/*     */             }
/*     */             else {
/*     */               
/* 530 */               block = Blocks.field_150348_b;
/*     */             } 
/*     */             
/* 533 */             if (y <= minY)
/*     */             {
/* 535 */               block.func_149743_a(world, x, y, z, aabb, collidingBoundingBoxes, (Entity)this);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 542 */     double d0 = 0.25D;
/* 543 */     List<Entity> list = world.func_72839_b((Entity)this, aabb.func_72314_b(d0, d0, d0));
/*     */     
/* 545 */     for (Entity entity : list) {
/*     */       
/* 547 */       AxisAlignedBB aabb1 = entity.func_70046_E();
/*     */       
/* 549 */       if (aabb1 != null && aabb1.func_72326_a(aabb))
/*     */       {
/* 551 */         collidingBoundingBoxes.add(aabb1);
/*     */       }
/*     */       
/* 554 */       aabb1 = func_70114_g(entity);
/*     */       
/* 556 */       if (aabb1 != null && aabb1.func_72326_a(aabb))
/*     */       {
/* 558 */         collidingBoundingBoxes.add(aabb1);
/*     */       }
/*     */     } 
/*     */     
/* 562 */     return collidingBoundingBoxes;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\EntitySithGhost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */