/*     */ package com.fiskmods.lightsabers.common.entity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
/*     */ import fiskfille.utils.common.entity.attribute.AttributeWrapper;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityThrowable;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class EntityLightsaber
/*     */   extends EntityThrowable
/*     */   implements IEntityAdditionalSpawnData
/*     */ {
/*     */   private ItemStack lightsaber;
/*     */   private int amplifier;
/*     */   public Object data;
/*     */   
/*     */   public EntityLightsaber(World world, EntityLivingBase entity, ItemStack itemstack, int amplifier) {
/*  42 */     super(world, entity);
/*  43 */     this.amplifier = amplifier;
/*  44 */     setItem(itemstack);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityLightsaber(World world) {
/*  49 */     super(world);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  55 */     super.func_70088_a();
/*  56 */     this.field_70180_af.func_75682_a(2, Byte.valueOf((byte)0));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getShouldReturn() {
/*  61 */     return (this.field_70180_af.func_75683_a(2) > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShouldReturn(boolean flag) {
/*  66 */     this.field_70180_af.func_75692_b(2, Byte.valueOf((byte)(flag ? 1 : 0)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack getItem() {
/*  71 */     return this.lightsaber;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItem(ItemStack itemstack) {
/*  76 */     this.lightsaber = itemstack;
/*  77 */     this.data = null;
/*     */     
/*  79 */     if (itemstack != null)
/*     */     {
/*  81 */       if (itemstack.func_77973_b() == ModItems.doubleLightsaber) {
/*     */         
/*  83 */         func_70105_a(3.15F / (2 - this.amplifier), 0.0625F);
/*  84 */         this.data = ItemDoubleLightsaber.get(itemstack);
/*     */       }
/*     */       else {
/*     */         
/*  88 */         func_70105_a(2.0F / (2 - this.amplifier), 0.0625F);
/*  89 */         this.data = LightsaberData.get(itemstack);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected float func_70185_h() {
/*  97 */     return 0.01F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected float func_70182_d() {
/* 103 */     return 2.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound nbt) {
/* 109 */     super.func_70014_b(nbt);
/*     */     
/* 111 */     if (getItem() != null)
/*     */     {
/* 113 */       nbt.func_74782_a("Item", (NBTBase)getItem().func_77955_b(new NBTTagCompound()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound nbt) {
/* 120 */     super.func_70037_a(nbt);
/* 121 */     setItem(ItemStack.func_77949_a(nbt.func_74775_l("LightsaberItem")));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 127 */     this.field_70142_S = this.field_70165_t;
/* 128 */     this.field_70137_T = this.field_70163_u;
/* 129 */     this.field_70136_U = this.field_70161_v;
/* 130 */     this.field_70169_q = this.field_70165_t;
/* 131 */     this.field_70167_r = this.field_70163_u;
/* 132 */     this.field_70166_s = this.field_70161_v;
/*     */     
/* 134 */     if (!this.field_70170_p.field_72995_K) {
/*     */       
/* 136 */       EntityLivingBase thrower = func_85052_h();
/*     */       
/* 138 */       if (thrower == null || !thrower.func_70089_S()) {
/*     */         
/* 140 */         if (!(thrower instanceof EntitySithGhost))
/*     */         {
/* 142 */           dropItem((Entity)this);
/*     */         }
/*     */         
/* 145 */         func_70106_y();
/*     */         
/*     */         return;
/*     */       } 
/* 149 */       if (this.field_70173_aa % 3 == 0)
/*     */       {
/* 151 */         this.field_70170_p.func_72956_a((Entity)this, (thrower instanceof EntityPlayer) ? ALSounds.player_lightsaber_swing : ALSounds.mob_lightsaber_swing, 1.0F, 1.0F);
/*     */       }
/*     */       
/* 154 */       if (this.field_70173_aa > 20)
/*     */       {
/* 156 */         setShouldReturn(true);
/*     */       }
/*     */       
/* 159 */       if (thrower != null && getShouldReturn())
/*     */       {
/* 161 */         if (func_70032_d((Entity)thrower) <= 2.0F) {
/*     */           
/* 163 */           if (thrower instanceof EntityPlayer) {
/*     */             
/* 165 */             EntityPlayer player = (EntityPlayer)thrower;
/*     */             
/* 167 */             if (player.field_71071_by.func_70448_g() == null)
/*     */             {
/* 169 */               player.func_70062_b(0, getItem());
/*     */             }
/* 171 */             else if (!player.field_71071_by.func_70441_a(getItem()))
/*     */             {
/* 173 */               dropItem((Entity)player);
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 178 */             thrower.func_70062_b(0, getItem());
/*     */           } 
/*     */           
/* 181 */           func_70106_y();
/*     */         }
/*     */         else {
/*     */           
/* 185 */           Vec3 vec3 = Vec3.func_72443_a(thrower.field_70165_t - this.field_70165_t, thrower.field_70163_u - this.field_70163_u + thrower.field_70131_O * 0.6D, thrower.field_70161_v - this.field_70161_v).func_72432_b();
/* 186 */           double d = 2.0D;
/*     */           
/* 188 */           this.field_70159_w = vec3.field_72450_a * d;
/* 189 */           this.field_70181_x = vec3.field_72448_b * d;
/* 190 */           this.field_70179_y = vec3.field_72449_c * d;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 195 */     if (!getShouldReturn()) {
/*     */       
/* 197 */       super.func_70071_h_();
/*     */     }
/*     */     else {
/*     */       
/* 201 */       func_70030_z();
/*     */       
/* 203 */       Vec3 pos = Vec3.func_72443_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/* 204 */       Vec3 nextPos = Vec3.func_72443_a(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
/* 205 */       MovingObjectPosition mop = this.field_70170_p.func_72933_a(pos, nextPos);
/*     */       
/* 207 */       pos = Vec3.func_72443_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/* 208 */       nextPos = Vec3.func_72443_a(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
/*     */       
/* 210 */       if (mop != null)
/*     */       {
/* 212 */         nextPos = Vec3.func_72443_a(mop.field_72307_f.field_72450_a, mop.field_72307_f.field_72448_b, mop.field_72307_f.field_72449_c);
/*     */       }
/*     */       
/* 215 */       if (!this.field_70170_p.field_72995_K) {
/*     */         
/* 217 */         Entity entity = null;
/* 218 */         List<Entity> list = this.field_70170_p.func_72839_b((Entity)this, this.field_70121_D.func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_72314_b(1.0D, 1.0D, 1.0D));
/* 219 */         double minDist = 0.0D;
/*     */         
/* 221 */         for (int i = 0; i < list.size(); i++) {
/*     */           
/* 223 */           Entity entity1 = list.get(i);
/*     */           
/* 225 */           if (entity1.func_70067_L() && (entity1 != func_85052_h() || this.field_70173_aa >= 5)) {
/*     */             
/* 227 */             AxisAlignedBB aabb = entity1.field_70121_D.func_72314_b(0.30000001192092896D, 0.30000001192092896D, 0.30000001192092896D);
/* 228 */             MovingObjectPosition mop1 = aabb.func_72327_a(pos, nextPos);
/*     */             
/* 230 */             if (mop1 != null) {
/*     */               
/* 232 */               double dist = pos.func_72438_d(mop1.field_72307_f);
/*     */               
/* 234 */               if (dist < minDist || minDist == 0.0D) {
/*     */                 
/* 236 */                 entity = entity1;
/* 237 */                 minDist = dist;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 243 */         if (entity != null)
/*     */         {
/* 245 */           mop = new MovingObjectPosition(entity);
/*     */         }
/*     */       } 
/*     */       
/* 249 */       if (mop != null)
/*     */       {
/* 251 */         if (mop.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK && this.field_70170_p.func_147439_a(mop.field_72311_b, mop.field_72312_c, mop.field_72309_d) == Blocks.field_150427_aO) {
/*     */           
/* 253 */           func_70063_aa();
/*     */         }
/*     */         else {
/*     */           
/* 257 */           func_70184_a(mop);
/*     */         } 
/*     */       }
/*     */       
/* 261 */       float motion = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
/* 262 */       this.field_70177_z = (float)(Math.atan2(this.field_70159_w, this.field_70179_y) * 180.0D / Math.PI);
/*     */       
/* 264 */       for (this.field_70125_A = (float)(Math.atan2(this.field_70181_x, motion) * 180.0D / Math.PI); this.field_70125_A - this.field_70127_C < -180.0F; this.field_70127_C -= 360.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 269 */       while (this.field_70125_A - this.field_70127_C >= 180.0F)
/*     */       {
/* 271 */         this.field_70127_C += 360.0F;
/*     */       }
/*     */       
/* 274 */       while (this.field_70177_z - this.field_70126_B < -180.0F)
/*     */       {
/* 276 */         this.field_70126_B -= 360.0F;
/*     */       }
/*     */       
/* 279 */       while (this.field_70177_z - this.field_70126_B >= 180.0F)
/*     */       {
/* 281 */         this.field_70126_B += 360.0F;
/*     */       }
/*     */       
/* 284 */       this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
/* 285 */       this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
/* 286 */       this.field_70165_t += this.field_70159_w;
/* 287 */       this.field_70163_u += this.field_70181_x;
/* 288 */       this.field_70161_v += this.field_70179_y;
/*     */       
/* 290 */       if (func_70090_H())
/*     */       {
/* 292 */         for (int i = 0; i < 4; i++) {
/*     */           
/* 294 */           float f = 0.25F;
/* 295 */           this.field_70170_p.func_72869_a("bubble", this.field_70165_t - this.field_70159_w * f, this.field_70163_u - this.field_70181_x * f, this.field_70161_v - this.field_70179_y * f, this.field_70159_w, this.field_70181_x, this.field_70179_y);
/*     */         } 
/*     */       }
/*     */       
/* 299 */       func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dropItem(Entity location) {
/* 305 */     EntityItem item = new EntityItem(this.field_70170_p);
/* 306 */     item.func_70012_b(location.field_70165_t, location.field_70163_u, location.field_70161_v, 0.0F, 0.0F);
/* 307 */     item.func_92058_a(this.lightsaber);
/* 308 */     this.field_70170_p.func_72838_d((Entity)item);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70184_a(MovingObjectPosition mop) {
/* 314 */     EntityLivingBase thrower = func_85052_h();
/*     */     
/* 316 */     if (thrower != null) {
/*     */       
/* 318 */       if (thrower instanceof EntitySithGhost && mop.field_72308_g instanceof EntitySithGhost) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 323 */       if (mop.field_72308_g != null && mop.field_72308_g != thrower) {
/*     */         
/* 325 */         if (this.lightsaber != null)
/*     */         {
/* 327 */           Collection<AttributeModifier> c = this.lightsaber.func_111283_C().get(SharedMonsterAttributes.field_111264_e.func_111108_a());
/* 328 */           AttributeWrapper wrapper = new AttributeWrapper(SharedMonsterAttributes.field_111264_e);
/*     */           
/* 330 */           if (!c.isEmpty()) {
/*     */             
/* 332 */             Iterator<AttributeModifier> iterator = c.iterator();
/*     */             
/* 334 */             while (iterator.hasNext()) {
/*     */               
/* 336 */               AttributeModifier modifier = iterator.next();
/* 337 */               wrapper.apply(modifier.func_111164_d(), modifier.func_111169_c());
/*     */             } 
/*     */           } 
/*     */           
/* 341 */           float damage = wrapper.getValue(1.0F);
/*     */           
/* 343 */           if (damage > 0.0F)
/*     */           {
/* 345 */             mop.field_72308_g.func_70097_a(ALDamageSources.causeLightsaberDamage((Entity)thrower), damage);
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 351 */         setShouldReturn(true);
/* 352 */         this.field_70181_x += 0.2D;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeSpawnData(ByteBuf buffer) {
/* 360 */     ByteBufUtils.writeItemStack(buffer, getItem());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readSpawnData(ByteBuf buffer) {
/* 366 */     setItem(ByteBufUtils.readItemStack(buffer));
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\EntityLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */