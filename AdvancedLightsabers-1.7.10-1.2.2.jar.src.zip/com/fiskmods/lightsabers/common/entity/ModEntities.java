/*    */ package com.fiskmods.lightsabers.common.entity;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import cpw.mods.fml.common.registry.EntityRegistry;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ public class ModEntities
/*    */ {
/* 10 */   private static int nextID = -1;
/*    */ 
/*    */   
/*    */   public static void register() {
/* 14 */     registerEntity((Class)EntityLightsaber.class, "Lightsaber", 64, 10, true);
/* 15 */     registerEntityWithEgg((Class)EntitySithGhost.class, "SithGhost", 80, 1, true, 2171169, 14864078);
/*    */   }
/*    */ 
/*    */   
/*    */   private static void registerEntity(Class<? extends Entity> entityClass, String name, int trackingRange, int updateFrequency, boolean sendVelocityUpdates) {
/* 20 */     EntityRegistry.registerModEntity(entityClass, name, ++nextID, Lightsabers.instance, trackingRange, updateFrequency, sendVelocityUpdates);
/*    */   }
/*    */ 
/*    */   
/*    */   private static void registerEntityWithEgg(Class<? extends Entity> entityClass, String name, int trackingRange, int updateFrequency, boolean sendVelocityUpdates, int primary, int secondary) {
/* 25 */     EntityRegistry.registerGlobalEntityID(entityClass, "lightsabers." + name, EntityRegistry.findGlobalUniqueEntityId(), primary, secondary);
/* 26 */     registerEntity(entityClass, name, trackingRange, updateFrequency, sendVelocityUpdates);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\entity\ModEntities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */