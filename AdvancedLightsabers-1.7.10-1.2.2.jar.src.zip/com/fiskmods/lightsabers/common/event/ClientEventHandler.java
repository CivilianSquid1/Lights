/*     */ package com.fiskmods.lightsabers.common.event;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.client.sound.SoundAL;
/*     */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.ALPlayerData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*     */ import com.fiskmods.lightsabers.common.force.PowerType;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffect;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectActive;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.google.common.collect.Maps;
/*     */ import cpw.mods.fml.client.event.ConfigChangedEvent;
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.RenderLivingEvent;
/*     */ import net.minecraftforge.client.event.RenderPlayerEvent;
/*     */ import net.minecraftforge.client.event.sound.PlaySoundEvent17;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientEventHandler
/*     */ {
/*  56 */   private Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static float renderTick;
/*  59 */   private Map<String, ItemStack> prevLightsaber1 = Maps.newHashMap();
/*  60 */   private Map<String, Boolean> hasPlayedSound = Maps.newHashMap();
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
/*  65 */     if (event.modID.equals("lightsabers")) {
/*     */       
/*  67 */       ModConfig.load(ModConfig.configFile);
/*  68 */       ModConfig.configFile.save();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
/*  75 */     EntityLivingBase entity = event.entityLiving;
/*  76 */     ItemStack itemstack = entity.func_70694_bm();
/*  77 */     World world = entity.field_70170_p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerTick(TickEvent.PlayerTickEvent event) {
/* 108 */     EntityPlayer player = event.player;
/* 109 */     World world = player.field_70170_p;
/* 110 */     ALPlayerData data = ALPlayerData.getData(player);
/*     */     
/* 112 */     if (event.phase == TickEvent.Phase.END)
/*     */     {
/* 114 */       if (player == this.mc.field_71439_g) {
/*     */         
/* 116 */         InventoryPlayer inventory = player.field_71071_by;
/* 117 */         ItemStack lightsaber = null;
/*     */         
/* 119 */         for (int i = 0; i < inventory.field_70462_a.length; i++) {
/*     */           
/* 121 */           if (inventory.field_70462_a[i] != null && inventory.field_70462_a[i].func_77973_b() == ModItems.lightsaber) {
/*     */             
/* 123 */             lightsaber = inventory.field_70462_a[i];
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 128 */         ALData.LIGHTSABER.set(player, LightsaberData.get(lightsaber));
/*     */         
/* 130 */         Power power = PowerManager.getSelectedPower(player);
/* 131 */         boolean flag = false;
/*     */         
/* 133 */         if (power != null && ((Integer)ALData.USE_POWER_COOLDOWN.get((Entity)player)).intValue() == 0 && ALHelper.getForcePowerMax(player) > 0 && power.powerStats.powerType == PowerType.PER_SECOND)
/*     */         {
/* 135 */           if (this.mc.field_71462_r == null && GameSettings.func_100015_a((KeyBinding)ALKeyBinds.ACTIVATE_POWER))
/*     */           {
/* 137 */             flag = (((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue() >= power.getUseCost(player));
/*     */           }
/*     */         }
/*     */         
/* 141 */         if (!flag && ((Boolean)ALData.USING_POWER.get((Entity)player)).booleanValue())
/*     */         {
/* 143 */           ALData.USE_POWER_COOLDOWN.set(player, Integer.valueOf(20));
/*     */         }
/*     */         
/* 146 */         ALData.USING_POWER.set(player, Boolean.valueOf(flag));
/* 147 */         flag = false;
/*     */         
/* 149 */         if (ModConfig.enableShaders)
/*     */         {
/* 151 */           if (StatusEffect.get((EntityLivingBase)player, Effect.GAZE) != null) {
/*     */             
/* 153 */             ALRenderHelper.startShaders(ALRenderHelper.SHADER_BLUE);
/* 154 */             flag = true;
/*     */           }
/* 156 */           else if (StatusEffect.get((EntityLivingBase)player, Effect.STEALTH) != null) {
/*     */             
/* 158 */             ALRenderHelper.startShaders(ALRenderHelper.SHADER_GRAY);
/* 159 */             flag = true;
/*     */           }
/* 161 */           else if (StatusEffect.get((EntityLivingBase)player, Effect.SPEED) != null) {
/*     */             
/* 163 */             ALRenderHelper.startShaders(ALRenderHelper.SHADER_BLUR);
/* 164 */             flag = true;
/*     */           } 
/*     */         }
/*     */         
/* 168 */         if (!flag && this.mc.field_71460_t.func_147706_e() != null) {
/*     */           
/* 170 */           String s = this.mc.field_71460_t.func_147706_e().func_148022_b();
/* 171 */           ResourceLocation[] shaders = { ALRenderHelper.SHADER_BLUE, ALRenderHelper.SHADER_GRAY, ALRenderHelper.SHADER_BLUR };
/*     */           
/* 173 */           for (ResourceLocation shader : shaders) {
/*     */             
/* 175 */             if (s.equals(shader.toString()))
/*     */             {
/* 177 */               ALRenderHelper.stopShaders();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderPlayerSpecialsPre(RenderPlayerEvent.Specials.Pre event) {
/* 189 */     EntityPlayer player = event.entityPlayer;
/* 190 */     LightsaberData data = (LightsaberData)ALData.LIGHTSABER.get((Entity)player);
/*     */     
/* 192 */     if (data != null && data != LightsaberData.EMPTY && (player.func_70694_bm() == null || player.func_70694_bm().func_77973_b() != ModItems.lightsaber)) {
/*     */       
/* 194 */       GL11.glPushMatrix();
/* 195 */       event.renderer.field_77109_a.field_78115_e.func_78794_c(0.0625F);
/* 196 */       GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 197 */       GL11.glTranslatef(0.2F, -0.55F, 0.15F);
/* 198 */       GL11.glRotatef(15.0F, 0.0F, 0.0F, 1.0F);
/* 199 */       GL11.glRotatef(10.0F, 1.0F, 0.0F, 0.0F);
/*     */       
/* 201 */       float scale = 0.15F;
/* 202 */       GL11.glScalef(scale, scale, scale);
/* 203 */       GL11.glTranslatef(0.0F, -((data.getPart(PartType.BODY)).height + (data.getPart(PartType.POMMEL)).height / 2.0F) * 0.0625F, 0.0F);
/* 204 */       ALRenderHelper.renderLightsaberHilt(data);
/* 205 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 208 */     for (StatusEffect status : StatusEffect.get((EntityLivingBase)player)) {
/*     */       
/* 210 */       Power power = status.effect.getPower(status.amplifier);
/* 211 */       PowerEffect powerEffect = power.powerEffect;
/*     */       
/* 213 */       if (powerEffect instanceof PowerEffectActive)
/*     */       {
/* 215 */         ((PowerEffectActive)powerEffect).render(player, event.partialRenderTick);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onRenderLivingSpecialsPre(RenderLivingEvent.Pre event) {
/* 223 */     EntityLivingBase entity = event.entity;
/* 224 */     StatusEffect effectStun = StatusEffect.get(entity, Effect.STUN);
/*     */     
/* 226 */     if (effectStun != null) {
/*     */       
/* 228 */       boolean prevLighting = GL11.glGetBoolean(2896);
/* 229 */       boolean prevTex2D = GL11.glGetBoolean(3553);
/* 230 */       boolean prevBlend = GL11.glGetBoolean(3042);
/* 231 */       float prevWidth = GL11.glGetFloat(2849);
/*     */       
/* 233 */       GL11.glPushMatrix();
/* 234 */       GL11.glTranslated(event.x, event.y + (entity.field_70131_O / 2.0F), event.z);
/* 235 */       Tessellator tessellator = Tessellator.field_78398_a;
/*     */       
/* 237 */       ALRenderHelper.setLighting(61680);
/* 238 */       GL11.glLineWidth(5.0F);
/* 239 */       GL11.glDepthMask(false);
/* 240 */       GL11.glDisable(3553);
/* 241 */       GL11.glDisable(2896);
/* 242 */       GL11.glEnable(3042);
/* 243 */       GL11.glAlphaFunc(516, 0.99F);
/* 244 */       GL11.glDisable(3008);
/* 245 */       GL11.glBlendFunc(770, 32772);
/*     */       
/* 247 */       float f = entity.field_70173_aa + renderTick;
/* 248 */       float range = Math.max(entity.field_70130_N, entity.field_70131_O) * 0.75F;
/* 249 */       float angleIncr = 10.0F;
/* 250 */       float coverage = 90.0F;
/* 251 */       int amount = 8;
/* 252 */       float spread = 8.0F;
/*     */       
/* 254 */       for (int i = 0; i < 2; i++) {
/*     */         
/* 256 */         for (int j = -amount; j <= amount; j++) {
/*     */           
/* 258 */           for (int k = -amount; k <= amount; k++) {
/*     */             
/* 260 */             GL11.glPushMatrix();
/*     */             
/* 262 */             if (i == 0)
/*     */             {
/* 264 */               GL11.glScalef(-1.0F, -1.0F, -1.0F);
/*     */             }
/*     */             
/* 267 */             tessellator.func_78371_b(3);
/* 268 */             tessellator.func_78370_a(54, 84, 181, (int)(50.0F * Math.min((effectStun.duration - renderTick) / 20.0F, 1.0F)));
/*     */             
/* 270 */             for (int l = 0; l <= coverage / angleIncr; l++) {
/*     */               
/* 272 */               Vec3 vec3 = Vec3.func_72443_a(0.0D, range, 0.0D);
/* 273 */               float pitch = l * angleIncr;
/* 274 */               float yaw = 180.0F + j * spread + MathHelper.func_76126_a(f / 10.0F) * 100.0F;
/* 275 */               float roll = k * spread + MathHelper.func_76134_b(f / 10.0F) * 100.0F;
/* 276 */               vec3.func_72440_a(-pitch * 3.1415927F / 180.0F);
/* 277 */               vec3.func_72442_b(-yaw * 3.1415927F / 180.0F);
/* 278 */               vec3.func_72446_c(-roll * 3.1415927F / 180.0F);
/* 279 */               tessellator.func_78377_a(vec3.field_72450_a, vec3.field_72448_b, vec3.field_72449_c);
/*     */             } 
/*     */             
/* 282 */             tessellator.func_78381_a();
/* 283 */             GL11.glPopMatrix();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 288 */       GL11.glLineWidth(prevWidth);
/* 289 */       GL11.glAlphaFunc(516, 0.1F);
/* 290 */       GL11.glEnable(3008);
/* 291 */       GL11.glDepthMask(true);
/*     */       
/* 293 */       if (prevLighting)
/*     */       {
/* 295 */         GL11.glEnable(2896);
/*     */       }
/*     */       
/* 298 */       if (prevTex2D)
/*     */       {
/* 300 */         GL11.glEnable(3553);
/*     */       }
/*     */       
/* 303 */       if (!prevBlend)
/*     */       {
/* 305 */         GL11.glDisable(3042);
/*     */       }
/*     */       
/* 308 */       ALRenderHelper.resetLighting();
/* 309 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onRenderLivingPre(RenderLivingEvent.Pre event) {
/* 316 */     EntityLivingBase entity = event.entity;
/* 317 */     StatusEffect effectGaze = StatusEffect.get((EntityLivingBase)this.mc.field_71439_g, Effect.GAZE);
/* 318 */     StatusEffect effectMeditation = StatusEffect.get(entity, Effect.MEDITATION);
/* 319 */     StatusEffect effectEnergyResist = StatusEffect.get(entity, Effect.RESIST);
/*     */     
/* 321 */     if (StatusEffect.get(entity, Effect.STEALTH) != null && (effectGaze == null || !ALRenderHelper.canGazeEntity((EntityPlayer)this.mc.field_71439_g, entity, effectGaze.amplifier))) {
/*     */       
/* 323 */       event.setCanceled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 327 */     boolean flag1 = false;
/* 328 */     float f5 = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * renderTick;
/*     */     
/* 330 */     if (entity != this.mc.field_71439_g && entity != this.mc.field_71439_g.field_70154_o && effectGaze != null && ALRenderHelper.canGazeEntity((EntityPlayer)this.mc.field_71439_g, entity, effectGaze.amplifier))
/*     */     {
/* 332 */       if (entity.field_70138_W > 0.0F) {
/*     */         
/* 334 */         int i = effectGaze.duration;
/* 335 */         float f = (i > 100) ? 1.0F : (0.2F + MathHelper.func_76126_a((i - renderTick) * 3.1415927F * 0.2F) * 0.2F);
/* 336 */         boolean prevLighting = GL11.glGetBoolean(2896);
/* 337 */         boolean flag = entity.func_82150_aj();
/* 338 */         entity.field_70138_W = -entity.field_70138_W;
/* 339 */         entity.func_82142_c(false);
/*     */         
/* 341 */         ALRenderHelper.setLighting(61680);
/*     */         
/* 343 */         if (!flag1) {
/*     */           
/* 345 */           RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 346 */           flag1 = true;
/*     */         } 
/*     */         
/* 349 */         GL11.glPushMatrix();
/* 350 */         GL11.glDepthMask(false);
/* 351 */         GL11.glDisable(2896);
/* 352 */         GL11.glEnable(3042);
/* 353 */         GL11.glDisable(3553);
/* 354 */         GL11.glAlphaFunc(516, 0.01F);
/* 355 */         GL11.glDisable(3008);
/* 356 */         GL11.glBlendFunc(770, 32772);
/* 357 */         GL11.glDisable(2929);
/* 358 */         GL11.glDepthFunc(514);
/*     */         
/* 360 */         if (flag) {
/*     */           
/* 362 */           GL11.glColor4f(1.0F, 0.0F, 1.0F, f);
/*     */         }
/*     */         else {
/*     */           
/* 366 */           GL11.glColor4f(1.0F, 0.0F, 0.0F, f);
/*     */         } 
/*     */         
/* 369 */         ALRenderHelper.overrideColor(true);
/* 370 */         RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 371 */         ALRenderHelper.overrideColor(false);
/* 372 */         GL11.glDepthFunc(515);
/* 373 */         GL11.glDisable(32826);
/* 374 */         GL11.glAlphaFunc(516, 0.1F);
/* 375 */         GL11.glEnable(3008);
/* 376 */         GL11.glBlendFunc(770, 771);
/* 377 */         GL11.glEnable(3553);
/* 378 */         GL11.glDisable(3042);
/* 379 */         GL11.glEnable(2929);
/* 380 */         GL11.glDepthMask(true);
/* 381 */         entity.func_82142_c(flag);
/* 382 */         ALRenderHelper.resetLighting();
/*     */         
/* 384 */         if (prevLighting)
/*     */         {
/* 386 */           GL11.glEnable(2896);
/*     */         }
/*     */         
/* 389 */         GL11.glPopMatrix();
/* 390 */         entity.field_70138_W = -entity.field_70138_W;
/* 391 */         event.setCanceled(true);
/*     */       } 
/*     */     }
/*     */     
/* 395 */     if (effectMeditation != null && !entity.func_98034_c((EntityPlayer)this.mc.field_71439_g))
/*     */     {
/* 397 */       if (entity.field_70138_W > 0.0F) {
/*     */         
/* 399 */         int i = effectMeditation.duration;
/* 400 */         float f = 0.7F + MathHelper.func_76126_a((i - renderTick) * 3.1415927F * 0.1F) * 0.3F;
/* 401 */         boolean prevLighting = GL11.glGetBoolean(2896);
/* 402 */         entity.field_70138_W = -entity.field_70138_W;
/*     */         
/* 404 */         ALRenderHelper.setLighting(61680);
/*     */         
/* 406 */         if (!flag1) {
/*     */           
/* 408 */           RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 409 */           flag1 = true;
/*     */         } 
/*     */         
/* 412 */         GL11.glPushMatrix();
/* 413 */         GL11.glDepthMask(false);
/* 414 */         GL11.glDisable(2896);
/* 415 */         GL11.glEnable(3042);
/* 416 */         GL11.glDisable(3553);
/* 417 */         GL11.glAlphaFunc(516, 0.01F);
/* 418 */         GL11.glDisable(3008);
/* 419 */         GL11.glBlendFunc(770, 32772);
/* 420 */         GL11.glDepthFunc(514);
/* 421 */         GL11.glColor4f(1.0F, 0.5F, 0.0F, f);
/* 422 */         ALRenderHelper.overrideColor(true);
/* 423 */         RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 424 */         ALRenderHelper.overrideColor(false);
/* 425 */         GL11.glDepthFunc(515);
/* 426 */         GL11.glDisable(32826);
/* 427 */         GL11.glAlphaFunc(516, 0.1F);
/* 428 */         GL11.glEnable(3008);
/* 429 */         GL11.glBlendFunc(770, 771);
/* 430 */         GL11.glEnable(3553);
/* 431 */         GL11.glDisable(3042);
/* 432 */         GL11.glDepthMask(true);
/* 433 */         ALRenderHelper.resetLighting();
/*     */         
/* 435 */         if (prevLighting)
/*     */         {
/* 437 */           GL11.glEnable(2896);
/*     */         }
/*     */         
/* 440 */         GL11.glPopMatrix();
/* 441 */         entity.field_70138_W = -entity.field_70138_W;
/* 442 */         event.setCanceled(true);
/*     */       } 
/*     */     }
/*     */     
/* 446 */     if (effectEnergyResist != null && !entity.func_98034_c((EntityPlayer)this.mc.field_71439_g))
/*     */     {
/* 448 */       if (entity.field_70138_W > 0.0F) {
/*     */         
/* 450 */         int i = effectEnergyResist.duration;
/* 451 */         float f = 0.7F + MathHelper.func_76126_a((i - renderTick) * 3.1415927F * 0.1F) * 0.3F;
/* 452 */         boolean prevLighting = GL11.glGetBoolean(2896);
/* 453 */         entity.field_70138_W = -entity.field_70138_W;
/*     */         
/* 455 */         ALRenderHelper.setLighting(61680);
/*     */         
/* 457 */         if (!flag1) {
/*     */           
/* 459 */           RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 460 */           flag1 = true;
/*     */         } 
/*     */         
/* 463 */         GL11.glPushMatrix();
/* 464 */         GL11.glDepthMask(false);
/* 465 */         GL11.glDisable(2896);
/* 466 */         GL11.glEnable(3042);
/* 467 */         GL11.glDisable(3553);
/* 468 */         GL11.glAlphaFunc(516, 0.01F);
/* 469 */         GL11.glDisable(3008);
/* 470 */         GL11.glBlendFunc(770, 32772);
/* 471 */         GL11.glDepthFunc(514);
/* 472 */         GL11.glColor4f(0.0F, 0.5F, 1.0F, f);
/* 473 */         ALRenderHelper.overrideColor(true);
/* 474 */         RenderManager.field_78727_a.func_147940_a((Entity)entity, event.x, event.y + ((entity == this.mc.field_71439_g) ? entity.field_70129_M : 0.0F), event.z, f5, renderTick);
/* 475 */         ALRenderHelper.overrideColor(false);
/* 476 */         GL11.glDepthFunc(515);
/* 477 */         GL11.glDisable(32826);
/* 478 */         GL11.glAlphaFunc(516, 0.1F);
/* 479 */         GL11.glEnable(3008);
/* 480 */         GL11.glBlendFunc(770, 771);
/* 481 */         GL11.glEnable(3553);
/* 482 */         GL11.glDisable(3042);
/* 483 */         GL11.glDepthMask(true);
/* 484 */         ALRenderHelper.resetLighting();
/*     */         
/* 486 */         if (prevLighting)
/*     */         {
/* 488 */           GL11.glEnable(2896);
/*     */         }
/*     */         
/* 491 */         GL11.glPopMatrix();
/* 492 */         entity.field_70138_W = -entity.field_70138_W;
/* 493 */         event.setCanceled(true);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSound(PlaySoundEvent17 event) {
/* 501 */     if (this.mc.field_71439_g != null) {
/*     */       
/* 503 */       String name = "lightsabers:" + event.name;
/*     */       
/* 505 */       if (!name.equals(ALSounds.player_force_stealth_on) && !name.equals(ALSounds.player_force_stealth_off) && !name.startsWith(ALSounds.ambient_stealth) && StatusEffect.get((EntityLivingBase)this.mc.field_71439_g, Effect.STEALTH) != null) {
/*     */         
/* 507 */         ISound sound = event.sound;
/* 508 */         event.result = (ISound)new SoundAL(sound.func_147650_b(), sound.func_147653_e() * 0.05F, sound.func_147655_f(), sound.func_147657_c(), sound.func_147652_d(), sound.func_147656_j(), sound.func_147649_g(), sound.func_147654_h(), sound.func_147651_i());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderTick(TickEvent.RenderTickEvent event) {
/* 516 */     renderTick = event.renderTickTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\event\ClientEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */