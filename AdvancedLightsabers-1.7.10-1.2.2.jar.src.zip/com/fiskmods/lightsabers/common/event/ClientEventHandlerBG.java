/*    */ package com.fiskmods.lightsabers.common.event;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import mods.battlegear2.api.RenderPlayerEventChild;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientEventHandlerBG
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onPreRenderSheathed(RenderPlayerEventChild.PreRenderSheathed event) {
/* 14 */     ItemStack itemstack = event.element;
/*    */     
/* 16 */     if (itemstack != null)
/*    */     {
/* 18 */       if (itemstack.func_77973_b() == ModItems.lightsaber || itemstack.func_77973_b() == ModItems.doubleLightsaber)
/*    */       {
/* 20 */         event.setCanceled(true);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\event\ClientEventHandlerBG.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */