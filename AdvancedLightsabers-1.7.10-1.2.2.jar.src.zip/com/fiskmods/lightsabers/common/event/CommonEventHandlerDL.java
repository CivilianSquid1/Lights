/*     */ package com.fiskmods.lightsabers.common.event;
/*     */ 
/*     */ import atomicstryker.dynamiclights.client.DynamicLights;
/*     */ import atomicstryker.dynamiclights.client.IDynamicLightSource;
/*     */ import com.fiskmods.lightsabers.common.config.ModConfig;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonEventHandlerDL
/*     */ {
/*  32 */   private Minecraft mc = FMLClientHandler.instance().getClient();
/*  33 */   private long nextUpdate = System.currentTimeMillis();
/*  34 */   private ArrayList<EntityLightAdapter> trackedEntities = new ArrayList<>();
/*     */   
/*     */   private Thread thread;
/*     */   private boolean threadRunning = false;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTick(TickEvent.ClientTickEvent tick) {
/*  41 */     if (this.mc.field_71441_e != null && System.currentTimeMillis() > this.nextUpdate && !DynamicLights.globalLightsOff() && ModConfig.dynamicLightsEnabled) {
/*     */       
/*  43 */       this.nextUpdate = System.currentTimeMillis() + ModConfig.dynamicLightsUpdateInterval;
/*     */       
/*  45 */       if (!this.threadRunning) {
/*     */         
/*  47 */         this.thread = new EntityListChecker(this.mc.field_71441_e.field_72996_f);
/*  48 */         this.thread.setPriority(1);
/*  49 */         this.thread.start();
/*  50 */         this.threadRunning = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int getEntityEquipmentMaxLight(Entity entity) {
/*  57 */     if (entity instanceof EntityLivingBase) {
/*     */       
/*  59 */       int light = getLightFromItemStack(((EntityLivingBase)entity).func_71124_b(0));
/*     */       
/*  61 */       for (int i = 1; i < (entity.func_70035_c()).length; i++)
/*     */       {
/*  63 */         light = DynamicLights.maxLight(light, getLightFromItemStack(entity.func_70035_c()[i]));
/*     */       }
/*     */       
/*  66 */       return light;
/*     */     } 
/*  68 */     if (entity instanceof com.fiskmods.lightsabers.common.entity.EntityLightsaber)
/*     */     {
/*  70 */       return 15;
/*     */     }
/*     */     
/*  73 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getLightFromItemStack(ItemStack itemstack) {
/*  78 */     if (itemstack != null && itemstack.func_77973_b() instanceof ItemLightsaberBase && ItemLightsaberBase.isActive(itemstack))
/*     */     {
/*  80 */       return 15;
/*     */     }
/*     */     
/*  83 */     return 0;
/*     */   }
/*     */   
/*     */   private class EntityListChecker
/*     */     extends Thread
/*     */   {
/*     */     private final Object[] list;
/*     */     
/*     */     public EntityListChecker(List<Entity> input) {
/*  92 */       this.list = input.toArray();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*  98 */       ArrayList<CommonEventHandlerDL.EntityLightAdapter> newList = Lists.newArrayList();
/*     */ 
/*     */       
/* 101 */       for (Object object : this.list) {
/*     */         
/* 103 */         Entity entity = (Entity)object;
/*     */         
/* 105 */         if (entity.func_70089_S() && CommonEventHandlerDL.this.getEntityEquipmentMaxLight(entity) > 0) {
/*     */           
/* 107 */           boolean found = false;
/* 108 */           Iterator<CommonEventHandlerDL.EntityLightAdapter> iter = CommonEventHandlerDL.this.trackedEntities.iterator();
/* 109 */           CommonEventHandlerDL.EntityLightAdapter adapter = null;
/*     */           
/* 111 */           while (iter.hasNext()) {
/*     */             
/* 113 */             adapter = iter.next();
/*     */             
/* 115 */             if (adapter.getAttachmentEntity().equals(entity)) {
/*     */               
/* 117 */               adapter.onTick();
/* 118 */               newList.add(adapter);
/* 119 */               found = true;
/* 120 */               iter.remove();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 125 */           if (!found) {
/*     */             
/* 127 */             adapter = new CommonEventHandlerDL.EntityLightAdapter(entity);
/* 128 */             adapter.onTick();
/* 129 */             newList.add(adapter);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 134 */       for (CommonEventHandlerDL.EntityLightAdapter adapter : CommonEventHandlerDL.this.trackedEntities)
/*     */       {
/* 136 */         adapter.onTick();
/*     */       }
/*     */       
/* 139 */       CommonEventHandlerDL.this.trackedEntities = newList;
/* 140 */       CommonEventHandlerDL.this.threadRunning = false;
/*     */     }
/*     */   }
/*     */   
/*     */   private class EntityLightAdapter
/*     */     implements IDynamicLightSource
/*     */   {
/*     */     private Entity entity;
/*     */     private int lightLevel;
/*     */     private boolean enabled;
/*     */     
/*     */     public EntityLightAdapter(Entity e) {
/* 152 */       this.lightLevel = 0;
/* 153 */       this.enabled = false;
/* 154 */       this.entity = e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onTick() {
/* 159 */       this.lightLevel = CommonEventHandlerDL.this.getEntityEquipmentMaxLight(this.entity);
/*     */       
/* 161 */       if (!this.enabled && this.lightLevel > 0) {
/*     */         
/* 163 */         enableLight();
/*     */       }
/* 165 */       else if (this.enabled && this.lightLevel < 1) {
/*     */         
/* 167 */         disableLight();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void enableLight() {
/* 173 */       DynamicLights.addLightSource(this);
/* 174 */       this.enabled = true;
/*     */     }
/*     */ 
/*     */     
/*     */     private void disableLight() {
/* 179 */       DynamicLights.removeLightSource(this);
/* 180 */       this.enabled = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Entity getAttachmentEntity() {
/* 186 */       return this.entity;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getLightLevel() {
/* 192 */       return this.lightLevel;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\event\CommonEventHandlerDL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */