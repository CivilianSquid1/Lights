/*     */ package com.fiskmods.lightsabers.common.event;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.container.ContainerCrystalPouch;
/*     */ import com.fiskmods.lightsabers.common.container.InventoryCrystalPouch;
/*     */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*     */ import com.fiskmods.lightsabers.common.damage.ALDamageTypes;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*     */ import com.fiskmods.lightsabers.common.data.ALPlayerData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.entity.EntityForceLightning;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerData;
/*     */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*     */ import com.fiskmods.lightsabers.common.force.PowerType;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectActive;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectChoke;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectFortify;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectMeditation;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectResist;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.MessageBroadcastState;
/*     */ import com.fiskmods.lightsabers.common.network.MessagePlayerJoin;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Iterables;
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import fiskfille.utils.helper.FiskServerUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IExtendedEntityProperties;
/*     */ import net.minecraftforge.event.entity.EntityEvent;
/*     */ import net.minecraftforge.event.entity.EntityJoinWorldEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingFallEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingHurtEvent;
/*     */ import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonEventHandler
/*     */ {
/*  68 */   private List<EntityPlayer> playersToSync = new ArrayList<>();
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityJoinWorld(EntityJoinWorldEvent event) {
/*  73 */     Entity entity = event.entity;
/*  74 */     World world = entity.field_70170_p;
/*     */     
/*  76 */     if (entity instanceof EntityPlayer) {
/*     */       
/*  78 */       EntityPlayer player = (EntityPlayer)entity;
/*     */       
/*  80 */       if (!world.field_72995_K)
/*     */       {
/*  82 */         this.playersToSync.add(player);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityConstruct(EntityEvent.EntityConstructing event) {
/*  90 */     event.entity.registerExtendedProperties("ALEntity", (IExtendedEntityProperties)new ALEntityData());
/*     */     
/*  92 */     if (event.entity instanceof EntityPlayer)
/*     */     {
/*  94 */       event.entity.registerExtendedProperties("ALPlayer", (IExtendedEntityProperties)new ALPlayerData());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onStartTracking(PlayerEvent.StartTracking event) {
/* 101 */     EntityPlayer player = event.entityPlayer;
/*     */     
/* 103 */     if (player != null && !player.field_70170_p.field_72995_K)
/*     */     {
/* 105 */       if (event.target instanceof EntityPlayer) {
/*     */         
/* 107 */         EntityPlayerMP tracked = (EntityPlayerMP)event.target;
/* 108 */         ALNetworkManager.wrapper.sendTo((IMessage)new MessageBroadcastState(player), tracked);
/* 109 */         ALNetworkManager.wrapper.sendTo((IMessage)new MessageBroadcastState((EntityPlayer)tracked), (EntityPlayerMP)player);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerClone(PlayerEvent.Clone event) {
/* 117 */     ALPlayerData.getData(event.entityPlayer).copy(ALPlayerData.getData(event.original));
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerTick(TickEvent.PlayerTickEvent event) {
/* 123 */     EntityPlayer player = event.player;
/* 124 */     World world = player.field_70170_p;
/*     */     
/* 126 */     if (event.phase == TickEvent.Phase.END) {
/*     */       
/* 128 */       List<Power> selectedPowers = (List<Power>)ALData.SELECTED_POWERS.get((Entity)player);
/*     */       
/* 130 */       for (int i = 0; i < selectedPowers.size(); i++) {
/*     */         
/* 132 */         Power power1 = selectedPowers.get(i);
/*     */         
/* 134 */         if (power1 != null) {
/*     */           Set<Power> set;
/*     */ 
/*     */           
/* 138 */           while (!(set = ALHelper.getUnlockedChildren(player, power1)).isEmpty())
/*     */           {
/* 140 */             power1 = (Power)Iterables.get(set, 0);
/*     */           }
/*     */           
/* 143 */           while (power1 != null && !PowerManager.hasPowerUnlocked(player, power1))
/*     */           {
/* 145 */             power1 = power1.parent;
/*     */           }
/*     */           
/* 148 */           selectedPowers.set(i, power1);
/*     */         } 
/*     */       } 
/*     */       
/* 152 */       if (((Boolean)ALData.USING_POWER.get((Entity)player)).booleanValue()) {
/*     */         
/* 154 */         ALData.TICKS_USING_POWER.incrWithoutNotify((Entity)player, Integer.valueOf(1));
/*     */       }
/*     */       else {
/*     */         
/* 158 */         ALData.TICKS_USING_POWER.setWithoutNotify((Entity)player, Integer.valueOf(0));
/*     */       } 
/*     */       
/* 161 */       Power power = PowerManager.getSelectedPower(player);
/*     */       
/* 163 */       if (player.func_70089_S()) {
/*     */         
/* 165 */         int max = ALHelper.getForcePowerMax(player);
/*     */         
/* 167 */         if (max > 0) {
/*     */           
/* 169 */           if (((Integer)ALData.USE_POWER_COOLDOWN.get((Entity)player)).intValue() > 0)
/*     */           {
/* 171 */             ALData.USE_POWER_COOLDOWN.incrWithoutNotify((Entity)player, Integer.valueOf(-1));
/*     */           }
/*     */           
/* 174 */           if (power != null && ((Boolean)ALData.USING_POWER.get((Entity)player)).booleanValue()) {
/*     */             
/* 176 */             if (power.powerStats.powerType == PowerType.PER_SECOND && ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue() >= power.getUseCost(player) && power.powerEffect.execute(player, event.side))
/*     */             {
/* 178 */               ALData.FORCE_POWER.incrWithoutNotify((Entity)player, Float.valueOf(-power.getUseCost(player) / 20.0F));
/*     */             }
/*     */           }
/* 181 */           else if (((Float)ALData.FORCE_POWER_DIFF.get((Entity)player)).floatValue() <= ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue()) {
/*     */             
/* 183 */             ALData.FORCE_POWER.incrWithoutNotify((Entity)player, Float.valueOf(ALHelper.getForcePowerRegen(player) / 20.0F));
/*     */           } 
/*     */           
/* 186 */           ALData.FORCE_POWER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(max));
/*     */         } 
/*     */         
/* 189 */         String drainingTo = (String)ALData.DRAINING_XP_TO.get((Entity)player);
/*     */         
/* 191 */         if (!StringUtils.func_151246_b(drainingTo)) {
/*     */           
/* 193 */           Power power1 = Power.getPowerFromName(drainingTo);
/*     */           
/* 195 */           if (power1 != null) {
/*     */             
/* 197 */             PowerData data = PowerManager.getPowerData(player, power1);
/*     */             
/* 199 */             if (data != null && !data.isUnlocked())
/*     */             {
/* 201 */               if (data.xpInvested >= power1.getActualXpCost(player)) {
/*     */                 
/* 203 */                 data.setUnlocked((Entity)player, true);
/* 204 */                 ALData.BASE_POWER.incrWithoutNotify((Entity)player, Byte.valueOf((byte)(power1.powerStats.baseBonus - power1.powerStats.baseRequirement)));
/*     */                 
/* 206 */                 if (Lightsabers.proxy.isClientPlayer((EntityLivingBase)player))
/*     */                 {
/* 208 */                   player.func_85030_a(ALSounds.block_holocron_unlock, 1.0F, 1.0F);
/*     */                 }
/*     */               }
/*     */               else {
/*     */                 
/* 213 */                 int j = power1.getActualXpCost(player) / 40;
/*     */                 
/* 215 */                 if (j > MathHelper.func_76141_d(((Float)ALData.FORCE_XP.get((Entity)player)).floatValue()))
/*     */                 {
/* 217 */                   j = MathHelper.func_76141_d(((Float)ALData.FORCE_XP.get((Entity)player)).floatValue());
/*     */                 }
/*     */                 
/* 220 */                 if (j > power1.getActualXpCost(player) - data.xpInvested)
/*     */                 {
/* 222 */                   j = power1.getActualXpCost(player) - data.xpInvested;
/*     */                 }
/*     */                 
/* 225 */                 data.xpInvested += j;
/* 226 */                 ALData.FORCE_XP.incrWithoutNotify((Entity)player, Float.valueOf(-(j)));
/*     */                 
/* 228 */                 if (Lightsabers.proxy.isClientPlayer((EntityLivingBase)player)) {
/*     */                   
/* 230 */                   Random rand = new Random();
/* 231 */                   player.func_85030_a(ALSounds.block_holocron_invest, 1.0F, 1.1F + (rand.nextFloat() - rand.nextFloat()) * 0.2F);
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 239 */       if (((Float)ALData.FORCE_POWER_DIFF.get((Entity)player)).floatValue() > ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue()) {
/*     */         
/* 241 */         ALData.FORCE_POWER_DIFF.incrWithoutNotify((Entity)player, Float.valueOf(-7.5F));
/* 242 */         ALData.FORCE_POWER_DIFF.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), ALData.FORCE_POWER_DIFF.get((Entity)player));
/*     */       }
/*     */       else {
/*     */         
/* 246 */         ALData.FORCE_POWER_DIFF.setWithoutNotify((Entity)player, ALData.FORCE_POWER.get((Entity)player));
/*     */       } 
/*     */       
/* 249 */       if (((Float)ALData.FORCE_PUSHING_TIMER.get((Entity)player)).floatValue() > 0.0F) {
/*     */         
/* 251 */         ALData.FORCE_PUSHING_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(-0.075F));
/* 252 */         ALData.FORCE_PUSHING_TIMER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(1.0F));
/*     */       }
/*     */       else {
/*     */         
/* 256 */         ALData.FORCE_PUSHING_TIMER.setWithoutNotify((Entity)player, Float.valueOf(0.0F));
/*     */       } 
/*     */       
/* 259 */       StatusEffect effectLightning = StatusEffect.get((EntityLivingBase)player, Effect.LIGHTNING);
/*     */       
/* 261 */       if (((Float)ALData.DRAIN_LIFE_TIMER.get((Entity)player)).floatValue() > 0.0F || effectLightning != null)
/*     */       {
/* 263 */         if (world.field_72995_K)
/*     */         {
/* 265 */           world.func_72838_d((Entity)new EntityForceLightning(world, (EntityLivingBase)player));
/*     */         }
/*     */       }
/*     */       
/* 269 */       if (((Float)ALData.DRAIN_LIFE_TIMER.get((Entity)player)).floatValue() > 0.0F) {
/*     */         
/* 271 */         float decr = 0.033333335F;
/* 272 */         ALData.DRAIN_LIFE_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(-decr));
/* 273 */         ALData.DRAIN_LIFE_TIMER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(1.0F));
/*     */         
/* 275 */         List<EntityLivingBase> list1 = world.field_72996_f;
/*     */         
/* 277 */         for (int j = 0; j < list1.size(); j++) {
/*     */           
/* 279 */           if (list1.get(j) instanceof EntityLivingBase) {
/*     */             
/* 281 */             EntityLivingBase entity = list1.get(j);
/* 282 */             StatusEffect effect = StatusEffect.get(entity, Effect.DRAIN);
/*     */             
/* 284 */             if (effect != null && effect.casterUUID != null && effect.casterUUID.equals(player.func_110124_au()))
/*     */             {
/* 286 */               float f = decr * (4 + effect.amplifier * 2) * 5.0F;
/* 287 */               float prevHealth = entity.func_110143_aJ();
/*     */               
/* 289 */               if (effect.duration % 5 == 0) {
/*     */                 
/* 291 */                 entity.field_70172_ad = 0;
/* 292 */                 entity.func_70097_a(ALDamageSources.causeForceLightningDamage((Entity)player), f);
/* 293 */                 player.func_70691_i(Math.max(prevHealth - entity.func_110143_aJ(), 0.0F));
/*     */               } 
/*     */               
/* 296 */               entity.field_70159_w = 0.0D;
/* 297 */               entity.field_70181_x = 0.05000000074505806D;
/* 298 */               entity.field_70179_y = 0.0D;
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 305 */         ALData.DRAIN_LIFE_TIMER.setWithoutNotify((Entity)player, Float.valueOf(0.0F));
/*     */       } 
/*     */       
/* 308 */       if (!StatusEffect.getTargets((EntityLivingBase)player, Effect.CHOKE).isEmpty()) {
/*     */         
/* 310 */         float decr = 0.016666668F;
/* 311 */         List<EntityLivingBase> list1 = world.field_72996_f;
/*     */         
/* 313 */         for (int j = 0; j < list1.size(); j++) {
/*     */           
/* 315 */           if (list1.get(j) instanceof EntityLivingBase) {
/*     */             
/* 317 */             EntityLivingBase entity = list1.get(j);
/* 318 */             StatusEffect effect = StatusEffect.get(entity, Effect.CHOKE);
/*     */             
/* 320 */             if (effect != null && effect.casterUUID != null && effect.casterUUID.equals(player.func_110124_au())) {
/*     */               
/* 322 */               float f = decr * (2 + effect.amplifier * 2) * 5.0F;
/*     */               
/* 324 */               if (effect.duration % 5 == 0) {
/*     */                 
/* 326 */                 entity.field_70172_ad = 0;
/* 327 */                 entity.func_70097_a(ALDamageSources.causeForceDamage((Entity)player), f);
/*     */               } 
/*     */               
/* 330 */               entity.field_70159_w = 0.0D;
/* 331 */               entity.field_70181_x = (0.001F * effect.duration);
/* 332 */               entity.field_70179_y = 0.0D;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 338 */       boolean rightArm = (effectLightning != null || !StatusEffect.getTargets((EntityLivingBase)player, Effect.CHOKE).isEmpty());
/* 339 */       boolean leftArm = (effectLightning != null || !StatusEffect.getTargets((EntityLivingBase)player, Effect.CHOKE, 2).isEmpty());
/*     */       
/* 341 */       if (rightArm) {
/*     */         
/* 343 */         ALData.RIGHT_ARM_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(0.33F));
/*     */       }
/*     */       else {
/*     */         
/* 347 */         ALData.RIGHT_ARM_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(-0.33F));
/*     */       } 
/*     */       
/* 350 */       if (leftArm) {
/*     */         
/* 352 */         ALData.LEFT_ARM_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(0.33F));
/*     */       }
/*     */       else {
/*     */         
/* 356 */         ALData.LEFT_ARM_TIMER.incrWithoutNotify((Entity)player, Float.valueOf(-0.33F));
/*     */       } 
/*     */       
/* 359 */       boolean flag = ((Boolean)ALData.USING_POWER.get((Entity)player)).booleanValue();
/* 360 */       boolean flag1 = ((Boolean)ALData.PREV_USING_POWER.get((Entity)player)).booleanValue();
/*     */       
/* 362 */       if (power != null)
/*     */       {
/* 364 */         if (power.powerEffect instanceof PowerEffectActive) {
/*     */           
/* 366 */           PowerEffectActive effect = (PowerEffectActive)power.powerEffect;
/*     */           
/* 368 */           if (flag && !flag1)
/*     */           {
/* 370 */             effect.start(player, event.side);
/*     */           }
/*     */           
/* 373 */           if (!flag && flag1)
/*     */           {
/* 375 */             effect.stop(player, event.side);
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 380 */       if (((Integer)ALData.PREV_XP.get((Entity)player)).intValue() < ALHelper.getTotalXp(player)) {
/*     */         
/* 382 */         float f = (ALHelper.getTotalXp(player) - ((Integer)ALData.PREV_XP.get((Entity)player)).intValue());
/* 383 */         ALData.FORCE_XP.incrWithoutNotify((Entity)player, Float.valueOf(f / 2.0F));
/*     */       } 
/*     */       
/* 386 */       if (((Byte)ALData.BASE_POWER.get((Entity)player)).byteValue() < 0)
/*     */       {
/* 388 */         ALData.BASE_POWER.setWithoutNotify((Entity)player, Byte.valueOf((byte)Math.max(ALHelper.getBasePower(player), 0)));
/*     */       }
/*     */       
/* 391 */       if (PowerManager.hasPowerUnlocked(player, Power.FORCE_SENSITIVITY)) {
/*     */         
/* 393 */         PowerManager.getPowerData(player, Power.LIGHT_SIDE).setUnlocked((Entity)player, true);
/* 394 */         PowerManager.getPowerData(player, Power.DARK_SIDE).setUnlocked((Entity)player, true);
/* 395 */         PowerManager.getPowerData(player, Power.NEUTRAL).setUnlocked((Entity)player, true);
/*     */       } 
/*     */       
/* 398 */       ALData.FORCE_POWER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(ALHelper.getForcePowerMax(player)));
/* 399 */       ALData.FORCE_POWER_DIFF.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(ALHelper.getForcePowerMax(player)));
/*     */       
/* 401 */       ALData.PREV_XP.setWithoutNotify((Entity)player, Integer.valueOf(ALHelper.getTotalXp(player)));
/* 402 */       ALData.PREV_USING_POWER.setWithoutNotify((Entity)player, ALData.USING_POWER.get((Entity)player));
/* 403 */       ALData.RIGHT_ARM_TIMER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(1.0F));
/* 404 */       ALData.LEFT_ARM_TIMER.clampWithoutNotify((Entity)player, Float.valueOf(0.0F), Float.valueOf(1.0F));
/*     */     }
/*     */     else {
/*     */       
/* 408 */       ALData.onUpdate((Entity)player);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
/* 415 */     EntityLivingBase entity = event.entityLiving;
/* 416 */     ALEntityData data = ALEntityData.getData(entity);
/*     */     
/* 418 */     if (data.forcePushed && entity.field_70132_H && !entity.field_70122_E) {
/*     */       
/* 420 */       data.forcePushed = false;
/* 421 */       entity.field_70172_ad = 0;
/*     */       
/* 423 */       double motX = entity.field_70169_q - entity.field_70165_t;
/* 424 */       double motY = entity.field_70167_r - entity.field_70163_u;
/* 425 */       double motZ = entity.field_70166_s - entity.field_70161_v;
/* 426 */       double vel = MathHelper.func_76133_a(motX * motX + motY * motY + motZ * motZ);
/*     */       
/* 428 */       float damage = (float)Math.max(vel * 5.0D - 3.0D, 0.0D);
/*     */       
/* 430 */       if (damage > 0.0F)
/*     */       {
/* 432 */         entity.func_70097_a(ALDamageSources.INTO_WALL, damage);
/*     */       }
/*     */     } 
/*     */     
/* 436 */     for (int i = 0; i < data.activeEffects.size(); i++) {
/*     */       
/* 438 */       StatusEffect status = data.activeEffects.get(i);
/*     */       
/* 440 */       if ((status.duration = (short)(status.duration - 1)) <= 0) {
/*     */         
/* 442 */         data.activeEffects.remove(i);
/*     */         
/* 444 */         if (status.effect == Effect.CHOKE)
/*     */         {
/* 446 */           StatusEffect.add(entity, Effect.STUN, (int)(PowerEffectChoke.getStunDuration(status.amplifier) * 20.0F), 0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 451 */     IAttributeInstance speedAttribute = entity.func_110148_a(SharedMonsterAttributes.field_111263_d);
/*     */     
/* 453 */     if (speedAttribute != null) {
/*     */       
/* 455 */       UUID stunModifierUUID = UUID.fromString("B2AB4DE3-8276-4B86-A448-230FA6FDC689");
/* 456 */       UUID speedModifierUUID = UUID.fromString("A1AB4DE3-8276-4B86-A448-480FA6DDB389");
/* 457 */       AttributeModifier stunModifier = (new AttributeModifier(stunModifierUUID, "Stun speed boost", -1.0D, 1)).func_111168_a(false);
/* 458 */       AttributeModifier speedModifier = (new AttributeModifier(speedModifierUUID, "Force speed boost", 1.0D, 1)).func_111168_a(false);
/*     */       
/* 460 */       if (speedAttribute.func_111127_a(stunModifierUUID) != null)
/*     */       {
/* 462 */         speedAttribute.func_111124_b(stunModifier);
/*     */       }
/*     */       
/* 465 */       if (speedAttribute.func_111127_a(speedModifierUUID) != null)
/*     */       {
/* 467 */         speedAttribute.func_111124_b(speedModifier);
/*     */       }
/*     */       
/* 470 */       if (StatusEffect.get(entity, Effect.STUN) != null) {
/*     */         
/* 472 */         speedAttribute.func_111121_a(stunModifier);
/* 473 */         entity.field_70160_al = false;
/* 474 */         entity.field_70181_x = -0.20000000298023224D;
/* 475 */         entity.func_70637_d(false);
/*     */       } 
/*     */       
/* 478 */       if (StatusEffect.get(entity, Effect.SPEED) != null)
/*     */       {
/* 480 */         speedAttribute.func_111121_a(speedModifier);
/*     */       }
/*     */     } 
/*     */     
/* 484 */     if (entity instanceof EntityPlayer) {
/*     */       
/* 486 */       EntityPlayer player = (EntityPlayer)event.entity;
/*     */       
/* 488 */       if (!player.field_70170_p.field_72995_K)
/*     */       {
/* 490 */         if (this.playersToSync.size() > 0 && this.playersToSync.contains(player)) {
/*     */           
/* 492 */           ALNetworkManager.wrapper.sendTo((IMessage)new MessagePlayerJoin(player), (EntityPlayerMP)player);
/* 493 */           this.playersToSync.remove(player);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*     */   public void onLivingFall(LivingFallEvent event) {
/* 502 */     if (event.entity instanceof EntityPlayer && event.distance > 3.0F) {
/*     */       
/* 504 */       EntityPlayer player = (EntityPlayer)event.entity;
/* 505 */       float force = ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue();
/*     */       
/* 507 */       if (force > 0.0F && PowerManager.hasPowerUnlocked(player, Power.REBOUND)) {
/*     */         
/* 509 */         float cost = Power.REBOUND.getUseCost(player);
/* 510 */         float amount = Math.min(Math.max(event.distance - 3.0F, 0.0F), MathHelper.func_76141_d(force / cost));
/*     */         
/* 512 */         if (amount > 0.0F) {
/*     */           
/* 514 */           event.distance -= amount;
/*     */           
/* 516 */           if (!event.entity.field_70170_p.field_72995_K)
/*     */           {
/* 518 */             ALData.FORCE_POWER.incr(player, Float.valueOf(-cost * amount));
/*     */           }
/*     */           
/* 521 */           amount -= 3.0F;
/* 522 */           player.func_85030_a(ALSounds.player_force_cast, Math.min(amount / 10.0F + 0.2F, 1.0F), 1.0F);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onLivingAttack(LivingAttackEvent event) {
/* 531 */     if (event.source.func_76346_g() instanceof EntityLivingBase) {
/*     */       
/* 533 */       EntityLivingBase attacker = (EntityLivingBase)event.source.func_76346_g();
/*     */       
/* 535 */       if (StatusEffect.has(attacker, Effect.STUN)) {
/*     */         
/* 537 */         event.setCanceled(true);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingHurt(LivingHurtEvent event) {
/* 546 */     EntityLivingBase entity = event.entityLiving;
/* 547 */     StatusEffect effectFortify = StatusEffect.get(entity, Effect.FORTIFY);
/* 548 */     StatusEffect effectEnergyResist = StatusEffect.get(entity, Effect.RESIST);
/*     */     
/* 550 */     if (event.source.func_76346_g() instanceof EntityLivingBase) {
/*     */       
/* 552 */       EntityLivingBase attacker = (EntityLivingBase)event.source.func_76346_g();
/* 553 */       StatusEffect effectMeditation = StatusEffect.get(attacker, Effect.MEDITATION);
/*     */       
/* 555 */       if (effectMeditation != null && FiskServerUtils.isMeleeDamage(event.source))
/*     */       {
/* 557 */         event.ammount *= PowerEffectMeditation.getModifierAmount(effectMeditation.amplifier);
/*     */       }
/*     */     } 
/*     */     
/* 561 */     if (effectFortify != null && ALDamageTypes.FORCE.isPresent(event.source))
/*     */     {
/* 563 */       event.ammount /= PowerEffectFortify.getModifierAmount(effectFortify.amplifier);
/*     */     }
/*     */     
/* 566 */     if (effectEnergyResist != null && ALDamageTypes.LIGHTSABER.isPresent(event.source))
/*     */     {
/* 568 */       event.ammount /= PowerEffectResist.getModifierAmount(effectEnergyResist.amplifier);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingDeath(LivingDeathEvent event) {
/* 575 */     (ALEntityData.getData(event.entityLiving)).activeEffects.clear();
/*     */     
/* 577 */     if (event.entity instanceof EntityPlayer) {
/*     */       
/* 579 */       EntityPlayer player = (EntityPlayer)event.entity;
/*     */       
/* 581 */       if (!player.field_70170_p.func_82736_K().func_82766_b("keepInventory")) {
/*     */         
/* 583 */         ALData.FORCE_XP.set(player, Float.valueOf(MathHelper.func_76141_d(((Float)ALData.FORCE_XP.get((Entity)player)).floatValue() * 0.7F)));
/*     */       }
/*     */       else {
/*     */         
/* 587 */         ALData.FORCE_XP.set(player, Float.valueOf(0.0F));
/*     */       } 
/*     */       
/* 590 */       ALData.onDeath((Entity)player);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityItemPickup(EntityItemPickupEvent event) {
/* 597 */     EntityPlayer player = event.entityPlayer;
/* 598 */     ItemStack item = event.item.func_92059_d();
/*     */     
/* 600 */     if (item != null && item.func_77973_b() == Item.func_150898_a(ModBlocks.lightsaberCrystal))
/*     */     {
/* 602 */       for (int i = 0; i < player.field_71071_by.func_70302_i_(); i++) {
/*     */         
/* 604 */         ItemStack itemstack = player.field_71071_by.func_70301_a(i);
/*     */         
/* 606 */         if (itemstack != null && itemstack.func_77973_b() == ModItems.crystalPouch) {
/*     */           
/* 608 */           InventoryCrystalPouch pouch = new InventoryCrystalPouch(player, i);
/*     */           
/* 610 */           if (player.field_71070_bA instanceof ContainerCrystalPouch) {
/*     */             
/* 612 */             InventoryCrystalPouch inventory = ((ContainerCrystalPouch)player.field_71070_bA).inventory;
/*     */             
/* 614 */             if (inventory.itemSlot == i)
/*     */             {
/* 616 */               pouch = inventory;
/*     */             }
/*     */           } 
/*     */           
/* 620 */           pouch.addItemStackToInventory(item);
/* 621 */           pouch.func_70296_d();
/*     */           
/* 623 */           if (item.field_77994_a <= 0)
/*     */             break; 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\event\CommonEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */