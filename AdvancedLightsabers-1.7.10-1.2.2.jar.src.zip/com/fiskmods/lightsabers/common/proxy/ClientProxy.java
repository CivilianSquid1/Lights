/*     */ package com.fiskmods.lightsabers.common.proxy;
/*     */ 
/*     */ import com.fiskmods.lightsabers.ALReflection;
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.client.gui.GuiOverlay;
/*     */ import com.fiskmods.lightsabers.client.render.entity.RenderForceLightning;
/*     */ import com.fiskmods.lightsabers.client.render.entity.RenderLightsaber;
/*     */ import com.fiskmods.lightsabers.client.render.entity.RenderSithGhost;
/*     */ import com.fiskmods.lightsabers.client.render.hilt.HiltRendererManager;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemCrystal;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemDisassemblyStation;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemHolocron;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemLightsaber;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemLightsaberForge;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemLightsaberStand;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemSithCoffin;
/*     */ import com.fiskmods.lightsabers.client.render.item.RenderItemSithStoneCoffin;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderCrystal;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderDisassemblyStation;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderHolocron;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderLightsaberForge;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderLightsaberStand;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderSithCoffin;
/*     */ import com.fiskmods.lightsabers.client.render.tile.RenderSithStoneCoffin;
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.entity.EntityForceLightning;
/*     */ import com.fiskmods.lightsabers.common.entity.EntityLightsaber;
/*     */ import com.fiskmods.lightsabers.common.entity.EntitySithGhost;
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandlerBG;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.keybinds.ALKeyBinds;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberStand;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*     */ import cpw.mods.fml.client.registry.ClientRegistry;
/*     */ import cpw.mods.fml.client.registry.RenderingRegistry;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import mods.battlegear2.api.core.BattlegearUtils;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import net.minecraftforge.client.MinecraftForgeClient;
/*     */ 
/*     */ public class ClientProxy
/*     */   extends CommonProxy
/*     */ {
/*     */   public void preInit() {
/*  60 */     super.preInit();
/*  61 */     ALReflection.client();
/*  62 */     ALKeyBinds.register();
/*     */     
/*  64 */     registerEventHandler(new ClientEventHandler());
/*  65 */     registerEventHandler(new GuiOverlay());
/*     */     
/*  67 */     if (Lightsabers.isBattlegearLoaded)
/*     */     {
/*  69 */       BattlegearUtils.RENDER_BUS.register(new ClientEventHandlerBG());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  76 */     super.init();
/*  77 */     HiltRendererManager.register();
/*     */     
/*  79 */     MinecraftForgeClient.registerItemRenderer(ModItems.lightsaber, (IItemRenderer)new RenderItemLightsaber());
/*  80 */     MinecraftForgeClient.registerItemRenderer(ModItems.doubleLightsaber, (IItemRenderer)new RenderItemDoubleLightsaber());
/*  81 */     MinecraftForgeClient.registerItemRenderer(ModItems.emitter, (IItemRenderer)new RenderItemLightsaberPart(PartType.EMITTER));
/*  82 */     MinecraftForgeClient.registerItemRenderer(ModItems.switchSection, (IItemRenderer)new RenderItemLightsaberPart(PartType.SWITCH_SECTION));
/*  83 */     MinecraftForgeClient.registerItemRenderer(ModItems.grip, (IItemRenderer)new RenderItemLightsaberPart(PartType.BODY));
/*  84 */     MinecraftForgeClient.registerItemRenderer(ModItems.pommel, (IItemRenderer)new RenderItemLightsaberPart(PartType.POMMEL));
/*  85 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.lightsaberCrystal), (IItemRenderer)new RenderItemCrystal());
/*  86 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.lightsaberForgeLight), (IItemRenderer)new RenderItemLightsaberForge());
/*  87 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.lightsaberForgeDark), (IItemRenderer)new RenderItemLightsaberForge());
/*  88 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.lightsaberStand), (IItemRenderer)RenderItemLightsaberStand.INSTANCE);
/*  89 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.disassemblyStation), (IItemRenderer)RenderItemDisassemblyStation.INSTANCE);
/*  90 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.sithCoffin), (IItemRenderer)new RenderItemSithCoffin());
/*  91 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.sithStoneCoffin), (IItemRenderer)new RenderItemSithStoneCoffin());
/*  92 */     MinecraftForgeClient.registerItemRenderer(Item.func_150898_a(ModBlocks.holocron), (IItemRenderer)new RenderItemHolocron());
/*     */     
/*  94 */     RenderingRegistry.registerEntityRenderingHandler(EntityLightsaber.class, (Render)new RenderLightsaber());
/*  95 */     RenderingRegistry.registerEntityRenderingHandler(EntitySithGhost.class, (Render)new RenderSithGhost());
/*  96 */     RenderingRegistry.registerEntityRenderingHandler(EntityForceLightning.class, (Render)new RenderForceLightning());
/*     */     
/*  98 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityCrystal.class, (TileEntitySpecialRenderer)new RenderCrystal());
/*  99 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityLightsaberForge.class, (TileEntitySpecialRenderer)new RenderLightsaberForge());
/* 100 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityLightsaberStand.class, (TileEntitySpecialRenderer)new RenderLightsaberStand());
/* 101 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityDisassemblyStation.class, (TileEntitySpecialRenderer)new RenderDisassemblyStation());
/* 102 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySithCoffin.class, (TileEntitySpecialRenderer)new RenderSithCoffin());
/* 103 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySithStoneCoffin.class, (TileEntitySpecialRenderer)new RenderSithStoneCoffin());
/* 104 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityHolocron.class, (TileEntitySpecialRenderer)new RenderHolocron());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Side getSide() {
/* 110 */     return Side.CLIENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRenderTick() {
/* 116 */     return ClientEventHandler.renderTick;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityPlayer getPlayer() {
/* 122 */     return (EntityPlayer)(Minecraft.func_71410_x()).field_71439_g;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClientPlayer(EntityLivingBase entity) {
/* 128 */     return (entity instanceof EntityPlayer && !(entity instanceof net.minecraft.client.entity.EntityOtherPlayerMP));
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\proxy\ClientProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */