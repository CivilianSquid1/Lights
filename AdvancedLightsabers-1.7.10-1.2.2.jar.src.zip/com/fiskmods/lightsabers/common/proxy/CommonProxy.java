/*    */ package com.fiskmods.lightsabers.common.proxy;
/*    */ 
/*    */ import com.fiskmods.lightsabers.ALReflection;
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.fiskmods.lightsabers.client.gui.GuiHandlerAL;
/*    */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.entity.ModEntities;
/*    */ import com.fiskmods.lightsabers.common.event.CommonEventHandler;
/*    */ import com.fiskmods.lightsabers.common.event.CommonEventHandlerDL;
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import com.fiskmods.lightsabers.common.force.PowerData;
/*    */ import com.fiskmods.lightsabers.common.generator.ModChestGen;
/*    */ import com.fiskmods.lightsabers.common.generator.WorldGeneratorOres;
/*    */ import com.fiskmods.lightsabers.common.generator.WorldGeneratorStructures;
/*    */ import com.fiskmods.lightsabers.common.hilt.HiltManager;
/*    */ import com.fiskmods.lightsabers.common.interaction.ALInteractions;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*    */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*    */ import com.fiskmods.lightsabers.common.recipe.ModRecipes;
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.common.IWorldGenerator;
/*    */ import cpw.mods.fml.common.network.IGuiHandler;
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.helper.NBTHelper;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ 
/*    */ public class CommonProxy
/*    */ {
/*    */   public void preInit() {
/* 37 */     ALReflection.common();
/* 38 */     ALData.init();
/*    */     
/* 40 */     ALNetworkManager.register();
/* 41 */     HiltManager.register();
/* 42 */     ALInteractions.register();
/* 43 */     ModItems.register();
/* 44 */     ModBlocks.register();
/* 45 */     ModRecipes.register();
/* 46 */     ModEntities.register();
/* 47 */     ModChestGen.register();
/* 48 */     Effect.register();
/*    */     
/* 50 */     registerSaveAdapters();
/*    */     
/* 52 */     if (Lightsabers.isDynamicLightsLoaded)
/*    */     {
/* 54 */       registerEventHandler(new CommonEventHandlerDL());
/*    */     }
/*    */     
/* 57 */     registerEventHandler(new CommonEventHandler());
/* 58 */     GameRegistry.registerWorldGenerator((IWorldGenerator)WorldGeneratorOres.INSTANCE, 0);
/* 59 */     GameRegistry.registerWorldGenerator((IWorldGenerator)WorldGeneratorStructures.INSTANCE, 0);
/* 60 */     NetworkRegistry.INSTANCE.registerGuiHandler("lightsabers", (IGuiHandler)new GuiHandlerAL());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {}
/*    */ 
/*    */   
/*    */   public void registerSaveAdapters() {
/* 69 */     NBTHelper.registerAdapter(Power.class, Power.Adapter.class);
/* 70 */     NBTHelper.registerAdapter(PowerData.class, PowerData.Adapter.class);
/* 71 */     NBTHelper.registerAdapter(PowerData.Container.class, PowerData.Container.Adapter.class);
/* 72 */     NBTHelper.registerAdapter(LightsaberData.class, LightsaberData.Adapter.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerEventHandler(Object obj) {
/* 77 */     MinecraftForge.EVENT_BUS.register(obj);
/* 78 */     MinecraftForge.TERRAIN_GEN_BUS.register(obj);
/* 79 */     FMLCommonHandler.instance().bus().register(obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public Side getSide() {
/* 84 */     return Side.SERVER;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getRenderTick() {
/* 89 */     return 1.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityPlayer getPlayer() {
/* 94 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isClientPlayer(EntityLivingBase entity) {
/* 99 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\proxy\CommonProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */