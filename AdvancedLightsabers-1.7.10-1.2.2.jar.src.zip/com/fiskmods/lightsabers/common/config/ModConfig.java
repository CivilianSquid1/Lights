/*    */ package com.fiskmods.lightsabers.common.config;
/*    */ 
/*    */ import net.minecraftforge.common.config.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModConfig
/*    */ {
/*    */   public static final String CATEGORY_DYNAMIC_LIGHTS = "Dynamic Lights";
/*    */   public static final String CATEGORY_RENDERING = "Rendering";
/*    */   public static boolean dynamicLightsEnabled;
/*    */   public static int dynamicLightsUpdateInterval;
/*    */   public static float renderGlobalMultiplier;
/*    */   public static float renderWidthMultiplier;
/*    */   public static float renderOpacityMultiplier;
/*    */   public static float renderSmoothingMultiplier;
/*    */   public static float renderLightingMultiplier;
/*    */   public static boolean enableShaders;
/*    */   public static Configuration configFile;
/*    */   
/*    */   public static void load(Configuration config) {
/* 24 */     configFile = config;
/*    */     
/* 26 */     dynamicLightsEnabled = configFile.getBoolean("Enable Dynamic Lights Support", "Dynamic Lights", true, "Whether support for Dynamic Lights is enabled.");
/* 27 */     dynamicLightsUpdateInterval = configFile.getInt("Dynamic Lights Update Interval", "Dynamic Lights", 1000, 0, 2147483647, "Update Interval time for all EntityLiving in milliseconds. The lower the better and costlier.");
/*    */     
/* 29 */     renderGlobalMultiplier = configFile.getFloat("Global Multiplier", "Rendering", 1.0F, 0.0F, Float.MAX_VALUE, "Global multiplier for lightsaber rendering values.");
/* 30 */     renderWidthMultiplier = configFile.getFloat("Width Multiplier", "Rendering", 1.0F, 0.0F, Float.MAX_VALUE, "Multiplier for lightsaber width.");
/* 31 */     renderOpacityMultiplier = configFile.getFloat("Opacity Multiplier", "Rendering", 1.0F, 0.0F, Float.MAX_VALUE, "Multiplier for lightsaber opacity.");
/* 32 */     renderSmoothingMultiplier = configFile.getFloat("Smoothing Multiplier", "Rendering", 1.0F, 0.0F, Float.MAX_VALUE, "Multiplier for lightsaber smooth lighting. (The higher, the prettier, but also more resource-costly.)");
/* 33 */     renderLightingMultiplier = configFile.getFloat("Lighting Multiplier", "Rendering", 1.0F, 0.0F, Float.MAX_VALUE, "Multiplier for lightsaber lighting.");
/* 34 */     enableShaders = configFile.getBoolean("Enable Shaders", "Rendering", true, "Enable use of shaders for certain Force powers?");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\config\ModConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */