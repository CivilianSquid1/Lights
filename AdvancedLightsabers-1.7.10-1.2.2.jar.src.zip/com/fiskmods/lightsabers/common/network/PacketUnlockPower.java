/*     */ package com.fiskmods.lightsabers.common.network;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerManager;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import cpw.mods.fml.common.network.simpleimpl.MessageContext;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketUnlockPower
/*     */   implements IMessage
/*     */ {
/*     */   public int id;
/*     */   private Power power;
/*     */   
/*     */   public PacketUnlockPower() {}
/*     */   
/*     */   public PacketUnlockPower(EntityPlayer player, Power p) {
/*  27 */     this.id = player.func_145782_y();
/*  28 */     this.power = p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fromBytes(ByteBuf buf) {
/*  34 */     this.id = buf.readInt();
/*  35 */     this.power = Power.getPowerFromName(ByteBufUtils.readUTF8String(buf));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/*  41 */     buf.writeInt(this.id);
/*  42 */     ByteBufUtils.writeUTF8String(buf, this.power.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Handler
/*     */     implements IMessageHandler<PacketUnlockPower, IMessage>
/*     */   {
/*     */     public IMessage onMessage(PacketUnlockPower message, MessageContext ctx) {
/*  50 */       Power power = message.power;
/*     */       
/*  52 */       if (ctx.side.isClient()) {
/*     */         
/*  54 */         EntityPlayer player = Lightsabers.proxy.getPlayer();
/*  55 */         Entity entity = player.field_70170_p.func_73045_a(message.id);
/*     */         
/*  57 */         if (entity instanceof EntityPlayer)
/*     */         {
/*  59 */           EntityPlayer player1 = (EntityPlayer)entity;
/*  60 */           onMessage(player1, message, ctx);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  65 */         EntityPlayerMP entityPlayerMP = (ctx.getServerHandler()).field_147369_b;
/*     */         
/*  67 */         if (entityPlayerMP != null) {
/*     */           
/*  69 */           Entity entity = ((EntityPlayer)entityPlayerMP).field_70170_p.func_73045_a(message.id);
/*     */           
/*  71 */           if (entity instanceof EntityPlayer) {
/*     */             
/*  73 */             EntityPlayer player1 = (EntityPlayer)entity;
/*     */             
/*  75 */             if (((EntityPlayer)entityPlayerMP).field_70170_p.field_72995_K) {
/*     */               
/*  77 */               ALNetworkManager.wrapper.sendToServer(new PacketUnlockPower(player1, power));
/*     */             }
/*     */             else {
/*     */               
/*  81 */               ALNetworkManager.wrapper.sendToDimension(new PacketUnlockPower(player1, power), ((EntityPlayer)entityPlayerMP).field_71093_bK);
/*     */             } 
/*     */             
/*  84 */             onMessage(player1, message, ctx);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  89 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onMessage(EntityPlayer player, PacketUnlockPower message, MessageContext ctx) {
/*  94 */       PowerManager.getPowerData(player, message.power).setUnlocked((Entity)player, true);
/*     */       
/*  96 */       if (message.power == Power.FORCE_SENSITIVITY) {
/*     */         
/*  98 */         PowerManager.getPowerData(player, Power.LIGHT_SIDE).setUnlocked((Entity)player, true);
/*  99 */         PowerManager.getPowerData(player, Power.DARK_SIDE).setUnlocked((Entity)player, true);
/* 100 */         PowerManager.getPowerData(player, Power.NEUTRAL).setUnlocked((Entity)player, true);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\PacketUnlockPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */