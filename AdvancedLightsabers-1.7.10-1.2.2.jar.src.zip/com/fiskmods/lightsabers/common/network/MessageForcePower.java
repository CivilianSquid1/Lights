package com.fiskmods.lightsabers.common.network;

public class MessageForcePower {}


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessageForcePower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */