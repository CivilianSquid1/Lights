/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.Log;
/*    */ import fiskfille.utils.common.network.AbstractMessage;
/*    */ import fiskfille.utils.helper.NBTHelper;
/*    */ import fiskfille.utils.registry.FiskRegistryEntry;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class MessagePlayerData
/*    */   extends AbstractMessage<MessagePlayerData>
/*    */ {
/*    */   private int id;
/*    */   private ALData type;
/*    */   private Object value;
/*    */   
/*    */   public MessagePlayerData() {}
/*    */   
/*    */   public MessagePlayerData(EntityPlayer player, ALData data, Object obj) {
/* 24 */     this.id = player.func_145782_y();
/* 25 */     this.type = data;
/* 26 */     this.value = obj;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 32 */     this.id = buf.readInt();
/* 33 */     this.type = (ALData)ALData.REGISTRY.getObjectById(buf.readShort());
/* 34 */     this.value = NBTHelper.fromBytes(buf, this.type.typeClass);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 40 */     buf.writeInt(this.id);
/* 41 */     buf.writeShort(ALData.REGISTRY.getIDForObject((FiskRegistryEntry)this.type));
/* 42 */     NBTHelper.toBytes(buf, this.value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 48 */     EntityPlayer player = getSender(this.id);
/* 49 */     Side senderSide = this.context.side.isClient() ? Side.SERVER : Side.CLIENT;
/*    */     
/* 51 */     if (!this.type.hasPerms(senderSide)) {
/*    */       
/* 53 */       Log.warn("Player %s tried to set %s to %s on illegal side %s!", new Object[] { player.func_70005_c_(), this.type, this.value, senderSide });
/*    */       
/*    */       return;
/*    */     } 
/* 57 */     if (this.context.side.isClient()) {
/*    */       
/* 59 */       this.type.setWithoutNotify((Entity)player, this.value);
/*    */     }
/*    */     else {
/*    */       
/* 63 */       this.type.set(player, this.value);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessagePlayerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */