/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*    */ import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.common.network.FiskNetworkHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ALNetworkManager
/*    */   extends FiskNetworkHelper
/*    */ {
/*    */   public static SimpleNetworkWrapper wrapper;
/*    */   
/*    */   public static void register() {
/* 18 */     wrapper = getWrapper("lightsabers");
/*    */     
/* 20 */     registerMessage(MessageBroadcastState.class);
/* 21 */     registerMessage(MessagePlayerData.class);
/*    */     
/* 23 */     registerMessage(MessagePlayerJoin.class, Side.CLIENT);
/* 24 */     registerMessage(MessageUpdateEffects.class, Side.CLIENT);
/*    */     
/* 26 */     registerPacket((Class)PacketTileAction.Handler.class, PacketTileAction.class);
/* 27 */     registerPacket((Class)PacketThrowLightsaber.Handler.class, PacketThrowLightsaber.class);
/* 28 */     registerPacket((Class)PacketUnlockPower.Handler.class, PacketUnlockPower.class);
/* 29 */     registerPacket((Class)PacketRightClick.Handler.class, PacketRightClick.class);
/*    */   }
/*    */ 
/*    */   
/*    */   private static <REQ extends cpw.mods.fml.common.network.simpleimpl.IMessage, REPLY extends cpw.mods.fml.common.network.simpleimpl.IMessage> void registerPacket(Class<? extends IMessageHandler<REQ, REPLY>> messageHandler, Class<REQ> requestMessageType) {
/* 34 */     wrapper.registerMessage(messageHandler, requestMessageType, getNextId("lightsabers"), Side.CLIENT);
/* 35 */     wrapper.registerMessage(messageHandler, requestMessageType, getNextId("lightsabers"), Side.SERVER);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\ALNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */