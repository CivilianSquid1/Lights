/*     */ package com.fiskmods.lightsabers.common.network;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.ALPlayerData;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerStats;
/*     */ import com.fiskmods.lightsabers.common.force.PowerType;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import cpw.mods.fml.common.network.simpleimpl.MessageContext;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketRightClick
/*     */   implements IMessage
/*     */ {
/*     */   public int id;
/*     */   private Power power;
/*     */   
/*     */   public PacketRightClick() {}
/*     */   
/*     */   public PacketRightClick(EntityPlayer player, Power p) {
/*  32 */     this.id = player.func_145782_y();
/*  33 */     this.power = p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fromBytes(ByteBuf buf) {
/*  39 */     this.id = buf.readInt();
/*  40 */     this.power = Power.getPowerFromName(ByteBufUtils.readUTF8String(buf));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/*  46 */     buf.writeInt(this.id);
/*  47 */     ByteBufUtils.writeUTF8String(buf, this.power.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void onMessage(EntityPlayer player, Power power, Side side) {
/*  52 */     ALPlayerData data = ALPlayerData.getData(player);
/*  53 */     PowerStats stats = power.powerStats;
/*  54 */     float force = ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue();
/*     */     
/*  56 */     if (force >= power.getUseCost(player))
/*     */     {
/*  58 */       if (power.powerStats.powerType == PowerType.PER_USE) {
/*     */         
/*  60 */         if (power.powerEffect.execute(player, side))
/*     */         {
/*  62 */           String sound = power.powerEffect.getCastSound(power.getSide());
/*     */           
/*  64 */           if (!StringUtils.func_151246_b(sound))
/*     */           {
/*  66 */             player.func_85030_a(sound, power.powerEffect.getCastSoundVolume(power.getSide()), power.powerEffect.getCastSoundPitch(power.getSide()));
/*     */           }
/*     */           
/*  69 */           ALData.FORCE_POWER.incrWithoutNotify((Entity)player, Float.valueOf(-power.getUseCost(player)));
/*  70 */           ALData.USE_POWER_COOLDOWN.setWithoutNotify((Entity)player, Integer.valueOf(20));
/*     */         }
/*  72 */         else if (side.isClient())
/*     */         {
/*  74 */           player.func_85030_a(ALSounds.player_force_fail, 1.0F, 1.0F);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  79 */       else if (power.powerEffect.execute(player, side)) {
/*     */         
/*  81 */         ALData.FORCE_POWER.incrWithoutNotify((Entity)player, Float.valueOf(-power.getUseCost(player) / 20.0F));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Handler
/*     */     implements IMessageHandler<PacketRightClick, IMessage>
/*     */   {
/*     */     public IMessage onMessage(PacketRightClick message, MessageContext ctx) {
/*  92 */       EntityPlayer clientPlayer = ctx.side.isClient() ? Lightsabers.proxy.getPlayer() : (EntityPlayer)(ctx.getServerHandler()).field_147369_b;
/*     */       
/*  94 */       if (clientPlayer != null)
/*     */       {
/*  96 */         if (clientPlayer.field_70170_p.func_73045_a(message.id) instanceof EntityPlayer) {
/*     */           
/*  98 */           EntityPlayer player = (EntityPlayer)clientPlayer.field_70170_p.func_73045_a(message.id);
/*     */           
/* 100 */           if (ctx.side.isServer() || player != clientPlayer) {
/*     */             
/* 102 */             PacketRightClick.onMessage(player, message.power, ctx.side);
/*     */             
/* 104 */             if (ctx.side.isServer())
/*     */             {
/* 106 */               ALNetworkManager.wrapper.sendToDimension(new PacketRightClick(player, message.power), clientPlayer.field_71093_bK);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 112 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\PacketRightClick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */