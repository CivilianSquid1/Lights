/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*    */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*    */ import cpw.mods.fml.common.network.simpleimpl.MessageContext;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketThrowLightsaber
/*    */   implements IMessage
/*    */ {
/*    */   public int id;
/*    */   private ItemStack lightsaber;
/*    */   
/*    */   public PacketThrowLightsaber() {}
/*    */   
/*    */   public PacketThrowLightsaber(EntityLivingBase entity, ItemStack itemstack) {
/* 28 */     this.id = entity.func_145782_y();
/* 29 */     this.lightsaber = itemstack;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 35 */     this.id = buf.readInt();
/* 36 */     this.lightsaber = ByteBufUtils.readItemStack(buf);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 42 */     buf.writeInt(this.id);
/* 43 */     ByteBufUtils.writeItemStack(buf, this.lightsaber);
/*    */   }
/*    */ 
/*    */   
/*    */   public static class Handler
/*    */     implements IMessageHandler<PacketThrowLightsaber, IMessage>
/*    */   {
/*    */     public IMessage onMessage(PacketThrowLightsaber message, MessageContext ctx) {
/* 51 */       ItemStack lightsaber = message.lightsaber;
/*    */       
/* 53 */       if (ctx.side.isClient()) {
/*    */         
/* 55 */         EntityPlayer player = Lightsabers.proxy.getPlayer();
/* 56 */         Entity entity = player.field_70170_p.func_73045_a(message.id);
/*    */         
/* 58 */         if (entity instanceof EntityLivingBase)
/*    */         {
/* 60 */           EntityLivingBase entity1 = (EntityLivingBase)entity;
/* 61 */           ItemLightsaberBase.throwLightsaber(entity1, lightsaber, 1);
/*    */         }
/*    */       
/*    */       } else {
/*    */         
/* 66 */         EntityPlayerMP entityPlayerMP = (ctx.getServerHandler()).field_147369_b;
/*    */         
/* 68 */         if (entityPlayerMP != null) {
/*    */           
/* 70 */           Entity entity = ((EntityPlayer)entityPlayerMP).field_70170_p.func_73045_a(message.id);
/*    */           
/* 72 */           if (entity instanceof EntityLivingBase) {
/*    */             
/* 74 */             EntityLivingBase entity1 = (EntityLivingBase)entity;
/*    */             
/* 76 */             if (((EntityPlayer)entityPlayerMP).field_70170_p.field_72995_K) {
/*    */               
/* 78 */               ALNetworkManager.wrapper.sendToServer(new PacketThrowLightsaber(entity1, lightsaber));
/*    */             }
/*    */             else {
/*    */               
/* 82 */               ALNetworkManager.wrapper.sendToDimension(new PacketThrowLightsaber(entity1, lightsaber), ((EntityPlayer)entityPlayerMP).field_71093_bK);
/*    */             } 
/*    */             
/* 85 */             ItemLightsaberBase.throwLightsaber(entity1, lightsaber, 1);
/*    */           } 
/*    */         } 
/*    */       } 
/*    */       
/* 90 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\PacketThrowLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */