/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*    */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*    */ import fiskfille.utils.common.network.AbstractMessage;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class MessageBroadcastState
/*    */   extends MessageSyncBase<MessageBroadcastState>
/*    */ {
/*    */   private int id;
/*    */   
/*    */   public MessageBroadcastState() {}
/*    */   
/*    */   public MessageBroadcastState(EntityPlayer player) {
/* 23 */     super(player);
/* 24 */     this.id = player.func_145782_y();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 30 */     this.id = buf.readInt();
/* 31 */     super.fromBytes(buf);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 37 */     buf.writeInt(this.id);
/* 38 */     super.toBytes(buf);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 44 */     EntityPlayer player = getSender(this.id);
/*    */     
/* 46 */     if (this.context.side.isClient() && Lightsabers.proxy.isClientPlayer((EntityLivingBase)player)) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 51 */     for (Map.Entry<ALData, Object> e : this.playerData.entrySet())
/*    */     {
/* 53 */       ((ALData)e.getKey()).setWithoutNotify((Entity)player, e.getValue());
/*    */     }
/*    */     
/* 56 */     if (!this.activeEffects.isEmpty())
/*    */     {
/* 58 */       Collections.sort(this.activeEffects);
/*    */     }
/*    */     
/* 61 */     (ALEntityData.getData((EntityLivingBase)player)).activeEffects = this.activeEffects;
/*    */     
/* 63 */     if (this.context.side.isServer())
/*    */     {
/* 65 */       ALNetworkManager.wrapper.sendToDimension((IMessage)new MessageBroadcastState(player), player.field_71093_bK);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessageBroadcastState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */