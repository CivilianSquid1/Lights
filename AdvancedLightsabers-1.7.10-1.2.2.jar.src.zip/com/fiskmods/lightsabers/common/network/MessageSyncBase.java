/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.data.ALPlayerData;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import com.google.common.collect.Lists;
/*    */ import fiskfille.utils.common.network.AbstractMessage;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MessageSyncBase<REQ extends MessageSyncBase>
/*    */   extends AbstractMessage<REQ>
/*    */ {
/*    */   protected Map<ALData, Object> playerData;
/*    */   protected List<StatusEffect> activeEffects;
/*    */   
/*    */   public MessageSyncBase() {}
/*    */   
/*    */   protected MessageSyncBase(EntityPlayer player) {
/* 27 */     this.playerData = (ALPlayerData.getData(player)).data;
/* 28 */     this.activeEffects = StatusEffect.get((EntityLivingBase)player);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 34 */     this.playerData = ALData.fromBytes(buf, new HashMap<>());
/* 35 */     this.activeEffects = Lists.newArrayList();
/* 36 */     int length = buf.readInt();
/*    */     
/* 38 */     for (int j = 0; j < length; j++) {
/*    */       
/* 40 */       StatusEffect effect = StatusEffect.fromBytes(buf);
/*    */       
/* 42 */       if (effect != null)
/*    */       {
/* 44 */         this.activeEffects.add(effect);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 52 */     ALData.toBytes(buf, this.playerData);
/* 53 */     buf.writeInt(this.activeEffects.size());
/*    */     
/* 55 */     for (StatusEffect effect : this.activeEffects)
/*    */     {
/* 57 */       effect.toBytes(buf);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessageSyncBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */