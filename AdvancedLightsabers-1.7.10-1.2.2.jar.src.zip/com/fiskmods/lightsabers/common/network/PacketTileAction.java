/*     */ package com.fiskmods.lightsabers.common.network;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import cpw.mods.fml.common.network.simpleimpl.MessageContext;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketTileAction
/*     */   implements IMessage
/*     */ {
/*     */   private int id;
/*     */   private int x;
/*     */   private int y;
/*     */   private int z;
/*     */   private int action;
/*     */   
/*     */   public PacketTileAction() {}
/*     */   
/*     */   public PacketTileAction(Entity entity, int x, int y, int z, int action) {
/*  35 */     this.id = (entity != null) ? entity.func_145782_y() : 0;
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.z = z;
/*  39 */     this.action = action;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fromBytes(ByteBuf buf) {
/*  45 */     this.id = buf.readInt();
/*  46 */     this.x = buf.readInt();
/*  47 */     this.y = buf.readInt();
/*  48 */     this.z = buf.readInt();
/*  49 */     this.action = buf.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/*  55 */     buf.writeInt(this.id);
/*  56 */     buf.writeInt(this.x);
/*  57 */     buf.writeInt(this.y);
/*  58 */     buf.writeInt(this.z);
/*  59 */     buf.writeInt(this.action);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Handler
/*     */     implements IMessageHandler<PacketTileAction, IMessage>
/*     */   {
/*     */     public IMessage onMessage(PacketTileAction message, MessageContext ctx) {
/*  67 */       EntityPlayer clientPlayer = ctx.side.isClient() ? Lightsabers.proxy.getPlayer() : (EntityPlayer)(ctx.getServerHandler()).field_147369_b;
/*  68 */       EntityPlayer player = null;
/*  69 */       World world = clientPlayer.field_70170_p;
/*  70 */       int action = message.action;
/*  71 */       int x = message.x;
/*  72 */       int y = message.y;
/*  73 */       int z = message.z;
/*     */       
/*  75 */       if (world.func_147438_o(x, y, z) instanceof TileEntitySithCoffin) {
/*     */         
/*  77 */         TileEntitySithCoffin tile = (TileEntitySithCoffin)world.func_147438_o(x, y, z);
/*     */         
/*  79 */         if (tile != null)
/*     */         {
/*  81 */           int metadata = tile.func_145832_p();
/*     */           
/*  83 */           if (world.func_73045_a(message.id) instanceof EntityPlayer) {
/*     */             
/*  85 */             player = (EntityPlayer)world.func_73045_a(message.id);
/*     */             
/*  87 */             if (action == 0)
/*     */             {
/*  89 */               if (tile.lidOpenTimer == 0) {
/*     */                 
/*  91 */                 tile.isLidOpen = true;
/*  92 */                 player.func_85030_a(ALSounds.block_sith_sarcophagus_open, 1.0F, 1.0F);
/*     */               }
/*  94 */               else if (tile.lidOpenTimer == 60) {
/*     */                 
/*  96 */                 tile.isLidOpen = false;
/*  97 */                 player.func_85030_a(ALSounds.block_sith_sarcophagus_close, 1.0F, 1.0F);
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 102 */           if (ctx.side.isServer())
/*     */           {
/* 104 */             ALNetworkManager.wrapper.sendToAll(new PacketTileAction((Entity)player, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, action));
/*     */           }
/*     */         }
/*     */       
/* 108 */       } else if (world.func_147438_o(x, y, z) instanceof TileEntitySithStoneCoffin) {
/*     */         
/* 110 */         TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */         
/* 112 */         if (tile != null)
/*     */         {
/* 114 */           int metadata = tile.func_145832_p();
/*     */           
/* 116 */           if (action == 0 || action == 1) {
/*     */             
/* 118 */             tile.baseplateOnly = (action > 0);
/*     */             
/* 120 */             if (tile.baseplateOnly) {
/*     */               
/* 122 */               world.func_147468_f(x, y + 1, z);
/*     */             }
/*     */             else {
/*     */               
/* 126 */               world.func_147465_d(x, y + 1, z, ModBlocks.sithStoneCoffin, tile.func_145832_p() + 4, 2);
/*     */             } 
/*     */             
/* 129 */             Entity entity = world.func_73045_a(message.id);
/*     */             
/* 131 */             if (entity != null) {
/*     */               
/* 133 */               Random rand = new Random();
/*     */               
/* 135 */               for (int i = 0; i < 128; i++) {
/*     */                 
/* 137 */                 double d0 = (rand.nextFloat() * 2.0F - 1.0F) * 1.2000000476837158D;
/* 138 */                 double d1 = (rand.nextFloat() * 2.4F - 1.0F);
/* 139 */                 double d2 = (rand.nextFloat() * 2.0F - 1.0F) * 1.2000000476837158D;
/* 140 */                 double d3 = entity.field_70165_t + d0 * entity.field_70130_N;
/* 141 */                 double d4 = entity.field_70121_D.field_72338_b + d1 * entity.field_70131_O;
/* 142 */                 double d5 = entity.field_70161_v + d2 * entity.field_70130_N;
/* 143 */                 world.func_72869_a("largesmoke", d3, d4, d5, 0.0D, 0.0D, 0.0D);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 148 */           if (ctx.side.isServer())
/*     */           {
/* 150 */             ALNetworkManager.wrapper.sendToAll(new PacketTileAction((Entity)player, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, action));
/*     */           }
/*     */         }
/*     */       
/* 154 */       } else if (world.func_147438_o(x, y, z) instanceof TileEntityHolocron) {
/*     */         
/* 156 */         TileEntityHolocron tile = (TileEntityHolocron)world.func_147438_o(x, y, z);
/*     */         
/* 158 */         if (tile != null) {
/*     */           
/* 160 */           int metadata = tile.func_145832_p();
/*     */           
/* 162 */           if (world.func_73045_a(message.id) instanceof EntityPlayer) {
/*     */             
/* 164 */             player = (EntityPlayer)world.func_73045_a(message.id);
/*     */             
/* 166 */             if (action == 0) {
/*     */               
/* 168 */               tile.playersUsing++;
/*     */             }
/* 170 */             else if (action == 1) {
/*     */               
/* 172 */               tile.playersUsing--;
/*     */             } 
/*     */           } 
/*     */           
/* 176 */           if (ctx.side.isServer())
/*     */           {
/* 178 */             ALNetworkManager.wrapper.sendToAll(new PacketTileAction((Entity)player, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, action));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 183 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\PacketTileAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */