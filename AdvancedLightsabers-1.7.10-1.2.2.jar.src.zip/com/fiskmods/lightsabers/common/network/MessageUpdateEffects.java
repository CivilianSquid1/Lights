/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import com.google.common.collect.Lists;
/*    */ import fiskfille.utils.common.network.AbstractMessage;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageUpdateEffects
/*    */   extends AbstractMessage<MessageUpdateEffects>
/*    */ {
/*    */   private int id;
/*    */   private List<StatusEffect> activeEffects;
/*    */   
/*    */   public MessageUpdateEffects() {}
/*    */   
/*    */   public MessageUpdateEffects(EntityLivingBase entity, List<StatusEffect> list) {
/* 25 */     this.id = entity.func_145782_y();
/* 26 */     this.activeEffects = list;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 32 */     this.id = buf.readInt();
/* 33 */     this.activeEffects = Lists.newArrayList();
/* 34 */     int length = buf.readInt();
/*    */     
/* 36 */     for (int i = 0; i < length; i++) {
/*    */       
/* 38 */       StatusEffect effect = StatusEffect.fromBytes(buf);
/*    */       
/* 40 */       if (effect != null)
/*    */       {
/* 42 */         this.activeEffects.add(effect);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 50 */     buf.writeInt(this.id);
/* 51 */     buf.writeInt(this.activeEffects.size());
/*    */     
/* 53 */     for (StatusEffect effect : this.activeEffects)
/*    */     {
/* 55 */       effect.toBytes(buf);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 62 */     (ALEntityData.getData((EntityLivingBase)getEntity(EntityLivingBase.class, this.id))).activeEffects = this.activeEffects;
/*    */     
/* 64 */     if (!this.activeEffects.isEmpty())
/*    */     {
/* 66 */       Collections.sort(this.activeEffects);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessageUpdateEffects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */