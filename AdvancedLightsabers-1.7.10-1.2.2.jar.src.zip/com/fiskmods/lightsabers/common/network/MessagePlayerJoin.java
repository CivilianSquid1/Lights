/*    */ package com.fiskmods.lightsabers.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*    */ import fiskfille.utils.common.network.AbstractMessage;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class MessagePlayerJoin
/*    */   extends MessageSyncBase<MessagePlayerJoin>
/*    */ {
/*    */   public MessagePlayerJoin() {}
/*    */   
/*    */   public MessagePlayerJoin(EntityPlayer player) {
/* 19 */     super(player);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 25 */     EntityPlayer player = getPlayer();
/*    */     
/* 27 */     for (Map.Entry<ALData, Object> e : this.playerData.entrySet())
/*    */     {
/* 29 */       ((ALData)e.getKey()).setWithoutNotify((Entity)player, e.getValue());
/*    */     }
/*    */     
/* 32 */     if (!this.activeEffects.isEmpty())
/*    */     {
/* 34 */       Collections.sort(this.activeEffects);
/*    */     }
/*    */     
/* 37 */     (ALEntityData.getData((EntityLivingBase)player)).activeEffects = this.activeEffects;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\network\MessagePlayerJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */