/*    */ package com.fiskmods.lightsabers.common.tileentity;
/*    */ 
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ 
/*    */ 
/*    */ public class TileEntityLightsaberForge
/*    */   extends TileEntity
/*    */ {
/*    */   public AxisAlignedBB getRenderBoundingBox() {
/* 11 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 1), (this.field_145849_e + 1)).func_72314_b(1.5D, 0.5D, 1.5D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntityLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */