/*    */ package com.fiskmods.lightsabers.common.tileentity;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.util.MathHelper;
/*    */ 
/*    */ 
/*    */ public class TileEntityHolocron
/*    */   extends TileEntity
/*    */ {
/*    */   public int playersUsing;
/*    */   public float openTimer;
/*    */   public float prevOpenTimer;
/*    */   public int openTicks;
/*    */   public int prevOpenTicks;
/*    */   
/*    */   public void func_145845_h() {
/* 22 */     this.prevOpenTimer = this.openTimer;
/* 23 */     this.prevOpenTicks = this.openTicks;
/*    */     
/* 25 */     if (this.playersUsing <= 0) {
/*    */       
/* 27 */       this.openTimer *= 0.85F;
/*    */     }
/* 29 */     else if (this.openTimer < 1.0F) {
/*    */       
/* 31 */       this.openTimer += 0.05F;
/* 32 */       this.openTimer *= 1.05F;
/*    */     } 
/*    */     
/* 35 */     if (this.openTimer < 1.0E-6D)
/*    */     {
/* 37 */       this.openTimer = 0.0F;
/*    */     }
/*    */     
/* 40 */     if (this.openTimer == 0.0F) {
/*    */       
/* 42 */       this.openTicks = 0;
/*    */     }
/* 44 */     else if (this.openTimer >= 1.0F) {
/*    */       
/* 46 */       this.openTicks++;
/*    */     } 
/*    */     
/* 49 */     this.openTimer = MathHelper.func_76131_a(this.openTimer, 0.0F, 1.0F);
/* 50 */     this.playersUsing = Math.max(this.playersUsing, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbttagcompound) {
/* 56 */     super.func_145839_a(nbttagcompound);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_145841_b(NBTTagCompound nbttagcompound) {
/* 63 */     super.func_145841_b(nbttagcompound);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB getRenderBoundingBox() {
/* 70 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 1), (this.field_145849_e + 1));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Packet func_145844_m() {
/* 76 */     NBTTagCompound syncData = new NBTTagCompound();
/* 77 */     func_145841_b(syncData);
/*    */     
/* 79 */     return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 1, syncData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDataPacket(NetworkManager netManager, S35PacketUpdateTileEntity packet) {
/* 85 */     func_145839_a(packet.func_148857_g());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntityHolocron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */