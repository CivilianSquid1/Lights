/*     */ package com.fiskmods.lightsabers.common.tileentity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.BlockSithCoffin;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.BlockDirectional;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ 
/*     */ public class TileEntitySithCoffin
/*     */   extends TileEntity
/*     */   implements IInventory
/*     */ {
/*     */   public static final int LID_OPEN_MAX = 60;
/*  23 */   private ItemStack[] itemstacks = new ItemStack[28];
/*     */   
/*     */   public boolean hasBeenOpened = false;
/*     */   public boolean isLidOpen = false;
/*  27 */   public int lidOpenTimer = 0;
/*  28 */   public int prevLidOpenTimer = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145845_h() {
/*  33 */     this.prevLidOpenTimer = this.lidOpenTimer;
/*     */     
/*  35 */     if (!this.isLidOpen) {
/*     */       
/*  37 */       if (this.lidOpenTimer > 0)
/*     */       {
/*  39 */         this.lidOpenTimer--;
/*     */       }
/*     */     }
/*  42 */     else if (this.lidOpenTimer < 60) {
/*     */       
/*  44 */       this.lidOpenTimer++;
/*     */     } 
/*     */     
/*  47 */     int metadata = func_145832_p();
/*  48 */     int dir = BlockDirectional.func_149895_l(metadata);
/*     */     
/*  50 */     if (!BlockSithCoffin.isBlockFrontOfCoffin(metadata))
/*     */     {
/*  52 */       if (!this.hasBeenOpened)
/*     */       {
/*  54 */         if (this.lidOpenTimer < 60) {
/*     */           
/*  56 */           double radius = 0.5D;
/*     */           double y;
/*  58 */           for (y = 0.0D; y <= (this.lidOpenTimer / 5.0F); y += 0.025D)
/*     */           {
/*  60 */             Random rand = new Random();
/*  61 */             double d = Math.cos(y * 2.0D);
/*  62 */             double x = radius * Math.cos(y + (this.lidOpenTimer / 2.0F)) * d;
/*  63 */             double z = radius * Math.sin(y + (this.lidOpenTimer / 2.0F)) * d;
/*  64 */             double motionX = ((rand.nextFloat() - 0.5F) * 0.5F) * d;
/*  65 */             double motionY = ((rand.nextFloat() - 0.5F) * 0.1F);
/*  66 */             double motionZ = ((rand.nextFloat() - 0.5F) * 0.5F) * d;
/*  67 */             this.field_145850_b.func_72869_a("smoke", (this.field_145851_c + 0.5F) + x + (BlockSithCoffin.DIRECTIONS[dir][0] * 0.5F), (this.field_145848_d + 0.8F) + y, (this.field_145849_e + 0.5F) + z + (BlockSithCoffin.DIRECTIONS[dir][1] * 0.5F), motionX, motionY, motionZ);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/*  72 */           this.hasBeenOpened = true;
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public float getLidOpenTimer(float partialTicks) {
/*  80 */     float f = (this.lidOpenTimer - this.prevLidOpenTimer);
/*  81 */     return (this.prevLidOpenTimer + f * partialTicks) / 60.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getRenderBoundingBox() {
/*  87 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 1), (this.field_145849_e + 1)).func_72314_b(1.0D, 0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/*  93 */     return this.itemstacks.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/*  99 */     return this.itemstacks[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/* 105 */     if (this.itemstacks[slot] != null) {
/*     */ 
/*     */ 
/*     */       
/* 109 */       if ((this.itemstacks[slot]).field_77994_a <= amount) {
/*     */         
/* 111 */         ItemStack itemStack = this.itemstacks[slot];
/* 112 */         this.itemstacks[slot] = null;
/* 113 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/* 117 */       ItemStack itemstack = this.itemstacks[slot].func_77979_a(amount);
/*     */       
/* 119 */       if ((this.itemstacks[slot]).field_77994_a == 0)
/*     */       {
/* 121 */         this.itemstacks[slot] = null;
/*     */       }
/*     */       
/* 124 */       return itemstack;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/* 136 */     if (this.itemstacks[slot] != null) {
/*     */       
/* 138 */       ItemStack itemstack = this.itemstacks[slot];
/* 139 */       this.itemstacks[slot] = null;
/* 140 */       return itemstack;
/*     */     } 
/*     */ 
/*     */     
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack itemstack) {
/* 151 */     this.itemstacks[slot] = itemstack;
/*     */     
/* 153 */     if (itemstack != null && itemstack.field_77994_a > func_70297_j_())
/*     */     {
/* 155 */       itemstack.field_77994_a = func_70297_j_();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_145825_b() {
/* 162 */     return "gui.sith_coffin";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/* 168 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt) {
/* 174 */     super.func_145839_a(nbt);
/* 175 */     NBTTagList nbttaglist = nbt.func_150295_c("Items", 10);
/* 176 */     this.itemstacks = new ItemStack[func_70302_i_()];
/*     */     
/* 178 */     for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
/*     */       
/* 180 */       NBTTagCompound nbttagcompound1 = nbttaglist.func_150305_b(i);
/* 181 */       byte slot = nbttagcompound1.func_74771_c("Slot");
/*     */       
/* 183 */       if (slot >= 0 && slot < this.itemstacks.length)
/*     */       {
/* 185 */         this.itemstacks[slot] = ItemStack.func_77949_a(nbttagcompound1);
/*     */       }
/*     */     } 
/*     */     
/* 189 */     this.hasBeenOpened = nbt.func_74767_n("HasBeenOpened");
/* 190 */     this.isLidOpen = nbt.func_74767_n("IsLidOpen");
/* 191 */     this.lidOpenTimer = nbt.func_74762_e("LidOpenTimer");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound nbt) {
/* 197 */     super.func_145841_b(nbt);
/* 198 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 200 */     for (int i = 0; i < this.itemstacks.length; i++) {
/*     */       
/* 202 */       if (this.itemstacks[i] != null) {
/*     */         
/* 204 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 205 */         nbttagcompound1.func_74774_a("Slot", (byte)i);
/* 206 */         this.itemstacks[i].func_77955_b(nbttagcompound1);
/* 207 */         nbttaglist.func_74742_a((NBTBase)nbttagcompound1);
/*     */       } 
/*     */     } 
/*     */     
/* 211 */     nbt.func_74782_a("Items", (NBTBase)nbttaglist);
/* 212 */     nbt.func_74757_a("HasBeenOpened", this.hasBeenOpened);
/* 213 */     nbt.func_74757_a("IsLidOpen", this.isLidOpen);
/* 214 */     nbt.func_74768_a("LidOpenTimer", this.lidOpenTimer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/* 220 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer player) {
/* 226 */     return (this.field_145850_b.func_147438_o(this.field_145851_c, this.field_145848_d, this.field_145849_e) != this) ? false : ((player.func_70092_e(this.field_145851_c + 0.5D, this.field_145848_d + 0.5D, this.field_145849_e + 0.5D) <= 64.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70295_k_() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70305_f() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int slot, ItemStack stack) {
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Packet func_145844_m() {
/* 248 */     NBTTagCompound syncData = new NBTTagCompound();
/* 249 */     func_145841_b(syncData);
/*     */     
/* 251 */     return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 1, syncData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDataPacket(NetworkManager netManager, S35PacketUpdateTileEntity packet) {
/* 257 */     func_145839_a(packet.func_148857_g());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntitySithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */