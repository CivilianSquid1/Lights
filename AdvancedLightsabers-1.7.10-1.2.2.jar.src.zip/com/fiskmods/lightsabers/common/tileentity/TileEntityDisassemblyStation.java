/*     */ package com.fiskmods.lightsabers.common.tileentity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ItemFocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEntityDisassemblyStation
/*     */   extends TileEntity
/*     */   implements ISidedInventory
/*     */ {
/*     */   public static final int TICKS_DISASSEMBLY = 2400;
/*     */   public static final int INPUT = 0;
/*     */   public static final int FUEL = 1;
/*  41 */   private static final int[] SLOTS_TOP = new int[] { 0 };
/*  42 */   private static final int[] SLOTS_BOTTOM = new int[] { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 1 };
/*  43 */   private static final int[] SLOTS_SIDES = new int[] { 0, 1 };
/*     */   
/*  45 */   private ItemStack[] itemstacks = new ItemStack[17];
/*     */   
/*     */   public int fuelTicks;
/*     */   
/*     */   public int maxFuelTicks;
/*     */   
/*     */   public int progress;
/*     */ 
/*     */   
/*     */   public void func_145845_h() {
/*  55 */     boolean burning = (this.fuelTicks > 0);
/*  56 */     boolean dirty = false;
/*     */     
/*  58 */     if (this.fuelTicks > 0)
/*     */     {
/*  60 */       this.fuelTicks--;
/*     */     }
/*     */     
/*  63 */     if (!this.field_145850_b.field_72995_K) {
/*     */       
/*  65 */       if (this.fuelTicks != 0 || (this.itemstacks[1] != null && this.itemstacks[0] != null)) {
/*     */         
/*  67 */         if (this.fuelTicks == 0 && canDisassemble(this.itemstacks[0]) && (this.maxFuelTicks = this.fuelTicks = getItemBurnTime(this.itemstacks[1])) > 0) {
/*     */           
/*  69 */           dirty = true;
/*     */           
/*  71 */           if (this.itemstacks[1] != null) {
/*     */             
/*  73 */             (this.itemstacks[1]).field_77994_a--;
/*     */             
/*  75 */             if ((this.itemstacks[1]).field_77994_a <= 0)
/*     */             {
/*  77 */               this.itemstacks[1] = null;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/*  82 */         if (isBurning() && canDisassemble(this.itemstacks[0])) {
/*     */           
/*  84 */           this.progress++;
/*     */           
/*  86 */           if (this.progress >= 2400)
/*     */           {
/*  88 */             this.progress = 0;
/*  89 */             disassembleItem();
/*  90 */             dirty = true;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/*  95 */           this.progress = 0;
/*     */         } 
/*     */       } 
/*     */       
/*  99 */       if (burning != ((this.fuelTicks > 0)))
/*     */       {
/* 101 */         dirty = true;
/*     */       }
/*     */     } 
/*     */     
/* 105 */     if (dirty)
/*     */     {
/* 107 */       func_70296_d();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getCookProgressScaled(int scale) {
/* 114 */     return this.progress * scale / 2400;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getBurnTimeRemainingScaled(int scale) {
/* 120 */     if (this.maxFuelTicks == 0)
/*     */     {
/* 122 */       this.maxFuelTicks = 200;
/*     */     }
/*     */     
/* 125 */     return this.fuelTicks * scale / this.maxFuelTicks;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBurning() {
/* 130 */     return (this.fuelTicks > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canDisassemble(ItemStack stack) {
/* 135 */     return (stack != null && stack.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaberBase);
/*     */   }
/*     */ 
/*     */   
/*     */   public void disassembleItem() {
/* 140 */     if (canDisassemble(this.itemstacks[0])) {
/*     */       
/* 142 */       Map<ItemStack, Float> drops = getOutput(this.itemstacks[0]);
/*     */       
/* 144 */       for (Map.Entry<ItemStack, Float> e : drops.entrySet()) {
/*     */         
/* 146 */         if (((Float)e.getValue()).floatValue() > this.field_145850_b.field_73012_v.nextFloat())
/*     */         {
/* 148 */           addOutputItem(e.getKey());
/*     */         }
/*     */       } 
/*     */       
/* 152 */       (this.itemstacks[0]).field_77994_a--;
/*     */       
/* 154 */       if ((this.itemstacks[0]).field_77994_a <= 0)
/*     */       {
/* 156 */         this.itemstacks[0] = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addOutputItem(ItemStack stack) {
/* 163 */     stack = stack.func_77946_l();
/*     */     
/* 165 */     for (int i = 2; i < func_70302_i_(); i++) {
/*     */       
/* 167 */       if (this.itemstacks[i] == null) {
/*     */         
/* 169 */         this.itemstacks[i] = stack.func_77946_l();
/*     */         return;
/*     */       } 
/* 172 */       if (ItemStack.func_77989_b(stack, this.itemstacks[i])) {
/*     */         
/* 174 */         int j = Math.min(stack.field_77994_a, stack.func_77976_d() - (this.itemstacks[i]).field_77994_a);
/* 175 */         (this.itemstacks[i]).field_77994_a += j;
/* 176 */         stack.field_77994_a -= j;
/*     */         
/* 178 */         if (stack.field_77994_a <= 0) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 185 */     ALHelper.dropItem(this.field_145850_b, this.field_145851_c, this.field_145848_d, this.field_145849_e, stack, this.field_145850_b.field_73012_v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<ItemStack, Float> getOutput(ItemStack stack) {
/* 190 */     if (stack.func_77973_b() instanceof ItemDoubleLightsaber) {
/*     */       
/* 192 */       LightsaberData[] data = ItemDoubleLightsaber.get(stack);
/* 193 */       Map<ItemStack, Float> drops = getOutput(data[0], true);
/* 194 */       drops.putAll(getOutput(data[1], true));
/*     */       
/* 196 */       return drops;
/*     */     } 
/*     */     
/* 199 */     return getOutput(LightsaberData.get(stack), (!stack.func_77942_o() || !stack.func_77978_p().func_74764_b("Special")));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<ItemStack, Float> getOutput(LightsaberData data, boolean salvageColor) {
/* 204 */     Map<ItemStack, Float> drops = new LinkedHashMap<>();
/* 205 */     drops.put(new ItemStack(ModItems.circuitry), Float.valueOf(0.25F));
/*     */     
/* 207 */     if (data.isHiltUniform()) {
/*     */       
/* 209 */       for (PartType type : PartType.values())
/*     */       {
/* 211 */         drops.put(ItemLightsaberPart.create(type, data.get(type)), Float.valueOf(1.0F));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 216 */       Map<Hilt, Integer> hilts = new HashMap<>();
/*     */       
/* 218 */       for (Hilt hilt : data.getHilt())
/*     */       {
/* 220 */         hilts.put(hilt, Integer.valueOf(((Integer)hilts.getOrDefault(hilt, Integer.valueOf(-1))).intValue() + 1));
/*     */       }
/*     */       
/* 223 */       for (PartType type : PartType.values()) {
/*     */         
/* 225 */         Hilt hilt = data.get(type);
/* 226 */         drops.put(ItemLightsaberPart.create(type, hilt), Float.valueOf(0.66F + 0.05F * ((Integer)hilts.get(hilt)).intValue()));
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     for (FocusingCrystal crystal : data.getFocusingCrystals())
/*     */     {
/* 232 */       drops.put(ItemFocusingCrystal.create(crystal), Float.valueOf(0.725F));
/*     */     }
/*     */     
/* 235 */     if (salvageColor) {
/*     */       
/* 237 */       CrystalColor color = data.getColor();
/* 238 */       drops.put(ItemCrystal.create(color), Float.valueOf(0.35F + 0.125F * ((EnumRarity)ItemCrystal.rarityMap.get(color)).ordinal()));
/*     */     } 
/*     */     
/* 241 */     return drops;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/* 247 */     return this.itemstacks.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/* 253 */     return this.itemstacks[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/* 259 */     if (this.itemstacks[slot] != null) {
/*     */       
/* 261 */       if ((this.itemstacks[slot]).field_77994_a <= amount)
/*     */       {
/* 263 */         return func_70304_b(slot);
/*     */       }
/*     */       
/* 266 */       ItemStack stack = this.itemstacks[slot].func_77979_a(amount);
/*     */       
/* 268 */       if ((this.itemstacks[slot]).field_77994_a <= 0)
/*     */       {
/* 270 */         this.itemstacks[slot] = null;
/*     */       }
/*     */       
/* 273 */       return stack;
/*     */     } 
/*     */     
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/* 282 */     if (this.itemstacks[slot] != null) {
/*     */       
/* 284 */       ItemStack stack = this.itemstacks[slot];
/* 285 */       this.itemstacks[slot] = null;
/*     */       
/* 287 */       return stack;
/*     */     } 
/*     */     
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack stack) {
/* 296 */     this.itemstacks[slot] = stack;
/*     */     
/* 298 */     if (stack != null && stack.field_77994_a > func_70297_j_())
/*     */     {
/* 300 */       stack.field_77994_a = func_70297_j_();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_145825_b() {
/* 307 */     return "gui.disassembly_station";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/* 313 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getRenderBoundingBox() {
/* 319 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 1), (this.field_145849_e + 1)).func_72314_b(1.5D, 1.0D, 1.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt) {
/* 325 */     super.func_145839_a(nbt);
/* 326 */     NBTTagList list = nbt.func_150295_c("Items", 10);
/* 327 */     this.itemstacks = new ItemStack[func_70302_i_()];
/*     */     
/* 329 */     for (int i = 0; i < list.func_74745_c(); i++) {
/*     */       
/* 331 */       NBTTagCompound tag = list.func_150305_b(i);
/* 332 */       byte slot = tag.func_74771_c("Slot");
/*     */       
/* 334 */       if (slot >= 0 && slot < this.itemstacks.length)
/*     */       {
/* 336 */         this.itemstacks[slot] = ItemStack.func_77949_a(tag);
/*     */       }
/*     */     } 
/*     */     
/* 340 */     this.fuelTicks = nbt.func_74765_d("BurnTime");
/* 341 */     this.progress = nbt.func_74765_d("DisassemblyTime");
/* 342 */     this.maxFuelTicks = getItemBurnTime(this.itemstacks[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound nbt) {
/* 348 */     super.func_145841_b(nbt);
/* 349 */     nbt.func_74777_a("BurnTime", (short)this.fuelTicks);
/* 350 */     nbt.func_74777_a("DisassemblyTime", (short)this.progress);
/* 351 */     NBTTagList list = new NBTTagList();
/*     */     
/* 353 */     for (int i = 0; i < this.itemstacks.length; i++) {
/*     */       
/* 355 */       if (this.itemstacks[i] != null) {
/*     */         
/* 357 */         NBTTagCompound tag = new NBTTagCompound();
/* 358 */         tag.func_74774_a("Slot", (byte)i);
/* 359 */         list.func_74742_a((NBTBase)this.itemstacks[i].func_77955_b(tag));
/*     */       } 
/*     */     } 
/*     */     
/* 363 */     nbt.func_74782_a("Items", (NBTBase)list);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/* 369 */     return 64;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getItemBurnTime(ItemStack stack) {
/* 374 */     return (stack != null) ? getFuelValue(stack) : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isItemFuel(ItemStack stack) {
/* 379 */     return (getItemBurnTime(stack) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer player) {
/* 385 */     return (this.field_145850_b.func_147438_o(this.field_145851_c, this.field_145848_d, this.field_145849_e) == this && player.func_70092_e(this.field_145851_c + 0.5D, this.field_145848_d + 0.5D, this.field_145849_e + 0.5D) <= 64.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70295_k_() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70305_f() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int slot, ItemStack stack) {
/* 401 */     return ((slot == 0 && canDisassemble(stack)) || (slot == 1 && isItemFuel(stack)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] func_94128_d(int side) {
/* 407 */     return (side == 0) ? SLOTS_BOTTOM : ((side == 1) ? SLOTS_TOP : SLOTS_SIDES);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_102007_a(int slot, ItemStack stack, int side) {
/* 413 */     return func_94041_b(slot, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_102008_b(int slot, ItemStack stack, int side) {
/* 419 */     return (side != 0 || slot != 1);
/*     */   }
/*     */   
/* 422 */   private static final Map<ItemStack, Integer> FUELS = new HashMap<>();
/*     */ 
/*     */   
/*     */   public static void registerFuel(ItemStack stack, int ticks) {
/* 426 */     FUELS.put(stack, Integer.valueOf(ticks));
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getFuelValue(ItemStack stack) {
/* 431 */     for (Map.Entry<ItemStack, Integer> e : FUELS.entrySet()) {
/*     */       
/* 433 */       if (((ItemStack)e.getKey()).func_77969_a(stack))
/*     */       {
/* 435 */         return ((Integer)e.getValue()).intValue();
/*     */       }
/*     */     } 
/*     */     
/* 439 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ImmutableMap<ItemStack, Integer> getFuels() {
/* 444 */     return ImmutableMap.copyOf(FUELS);
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 449 */     registerFuel(new ItemStack(Items.field_151137_ax), 300);
/* 450 */     registerFuel(new ItemStack(Blocks.field_150451_bX), 2700);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntityDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */