/*     */ package com.fiskmods.lightsabers.common.tileentity;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEntityLightsaberStand
/*     */   extends TileEntity
/*     */ {
/*     */   private ItemStack displayStack;
/*     */   private UUID owner;
/*     */   
/*     */   public boolean setDisplayStack(ItemStack stack) {
/*  26 */     if (isItemValid(stack) && !ItemStack.func_77989_b(this.displayStack, stack)) {
/*     */       
/*  28 */       this.displayStack = stack;
/*  29 */       this.field_145850_b.func_147471_g(this.field_145851_c, this.field_145848_d, this.field_145849_e);
/*  30 */       func_70296_d();
/*     */       
/*  32 */       return true;
/*     */     } 
/*     */     
/*  35 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isItemValid(ItemStack stack) {
/*  40 */     return (stack == null || stack.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaberBase);
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack getDisplayStack() {
/*  45 */     return this.displayStack;
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getOwner() {
/*  50 */     return this.owner;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOwner(EntityLivingBase entity) {
/*  55 */     if (entity instanceof EntityPlayer) {
/*     */       
/*  57 */       GameProfile profile = ((EntityPlayer)entity).func_146103_bH();
/*     */       
/*  59 */       if (profile != null && profile.getId() != null)
/*     */       {
/*  61 */         this.owner = profile.getId();
/*     */       }
/*     */     }
/*  64 */     else if (entity != null) {
/*     */       
/*  66 */       this.owner = entity.func_110124_au();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOwner(EntityLivingBase entity) {
/*  72 */     if (this.owner == null)
/*     */     {
/*  74 */       return false;
/*     */     }
/*     */     
/*  77 */     if (entity instanceof EntityPlayer) {
/*     */       
/*  79 */       GameProfile profile = ((EntityPlayer)entity).func_146103_bH();
/*     */       
/*  81 */       if (profile != null && profile.getId() != null)
/*     */       {
/*  83 */         return this.owner.equals(profile.getId());
/*     */       }
/*     */     }
/*  86 */     else if (entity != null) {
/*     */       
/*  88 */       return this.owner.equals(entity.func_110124_au());
/*     */     } 
/*     */     
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getRenderBoundingBox() {
/*  97 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 1), (this.field_145849_e + 1)).func_72314_b(0.5D, 0.5D, 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt) {
/* 103 */     super.func_145839_a(nbt);
/*     */     
/* 105 */     if (nbt.func_150297_b("DisplayStack", 10)) {
/*     */       
/* 107 */       this.displayStack = ItemStack.func_77949_a(nbt.func_74775_l("DisplayStack"));
/*     */     }
/*     */     else {
/*     */       
/* 111 */       this.displayStack = null;
/*     */     } 
/*     */     
/* 114 */     if (nbt.func_150297_b("Owner", 10)) {
/*     */       
/* 116 */       NBTTagCompound compound = nbt.func_74775_l("Owner");
/*     */       
/* 118 */       if (compound.func_150297_b("UUIDMost", 4) && compound.func_150297_b("UUIDLeast", 4))
/*     */       {
/* 120 */         this.owner = new UUID(compound.func_74763_f("UUIDMost"), compound.func_74763_f("UUIDLeast"));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound nbt) {
/* 128 */     super.func_145841_b(nbt);
/*     */     
/* 130 */     if (this.displayStack != null)
/*     */     {
/* 132 */       nbt.func_74782_a("DisplayStack", (NBTBase)this.displayStack.func_77955_b(new NBTTagCompound()));
/*     */     }
/*     */     
/* 135 */     if (this.owner != null) {
/*     */       
/* 137 */       NBTTagCompound compound = new NBTTagCompound();
/* 138 */       compound.func_74772_a("UUIDMost", this.owner.getMostSignificantBits());
/* 139 */       compound.func_74772_a("UUIDLeast", this.owner.getLeastSignificantBits());
/* 140 */       nbt.func_74782_a("Owner", (NBTBase)compound);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Packet func_145844_m() {
/* 147 */     NBTTagCompound syncData = new NBTTagCompound();
/* 148 */     func_145841_b(syncData);
/*     */     
/* 150 */     return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 1, syncData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDataPacket(NetworkManager netManager, S35PacketUpdateTileEntity packet) {
/* 156 */     func_145839_a(packet.func_148857_g());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntityLightsaberStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */