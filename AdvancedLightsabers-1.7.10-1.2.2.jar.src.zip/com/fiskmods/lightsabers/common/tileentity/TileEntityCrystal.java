/*    */ package com.fiskmods.lightsabers.common.tileentity;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class TileEntityCrystal
/*    */   extends TileEntity
/*    */ {
/* 13 */   private CrystalColor crystalColor = CrystalColor.get(0);
/*    */ 
/*    */   
/*    */   public void setColor(CrystalColor color) {
/* 17 */     if (this.crystalColor != color) {
/*    */       
/* 19 */       this.crystalColor = color;
/* 20 */       func_70296_d();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public CrystalColor getColor() {
/* 26 */     return this.crystalColor;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbt) {
/* 32 */     super.func_145839_a(nbt);
/* 33 */     this.crystalColor = CrystalColor.get(nbt.func_74762_e("color"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_145841_b(NBTTagCompound nbt) {
/* 39 */     super.func_145841_b(nbt);
/* 40 */     nbt.func_74768_a("color", this.crystalColor.id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Packet func_145844_m() {
/* 46 */     NBTTagCompound syncData = new NBTTagCompound();
/* 47 */     func_145841_b(syncData);
/*    */     
/* 49 */     return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 1, syncData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDataPacket(NetworkManager netManager, S35PacketUpdateTileEntity packet) {
/* 55 */     func_145839_a(packet.func_148857_g());
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntityCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */