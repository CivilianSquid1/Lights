/*     */ package com.fiskmods.lightsabers.common.tileentity;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.BlockSithStoneCoffin;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ 
/*     */ 
/*     */ public class TileEntitySithStoneCoffin
/*     */   extends TileEntity
/*     */ {
/*     */   public TileEntitySithCoffin mainCoffin;
/*     */   public ItemStack equipment;
/*     */   public boolean baseplateOnly = false;
/*     */   public boolean taskFinished = false;
/*     */   private int mainCoffinX;
/*     */   private int mainCoffinY;
/*     */   private int mainCoffinZ;
/*     */   
/*     */   public void func_145845_h() {
/*  30 */     if (this.mainCoffin != null) {
/*     */       
/*  32 */       int x = this.mainCoffin.field_145851_c;
/*  33 */       int y = this.mainCoffin.field_145848_d;
/*  34 */       int z = this.mainCoffin.field_145849_e;
/*     */       
/*  36 */       if (!this.baseplateOnly) {
/*     */         
/*  38 */         double radius = 14.0D;
/*  39 */         List<EntityPlayer> list = this.field_145850_b.func_72872_a(EntityPlayer.class, AxisAlignedBB.func_72330_a(x, y, z, (x + 1), (y + 1), (z + 1)).func_72314_b(radius, 2.0D, radius));
/*     */         
/*  41 */         if (!list.isEmpty())
/*     */         {
/*  43 */           this.baseplateOnly = true;
/*  44 */           this.taskFinished = true;
/*     */           
/*  46 */           for (int i = 0; i < 2; i++)
/*     */           {
/*  48 */             this.field_145850_b.func_72926_e(2001, this.field_145851_c, this.field_145848_d + i, this.field_145849_e, Block.func_149682_b(this.field_145850_b.func_147439_a(this.field_145851_c, this.field_145848_d + i, this.field_145849_e)) + (this.field_145850_b.func_72805_g(this.field_145851_c, this.field_145848_d + i, this.field_145849_e) << 12));
/*     */           }
/*     */           
/*  51 */           if (!this.field_145850_b.field_72995_K)
/*     */           {
/*  53 */             BlockSithStoneCoffin.spawnSithGhost(this.field_145850_b, this.field_145851_c, this.field_145848_d, this.field_145849_e).func_70624_b((EntityLivingBase)list.get(0));
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/*  60 */       TileEntity tile = this.field_145850_b.func_147438_o(this.mainCoffinX, this.mainCoffinY, this.mainCoffinZ);
/*     */       
/*  62 */       if (tile instanceof TileEntitySithCoffin)
/*     */       {
/*  64 */         this.mainCoffin = (TileEntitySithCoffin)tile;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMainCoffin(TileEntitySithCoffin tile) {
/*  71 */     this.mainCoffin = tile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound nbt) {
/*  77 */     super.func_145841_b(nbt);
/*     */     
/*  79 */     if (this.mainCoffin != null) {
/*     */       
/*  81 */       nbt.func_74768_a("CoffinX", this.mainCoffin.field_145851_c);
/*  82 */       nbt.func_74768_a("CoffinY", this.mainCoffin.field_145848_d);
/*  83 */       nbt.func_74768_a("CoffinZ", this.mainCoffin.field_145849_e);
/*     */     } 
/*     */     
/*  86 */     if (this.equipment != null) {
/*     */       
/*  88 */       NBTTagCompound nbttagcompound = new NBTTagCompound();
/*  89 */       this.equipment.func_77955_b(nbttagcompound);
/*  90 */       nbt.func_74782_a("Equipment", (NBTBase)nbttagcompound);
/*     */     } 
/*     */     
/*  93 */     nbt.func_74757_a("BaseplateOnly", this.baseplateOnly);
/*  94 */     nbt.func_74757_a("TaskFinished", this.taskFinished);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt) {
/* 100 */     super.func_145839_a(nbt);
/* 101 */     this.mainCoffinX = nbt.func_74762_e("CoffinX");
/* 102 */     this.mainCoffinY = nbt.func_74762_e("CoffinY");
/* 103 */     this.mainCoffinZ = nbt.func_74762_e("CoffinZ");
/* 104 */     this.baseplateOnly = nbt.func_74767_n("BaseplateOnly");
/* 105 */     this.taskFinished = nbt.func_74767_n("TaskFinished");
/*     */     
/* 107 */     if (nbt.func_74764_b("Equipment")) {
/*     */       
/* 109 */       NBTTagCompound nbttagcompound = nbt.func_74775_l("Equipment");
/* 110 */       this.equipment = ItemStack.func_77949_a(nbttagcompound);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getRenderBoundingBox() {
/* 117 */     return AxisAlignedBB.func_72330_a(this.field_145851_c, this.field_145848_d, this.field_145849_e, (this.field_145851_c + 1), (this.field_145848_d + 2), (this.field_145849_e + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Packet func_145844_m() {
/* 123 */     NBTTagCompound syncData = new NBTTagCompound();
/* 124 */     func_145841_b(syncData);
/*     */     
/* 126 */     return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 1, syncData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDataPacket(NetworkManager netManager, S35PacketUpdateTileEntity packet) {
/* 132 */     func_145839_a(packet.func_148857_g());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\tileentity\TileEntitySithStoneCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */