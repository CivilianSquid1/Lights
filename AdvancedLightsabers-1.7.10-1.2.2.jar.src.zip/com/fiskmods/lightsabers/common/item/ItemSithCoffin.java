/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemSithCoffin
/*    */   extends ItemBlock {
/*    */   public ItemSithCoffin(Block block) {
/* 14 */     super(block);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_77648_a(ItemStack itemstack, EntityPlayer player, World world, int x, int y, int z, int side, float f, float f1, float f2) {
/* 20 */     if (world.field_72995_K)
/*    */     {
/* 22 */       return true;
/*    */     }
/* 24 */     if (side != 1)
/*    */     {
/* 26 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 30 */     int dir = MathHelper.func_76128_c((player.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x3;
/* 31 */     byte x1 = 0;
/* 32 */     byte z1 = 0;
/*    */     
/* 34 */     if (dir == 0)
/*    */     {
/* 36 */       z1 = 1;
/*    */     }
/*    */     
/* 39 */     if (dir == 1)
/*    */     {
/* 41 */       x1 = -1;
/*    */     }
/*    */     
/* 44 */     if (dir == 2)
/*    */     {
/* 46 */       z1 = -1;
/*    */     }
/*    */     
/* 49 */     if (dir == 3)
/*    */     {
/* 51 */       x1 = 1;
/*    */     }
/*    */     
/* 54 */     y++;
/*    */     
/* 56 */     if (player.func_82247_a(x, y, z, side, itemstack) && player.func_82247_a(x + x1, y, z + z1, side, itemstack)) {
/*    */       
/* 58 */       if (world.func_147437_c(x, y, z) && world.func_147437_c(x + x1, y, z + z1) && World.func_147466_a((IBlockAccess)world, x, y - 1, z) && World.func_147466_a((IBlockAccess)world, x + x1, y - 1, z + z1)) {
/*    */         
/* 60 */         world.func_147465_d(x, y, z, this.field_150939_a, dir, 3);
/*    */         
/* 62 */         if (world.func_147439_a(x, y, z) == this.field_150939_a)
/*    */         {
/* 64 */           world.func_147465_d(x + x1, y, z + z1, this.field_150939_a, dir + 8, 3);
/*    */         }
/*    */         
/* 67 */         itemstack.field_77994_a--;
/* 68 */         return true;
/*    */       } 
/*    */ 
/*    */       
/* 72 */       return false;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 77 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */