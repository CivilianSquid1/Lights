/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.util.MathHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemHolocron
/*    */   extends ItemBlockWithMetadata
/*    */ {
/*    */   private IIcon[] icons;
/*    */   
/*    */   public ItemHolocron(Block block) {
/* 19 */     super(block);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77667_c(ItemStack itemstack) {
/* 25 */     return "tile." + ((itemstack.func_77960_j() == 0) ? "jedi" : "sith") + "_holocron";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IIcon func_77617_a(int damage) {
/* 31 */     return this.icons[MathHelper.func_76125_a(damage, 0, 1)];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int func_94901_k() {
/* 38 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_94581_a(IIconRegister par1IIconRegister) {
/* 44 */     this.icons = new IIcon[2];
/* 45 */     this.icons[0] = par1IIconRegister.func_94245_a("lightsabers:jedi_holocron");
/* 46 */     this.icons[1] = par1IIconRegister.func_94245_a("lightsabers:sith_holocron");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemHolocron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */