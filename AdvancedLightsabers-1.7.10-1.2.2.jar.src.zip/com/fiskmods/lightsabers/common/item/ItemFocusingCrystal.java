/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ 
/*     */ 
/*     */ public class ItemFocusingCrystal
/*     */   extends Item
/*     */   implements ILightsaberComponent
/*     */ {
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon[] icons;
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static IIcon outlineIcon;
/*     */   
/*     */   public ItemFocusingCrystal() {
/*  30 */     func_77627_a(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFingerprint(ItemStack stack, int slot) {
/*  36 */     return get(stack).getCode() << 32L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatibleSlot(ItemStack stack, int slot) {
/*  42 */     return (slot == 6 || slot == 7);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WeightedRandomChestContent getChestGenBase(ChestGenHooks chest, Random rand, WeightedRandomChestContent original) {
/*  48 */     return new WeightedRandomChestContent(create(getRandom(rand)), original.field_76295_d, original.field_76296_e, original.field_76292_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_77667_c(ItemStack stack) {
/*  54 */     return func_77658_a() + "." + get(stack).name().toLowerCase(Locale.ROOT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  60 */     for (FocusingCrystal crystal : FocusingCrystal.values())
/*     */     {
/*  62 */       list.add(create(crystal));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity func_77613_e(ItemStack itemstack) {
/*  69 */     return EnumRarity.epic;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon func_77617_a(int damage) {
/*  75 */     int i = MathHelper.func_76125_a(damage, 0, (FocusingCrystal.values()).length - 1);
/*  76 */     return this.icons[i];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_94581_a(IIconRegister iconRegister) {
/*  83 */     this.icons = new IIcon[(FocusingCrystal.values()).length];
/*     */     
/*  85 */     for (FocusingCrystal crystal : FocusingCrystal.values())
/*     */     {
/*  87 */       this.icons[crystal.ordinal()] = iconRegister.func_94245_a(func_111208_A() + "_" + crystal.name().toLowerCase(Locale.ROOT));
/*     */     }
/*     */     
/*  90 */     outlineIcon = iconRegister.func_94245_a(func_111208_A() + "_outline");
/*     */   }
/*     */ 
/*     */   
/*     */   public static FocusingCrystal get(ItemStack itemstack) {
/*  95 */     return get(itemstack.func_77960_j());
/*     */   }
/*     */ 
/*     */   
/*     */   public static FocusingCrystal get(int id) {
/* 100 */     return FocusingCrystal.values()[Math.abs(id) % (FocusingCrystal.values()).length];
/*     */   }
/*     */ 
/*     */   
/*     */   public static FocusingCrystal getRandom(Random rand) {
/* 105 */     return FocusingCrystal.values()[rand.nextInt((FocusingCrystal.values()).length)];
/*     */   }
/*     */ 
/*     */   
/*     */   public static FocusingCrystal getRandom() {
/* 110 */     return getRandom(new Random());
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(FocusingCrystal crystal) {
/* 115 */     return new ItemStack(ModItems.focusingCrystal, 1, crystal.ordinal());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemFocusingCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */