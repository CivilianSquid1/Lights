/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModItems
/*    */ {
/*    */   public static Item circuitry;
/*    */   public static Item focusingCrystal;
/*    */   public static Item crystalPouch;
/*    */   public static Item emitter;
/*    */   public static Item switchSection;
/*    */   public static Item grip;
/*    */   public static Item pommel;
/*    */   public static Item lightsaber;
/*    */   public static Item doubleLightsaber;
/*    */   
/*    */   public static void register() {
/* 23 */     circuitry = new ItemCircuitry();
/* 24 */     focusingCrystal = new ItemFocusingCrystal();
/* 25 */     crystalPouch = new ItemCrystalPouch();
/*    */     
/* 27 */     emitter = new ItemLightsaberPart(PartType.EMITTER);
/* 28 */     switchSection = new ItemLightsaberPart(PartType.SWITCH_SECTION);
/* 29 */     grip = new ItemLightsaberPart(PartType.BODY);
/* 30 */     pommel = new ItemLightsaberPart(PartType.POMMEL);
/*    */     
/* 32 */     lightsaber = (Item)new ItemLightsaber();
/* 33 */     doubleLightsaber = (Item)new ItemDoubleLightsaber();
/*    */ 
/*    */     
/* 36 */     ItemRegistry.registerItem(circuitry, "lightsaber_circuitry");
/* 37 */     ItemRegistry.registerItem(focusingCrystal, "focusing_crystal");
/* 38 */     ItemRegistry.registerItem(crystalPouch, "crystal_pouch");
/*    */     
/* 40 */     ItemRegistry.registerItem(emitter, "lightsaber_blade_emitter");
/* 41 */     ItemRegistry.registerItem(switchSection, "lightsaber_switch_module");
/* 42 */     ItemRegistry.registerItem(grip, "lightsaber_grip");
/* 43 */     ItemRegistry.registerItem(pommel, "lightsaber_pommel");
/*    */     
/* 45 */     ItemRegistry.registerItem(lightsaber, "lightsaber");
/* 46 */     ItemRegistry.registerItem(doubleLightsaber, "double_lightsaber");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ModItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */