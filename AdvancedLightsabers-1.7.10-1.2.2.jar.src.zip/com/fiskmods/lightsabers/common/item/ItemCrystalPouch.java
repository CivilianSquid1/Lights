/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemCrystalPouch
/*     */   extends Item
/*     */ {
/*  26 */   public static final UUID NULL_UUID = UUID.randomUUID();
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon overlay;
/*     */ 
/*     */   
/*     */   public ItemCrystalPouch() {
/*  34 */     func_77625_d(1);
/*  35 */     func_77627_a(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack itemstack, World world, EntityPlayer player) {
/*  41 */     if (!itemstack.func_77942_o())
/*     */     {
/*  43 */       itemstack.func_77982_d(new NBTTagCompound());
/*     */     }
/*     */     
/*  46 */     player.openGui(Lightsabers.instance, 3, world, player.field_71071_by.field_70461_c, 0, 0);
/*  47 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean inHand) {
/*  53 */     if (!world.field_72995_K)
/*     */     {
/*  55 */       if (!itemstack.func_77942_o() || !itemstack.func_77978_p().func_150297_b("PouchID", 8))
/*     */       {
/*  57 */         getUUID(itemstack);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  65 */     for (CrystalColor color : CrystalColor.values())
/*     */     {
/*  67 */       list.add(ItemCrystal.create(color, ModItems.crystalPouch));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity func_77613_e(ItemStack itemstack) {
/*  74 */     return ItemCrystal.rarityMap.get(ItemCrystal.get(itemstack));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_77624_a(ItemStack itemstack, EntityPlayer player, List<String> list, boolean advanced) {
/*  81 */     list.add(ItemCrystal.get(itemstack).getLocalizedName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack itemstack, int pass) {
/*  88 */     return (pass == 1) ? (ItemCrystal.get(itemstack)).color : super.func_82790_a(itemstack, pass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_77623_v() {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon func_77618_c(int damage, int pass) {
/* 102 */     return (pass == 1) ? this.overlay : this.field_77791_bV;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_94581_a(IIconRegister iconRegister) {
/* 109 */     super.func_94581_a(iconRegister);
/* 110 */     this.overlay = iconRegister.func_94245_a(func_111208_A() + "_overlay");
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isPouch(ItemStack stack) {
/* 115 */     return (stack != null && stack.func_77973_b() == ModItems.crystalPouch);
/*     */   }
/*     */ 
/*     */   
/*     */   public static UUID getUUID(ItemStack stack) {
/* 120 */     if (!isPouch(stack))
/*     */     {
/* 122 */       return NULL_UUID;
/*     */     }
/*     */     
/* 125 */     if (!stack.func_77942_o())
/*     */     {
/* 127 */       stack.func_77982_d(new NBTTagCompound());
/*     */     }
/*     */     
/* 130 */     if (!stack.func_77978_p().func_150297_b("PouchID", 8)) {
/*     */       
/* 132 */       UUID uuid = UUID.randomUUID();
/* 133 */       stack.func_77978_p().func_74778_a("PouchID", uuid.toString());
/*     */       
/* 135 */       return uuid;
/*     */     } 
/*     */     
/* 138 */     return UUID.fromString(stack.func_77978_p().func_74779_i("PouchID"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemCrystalPouch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */