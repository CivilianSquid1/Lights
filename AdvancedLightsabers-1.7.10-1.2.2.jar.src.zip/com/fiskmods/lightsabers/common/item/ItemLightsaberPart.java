/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemLightsaberPart
/*     */   extends Item
/*     */   implements ILightsaberComponent
/*     */ {
/*     */   public final PartType partType;
/*     */   
/*     */   public ItemLightsaberPart(PartType type) {
/*  28 */     func_77625_d(16);
/*  29 */     func_77627_a(true);
/*  30 */     this.partType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFingerprint(ItemStack stack, int slot) {
/*  36 */     return (Hilt.REGISTRY.getIDForObject((FiskRegistryEntry)get(stack)) << this.partType.ordinal() * 6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatibleSlot(ItemStack stack, int slot) {
/*  42 */     return (slot == this.partType.ordinal());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WeightedRandomChestContent getChestGenBase(ChestGenHooks chest, Random rand, WeightedRandomChestContent original) {
/*  48 */     return new WeightedRandomChestContent(create(getRandomType(rand), (Hilt)Hilt.REGISTRY.getRandom(rand)), original.field_76295_d, original.field_76296_e, original.field_76292_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  54 */     for (Hilt hilt : Hilt.REGISTRY)
/*     */     {
/*  56 */       list.add(create(this.partType, hilt));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77624_a(ItemStack itemstack, EntityPlayer player, List<String> list, boolean flag) {
/*  63 */     list.add(get(itemstack).getLocalizedName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_94581_a(IIconRegister iconRegister) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hilt get(ItemStack itemstack) {
/*  74 */     int id = 0;
/*     */     
/*  76 */     if (itemstack.func_77942_o())
/*     */     {
/*  78 */       if (itemstack.func_77978_p().func_150297_b("lightsaber", 8)) {
/*     */         
/*  80 */         id = Hilt.REGISTRY.getIDForObject(Hilt.REGISTRY.getObject((String)Hilt.LEGACY_MAPPINGS.get(itemstack.func_77978_p().func_74779_i("lightsaber"))));
/*  81 */         itemstack.func_77978_p().func_82580_o("lightsaber");
/*  82 */         itemstack.func_77978_p().func_82580_o("type");
/*  83 */         itemstack.func_77978_p().func_74774_a("Type", (byte)id);
/*     */       }
/*  85 */       else if (itemstack.func_77978_p().func_150297_b("Type", 99)) {
/*     */         
/*  87 */         id = itemstack.func_77978_p().func_74771_c("Type");
/*     */       } 
/*     */     }
/*     */     
/*  91 */     return (Hilt)Hilt.REGISTRY.getObjectById(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Item getItem(PartType type) {
/*  96 */     switch (type) {
/*     */       
/*     */       case EMITTER:
/*  99 */         return ModItems.emitter;
/*     */       case SWITCH_SECTION:
/* 101 */         return ModItems.switchSection;
/*     */       case BODY:
/* 103 */         return ModItems.grip;
/*     */       case POMMEL:
/* 105 */         return ModItems.pommel;
/*     */     } 
/*     */     
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(PartType type, Hilt hilt) {
/* 113 */     ItemStack itemstack = new ItemStack(getItem(type));
/* 114 */     itemstack.func_77982_d(new NBTTagCompound());
/* 115 */     itemstack.func_77978_p().func_74774_a("Type", (byte)Hilt.REGISTRY.getIDForObject((FiskRegistryEntry)hilt));
/*     */     
/* 117 */     return itemstack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static PartType getType(ItemStack itemstack) {
/* 122 */     return (itemstack.func_77973_b() instanceof ItemLightsaberPart) ? ((ItemLightsaberPart)itemstack.func_77973_b()).partType : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static PartType getRandomType(Random rand) {
/* 127 */     return PartType.values()[rand.nextInt((PartType.values()).length)];
/*     */   }
/*     */ 
/*     */   
/*     */   public static PartType getRandomType() {
/* 132 */     return getRandomType(new Random());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemLightsaberPart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */