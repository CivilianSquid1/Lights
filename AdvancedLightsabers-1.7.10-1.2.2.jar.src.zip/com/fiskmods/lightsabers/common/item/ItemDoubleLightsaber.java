/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.ALReflection;
/*     */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.common.Optional.Interface;
/*     */ import cpw.mods.fml.common.Optional.InterfaceList;
/*     */ import fiskfille.utils.helper.NBTHelper;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import mods.battlegear2.api.IAllowItem;
/*     */ import mods.battlegear2.api.IOffhandWield;
/*     */ import net.minecraft.command.IEntitySelector;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagLong;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.stats.AchievementList;
/*     */ import net.minecraft.stats.StatBase;
/*     */ import net.minecraft.stats.StatList;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InterfaceList({@Interface(modid = "battlegear2", iface = "mods.battlegear2.api.IOffhandWield"), @Interface(modid = "battlegear2", iface = "mods.battlegear2.api.IAllowItem")})
/*     */ public class ItemDoubleLightsaber
/*     */   extends ItemLightsaberBase
/*     */   implements IOffhandWield, IAllowItem
/*     */ {
/*     */   public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean inHand) {
/*  49 */     if (!world.field_72995_K)
/*     */     {
/*  51 */       if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("UpperLightsaber", 10) && itemstack.func_77978_p().func_150297_b("LowerLightsaber", 10))
/*     */       {
/*  53 */         get(itemstack);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  61 */     LightsaberData[] array = new LightsaberData[2];
/*     */     
/*  63 */     for (Hilt hilt : Hilt.REGISTRY) {
/*     */       
/*  65 */       if (hilt.getType() == Hilt.Type.DOUBLE) {
/*     */         
/*  67 */         for (int i = 0; i < array.length; i++)
/*     */         {
/*  69 */           array[i] = (new LightsaberData()).set(hilt).set(hilt.getColor()).set((FocusingCrystal[])hilt.getFocusingCrystals().toArray((Object[])new FocusingCrystal[2]));
/*     */         }
/*     */         
/*  72 */         list.add(create(array));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77624_a(ItemStack itemstack, EntityPlayer player, List<String> list, boolean advanced) {
/*  80 */     LightsaberData[] array = get(itemstack);
/*  81 */     Hilt[][] hilt = { array[0].getHilt(), array[1].getHilt() };
/*  82 */     String space = "  ";
/*     */     
/*  84 */     list.add(StatCollector.func_74838_a("lightsaber.color"));
/*  85 */     list.add(space + array[0].getColor().getLocalizedName());
/*     */     
/*  87 */     if (array[0].getColor() != array[1].getColor())
/*     */     {
/*  89 */       list.add(space + array[1].getColor().getLocalizedName());
/*     */     }
/*     */     
/*  92 */     list.add(StatCollector.func_74838_a("lightsaber.hilt"));
/*     */     
/*  94 */     if (array[0].isHiltUniform() && array[1].isHiltUniform()) {
/*     */       
/*  96 */       list.add(space + hilt[0][0].getLocalizedName());
/*     */       
/*  98 */       if (hilt[0][0] != hilt[1][0])
/*     */       {
/* 100 */         list.add(space + hilt[1][0].getLocalizedName());
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 105 */       for (int j = 0; j < ((array[0].getHiltBits() == array[1].getHiltBits()) ? 1 : hilt.length); j++) {
/*     */         
/* 107 */         List<Hilt> list1 = Lists.newArrayList((Object[])hilt[j]);
/*     */         
/* 109 */         if (j == 1)
/*     */         {
/* 111 */           Collections.reverse(list1);
/*     */         }
/*     */         
/* 114 */         for (int k = 0; k < list1.size(); k++)
/*     */         {
/* 116 */           list.add(space + ((Hilt)list1.get(k)).getLocalizedName());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     FocusingCrystal[][] crystals = { array[0].getFocusingCrystals(), array[1].getFocusingCrystals() };
/* 122 */     String[] astring = { "upper", "lower" };
/*     */     
/* 124 */     if ((crystals[0]).length > 0 || (crystals[1]).length > 0)
/*     */     {
/* 126 */       list.add(StatCollector.func_74838_a("lightsaber.focusingCrystals"));
/*     */     }
/*     */     
/* 129 */     for (int i = 0; i < astring.length; i++) {
/*     */       
/* 131 */       if ((crystals[i]).length > 0) {
/*     */         
/* 133 */         list.add(space + StatCollector.func_74838_a("lightsaber." + astring[i]));
/*     */         
/* 135 */         for (FocusingCrystal crystal : crystals[i])
/*     */         {
/* 137 */           list.add(space + space + crystal.getLocalizedName());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     if (advanced)
/*     */     {
/* 144 */       list.add(StatCollector.func_74837_a("lightsaber.code.double", new Object[] { Long.toHexString((array[0]).hash).toUpperCase(Locale.ROOT), Long.toHexString((array[1]).hash).toUpperCase(Locale.ROOT) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77644_a(ItemStack itemstack, EntityLivingBase target, EntityLivingBase attacker) {
/* 151 */     float width = attacker.field_70130_N * 2.0F;
/* 152 */     Vec3 vec3 = VectorHelper.getOffsetCoords(attacker, 0.0D, 0.0D, -0.20000000298023224D);
/* 153 */     AxisAlignedBB aabb = AxisAlignedBB.func_72330_a(-width, 0.0D, -width, width, attacker.field_70131_O, width).func_72317_d(vec3.field_72450_a, attacker.field_70121_D.field_72338_b, vec3.field_72449_c);
/* 154 */     List<EntityLivingBase> list = attacker.field_70170_p.func_82733_a(EntityLivingBase.class, aabb, IEntitySelector.field_94557_a);
/*     */     
/* 156 */     for (EntityLivingBase entity : list) {
/*     */       
/* 158 */       if (entity != attacker) {
/*     */         
/* 160 */         ItemStack stack = attacker.func_70694_bm();
/*     */         
/* 162 */         if (attacker instanceof EntityPlayer && stack != null && stack.func_77973_b().onLeftClickEntity(stack, (EntityPlayer)attacker, (Entity)entity)) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 167 */         if (entity.func_70075_an())
/*     */         {
/* 169 */           if (!entity.func_85031_j((Entity)attacker)) {
/*     */             
/* 171 */             float attackDamage = (float)attacker.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
/* 172 */             float livingModifier = EnchantmentHelper.func_77512_a(attacker, entity);
/* 173 */             int knockback = EnchantmentHelper.func_77507_b(attacker, entity);
/*     */             
/* 175 */             if (attacker.func_70051_ag())
/*     */             {
/* 177 */               knockback++;
/*     */             }
/*     */             
/* 180 */             if (attackDamage > 0.0F || livingModifier > 0.0F) {
/*     */               
/* 182 */               boolean crit = (attacker.field_70143_R > 0.0F && !attacker.field_70122_E && !attacker.func_70617_f_() && !attacker.func_70090_H() && !attacker.func_70644_a(Potion.field_76440_q) && attacker.field_70154_o == null);
/*     */               
/* 184 */               if (crit && attackDamage > 0.0F)
/*     */               {
/* 186 */                 attackDamage *= 1.5F;
/*     */               }
/*     */               
/* 189 */               attackDamage += livingModifier;
/*     */               
/* 191 */               boolean onFire = false;
/* 192 */               int fire = EnchantmentHelper.func_90036_a(attacker);
/*     */               
/* 194 */               if (fire > 0 && !entity.func_70027_ad()) {
/*     */                 
/* 196 */                 onFire = true;
/* 197 */                 entity.func_70015_d(1);
/*     */               } 
/*     */               
/* 200 */               boolean success = entity.func_70097_a(ALDamageSources.causeLightsaberDamage((Entity)attacker), attackDamage);
/*     */               
/* 202 */               if (success) {
/*     */                 
/* 204 */                 if (knockback > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 213 */                   double d = (knockback * 0.25F);
/* 214 */                   double x = attacker.field_70165_t - entity.field_70165_t;
/* 215 */                   double z = attacker.field_70161_v - entity.field_70161_v;
/*     */                   
/* 217 */                   while (Math.sqrt(x * x + z * z) > d) {
/*     */                     
/* 219 */                     double d1 = 0.95D;
/* 220 */                     x *= d1;
/* 221 */                     z *= d1;
/*     */                   } 
/*     */                   
/* 224 */                   while (Math.sqrt(x * x + z * z) < d) {
/*     */                     
/* 226 */                     double d1 = 1.05D;
/* 227 */                     x *= d1;
/* 228 */                     z *= d1;
/*     */                   } 
/*     */                   
/* 231 */                   entity.func_70024_g(-x, 0.1D, -z);
/*     */                   
/* 233 */                   attacker.field_70159_w *= 0.6D;
/* 234 */                   attacker.field_70179_y *= 0.6D;
/* 235 */                   attacker.func_70031_b(false);
/*     */                 } 
/*     */                 
/* 238 */                 if (attacker instanceof EntityPlayer) {
/*     */                   
/* 240 */                   EntityPlayer player = (EntityPlayer)attacker;
/*     */                   
/* 242 */                   if (crit)
/*     */                   {
/* 244 */                     player.func_71009_b((Entity)entity);
/*     */                   }
/*     */                   
/* 247 */                   if (livingModifier > 0.0F)
/*     */                   {
/* 249 */                     player.func_71047_c((Entity)entity);
/*     */                   }
/*     */                   
/* 252 */                   if (attackDamage >= 18.0F)
/*     */                   {
/* 254 */                     player.func_71029_a((StatBase)AchievementList.field_75999_E);
/*     */                   }
/*     */                   
/* 257 */                   player.func_130011_c((Entity)entity);
/* 258 */                   EnchantmentHelper.func_151384_a(entity, (Entity)player);
/* 259 */                   EnchantmentHelper.func_151385_b((EntityLivingBase)player, (Entity)entity);
/*     */                   
/* 261 */                   player.func_71064_a(StatList.field_75951_w, Math.round(attackDamage * 10.0F));
/*     */                   
/* 263 */                   if (fire > 0)
/*     */                   {
/* 265 */                     entity.func_70015_d(fire * 4);
/*     */                   }
/*     */                   
/* 268 */                   player.func_71020_j(0.3F);
/*     */                 }  continue;
/*     */               } 
/* 271 */               if (onFire)
/*     */               {
/* 273 */                 entity.func_70066_B();
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 281 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOffhandWieldable(ItemStack itemstack, EntityPlayer player) {
/* 287 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allowOffhand(ItemStack main, ItemStack off) {
/* 293 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static LightsaberData[] readFromNBT(NBTTagCompound nbt) {
/* 298 */     LightsaberData[] array = { LightsaberData.EMPTY, LightsaberData.EMPTY };
/*     */     
/* 300 */     if (nbt.func_150297_b("UpperLightsaber", 10) && nbt.func_150297_b("LowerLightsaber", 10)) {
/*     */       
/* 302 */       NBTTagList list = new NBTTagList();
/* 303 */       String[] astring = { "UpperLightsaber", "LowerLightsaber" };
/*     */       
/* 305 */       for (int i = 0; i < astring.length; i++) {
/*     */         
/* 307 */         NBTTagCompound compound = nbt.func_74775_l(astring[i]);
/* 308 */         compound.func_74782_a("Lightsaber", compound.func_74737_b());
/*     */         
/* 310 */         array[i] = LightsaberData.readFromNBT(compound);
/* 311 */         list.func_74742_a((NBTBase)new NBTTagLong((array[i]).hash));
/* 312 */         nbt.func_82580_o(astring[i]);
/*     */       } 
/*     */       
/* 315 */       nbt.func_74782_a("Lightsaber", (NBTBase)list);
/*     */     }
/* 317 */     else if (nbt.func_150297_b("Lightsaber", 9)) {
/*     */       
/* 319 */       NBTTagList list = nbt.func_150295_c("Lightsaber", 4);
/* 320 */       List<NBTBase> tags = (List<NBTBase>)ALReflection.tagList.get(list);
/*     */       
/* 322 */       for (int i = 0; i < Math.min(tags.size(), array.length); i++) {
/*     */         
/* 324 */         LightsaberData data = (LightsaberData)NBTHelper.readFromNBT(tags.get(i), LightsaberData.class);
/*     */         
/* 326 */         if (data != null)
/*     */         {
/* 328 */           array[i] = data.strip();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 333 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   public static LightsaberData[] get(ItemStack itemstack) {
/* 338 */     if (itemstack != null && itemstack.func_77942_o())
/*     */     {
/* 340 */       return readFromNBT(itemstack.func_77978_p());
/*     */     }
/*     */     
/* 343 */     return new LightsaberData[] { LightsaberData.EMPTY, LightsaberData.EMPTY };
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(LightsaberData[] array) {
/* 348 */     ItemStack itemstack = new ItemStack(ModItems.doubleLightsaber);
/* 349 */     NBTTagList list = new NBTTagList();
/*     */     
/* 351 */     for (int i = 0; i < array.length; i++)
/*     */     {
/* 353 */       list.func_74742_a((NBTBase)new NBTTagLong((array[i]).hash));
/*     */     }
/*     */     
/* 356 */     itemstack.func_77982_d(new NBTTagCompound());
/* 357 */     itemstack.func_77978_p().func_74782_a("Lightsaber", (NBTBase)list);
/*     */     
/* 359 */     return itemstack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(ItemStack upper, ItemStack lower) {
/* 364 */     return create(new LightsaberData[] { LightsaberData.get(upper), LightsaberData.get(lower) });
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemDoubleLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */