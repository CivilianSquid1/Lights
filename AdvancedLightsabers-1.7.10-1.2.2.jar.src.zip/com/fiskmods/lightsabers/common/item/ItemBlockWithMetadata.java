/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.util.IIcon;
/*    */ 
/*    */ public class ItemBlockWithMetadata
/*    */   extends ItemBlock
/*    */ {
/*    */   private Block block;
/*    */   
/*    */   public ItemBlockWithMetadata(Block block) {
/* 15 */     super(block);
/* 16 */     this.block = block;
/* 17 */     func_77656_e(0);
/* 18 */     func_77627_a(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public IIcon func_77617_a(int damage) {
/* 28 */     return this.block.func_149691_a(2, damage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_77647_b(int meta) {
/* 37 */     return meta;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemBlockWithMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */