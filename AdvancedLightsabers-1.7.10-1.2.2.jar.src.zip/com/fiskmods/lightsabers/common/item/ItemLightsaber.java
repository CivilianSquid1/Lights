/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import cpw.mods.fml.common.Optional.Interface;
/*     */ import cpw.mods.fml.common.Optional.InterfaceList;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import mods.battlegear2.api.PlayerEventChild;
/*     */ import mods.battlegear2.api.weapons.IBattlegearWeapon;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InterfaceList({@Interface(modid = "battlegear2", iface = "mods.battlegear2.api.weapons.IBattlegearWeapon")})
/*     */ public class ItemLightsaber
/*     */   extends ItemLightsaberBase
/*     */   implements IBattlegearWeapon
/*     */ {
/*     */   public String func_77653_i(ItemStack itemstack) {
/*  37 */     if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("Special", 8))
/*     */     {
/*  39 */       return "FISHSTICKS!!";
/*     */     }
/*     */     
/*  42 */     return super.func_77653_i(itemstack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity func_77613_e(ItemStack itemstack) {
/*  48 */     if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("Special", 8))
/*     */     {
/*  50 */       return EnumRarity.rare;
/*     */     }
/*     */     
/*  53 */     return EnumRarity.common;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WeightedRandomChestContent getChestGenBase(ChestGenHooks chest, Random rand, WeightedRandomChestContent original) {
/*  59 */     ItemStack itemstack = original.field_76297_b;
/*     */     
/*  61 */     if (itemstack.func_77942_o() && itemstack.func_77978_p().func_74767_n("SithTombLoot")) {
/*     */       
/*  63 */       itemstack = LightsaberData.createRandom(rand, (rand.nextInt(5) == 0) ? CrystalColor.PURPLE : CrystalColor.RED);
/*     */       
/*  65 */       if (rand.nextInt(4) == 0)
/*     */       {
/*  67 */         itemstack = ItemDoubleLightsaber.create(itemstack, itemstack);
/*     */       }
/*     */     }
/*  70 */     else if (itemstack.func_77942_o() && itemstack.func_77978_p().func_74767_n("JediTempleLoot")) {
/*     */       
/*  72 */       itemstack = LightsaberData.createRandom(rand, rand.nextBoolean() ? CrystalColor.MEDIUM_BLUE : CrystalColor.GREEN);
/*     */       
/*  74 */       if (rand.nextInt(8) == 0)
/*     */       {
/*  76 */         itemstack = ItemDoubleLightsaber.create(itemstack, itemstack);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  81 */       itemstack = LightsaberData.createRandom(rand);
/*     */     } 
/*     */     
/*  84 */     return new WeightedRandomChestContent(itemstack, original.field_76295_d, original.field_76296_e, original.field_76292_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean inHand) {
/*  90 */     if (!world.field_72995_K)
/*     */     {
/*  92 */       if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("Lightsaber", 10))
/*     */       {
/*  94 */         LightsaberData.get(itemstack);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/* 102 */     for (Hilt hilt : Hilt.REGISTRY) {
/*     */       
/* 104 */       if (hilt.getType() == Hilt.Type.SINGLE)
/*     */       {
/* 106 */         list.add(hilt.createDefault().create());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77624_a(ItemStack itemstack, EntityPlayer player, List<String> list, boolean advanced) {
/* 114 */     LightsaberData data = LightsaberData.get(itemstack);
/* 115 */     Hilt[] hilt = data.getHilt();
/* 116 */     String space = "  ";
/*     */     
/* 118 */     list.add(StatCollector.func_74838_a("lightsaber.color"));
/* 119 */     list.add(space + data.getColor().getLocalizedName());
/* 120 */     list.add(StatCollector.func_74838_a("lightsaber.hilt"));
/*     */     
/* 122 */     if (data.isHiltUniform()) {
/*     */       
/* 124 */       list.add(space + hilt[0].getLocalizedName());
/*     */     }
/*     */     else {
/*     */       
/* 128 */       for (int i = 0; i < hilt.length; i++)
/*     */       {
/* 130 */         list.add(space + hilt[i].getLocalizedName());
/*     */       }
/*     */     } 
/*     */     
/* 134 */     FocusingCrystal[] crystals = data.getFocusingCrystals();
/*     */     
/* 136 */     if (crystals.length > 0) {
/*     */       
/* 138 */       list.add(StatCollector.func_74838_a("lightsaber.focusingCrystals"));
/*     */       
/* 140 */       for (FocusingCrystal crystal : crystals)
/*     */       {
/* 142 */         list.add(space + crystal.getLocalizedName());
/*     */       }
/*     */     } 
/*     */     
/* 146 */     if (advanced)
/*     */     {
/* 148 */       list.add(StatCollector.func_74837_a("lightsaber.code.single", new Object[] { Long.toHexString(data.hash).toUpperCase(Locale.ROOT) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allowOffhand(ItemStack main, ItemStack off) {
/* 155 */     if (main != null && main.func_77973_b() == ModItems.doubleLightsaber)
/*     */     {
/* 157 */       return false;
/*     */     }
/*     */     
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sheatheOnBack(ItemStack item) {
/* 166 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOffhandHandDual(ItemStack off) {
/* 172 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offhandAttackEntity(PlayerEventChild.OffhandAttackEvent event, ItemStack mainhandItem, ItemStack offhandItem) {
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offhandClickAir(PlayerInteractEvent event, ItemStack mainhandItem, ItemStack offhandItem) {
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offhandClickBlock(PlayerInteractEvent event, ItemStack mainhandItem, ItemStack offhandItem) {
/* 190 */     return false;
/*     */   }
/*     */   
/*     */   public void performPassiveEffects(Side effectiveSide, ItemStack mainhandItem, ItemStack offhandItem) {}
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemLightsaber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */