/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.entity.EntityLightsaber;
/*     */ import com.google.common.collect.Multimap;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ItemLightsaberBase
/*     */   extends ItemSword
/*     */ {
/*     */   public ItemLightsaberBase() {
/*  31 */     super(Item.ToolMaterial.EMERALD);
/*  32 */     func_77627_a(true);
/*  33 */     func_77625_d(1);
/*  34 */     func_77656_e(0);
/*  35 */     func_77664_n();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack itemstack, World world, EntityPlayer player) {
/*  41 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onEntitySwing(EntityLivingBase entity, ItemStack itemstack) {
/*  47 */     if (isActive(itemstack)) {
/*     */       
/*  49 */       MovingObjectPosition mop = getMovingObjectPosition(entity.field_70170_p, entity, true);
/*     */       
/*  51 */       if (mop == null || mop.field_72313_a != MovingObjectPosition.MovingObjectType.BLOCK) {
/*     */         
/*  53 */         entity.func_85030_a((entity instanceof EntityPlayer) ? ALSounds.player_lightsaber_swing : ALSounds.mob_lightsaber_swing, 1.0F, 1.0F);
/*     */       }
/*     */       else {
/*     */         
/*  57 */         return onPunchBlock(itemstack, entity, mop);
/*     */       } 
/*     */     } 
/*     */     
/*  61 */     return super.onEntitySwing(entity, itemstack);
/*     */   }
/*     */ 
/*     */   
/*     */   private MovingObjectPosition getMovingObjectPosition(World world, EntityLivingBase entity, boolean b) {
/*  66 */     if (entity instanceof EntityPlayer) {
/*     */       
/*  68 */       double reach = 5.0D;
/*     */       
/*  70 */       if (entity instanceof EntityPlayerMP)
/*     */       {
/*  72 */         reach = ((EntityPlayerMP)entity).field_71134_c.getBlockReachDistance();
/*     */       }
/*     */       
/*  75 */       MovingObjectPosition mop = func_77621_a(world, (EntityPlayer)entity, b);
/*     */       
/*  77 */       Vec3 position = Vec3.func_72443_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
/*  78 */       Vec3 look = entity.func_70676_i(0.0F);
/*  79 */       Vec3 lookPosition = position.func_72441_c(look.field_72450_a * reach, look.field_72448_b * reach, look.field_72449_c * reach);
/*  80 */       float expand = 1.0F;
/*  81 */       List possibleEntities = world.func_72839_b((Entity)entity, entity.field_70121_D.func_72321_a(look.field_72450_a * reach, look.field_72448_b * reach, look.field_72449_c * reach).func_72314_b(expand, expand, expand));
/*  82 */       double closestDistance = reach;
/*     */       
/*  84 */       for (Object possibleEntity : possibleEntities) {
/*     */         
/*  86 */         Entity selectingEntity = (Entity)possibleEntity;
/*     */         
/*  88 */         if (selectingEntity.func_70067_L()) {
/*     */           
/*  90 */           float borderSize = selectingEntity.func_70111_Y();
/*  91 */           AxisAlignedBB selectionBounds = selectingEntity.field_70121_D.func_72314_b(borderSize, borderSize, borderSize);
/*  92 */           MovingObjectPosition entityMOP = selectionBounds.func_72327_a(position, lookPosition);
/*     */           
/*  94 */           if (entityMOP != null)
/*     */           {
/*  96 */             entityMOP.field_72313_a = MovingObjectPosition.MovingObjectType.ENTITY;
/*     */           }
/*     */           
/*  99 */           if (selectionBounds.func_72318_a(position)) {
/*     */             
/* 101 */             if (closestDistance > 0.0D || closestDistance == 0.0D) {
/*     */               
/* 103 */               mop = entityMOP;
/* 104 */               closestDistance = 0.0D;
/*     */             }  continue;
/*     */           } 
/* 107 */           if (entityMOP != null) {
/*     */             
/* 109 */             double distanceToEntity = position.func_72438_d(entityMOP.field_72307_f);
/*     */             
/* 111 */             if (distanceToEntity < closestDistance || closestDistance == 0.0D) {
/*     */               
/* 113 */               if (selectingEntity == selectingEntity.field_70154_o && !selectingEntity.canRiderInteract()) {
/*     */                 
/* 115 */                 if (closestDistance == 0.0D)
/*     */                 {
/* 117 */                   mop = entityMOP;
/*     */                 }
/*     */                 
/*     */                 continue;
/*     */               } 
/* 122 */               mop = entityMOP;
/* 123 */               closestDistance = distanceToEntity;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 130 */       return mop;
/*     */     } 
/*     */     
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onPunchBlock(ItemStack stack, EntityLivingBase entity, MovingObjectPosition mop) {
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onLeftClickEntity(ItemStack itemstack, EntityPlayer player, Entity entity) {
/* 144 */     return !isActive(itemstack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap getAttributeModifiers(ItemStack stack) {
/* 150 */     Multimap multimap = super.getAttributeModifiers(stack);
/* 151 */     multimap.removeAll(SharedMonsterAttributes.field_111264_e.func_111108_a());
/* 152 */     multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", 8.0D, 0));
/* 153 */     return multimap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_94581_a(IIconRegister iconRegister) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isActive(ItemStack itemstack) {
/* 164 */     return (itemstack != null && itemstack.func_77942_o() && itemstack.func_77978_p().func_74767_n("active"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack setActive(ItemStack itemstack, boolean state) {
/* 169 */     if (!itemstack.func_77942_o())
/*     */     {
/* 171 */       itemstack.func_77982_d(new NBTTagCompound());
/*     */     }
/*     */     
/* 174 */     itemstack.func_77978_p().func_74757_a("active", state);
/*     */     
/* 176 */     return itemstack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void ignite(EntityLivingBase entity, boolean state) {
/* 181 */     ItemStack itemstack = entity.func_70694_bm();
/*     */     
/* 183 */     if (itemstack != null && isActive(itemstack) != state) {
/*     */       
/* 185 */       String[] sounds = { ALSounds.mob_lightsaber_on, ALSounds.mob_lightsaber_off };
/*     */       
/* 187 */       if (entity instanceof EntityPlayer)
/*     */       {
/* 189 */         sounds = new String[] { ALSounds.player_lightsaber_on, ALSounds.player_lightsaber_off };
/*     */       }
/*     */       
/* 192 */       entity.field_70170_p.func_72956_a((Entity)entity, sounds[state ? 0 : 1], 1.0F, 1.0F);
/* 193 */       setActive(itemstack, state);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void throwLightsaber(EntityLivingBase entity, ItemStack itemstack, int amplifier) {
/* 199 */     entity.field_70170_p.func_72838_d((Entity)new EntityLightsaber(entity.field_70170_p, entity, itemstack, amplifier));
/* 200 */     entity.func_70062_b(0, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemLightsaberBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */