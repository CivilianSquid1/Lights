/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemSithStoneCoffin
/*    */   extends ItemBlock
/*    */ {
/*    */   public ItemSithStoneCoffin(Block block) {
/* 16 */     super(block);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean placeBlockAt(ItemStack itemstack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 22 */     if (!world.func_147465_d(x, y, z, this.field_150939_a, metadata, 3))
/*    */     {
/* 24 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 28 */     TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*    */     
/* 30 */     if (tile != null) {
/*    */       
/* 32 */       if (itemstack.func_77942_o() && itemstack.func_77978_p().func_74764_b("Equipment")) {
/*    */         
/* 34 */         NBTTagCompound nbttagcompound = itemstack.func_77978_p().func_74775_l("Equipment");
/* 35 */         tile.equipment = ItemStack.func_77949_a(nbttagcompound);
/*    */       } 
/*    */       
/* 38 */       tile.taskFinished = true;
/*    */     } 
/*    */ 
/*    */     
/* 42 */     if (world.func_147439_a(x, y, z) == this.field_150939_a) {
/*    */       
/* 44 */       this.field_150939_a.func_149689_a(world, x, y, z, (EntityLivingBase)player, itemstack);
/* 45 */       this.field_150939_a.func_149714_e(world, x, y, z, metadata);
/*    */     } 
/*    */     
/* 48 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemSithStoneCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */