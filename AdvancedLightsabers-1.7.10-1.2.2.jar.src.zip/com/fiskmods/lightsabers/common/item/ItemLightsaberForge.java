/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemLightsaberForge
/*    */   extends ItemBlock
/*    */ {
/*    */   public ItemLightsaberForge(Block block) {
/* 14 */     super(block);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_77648_a(ItemStack itemstack, EntityPlayer player, World world, int x, int y, int z, int side, float f, float f1, float f2) {
/* 20 */     if (world.field_72995_K)
/*    */     {
/* 22 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 26 */     if (side == 0)
/*    */     {
/* 28 */       y--;
/*    */     }
/*    */     
/* 31 */     if (side == 1)
/*    */     {
/* 33 */       y++;
/*    */     }
/*    */     
/* 36 */     if (side == 2)
/*    */     {
/* 38 */       z--;
/*    */     }
/*    */     
/* 41 */     if (side == 3)
/*    */     {
/* 43 */       z++;
/*    */     }
/*    */     
/* 46 */     if (side == 4)
/*    */     {
/* 48 */       x--;
/*    */     }
/*    */     
/* 51 */     if (side == 5)
/*    */     {
/* 53 */       x++;
/*    */     }
/*    */     
/* 56 */     int dir = MathHelper.func_76128_c((player.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x3;
/* 57 */     byte x1 = 0;
/* 58 */     byte z1 = 0;
/*    */     
/* 60 */     if (dir == 0)
/*    */     {
/* 62 */       x1 = -1;
/*    */     }
/*    */     
/* 65 */     if (dir == 1)
/*    */     {
/* 67 */       z1 = -1;
/*    */     }
/*    */     
/* 70 */     if (dir == 2)
/*    */     {
/* 72 */       x1 = 1;
/*    */     }
/*    */     
/* 75 */     if (dir == 3)
/*    */     {
/* 77 */       z1 = 1;
/*    */     }
/*    */     
/* 80 */     if (player.func_82247_a(x, y, z, side, itemstack))
/*    */     {
/* 82 */       if (world.func_147437_c(x, y, z) && world.func_147437_c(x + x1, y, z + z1) && player.func_82247_a(x + x1, y, z + z1, side, itemstack)) {
/*    */         
/* 84 */         world.func_147465_d(x, y, z, this.field_150939_a, dir, 3);
/*    */         
/* 86 */         if (world.func_147439_a(x, y, z) == this.field_150939_a)
/*    */         {
/* 88 */           world.func_147465_d(x + x1, y, z + z1, this.field_150939_a, dir + 4, 2);
/*    */         }
/*    */         
/* 91 */         world.func_72908_a(x + 0.5D, y + 0.5D, z + 0.5D, this.field_150939_a.field_149762_H.func_150496_b(), (this.field_150939_a.field_149762_H.func_150497_c() + 1.0F) / 2.0F, this.field_150939_a.field_149762_H.func_150494_d() * 0.8F);
/* 92 */         itemstack.field_77994_a--;
/* 93 */         return true;
/*    */       } 
/*    */     }
/*    */     
/* 97 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */