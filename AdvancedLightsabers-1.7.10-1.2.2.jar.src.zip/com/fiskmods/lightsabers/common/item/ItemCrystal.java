/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fiskfille.utils.helper.FiskMath;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemCrystal
/*     */   extends ItemBlock
/*     */   implements ILightsaberComponent
/*     */ {
/*     */   public ItemCrystal(Block block) {
/*  37 */     super(block);
/*  38 */     func_77627_a(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFingerprint(ItemStack stack, int slot) {
/*  44 */     return ((getId(stack) & 0xFF) << 24);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatibleSlot(ItemStack stack, int slot) {
/*  50 */     return (slot == 5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WeightedRandomChestContent getChestGenBase(ChestGenHooks chest, Random rand, WeightedRandomChestContent original) {
/*  56 */     ItemStack itemstack = original.field_76297_b;
/*  57 */     String category = "";
/*     */     
/*  59 */     if (itemstack.func_77942_o())
/*     */     {
/*  61 */       category = itemstack.func_77978_p().func_74779_i("ChestGenCategory");
/*     */     }
/*     */     
/*  64 */     List<CrystalColor> list = Lists.newArrayList();
/*     */     
/*  66 */     for (CrystalColor color : CrystalColor.values()) {
/*     */       
/*  68 */       if (Arrays.<Object>asList((Object[])chestMap.get(color)).contains(category))
/*     */       {
/*  70 */         for (int i = ((EnumRarity)rarityMap.get(color)).ordinal() - 1; i >= 0; i--)
/*     */         {
/*  72 */           list.add(color);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/*  77 */     if (list.isEmpty())
/*     */     {
/*  79 */       list.addAll(Arrays.asList(CrystalColor.values()));
/*     */     }
/*     */     
/*  82 */     return new WeightedRandomChestContent(create(list.get(rand.nextInt(list.size()))), original.field_76295_d, original.field_76296_e, original.field_76292_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity func_77613_e(ItemStack itemstack) {
/*  88 */     return rarityMap.get(get(itemstack));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean inHand) {
/*  94 */     if (!world.field_72995_K)
/*     */     {
/*  96 */       if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("color", 99))
/*     */       {
/*  98 */         getId(itemstack);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77624_a(ItemStack itemstack, EntityPlayer player, List<String> list, boolean advanced) {
/* 106 */     list.add(get(itemstack).getLocalizedName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack itemstack, int metadata) {
/* 113 */     return (get(itemstack)).color;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_94581_a(IIconRegister iconRegister) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getId(ItemStack itemstack) {
/* 124 */     if (itemstack.func_77942_o() && itemstack.func_77978_p().func_150297_b("color", 99)) {
/*     */       
/* 126 */       itemstack.func_77964_b(itemstack.func_77978_p().func_74762_e("color"));
/* 127 */       itemstack.func_77978_p().func_82580_o("color");
/*     */       
/* 129 */       if (itemstack.func_77978_p().func_82582_d())
/*     */       {
/* 131 */         itemstack.func_77982_d(null);
/*     */       }
/*     */     } 
/*     */     
/* 135 */     return itemstack.func_77960_j();
/*     */   }
/*     */ 
/*     */   
/*     */   public static CrystalColor get(ItemStack itemstack) {
/* 140 */     return CrystalColor.get(getId(itemstack));
/*     */   }
/*     */ 
/*     */   
/*     */   public static CrystalColor getRandomGen(Random rand) {
/* 145 */     return (CrystalColor)FiskMath.getWeightedI(rand, genRarityMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(CrystalColor color, Item item) {
/* 150 */     return new ItemStack(item, 1, color.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack create(CrystalColor color) {
/* 155 */     return create(color, Item.func_150898_a(ModBlocks.lightsaberCrystal));
/*     */   }
/*     */   
/* 158 */   public static Map<CrystalColor, EnumRarity> rarityMap = Maps.newHashMap();
/* 159 */   public static Map<CrystalColor, String[]> chestMap = Maps.newHashMap();
/*     */   
/* 161 */   private static Map<CrystalColor, Integer> genRarityMap = Maps.newHashMap();
/* 162 */   private static final int[] GEN_RARITY = new int[] { 90, 30, 10, 1 };
/*     */ 
/*     */   
/*     */   public static void registerRarity(CrystalColor color, EnumRarity rarity, String... chests) {
/* 166 */     rarityMap.put(color, rarity);
/* 167 */     chestMap.put(color, chests);
/*     */     
/* 169 */     genRarityMap.put(color, Integer.valueOf(GEN_RARITY[rarity.ordinal()]));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean hasInit = false;
/*     */   
/*     */   private static void init() throws Exception {
/* 176 */     if (hasInit) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 181 */     hasInit = true;
/*     */     
/* 183 */     registerRarity(CrystalColor.DEEP_BLUE, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "dungeonChest" });
/* 184 */     registerRarity(CrystalColor.MEDIUM_BLUE, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "dungeonChest" });
/* 185 */     registerRarity(CrystalColor.LIGHT_BLUE, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "dungeonChest" });
/* 186 */     registerRarity(CrystalColor.AMBER, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidDesertyChest" });
/* 187 */     registerRarity(CrystalColor.YELLOW, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidDesertyChest" });
/* 188 */     registerRarity(CrystalColor.GOLD, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidDesertyChest" });
/* 189 */     registerRarity(CrystalColor.LIME_GREEN, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidJungleChest", "pyramidDesertyChest" });
/* 190 */     registerRarity(CrystalColor.GREEN, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidJungleChest" });
/* 191 */     registerRarity(CrystalColor.MINT_GREEN, EnumRarity.common, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidJungleChest" });
/*     */     
/* 193 */     registerRarity(CrystalColor.MAGENTA, EnumRarity.uncommon, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "dungeonChest" });
/* 194 */     registerRarity(CrystalColor.PINK, EnumRarity.uncommon, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "dungeonChest" });
/* 195 */     registerRarity(CrystalColor.RED, EnumRarity.uncommon, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "villageBlacksmith" });
/* 196 */     registerRarity(CrystalColor.BLOOD_ORANGE, EnumRarity.uncommon, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "pyramidDesertyChest" });
/*     */     
/* 198 */     registerRarity(CrystalColor.INDIGO, EnumRarity.rare, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "strongholdLibrary" });
/* 199 */     registerRarity(CrystalColor.PURPLE, EnumRarity.rare, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "strongholdLibrary" });
/* 200 */     registerRarity(CrystalColor.CYAN, EnumRarity.rare, new String[] { "sithTombCoffin", "sithTombTreasury", "sithTombAnnex", "strongholdLibrary" });
/*     */     
/* 202 */     registerRarity(CrystalColor.ARCTIC_BLUE, EnumRarity.epic, new String[] { "sithTombTreasury", "mineshaftCorridor" });
/* 203 */     registerRarity(CrystalColor.WHITE, EnumRarity.epic, new String[] { "sithTombTreasury", "mineshaftCorridor" });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 210 */       init();
/*     */     }
/* 212 */     catch (Exception e) {
/*     */       
/* 214 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */