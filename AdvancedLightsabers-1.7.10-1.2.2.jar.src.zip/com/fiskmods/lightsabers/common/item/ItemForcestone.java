/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.block.BlockForcestone;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemMultiTexture;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.IIcon;
/*    */ 
/*    */ 
/*    */ public class ItemForcestone
/*    */   extends ItemMultiTexture
/*    */ {
/*    */   public ItemForcestone(Block block) {
/* 16 */     super(block, block, BlockForcestone.NAMES);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public IIcon func_77617_a(int metadata) {
/* 24 */     return super.func_77617_a(metadata);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_77647_b(int metadata) {
/* 31 */     return metadata;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77667_c(ItemStack itemstack) {
/* 37 */     int i = itemstack.func_77960_j();
/*    */     
/* 39 */     if (i > 2)
/*    */     {
/* 41 */       i -= 2;
/*    */     }
/*    */     
/* 44 */     if (i < 0 || i >= this.field_150942_c.length)
/*    */     {
/* 46 */       i = 0;
/*    */     }
/*    */     
/* 49 */     return func_77658_a() + "." + this.field_150942_c[i];
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemForcestone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */