package com.fiskmods.lightsabers.common.item;

import net.minecraft.item.ItemStack;

public interface ILightsaberComponent {
  long getFingerprint(ItemStack paramItemStack, int paramInt);
  
  boolean isCompatibleSlot(ItemStack paramItemStack, int paramInt);
}


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ILightsaberComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */