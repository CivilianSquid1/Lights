/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.google.common.collect.Lists;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import java.util.List;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.oredict.OreDictionary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemRegistry
/*    */ {
/*    */   public static void registerItem(Item item, String unlocalizedName) {
/* 17 */     item.func_77637_a(Lightsabers.CREATIVE_TAB);
/* 18 */     registerItemNoTab(item, unlocalizedName);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerIngot(Item item, String unlocalizedName, String oreDictName) {
/* 23 */     registerItem(item, unlocalizedName);
/*    */     
/* 25 */     if (item.func_77614_k()) {
/*    */       
/* 27 */       List<ItemStack> list = Lists.newArrayList();
/* 28 */       item.func_150895_a(item, item.func_77640_w(), list);
/*    */       
/* 30 */       for (ItemStack itemstack : list)
/*    */       {
/* 32 */         OreDictionary.registerOre(oreDictName, itemstack);
/*    */       }
/*    */     }
/*    */     else {
/*    */       
/* 37 */       OreDictionary.registerOre(oreDictName, item);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemNoTab(Item item, String unlocalizedName) {
/* 43 */     item.func_77655_b(unlocalizedName);
/* 44 */     item.func_111206_d("lightsabers:" + unlocalizedName);
/*    */     
/* 46 */     GameRegistry.registerItem(item, unlocalizedName);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */