/*     */ package com.fiskmods.lightsabers.common.item;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.block.BlockDisassemblyStation;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemDisassemblyTable
/*     */   extends ItemBlock
/*     */ {
/*     */   public ItemDisassemblyTable(Block block) {
/*  18 */     super(block);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77648_a(ItemStack itemstack, EntityPlayer player, World world, int x, int y, int z, int side, float f, float f1, float f2) {
/*  24 */     if (world.field_72995_K)
/*     */     {
/*  26 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  30 */     if (side == 0)
/*     */     {
/*  32 */       y--;
/*     */     }
/*     */     
/*  35 */     if (side == 1)
/*     */     {
/*  37 */       y++;
/*     */     }
/*     */     
/*  40 */     if (side == 2)
/*     */     {
/*  42 */       z--;
/*     */     }
/*     */     
/*  45 */     if (side == 3)
/*     */     {
/*  47 */       z++;
/*     */     }
/*     */     
/*  50 */     if (side == 4)
/*     */     {
/*  52 */       x--;
/*     */     }
/*     */     
/*  55 */     if (side == 5)
/*     */     {
/*  57 */       x++;
/*     */     }
/*     */     
/*  60 */     int dir = MathHelper.func_76128_c((player.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x3;
/*  61 */     byte x1 = 0;
/*  62 */     byte z1 = 0;
/*     */     
/*  64 */     if (dir == 0)
/*     */     {
/*  66 */       x1 = -1;
/*     */     }
/*     */     
/*  69 */     if (dir == 1)
/*     */     {
/*  71 */       z1 = -1;
/*     */     }
/*     */     
/*  74 */     if (dir == 2)
/*     */     {
/*  76 */       x1 = 1;
/*     */     }
/*     */     
/*  79 */     if (dir == 3)
/*     */     {
/*  81 */       z1 = 1;
/*     */     }
/*     */     
/*  84 */     if (player.func_82247_a(x, y, z, side, itemstack))
/*     */     {
/*  86 */       if (world.func_147437_c(x, y, z) && world.func_147437_c(x + x1, y, z + z1) && player.func_82247_a(x + x1, y, z + z1, side, itemstack)) {
/*     */         
/*  88 */         world.func_147465_d(x, y, z, this.field_150939_a, BlockDisassemblyStation.serialize(dir, BlockDisassemblyStation.Part.BASE), 3);
/*     */         
/*  90 */         if (world.func_147439_a(x, y, z) == this.field_150939_a) {
/*     */           
/*  92 */           world.func_147465_d(x + x1, y, z + z1, this.field_150939_a, BlockDisassemblyStation.serialize(dir, BlockDisassemblyStation.Part.SIDE), 2);
/*  93 */           world.func_147465_d(x + x1, y + 1, z + z1, this.field_150939_a, BlockDisassemblyStation.serialize(dir, BlockDisassemblyStation.Part.TOP), 2);
/*  94 */           world.func_147465_d(x, y + 1, z, this.field_150939_a, BlockDisassemblyStation.serialize(dir, BlockDisassemblyStation.Part.TOP), 2);
/*     */         } 
/*     */         
/*  97 */         world.func_72908_a(x + 0.5D, y + 0.5D, z + 0.5D, this.field_150939_a.field_149762_H.func_150496_b(), (this.field_150939_a.field_149762_H.func_150497_c() + 1.0F) / 2.0F, this.field_150939_a.field_149762_H.func_150494_d() * 0.8F);
/*  98 */         itemstack.field_77994_a--;
/*  99 */         return true;
/*     */       } 
/*     */     }
/*     */     
/* 103 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemDisassemblyTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */