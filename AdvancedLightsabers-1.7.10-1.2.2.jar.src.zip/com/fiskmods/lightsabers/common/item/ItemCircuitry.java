/*    */ package com.fiskmods.lightsabers.common.item;
/*    */ 
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemCircuitry
/*    */   extends Item
/*    */   implements ILightsaberComponent
/*    */ {
/*    */   public long getFingerprint(ItemStack stack, int slot) {
/* 11 */     return 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCompatibleSlot(ItemStack stack, int slot) {
/* 17 */     return (slot == 4);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\item\ItemCircuitry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */