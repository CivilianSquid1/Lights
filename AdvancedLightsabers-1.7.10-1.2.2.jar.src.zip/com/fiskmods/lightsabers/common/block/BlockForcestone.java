/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockForcestone
/*     */   extends Block
/*     */ {
/*  18 */   public static final String[] NAMES = new String[] { "default", "inscribed", "pillar", "cracked", "mossy" };
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon[] icons;
/*     */ 
/*     */   
/*     */   public BlockForcestone() {
/*  25 */     super(Material.field_151576_e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon func_149691_a(int side, int metadata) {
/*  32 */     if (metadata != 2 && metadata != 3 && metadata != 4) {
/*     */       
/*  34 */       if (metadata == 1)
/*     */       {
/*  36 */         return (side == 0 || side == 1) ? this.icons[0] : this.icons[1];
/*     */       }
/*  38 */       if (metadata > 4)
/*     */       {
/*  40 */         return this.icons[Math.min(metadata - 1, this.icons.length - 1)];
/*     */       }
/*     */       
/*  43 */       return this.icons[0];
/*     */     } 
/*     */ 
/*     */     
/*  47 */     return (metadata == 2 && (side == 1 || side == 0)) ? this.icons[2] : ((metadata == 3 && (side == 5 || side == 4)) ? this.icons[2] : ((metadata == 4 && (side == 2 || side == 3)) ? this.icons[2] : this.icons[3]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149660_a(World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/*  54 */     if (metadata == 2)
/*     */     {
/*  56 */       switch (side) {
/*     */         
/*     */         case 0:
/*     */         case 1:
/*  60 */           return 2;
/*     */         case 2:
/*     */         case 3:
/*  63 */           return 4;
/*     */         case 4:
/*     */         case 5:
/*  66 */           return 3;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  74 */     return metadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149692_a(int metadata) {
/*  81 */     return (metadata != 3 && metadata != 4) ? metadata : 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ItemStack func_149644_j(int metadata) {
/*  87 */     return super.func_149644_j((metadata == 3 || metadata == 4) ? 2 : metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/*  93 */     return 39;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149666_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/* 105 */     list.add(new ItemStack(item, 1, 0));
/* 106 */     list.add(new ItemStack(item, 1, 1));
/* 107 */     list.add(new ItemStack(item, 1, 2));
/* 108 */     list.add(new ItemStack(item, 1, 5));
/* 109 */     list.add(new ItemStack(item, 1, 6));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149651_a(IIconRegister iconRegister) {
/* 116 */     this.icons = new IIcon[6];
/* 117 */     this.icons[0] = iconRegister.func_94245_a(func_149641_N());
/* 118 */     this.icons[1] = iconRegister.func_94245_a(func_149641_N() + "_inscribed");
/* 119 */     this.icons[2] = iconRegister.func_94245_a(func_149641_N() + "_pillar_top");
/* 120 */     this.icons[3] = iconRegister.func_94245_a(func_149641_N() + "_pillar");
/* 121 */     this.icons[4] = iconRegister.func_94245_a(func_149641_N() + "_cracked");
/* 122 */     this.icons[5] = iconRegister.func_94245_a(func_149641_N() + "_mossy");
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockForcestone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */