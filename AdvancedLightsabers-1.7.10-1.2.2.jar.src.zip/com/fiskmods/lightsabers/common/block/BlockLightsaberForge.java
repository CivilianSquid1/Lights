/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockLightsaberForge
/*     */   extends Block
/*     */   implements ITileEntityProvider
/*     */ {
/*  26 */   public static final int[][] DIRECTIONS = new int[][] { { -1, 0 }, { 0, -1 }, { 1, 0 }, { 0, 1 } };
/*     */   
/*     */   public Block block;
/*     */ 
/*     */   
/*     */   public BlockLightsaberForge(Block block) {
/*  32 */     super(Material.field_151573_f);
/*  33 */     func_149711_c(1.5F);
/*  34 */     func_149752_b(100.0F);
/*  35 */     setHarvestLevel("pickaxe", 0);
/*  36 */     func_149672_a(field_149777_j);
/*  37 */     this.block = block;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int metadata, float hitX, float hitY, float hitZ) {
/*  43 */     if (!player.func_70093_af()) {
/*     */       
/*  45 */       player.openGui(Lightsabers.instance, 0, world, x, y, z);
/*  46 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/*  63 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/*  75 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  76 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/*  83 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  84 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/*  90 */     setBounds(world.func_72805_g(x, y, z));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBounds(int metadata) {
/*  95 */     int direction = getDirection(metadata);
/*  96 */     int i = isBlockSideOfPanel(metadata) ? 0 : 1;
/*  97 */     float f = 0.8125F;
/*     */     
/*  99 */     if (direction == 0) {
/*     */       
/* 101 */       func_149676_a(-i, 0.0F, 0.0F, (2 - i), f, 1.0F);
/*     */     }
/* 103 */     else if (direction == 1) {
/*     */       
/* 105 */       func_149676_a(0.0F, 0.0F, -i, 1.0F, f, (2 - i));
/*     */     }
/* 107 */     else if (direction == 2) {
/*     */       
/* 109 */       func_149676_a((-1 + i), 0.0F, 0.0F, (1 + i), f, 1.0F);
/*     */     }
/* 111 */     else if (direction == 3) {
/*     */       
/* 113 */       func_149676_a(0.0F, 0.0F, (-1 + i), 1.0F, f, (1 + i));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/* 120 */     int metadata = world.func_72805_g(x, y, z);
/* 121 */     int direction = getDirection(metadata);
/*     */     
/* 123 */     if (isBlockSideOfPanel(metadata)) {
/*     */       
/* 125 */       if (world.func_147439_a(x - DIRECTIONS[direction][0], y, z - DIRECTIONS[direction][1]) != this)
/*     */       {
/* 127 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     }
/* 130 */     else if (world.func_147439_a(x + DIRECTIONS[direction][0], y, z + DIRECTIONS[direction][1]) != this) {
/*     */       
/* 132 */       world.func_147468_f(x, y, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/* 139 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_149650_a(int metadata, Random rand, int i) {
/* 145 */     return super.func_149650_a(metadata, rand, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBlockSideOfPanel(int metadata) {
/* 150 */     return (metadata >= 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getDirection(int metadata) {
/* 155 */     return metadata % 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149690_a(World world, int x, int y, int z, int metadata, float f, int i) {
/* 163 */     super.func_149690_a(world, x, y, z, metadata, f, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149656_h() {
/* 170 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149681_a(World world, int x, int y, int z, int metadata, EntityPlayer player) {
/* 176 */     if (player.field_71075_bZ.field_75098_d && isBlockSideOfPanel(metadata)) {
/*     */       
/* 178 */       int dir = getDirection(metadata);
/*     */       
/* 180 */       x += DIRECTIONS[dir][0];
/* 181 */       z += DIRECTIONS[dir][1];
/*     */       
/* 183 */       if (world.func_147439_a(x, y, z) == this)
/*     */       {
/* 185 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 193 */     return (TileEntity)new TileEntityLightsaberForge();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon func_149691_a(int side, int meta) {
/* 199 */     return this.block.func_149691_a(side, meta);
/*     */   }
/*     */   
/*     */   public void func_149651_a(IIconRegister par1IIconRegister) {}
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockLightsaberForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */