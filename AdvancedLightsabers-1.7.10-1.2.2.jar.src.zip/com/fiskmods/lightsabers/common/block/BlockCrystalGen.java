/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCrystalGen
/*    */   extends BlockBasic
/*    */ {
/*    */   public BlockCrystalGen() {
/* 21 */     super(Material.field_151579_a);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB func_149668_a(World world, int x, int y, int z) {
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149686_d() {
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149662_c() {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149674_a(World world, int x, int y, int z, Random rand) {
/* 51 */     replace(world, x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149726_b(World world, int x, int y, int z) {
/* 57 */     replace(world, x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/* 65 */     replace(world, x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_149745_a(Random random) {
/* 72 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void replace(World world, int x, int y, int z) {
/* 77 */     if (ModBlocks.lightsaberCrystal.func_149742_c(world, x, y, z) && world.func_147465_d(x, y, z, ModBlocks.lightsaberCrystal, 0, 2)) {
/*    */       
/* 79 */       TileEntityCrystal tile = (TileEntityCrystal)world.func_147438_o(x, y, z);
/*    */       
/* 81 */       if (tile != null)
/*    */       {
/* 83 */         Random rand = new Random(world.func_72905_C() + (x * x * 4987142) + (x * 5947611) + (z * z) * 4392871L + (z * 389711) ^ 0x3AD8025FL ^ y);
/* 84 */         tile.setColor(ItemCrystal.getRandomGen(rand));
/*    */       }
/*    */     
/*    */     } else {
/*    */       
/* 89 */       world.func_147465_d(x, y, z, Blocks.field_150350_a, 0, 2);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149651_a(IIconRegister iconRegister) {
/* 96 */     this.field_149761_L = iconRegister.func_94245_a("lightsabers:lightsaber_crystal");
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockCrystalGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */