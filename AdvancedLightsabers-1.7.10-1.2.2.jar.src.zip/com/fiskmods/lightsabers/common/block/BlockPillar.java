/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.block.BlockRotatedPillar;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.util.IIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockPillar
/*    */   extends BlockRotatedPillar
/*    */ {
/*    */   public BlockPillar() {
/* 16 */     super(Material.field_151576_e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected IIcon func_150163_b(int i) {
/* 23 */     return this.field_149761_L;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149651_a(IIconRegister par1IIconRegister) {
/* 29 */     this.field_150164_N = par1IIconRegister.func_94245_a("lightsabers:" + func_149739_a().substring(5) + "_top");
/* 30 */     this.field_149761_L = par1IIconRegister.func_94245_a("lightsabers:" + func_149739_a().substring(5));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockPillar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */