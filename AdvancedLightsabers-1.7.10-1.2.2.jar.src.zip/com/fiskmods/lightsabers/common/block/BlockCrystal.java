/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ 
/*     */ 
/*     */ public class BlockCrystal
/*     */   extends BlockBasic
/*     */   implements ITileEntityProvider
/*     */ {
/*  32 */   private Random rand = new Random();
/*     */ 
/*     */   
/*     */   public BlockCrystal() {
/*  36 */     super(Material.field_151592_s);
/*  37 */     func_149715_a(0.25F);
/*  38 */     func_149711_c(2.0F);
/*  39 */     func_149752_b(10.0F);
/*  40 */     func_149672_a(Block.field_149778_k);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149666_a(Item item, CreativeTabs tab, List<ItemStack> subBlocks) {
/*  47 */     for (CrystalColor color : CrystalColor.values())
/*     */     {
/*  49 */       subBlocks.add(ItemCrystal.create(color));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_149668_a(World world, int x, int y, int z) {
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/*  74 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canPlaceAt(World world, int x, int y, int z) {
/*  85 */     if (World.func_147466_a((IBlockAccess)world, x, y, z))
/*     */     {
/*  87 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  91 */     Block block = world.func_147439_a(x, y, z);
/*  92 */     return block.canPlaceTorchOnTop(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149742_c(World world, int x, int y, int z) {
/*  99 */     return (world.isSideSolid(x - 1, y, z, ForgeDirection.EAST, true) || world.isSideSolid(x + 1, y, z, ForgeDirection.WEST, true) || world.isSideSolid(x, y, z - 1, ForgeDirection.SOUTH, true) || world.isSideSolid(x, y, z + 1, ForgeDirection.NORTH, true) || canPlaceAt(world, x, y - 1, z) || canPlaceAt(world, x, y + 1, z));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149660_a(World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 105 */     int j1 = metadata;
/*     */     
/* 107 */     if (side == 0 && canPlaceAt(world, x, y + 1, z))
/*     */     {
/* 109 */       j1 = 6;
/*     */     }
/*     */     
/* 112 */     if (side == 1 && canPlaceAt(world, x, y - 1, z))
/*     */     {
/* 114 */       j1 = 5;
/*     */     }
/*     */     
/* 117 */     if (side == 2 && world.isSideSolid(x, y, z + 1, ForgeDirection.NORTH, true))
/*     */     {
/* 119 */       j1 = 4;
/*     */     }
/*     */     
/* 122 */     if (side == 3 && world.isSideSolid(x, y, z - 1, ForgeDirection.SOUTH, true))
/*     */     {
/* 124 */       j1 = 3;
/*     */     }
/*     */     
/* 127 */     if (side == 4 && world.isSideSolid(x + 1, y, z, ForgeDirection.WEST, true))
/*     */     {
/* 129 */       j1 = 2;
/*     */     }
/*     */     
/* 132 */     if (side == 5 && world.isSideSolid(x - 1, y, z, ForgeDirection.EAST, true))
/*     */     {
/* 134 */       j1 = 1;
/*     */     }
/*     */     
/* 137 */     return j1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149674_a(World world, int x, int y, int z, Random rand) {
/* 143 */     super.func_149674_a(world, x, y, z, rand);
/*     */     
/* 145 */     if (world.func_72805_g(x, y, z) == 0)
/*     */     {
/* 147 */       func_149726_b(world, x, y, z);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149726_b(World world, int x, int y, int z) {
/* 154 */     if (world.func_72805_g(x, y, z) == 0)
/*     */     {
/* 156 */       if (world.isSideSolid(x - 1, y, z, ForgeDirection.EAST, true)) {
/*     */         
/* 158 */         world.func_72921_c(x, y, z, 1, 2);
/*     */       }
/* 160 */       else if (world.isSideSolid(x + 1, y, z, ForgeDirection.WEST, true)) {
/*     */         
/* 162 */         world.func_72921_c(x, y, z, 2, 2);
/*     */       }
/* 164 */       else if (world.isSideSolid(x, y, z - 1, ForgeDirection.SOUTH, true)) {
/*     */         
/* 166 */         world.func_72921_c(x, y, z, 3, 2);
/*     */       }
/* 168 */       else if (world.isSideSolid(x, y, z + 1, ForgeDirection.NORTH, true)) {
/*     */         
/* 170 */         world.func_72921_c(x, y, z, 4, 2);
/*     */       }
/* 172 */       else if (canPlaceAt(world, x, y - 1, z)) {
/*     */         
/* 174 */         world.func_72921_c(x, y, z, 5, 2);
/*     */       }
/* 176 */       else if (canPlaceAt(world, x, y + 1, z)) {
/*     */         
/* 178 */         world.func_72921_c(x, y, z, 6, 2);
/*     */       } 
/*     */     }
/*     */     
/* 182 */     func_150109_e(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/* 188 */     func_150108_b(world, x, y, z, block);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean func_150108_b(World world, int x, int y, int z, Block block) {
/* 193 */     if (func_150109_e(world, x, y, z)) {
/*     */       
/* 195 */       int l = world.func_72805_g(x, y, z);
/* 196 */       boolean flag = false;
/*     */       
/* 198 */       if (!world.isSideSolid(x - 1, y, z, ForgeDirection.EAST, true) && l == 1)
/*     */       {
/* 200 */         flag = true;
/*     */       }
/*     */       
/* 203 */       if (!world.isSideSolid(x + 1, y, z, ForgeDirection.WEST, true) && l == 2)
/*     */       {
/* 205 */         flag = true;
/*     */       }
/*     */       
/* 208 */       if (!world.isSideSolid(x, y, z - 1, ForgeDirection.SOUTH, true) && l == 3)
/*     */       {
/* 210 */         flag = true;
/*     */       }
/*     */       
/* 213 */       if (!world.isSideSolid(x, y, z + 1, ForgeDirection.NORTH, true) && l == 4)
/*     */       {
/* 215 */         flag = true;
/*     */       }
/*     */       
/* 218 */       if (!canPlaceAt(world, x, y - 1, z) && l == 5)
/*     */       {
/* 220 */         flag = true;
/*     */       }
/*     */       
/* 223 */       if (!canPlaceAt(world, x, y + 1, z) && l == 6)
/*     */       {
/* 225 */         flag = true;
/*     */       }
/*     */       
/* 228 */       if (flag) {
/*     */         
/* 230 */         func_149697_b(world, x, y, z, world.func_72805_g(x, y, z), 0);
/* 231 */         world.func_147468_f(x, y, z);
/* 232 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 236 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 241 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_150109_e(World world, int x, int y, int z) {
/* 247 */     if (!func_149742_c(world, x, y, z)) {
/*     */       
/* 249 */       if (world.func_147439_a(x, y, z) == this) {
/*     */         
/* 251 */         func_149697_b(world, x, y, z, 1, 0);
/* 252 */         world.func_147468_f(x, y, z);
/*     */       } 
/*     */       
/* 255 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 259 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovingObjectPosition func_149731_a(World world, int x, int y, int z, Vec3 vec3, Vec3 vec31) {
/* 266 */     int l = world.func_72805_g(x, y, z);
/* 267 */     float f = 0.0625F;
/* 268 */     float width = f * 6.0F;
/* 269 */     float height = f * 6.0F;
/*     */     
/* 271 */     if (l == 1) {
/*     */       
/* 273 */       func_149676_a(0.0F, 0.5F - width / 2.0F, 0.5F - width / 2.0F, height, 0.5F + width / 2.0F, 0.5F + width / 2.0F);
/*     */     }
/* 275 */     else if (l == 2) {
/*     */       
/* 277 */       func_149676_a(1.0F - height, 0.5F - width / 2.0F, 0.5F - width / 2.0F, 1.0F, 0.5F + width / 2.0F, 0.5F + width / 2.0F);
/*     */     }
/* 279 */     else if (l == 3) {
/*     */       
/* 281 */       func_149676_a(0.5F - width / 2.0F, 0.5F - width / 2.0F, 0.0F, 0.5F + width / 2.0F, 0.5F + width / 2.0F, height);
/*     */     }
/* 283 */     else if (l == 4) {
/*     */       
/* 285 */       func_149676_a(0.5F - width / 2.0F, 0.5F - width / 2.0F, 1.0F - height, 0.5F + width / 2.0F, 0.5F + width / 2.0F, 1.0F);
/*     */     }
/* 287 */     else if (l == 5) {
/*     */       
/* 289 */       func_149676_a(0.5F - width / 2.0F, 0.0F, 0.5F - width / 2.0F, 0.5F + width / 2.0F, height, 0.5F + width / 2.0F);
/*     */     }
/*     */     else {
/*     */       
/* 293 */       func_149676_a(0.5F - width / 2.0F, 1.0F - height, 0.5F - width / 2.0F, 0.5F + width / 2.0F, 1.0F, 0.5F + width / 2.0F);
/*     */     } 
/*     */     
/* 296 */     return super.func_149731_a(world, x, y, z, vec3, vec31);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149689_a(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemstack) {
/* 302 */     super.func_149689_a(world, x, y, z, entity, itemstack);
/* 303 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 305 */     if (tile instanceof TileEntityCrystal)
/*     */     {
/* 307 */       ((TileEntityCrystal)tile).setColor(ItemCrystal.get(itemstack));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
/* 314 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 316 */     if (tile instanceof TileEntityCrystal)
/*     */     {
/* 318 */       return ItemCrystal.create(((TileEntityCrystal)tile).getColor());
/*     */     }
/*     */     
/* 321 */     return super.getPickBlock(target, world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int metadata, float hitX, float hitY, float hitZ) {
/* 327 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 329 */     if (tile instanceof TileEntityCrystal) {
/*     */       
/* 331 */       func_149642_a(world, x, y, z, ItemCrystal.create(((TileEntityCrystal)tile).getColor()));
/* 332 */       world.func_147449_b(x, y, z, Blocks.field_150350_a);
/*     */       
/* 334 */       return true;
/*     */     } 
/*     */     
/* 337 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int quantityDropped(int meta, int fortune, Random random) {
/* 343 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_149720_d(IBlockAccess world, int x, int y, int z) {
/* 350 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 352 */     if (tile instanceof TileEntityCrystal)
/*     */     {
/* 354 */       return (((TileEntityCrystal)tile).getColor()).color;
/*     */     }
/*     */     
/* 357 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 363 */     return (TileEntity)new TileEntityCrystal();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */