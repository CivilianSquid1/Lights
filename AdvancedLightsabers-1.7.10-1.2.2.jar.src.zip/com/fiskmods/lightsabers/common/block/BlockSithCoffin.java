/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.PacketTileAction;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockSithCoffin
/*     */   extends BlockContainer
/*     */   implements ITileEntityProvider {
/*  28 */   public static final int[][] DIRECTIONS = new int[][] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
/*     */   
/*  30 */   private Random rand = new Random();
/*     */ 
/*     */   
/*     */   public BlockSithCoffin() {
/*  34 */     super(Material.field_151576_e);
/*  35 */     func_149711_c(50.0F);
/*  36 */     func_149752_b(2000.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/*  42 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/*  54 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/*  66 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  67 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/*  74 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  75 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/*  81 */     int metadata = world.func_72805_g(x, y, z);
/*  82 */     int i = isBlockFrontOfCoffin(metadata) ? 1 : 0;
/*  83 */     int dir = getDirection(metadata);
/*  84 */     float f = 0.9575F;
/*  85 */     float height = 0.9375F;
/*     */     
/*  87 */     if (dir == 0) {
/*     */       
/*  89 */       func_149676_a(0.0F, 0.0F, -i, 1.0F, height, (2 - i));
/*     */     }
/*  91 */     else if (dir == 1) {
/*     */       
/*  93 */       func_149676_a((i - 1), 0.0F, 0.0F, (1 + i), height, 1.0F);
/*     */     }
/*  95 */     else if (dir == 2) {
/*     */       
/*  97 */       func_149676_a(0.0F, 0.0F, (i - 1), 1.0F, height, (1 + i));
/*     */     }
/*  99 */     else if (dir == 3) {
/*     */       
/* 101 */       func_149676_a(-i, 0.0F, 0.0F, (2 - i), height, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/* 108 */     int metadata = world.func_72805_g(x, y, z);
/* 109 */     int dir = getDirection(metadata);
/*     */     
/* 111 */     if (isBlockFrontOfCoffin(metadata)) {
/*     */       
/* 113 */       if (world.func_147439_a(x - DIRECTIONS[dir][0], y, z - DIRECTIONS[dir][1]) != this)
/*     */       {
/* 115 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     }
/* 118 */     else if (world.func_147439_a(x + DIRECTIONS[dir][0], y, z + DIRECTIONS[dir][1]) != this) {
/*     */       
/* 120 */       world.func_147468_f(x, y, z);
/*     */       
/* 122 */       if (!world.field_72995_K)
/*     */       {
/* 124 */         func_149697_b(world, x, y, z, metadata, 0);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
/* 132 */     int metadata = world.func_72805_g(x, y, z);
/* 133 */     int dir = getDirection(metadata);
/*     */     
/* 135 */     if (isBlockFrontOfCoffin(metadata)) {
/*     */       
/* 137 */       x -= DIRECTIONS[dir][0];
/* 138 */       z -= DIRECTIONS[dir][1];
/*     */     } 
/*     */     
/* 141 */     TileEntitySithCoffin tile = (TileEntitySithCoffin)world.func_147438_o(x, y, z);
/*     */     
/* 143 */     if (tile != null) {
/*     */       
/* 145 */       if (!tile.hasBeenOpened || tile.lidOpenTimer == 0 || player.func_70093_af()) {
/*     */         
/* 147 */         sendActionPacket(tile, player, 0);
/* 148 */         return true;
/*     */       } 
/* 150 */       if (tile.lidOpenTimer == 60) {
/*     */         
/* 152 */         player.openGui(Lightsabers.instance, 1, world, x, y, z);
/* 153 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendActionPacket(TileEntitySithCoffin tile, EntityPlayer player, int action) {
/* 162 */     if (player.field_70170_p.field_72995_K)
/*     */     {
/* 164 */       ALNetworkManager.wrapper.sendToServer((IMessage)new PacketTileAction((Entity)player, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, action));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_149650_a(int metadata, Random rand, int fortune) {
/* 171 */     return isBlockFrontOfCoffin(metadata) ? Item.func_150899_d(0) : super.func_149650_a(metadata, rand, fortune);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBlockFrontOfCoffin(int metadata) {
/* 176 */     return ((metadata & 0x8) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getDirection(int metadata) {
/* 181 */     return metadata & 0x3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149690_a(World world, int x, int y, int z, int metadata, float dropChance, int fortune) {
/* 187 */     if (!isBlockFrontOfCoffin(metadata))
/*     */     {
/* 189 */       super.func_149690_a(world, x, y, z, metadata, dropChance, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149656_h() {
/* 196 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149681_a(World world, int x, int y, int z, int metadata, EntityPlayer player) {
/* 202 */     if (player.field_71075_bZ.field_75098_d && isBlockFrontOfCoffin(metadata)) {
/*     */       
/* 204 */       int dir = getDirection(metadata);
/* 205 */       x -= DIRECTIONS[dir][0];
/* 206 */       z -= DIRECTIONS[dir][1];
/*     */       
/* 208 */       if (world.func_147439_a(x, y, z) == this)
/*     */       {
/* 210 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 218 */     return (TileEntity)new TileEntitySithCoffin();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149651_a(IIconRegister iconRegister) {
/* 224 */     this.field_149761_L = iconRegister.func_94245_a("obsidian");
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockSithCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */