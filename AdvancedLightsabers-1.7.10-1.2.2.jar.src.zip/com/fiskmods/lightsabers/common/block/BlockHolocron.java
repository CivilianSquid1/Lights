/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.PacketTileAction;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockHolocron
/*     */   extends BlockContainer
/*     */ {
/*  29 */   private String[][] iconNames = new String[][] { { "jedi_holocron_side", "jedi_holocron_corner", "jedi_holocron_corner_bottom", "jedi_holocron_corner_side" }, { "sith_holocron_bottom", "sith_holocron_side" } };
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon[][] icons;
/*     */ 
/*     */   
/*     */   protected BlockHolocron() {
/*  36 */     super(Material.field_151594_q);
/*  37 */     func_149752_b(2000.0F);
/*  38 */     func_149715_a(0.5F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int metadata, float hitX, float hitY, float hitZ) {
/*  44 */     if (!player.func_70093_af()) {
/*     */       
/*  46 */       TileEntityHolocron tile = (TileEntityHolocron)world.func_147438_o(x, y, z);
/*     */       
/*  48 */       if (tile != null) {
/*     */         
/*  50 */         if (world.field_72995_K)
/*     */         {
/*  52 */           ALNetworkManager.wrapper.sendToServer((IMessage)new PacketTileAction((Entity)player, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, 0));
/*     */         }
/*     */         
/*  55 */         player.openGui(Lightsabers.instance, 2, world, x, y, z);
/*     */       } 
/*     */       
/*  58 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/*  69 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  70 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/*  77 */     func_149719_a((IBlockAccess)world, x, y, z);
/*  78 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/*  84 */     float f = 0.0F;
/*     */     
/*  86 */     if (world.func_147438_o(x, y, z) instanceof TileEntityHolocron) {
/*     */       
/*  88 */       TileEntityHolocron tile = (TileEntityHolocron)world.func_147438_o(x, y, z);
/*  89 */       f = tile.prevOpenTimer + (tile.openTimer - tile.prevOpenTimer) * Lightsabers.proxy.getRenderTick();
/*     */     } 
/*     */     
/*  92 */     float size = 0.25F;
/*  93 */     float offset = size * f;
/*     */     
/*  95 */     if (world.func_72805_g(x, y, z) == 0)
/*     */     {
/*  97 */       size -= 0.125F * f;
/*     */     }
/*     */     
/* 100 */     func_149676_a(size, offset, size, 1.0F - size, 1.0F - size * 2.0F + offset, 1.0F - size);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/* 112 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149666_a(Item item, CreativeTabs tab, List<ItemStack> subBlocks) {
/* 125 */     subBlocks.add(new ItemStack(item, 1, 0));
/* 126 */     subBlocks.add(new ItemStack(item, 1, 1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149692_a(int metadata) {
/* 132 */     return metadata;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon func_149691_a(int side, int meta) {
/* 138 */     IIcon[] icons1 = this.icons[MathHelper.func_76125_a(meta, 0, this.icons.length - 1)];
/* 139 */     return icons1[MathHelper.func_76125_a(side, 0, icons1.length - 1)];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 145 */     return (TileEntity)new TileEntityHolocron();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149651_a(IIconRegister par1IIconRegister) {
/* 151 */     this.icons = new IIcon[this.iconNames.length][];
/*     */     
/* 153 */     for (int i = 0; i < this.iconNames.length; i++) {
/*     */       
/* 155 */       this.icons[i] = new IIcon[(this.iconNames[i]).length];
/*     */       
/* 157 */       for (int j = 0; j < (this.iconNames[i]).length; j++)
/*     */       {
/* 159 */         this.icons[i][j] = par1IIconRegister.func_94245_a("lightsabers:" + this.iconNames[i][j]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockHolocron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */