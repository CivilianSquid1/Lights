/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.generator.structure.StructureSithTomb;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockStructureSpawner
/*    */   extends BlockBasic
/*    */ {
/*    */   public BlockStructureSpawner() {
/* 19 */     super(Material.field_151576_e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB func_149668_a(World world, int x, int y, int z) {
/* 25 */     if (Keyboard.isKeyDown(50))
/*    */     {
/* 27 */       spawnStructure(world, x, y, z);
/*    */     }
/*    */     
/* 30 */     return super.func_149668_a(world, x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int metadata, float hitX, float hitY, float hitZ) {
/* 36 */     spawnStructure(world, x, y, z);
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   private void spawnStructure(World world, int x, int y, int z) {
/* 42 */     StructureSithTomb structureSithTomb = new StructureSithTomb(world, x, y, z);
/* 43 */     Random rand = new Random();
/*    */ 
/*    */     
/* 46 */     structureSithTomb.spawnStructure(rand);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockStructureSpawner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */