/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.entity.EntitySithGhost;
/*     */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*     */ import com.fiskmods.lightsabers.common.network.PacketTileAction;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockSithStoneCoffin
/*     */   extends BlockContainer {
/*  31 */   private final Random rand = new Random();
/*     */ 
/*     */   
/*     */   public BlockSithStoneCoffin() {
/*  35 */     super(Material.field_151576_e);
/*  36 */     func_149711_c(50.0F);
/*  37 */     func_149752_b(2000.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntitySithGhost spawnSithGhost(World world, int x, int y, int z) {
/*  42 */     EntitySithGhost entity = new EntitySithGhost(world);
/*  43 */     entity.func_70012_b((x + 0.5F), (y + 0.1875F), (z + 0.5F), (world.func_72805_g(x, y, z) * 90), 0.0F);
/*  44 */     entity.func_110161_a(null);
/*  45 */     entity.field_70173_aa = -entity.func_70681_au().nextInt(20);
/*  46 */     entity.hasRestingPlace = true;
/*  47 */     entity.restingPlaceX = x;
/*  48 */     entity.restingPlaceY = y;
/*  49 */     entity.restingPlaceZ = z;
/*     */     
/*  51 */     if (world.func_147438_o(x, y, z) instanceof TileEntitySithStoneCoffin) {
/*     */       
/*  53 */       TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */       
/*  55 */       if (tile.equipment != null) {
/*     */         
/*  57 */         if (tile.equipment.func_77942_o())
/*     */         {
/*  59 */           tile.equipment.func_77978_p().func_74757_a("active", false);
/*     */         }
/*     */         
/*  62 */         entity.func_70062_b(0, tile.equipment);
/*     */       } 
/*     */       
/*  65 */       tile.baseplateOnly = true;
/*     */     } 
/*     */     
/*  68 */     world.func_72838_d((Entity)entity);
/*  69 */     return entity;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149726_b(World world, int x, int y, int z) {
/*  75 */     super.func_149726_b(world, x, y, z);
/*     */     
/*  77 */     if (world.func_72864_z(x, y, z))
/*     */     {
/*  79 */       activate(world, x, y, z);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/*  86 */     int metadata = world.func_72805_g(x, y, z);
/*     */     
/*  88 */     if (metadata >= 4) {
/*     */       
/*  90 */       if (world.func_147439_a(x, y - 1, z) != ModBlocks.sithStoneCoffin)
/*     */       {
/*  92 */         world.func_147468_f(x, y, z);
/*  93 */         func_149749_a(world, x, y, z, block, metadata);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  98 */       TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */       
/* 100 */       if ((tile == null || !tile.baseplateOnly) && world.func_147439_a(x, y + 1, z) != ModBlocks.sithStoneCoffin) {
/*     */         
/* 102 */         world.func_147468_f(x, y, z);
/* 103 */         func_149749_a(world, x, y, z, block, metadata);
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     if (world.func_72864_z(x, y, z))
/*     */     {
/* 109 */       activate(world, x, y, z);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void activate(World world, int x, int y, int z) {
/* 115 */     if (world.func_72805_g(x, y, z) >= 4)
/*     */     {
/* 117 */       y--;
/*     */     }
/*     */     
/* 120 */     TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */     
/* 122 */     if (tile != null)
/*     */     {
/* 124 */       if (!tile.baseplateOnly)
/*     */       {
/* 126 */         if (!world.field_72995_K) {
/*     */           
/* 128 */           spawnSithGhost(world, x, y, z);
/* 129 */           ALNetworkManager.wrapper.sendToServer((IMessage)new PacketTileAction(null, x, y, z, 1));
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149699_a(World world, int x, int y, int z, EntityPlayer player) {
/* 138 */     if (!player.field_71075_bZ.field_75098_d && !world.field_72995_K) {
/*     */       
/* 140 */       if (world.func_72805_g(x, y, z) >= 4)
/*     */       {
/* 142 */         y--;
/*     */       }
/*     */       
/* 145 */       TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */       
/* 147 */       if (tile != null)
/*     */       {
/* 149 */         if (!tile.baseplateOnly && tile.taskFinished) {
/*     */           
/* 151 */           world.func_72926_e(2001, x, y, z, Block.func_149682_b(world.func_147439_a(x, y, z)) + (world.func_72805_g(x, y, z) << 12));
/* 152 */           world.func_147468_f(x, y, z);
/*     */           
/* 154 */           ItemStack itemstack = new ItemStack((Block)this);
/* 155 */           itemstack.func_77982_d(new NBTTagCompound());
/*     */           
/* 157 */           if (tile.equipment != null) {
/*     */             
/* 159 */             NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 160 */             tile.equipment.func_77955_b(nbttagcompound);
/* 161 */             itemstack.func_77978_p().func_74782_a("Equipment", (NBTBase)nbttagcompound);
/*     */           } 
/*     */           
/* 164 */           float f = this.rand.nextFloat() * 0.8F + 0.1F;
/* 165 */           float f1 = this.rand.nextFloat() * 0.8F + 0.1F;
/* 166 */           float f2 = this.rand.nextFloat() * 0.8F + 0.1F;
/* 167 */           float f3 = 0.05F;
/* 168 */           EntityItem entityitem = new EntityItem(world, (x + f), (y + f1), (z + f2), itemstack);
/* 169 */           entityitem.field_70159_w = ((float)this.rand.nextGaussian() * f3);
/* 170 */           entityitem.field_70181_x = ((float)this.rand.nextGaussian() * f3 + 0.2F);
/* 171 */           entityitem.field_70179_y = ((float)this.rand.nextGaussian() * f3);
/* 172 */           world.func_72838_d((Entity)entityitem);
/*     */           
/* 174 */           func_149749_a(world, x, y, z, world.func_147439_a(x, y, z), world.func_72805_g(x, y, z));
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 179 */     super.func_149699_a(world, x, y, z, player);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/* 185 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/* 197 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/* 210 */     func_149719_a((IBlockAccess)world, x, y, z);
/* 211 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/* 217 */     int metadata = world.func_72805_g(x, y, z);
/* 218 */     float f = 0.0625F;
/*     */     
/* 220 */     if (metadata < 4) {
/*     */       
/* 222 */       addBox(0.0F, 0.0F, 0.0F, 1.0F, 3.0F * f, 1.0F, world, x, y, z, aabb, list, entity);
/*     */       
/* 224 */       TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/*     */       
/* 226 */       if (tile != null && !tile.baseplateOnly)
/*     */       {
/* 228 */         if (metadata == 0) {
/*     */           
/* 230 */           addBox(1.5F * f, 3.0F * f, 1.5F * f, 14.5F * f, 31.0F * f, 10.5F * f, world, x, y, z, aabb, list, entity);
/*     */         }
/* 232 */         else if (metadata == 1) {
/*     */           
/* 234 */           addBox(5.5F * f, 3.0F * f, 1.5F * f, 14.5F * f, 31.0F * f, 14.5F * f, world, x, y, z, aabb, list, entity);
/*     */         }
/* 236 */         else if (metadata == 2) {
/*     */           
/* 238 */           addBox(1.5F * f, 3.0F * f, 5.5F * f, 14.5F * f, 31.0F * f, 14.5F * f, world, x, y, z, aabb, list, entity);
/*     */         }
/* 240 */         else if (metadata == 3) {
/*     */           
/* 242 */           addBox(1.5F * f, 3.0F * f, 1.5F * f, 10.5F * f, 31.0F * f, 14.5F * f, world, x, y, z, aabb, list, entity);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 247 */     func_149719_a((IBlockAccess)world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBox(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/* 252 */     func_149676_a(minX, minY, minZ, maxX, maxY, maxZ);
/* 253 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/* 259 */     int metadata = world.func_72805_g(x, y, z);
/*     */     
/* 261 */     if (metadata >= 4)
/*     */     {
/* 263 */       y--;
/*     */     }
/*     */     
/* 266 */     TileEntitySithStoneCoffin tile = (TileEntitySithStoneCoffin)world.func_147438_o(x, y, z);
/* 267 */     boolean flag = false;
/*     */     
/* 269 */     if (tile != null)
/*     */     {
/* 271 */       flag = tile.baseplateOnly;
/*     */     }
/*     */     
/* 274 */     if (metadata >= 4) {
/*     */       
/* 276 */       if (!flag)
/*     */       {
/* 278 */         func_149676_a(0.0F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */       }
/*     */       else
/*     */       {
/* 282 */         func_149676_a(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*     */       }
/*     */     
/* 285 */     } else if (!flag) {
/*     */       
/* 287 */       func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
/*     */     }
/*     */     else {
/*     */       
/* 291 */       func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, 0.1875F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149742_c(World world, int x, int y, int z) {
/* 298 */     return (y < world.func_72800_K() - 1 && super.func_149742_c(world, x, y, z) && super.func_149742_c(world, x, y + 1, z));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149689_a(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemstack) {
/* 304 */     int rotation = MathHelper.func_76128_c((entity.field_70177_z * 4.0F / 360.0F) + 2.5D) & 0x3;
/*     */     
/* 306 */     world.func_72921_c(x, y, z, rotation, 2);
/* 307 */     world.func_147465_d(x, y + 1, z, (Block)this, rotation + 4, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 313 */     return (TileEntity)new TileEntitySithStoneCoffin();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149651_a(IIconRegister iconRegister) {
/* 320 */     this.field_149761_L = iconRegister.func_94245_a("hardened_clay_stained_black");
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockSithStoneCoffin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */