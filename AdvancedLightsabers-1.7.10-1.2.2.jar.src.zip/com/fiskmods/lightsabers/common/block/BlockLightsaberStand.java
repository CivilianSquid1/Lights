/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberStand;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.ChatStyle;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ 
/*     */ 
/*     */ public class BlockLightsaberStand
/*     */   extends BlockContainer
/*     */ {
/*  32 */   private final Random rand = new Random();
/*     */ 
/*     */   
/*     */   public BlockLightsaberStand() {
/*  36 */     super(Material.field_151573_f);
/*  37 */     func_149711_c(1.5F);
/*  38 */     func_149752_b(10.0F);
/*  39 */     setHarvestLevel("pickaxe", 0);
/*  40 */     func_149672_a(field_149777_j);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
/*  46 */     if (!world.field_72995_K) {
/*     */       
/*  48 */       TileEntity tileentity = world.func_147438_o(x, y, z);
/*     */       
/*  50 */       if (tileentity instanceof TileEntityLightsaberStand) {
/*     */         
/*  52 */         TileEntityLightsaberStand tile = (TileEntityLightsaberStand)tileentity;
/*     */         
/*  54 */         if (player.field_71075_bZ.field_75098_d || tile.isOwner((EntityLivingBase)player)) {
/*     */           
/*  56 */           ItemStack stack = tile.getDisplayStack();
/*     */           
/*  58 */           if (tile.setDisplayStack(player.func_70694_bm()))
/*     */           {
/*  60 */             player.func_70062_b(0, stack);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/*  65 */           player.func_145747_a((new ChatComponentTranslation("message.lightsaberStand.notOwner", new Object[0])).func_150255_a((new ChatStyle()).func_150238_a(EnumChatFormatting.RED)));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149749_a(World world, int x, int y, int z, Block block, int metadata) {
/*  76 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/*  78 */     if (tile instanceof TileEntityLightsaberStand) {
/*     */       
/*  80 */       ItemStack itemstack = ((TileEntityLightsaberStand)tile).getDisplayStack();
/*     */       
/*  82 */       if (itemstack != null) {
/*     */         
/*  84 */         float f = this.rand.nextFloat() * 0.8F + 0.1F;
/*  85 */         float f1 = this.rand.nextFloat() * 0.8F + 0.1F;
/*  86 */         float f2 = this.rand.nextFloat() * 0.8F + 0.1F;
/*     */         
/*  88 */         while (itemstack.field_77994_a > 0) {
/*     */           
/*  90 */           int j1 = this.rand.nextInt(21) + 10;
/*     */           
/*  92 */           if (j1 > itemstack.field_77994_a)
/*     */           {
/*  94 */             j1 = itemstack.field_77994_a;
/*     */           }
/*     */           
/*  97 */           itemstack.field_77994_a -= j1;
/*  98 */           EntityItem entityitem = new EntityItem(world, (x + f), (y + f1), (z + f2), new ItemStack(itemstack.func_77973_b(), j1, itemstack.func_77960_j()));
/*     */           
/* 100 */           if (itemstack.func_77942_o())
/*     */           {
/* 102 */             entityitem.func_92059_d().func_77982_d((NBTTagCompound)itemstack.func_77978_p().func_74737_b());
/*     */           }
/*     */           
/* 105 */           float f3 = 0.05F;
/* 106 */           entityitem.field_70159_w = ((float)this.rand.nextGaussian() * f3);
/* 107 */           entityitem.field_70181_x = ((float)this.rand.nextGaussian() * f3 + 0.2F);
/* 108 */           entityitem.field_70179_y = ((float)this.rand.nextGaussian() * f3);
/* 109 */           world.func_72838_d((Entity)entityitem);
/*     */         } 
/*     */       } 
/*     */       
/* 113 */       world.func_147453_f(x, y, z, block);
/*     */     } 
/*     */     
/* 116 */     super.func_149749_a(world, x, y, z, block, metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/* 128 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149707_d(World world, int x, int y, int z, int side) {
/* 140 */     ForgeDirection dir = ForgeDirection.getOrientation(side);
/* 141 */     return (dir != ForgeDirection.DOWN && world.isSideSolid(x - dir.offsetX, y - dir.offsetY, z - dir.offsetZ, dir, true) && super.func_149707_d(world, x, y, z, side));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149718_j(World world, int x, int y, int z) {
/* 147 */     ForgeDirection dir = getDirection(world.func_72805_g(x, y, z));
/* 148 */     return world.isSideSolid(x - dir.offsetX, y - dir.offsetY, z - dir.offsetZ, dir, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149660_a(World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 154 */     if (side == 1)
/*     */     {
/* 156 */       side = 0;
/*     */     }
/*     */     
/* 159 */     return side;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ForgeDirection getDirection(int metadata) {
/* 164 */     if (metadata == 0)
/*     */     {
/* 166 */       metadata = 1;
/*     */     }
/*     */     
/* 169 */     return ForgeDirection.getOrientation(metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149726_b(World world, int x, int y, int z) {
/* 175 */     updatePlacement(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/* 181 */     updatePlacement(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePlacement(World world, int x, int y, int z) {
/* 186 */     if (!func_149718_j(world, x, y, z) && world.func_147439_a(x, y, z) == this) {
/*     */       
/* 188 */       func_149697_b(world, x, y, z, 1, 0);
/* 189 */       world.func_147468_f(x, y, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/* 196 */     func_149719_a((IBlockAccess)world, x, y, z);
/* 197 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/* 204 */     func_149719_a((IBlockAccess)world, x, y, z);
/* 205 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/* 211 */     int metadata = world.func_72805_g(x, y, z);
/* 212 */     float w = 0.171875F;
/* 213 */     float l = 0.328125F;
/* 214 */     float h = 0.8125F;
/*     */     
/* 216 */     if (metadata == 2) {
/*     */       
/* 218 */       func_149676_a(w, l, h, 1.0F - w, 1.0F - l, 1.0F);
/*     */     }
/* 220 */     else if (metadata == 3) {
/*     */       
/* 222 */       func_149676_a(w, l, 0.0F, 1.0F - w, 1.0F - l, 1.0F - h);
/*     */     }
/* 224 */     else if (metadata == 4) {
/*     */       
/* 226 */       func_149676_a(h, l, w, 1.0F, 1.0F - l, 1.0F - w);
/*     */     }
/* 228 */     else if (metadata == 5) {
/*     */       
/* 230 */       func_149676_a(0.0F, l, w, 1.0F - h, 1.0F - l, 1.0F - w);
/*     */     }
/* 232 */     else if ((metadata & 0x1) == 0) {
/*     */       
/* 234 */       func_149676_a(w, 0.0F, l, 1.0F - w, 1.0F - h, 1.0F - l);
/*     */     }
/*     */     else {
/*     */       
/* 238 */       func_149676_a(l, 0.0F, w, 1.0F - l, 1.0F - h, 1.0F - w);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149689_a(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemstack) {
/* 245 */     super.func_149689_a(world, x, y, z, entity, itemstack);
/* 246 */     TileEntity tile = world.func_147438_o(x, y, z);
/* 247 */     int metadata = world.func_72805_g(x, y, z);
/*     */     
/* 249 */     if (metadata == 0) {
/*     */       
/* 251 */       int i = MathHelper.func_76128_c((entity.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x1;
/* 252 */       world.func_72921_c(x, y, z, i, 2);
/*     */     } 
/*     */     
/* 255 */     if (tile instanceof TileEntityLightsaberStand)
/*     */     {
/* 257 */       ((TileEntityLightsaberStand)tile).setOwner(entity);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149651_a(IIconRegister iconRegister) {
/* 265 */     this.field_149761_L = iconRegister.func_94245_a("iron_block");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 271 */     return (TileEntity)new TileEntityLightsaberStand();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockLightsaberStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */