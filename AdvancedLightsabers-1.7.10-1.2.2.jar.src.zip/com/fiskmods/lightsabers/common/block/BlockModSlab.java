/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockSlab;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.Facing;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockModSlab
/*     */   extends BlockSlab
/*     */ {
/*  22 */   public static final String[] field_150006_b = new String[] { "light", "dark" };
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon field_150007_M;
/*     */ 
/*     */   
/*     */   public BlockModSlab(boolean flag) {
/*  29 */     super(flag, Material.field_151576_e);
/*  30 */     this.field_149783_u = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon func_149691_a(int side, int metadata) {
/*  37 */     int k = metadata & 0x7;
/*     */     
/*  39 */     if (this.field_150004_a && (metadata & 0x8) != 0)
/*     */     {
/*  41 */       side = 1;
/*     */     }
/*     */     
/*  44 */     return (k == 0) ? ModBlocks.lightForcestone.func_149733_h(side) : ModBlocks.darkForcestone.func_149733_h(side);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_149650_a(int p_149650_1_, Random p_149650_2_, int p_149650_3_) {
/*  50 */     return Item.func_150898_a((Block)ModBlocks.forcestoneSlab);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ItemStack func_149644_j(int p_149644_1_) {
/*  56 */     return new ItemStack(Item.func_150898_a((Block)ModBlocks.forcestoneSlab), 2, p_149644_1_ & 0x7);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_150002_b(int p_150002_1_) {
/*  62 */     if (p_150002_1_ < 0 || p_150002_1_ >= field_150006_b.length)
/*     */     {
/*  64 */       p_150002_1_ = 0;
/*     */     }
/*     */     
/*  67 */     return func_149739_a() + "." + field_150006_b[p_150002_1_];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149666_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  74 */     if (item != Item.func_150898_a((Block)ModBlocks.forcestoneDoubleSlab))
/*     */     {
/*  76 */       for (int i = 0; i < field_150006_b.length; i++)
/*     */       {
/*  78 */         list.add(new ItemStack(item, 1, i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item func_149694_d(World p_149694_1_, int p_149694_2_, int p_149694_3_, int p_149694_4_) {
/*  87 */     return Item.func_150898_a((Block)ModBlocks.forcestoneSlab);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_149646_a(IBlockAccess p_149646_1_, int p_149646_2_, int p_149646_3_, int p_149646_4_, int p_149646_5_) {
/*  94 */     if (this.field_150004_a)
/*     */     {
/*  96 */       return super.func_149646_a(p_149646_1_, p_149646_2_, p_149646_3_, p_149646_4_, p_149646_5_);
/*     */     }
/*  98 */     if (p_149646_5_ != 1 && p_149646_5_ != 0 && !super.func_149646_a(p_149646_1_, p_149646_2_, p_149646_3_, p_149646_4_, p_149646_5_))
/*     */     {
/* 100 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 104 */     int i1 = p_149646_2_ + Facing.field_71586_b[Facing.field_71588_a[p_149646_5_]];
/* 105 */     int j1 = p_149646_3_ + Facing.field_71587_c[Facing.field_71588_a[p_149646_5_]];
/* 106 */     int k1 = p_149646_4_ + Facing.field_71585_d[Facing.field_71588_a[p_149646_5_]];
/* 107 */     boolean flag = ((p_149646_1_.func_72805_g(i1, j1, k1) & 0x8) != 0);
/* 108 */     return flag ? ((p_149646_5_ == 0) ? true : ((p_149646_5_ == 1 && super.func_149646_a(p_149646_1_, p_149646_2_, p_149646_3_, p_149646_4_, p_149646_5_)) ? true : ((!func_150003_a(p_149646_1_.func_147439_a(p_149646_2_, p_149646_3_, p_149646_4_)) || (p_149646_1_.func_72805_g(p_149646_2_, p_149646_3_, p_149646_4_) & 0x8) == 0)))) : ((p_149646_5_ == 1) ? true : ((p_149646_5_ == 0 && super.func_149646_a(p_149646_1_, p_149646_2_, p_149646_3_, p_149646_4_, p_149646_5_)) ? true : ((!func_150003_a(p_149646_1_.func_147439_a(p_149646_2_, p_149646_3_, p_149646_4_)) || (p_149646_1_.func_72805_g(p_149646_2_, p_149646_3_, p_149646_4_) & 0x8) != 0))));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private static boolean func_150003_a(Block p_150003_0_) {
/* 115 */     return (p_150003_0_ == ModBlocks.forcestoneSlab);
/*     */   }
/*     */   
/*     */   public void func_149651_a(IIconRegister par1IIconRegister) {}
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockModSlab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */