/*     */ package com.fiskmods.lightsabers.common.block;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class BlockDisassemblyStation
/*     */   extends BlockContainer
/*     */ {
/*  29 */   public static final int[][] DIRECTIONS = new int[][] { { -1, 0 }, { 0, -1 }, { 1, 0 }, { 0, 1 } };
/*     */   
/*  31 */   private Random rand = new Random();
/*     */ 
/*     */   
/*     */   public BlockDisassemblyStation() {
/*  35 */     super(Material.field_151573_f);
/*  36 */     func_149711_c(5.0F);
/*  37 */     func_149752_b(10.0F);
/*  38 */     setHarvestLevel("pickaxe", 1);
/*  39 */     func_149672_a(field_149777_j);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149727_a(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
/*  45 */     if (!world.field_72995_K) {
/*     */       
/*  47 */       TileEntity tile = getBase(world, x, y, z);
/*     */       
/*  49 */       if (tile != null)
/*     */       {
/*  51 */         player.openGui(Lightsabers.instance, 4, world, tile.field_145851_c, tile.field_145848_d, tile.field_145849_e);
/*     */       }
/*     */     } 
/*     */     
/*  55 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149695_a(World world, int x, int y, int z, Block block) {
/*  61 */     int metadata = world.func_72805_g(x, y, z);
/*  62 */     int dir = getRotation(metadata);
/*  63 */     Part part = Part.get(metadata);
/*     */     
/*  65 */     if (part == Part.TOP) {
/*     */       
/*  67 */       if (world.func_147439_a(x, y - 1, z) != this)
/*     */       {
/*  69 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     }
/*  72 */     else if (part == Part.SIDE) {
/*     */       
/*  74 */       if (world.func_147439_a(x - DIRECTIONS[dir][0], y, z - DIRECTIONS[dir][1]) != this || world.func_147439_a(x, y + 1, z) != this)
/*     */       {
/*  76 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     }
/*  79 */     else if (world.func_147439_a(x + DIRECTIONS[dir][0], y, z + DIRECTIONS[dir][1]) != this || world.func_147439_a(x, y + 1, z) != this) {
/*     */       
/*  81 */       world.func_147468_f(x, y, z);
/*     */       
/*  83 */       if (!world.field_72995_K)
/*     */       {
/*  85 */         func_149697_b(world, x, y, z, metadata, 0);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_149650_a(int metadata, Random rand, int fortune) {
/*  93 */     return isBasePart(metadata) ? super.func_149650_a(metadata, rand, fortune) : Item.func_150899_d(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149690_a(World world, int x, int y, int z, int metadata, float chance, int fortune) {
/*  99 */     if (isBasePart(metadata))
/*     */     {
/* 101 */       super.func_149690_a(world, x, y, z, metadata, chance, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149681_a(World world, int x, int y, int z, int metadata, EntityPlayer player) {
/*     */     TileEntity tile;
/* 110 */     if (player.field_71075_bZ.field_75098_d && !isBasePart(metadata) && (tile = getBase(world, x, y, z)) != null) {
/*     */       
/* 112 */       x = tile.field_145851_c;
/* 113 */       y = tile.field_145848_d;
/* 114 */       z = tile.field_145849_e;
/*     */       
/* 116 */       if (world.func_147439_a(x, y, z) == this)
/*     */       {
/* 118 */         world.func_147468_f(x, y, z);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149749_a(World world, int x, int y, int z, Block block, int metadata) {
/* 126 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 128 */     if (tile instanceof IInventory) {
/*     */       
/* 130 */       IInventory inventory = (IInventory)tile;
/*     */       
/* 132 */       for (int i = 0; i < inventory.func_70302_i_(); i++) {
/*     */         
/* 134 */         ItemStack stack = inventory.func_70301_a(i);
/*     */         
/* 136 */         if (stack != null)
/*     */         {
/* 138 */           ALHelper.dropItem(world, x, y, z, stack, this.rand);
/*     */         }
/*     */       } 
/*     */       
/* 142 */       world.func_147453_f(x, y, z, block);
/*     */     } 
/*     */     
/* 145 */     super.func_149749_a(world, x, y, z, block, metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149645_b() {
/* 157 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_149633_g(World world, int x, int y, int z) {
/* 170 */     func_149719_a((IBlockAccess)world, x, y, z);
/* 171 */     return super.func_149633_g(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149743_a(World world, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/* 177 */     func_149719_a((IBlockAccess)world, x, y, z);
/* 178 */     super.func_149743_a(world, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149719_a(IBlockAccess world, int x, int y, int z) {
/* 184 */     int metadata = world.func_72805_g(x, y, z);
/* 185 */     Part part = Part.get(metadata);
/* 186 */     float f = 0.0625F;
/*     */     
/* 188 */     if (part == Part.TOP) {
/*     */       
/* 190 */       int dir = getRotation(metadata);
/* 191 */       float width = f * 12.4F;
/* 192 */       float height = f * 13.0F;
/* 193 */       float f1 = f;
/*     */       
/* 195 */       if (isBasePart(world.func_72805_g(x, y - 1, z)))
/*     */       {
/* 197 */         f1 = -f * 2.0F;
/*     */       }
/*     */       
/* 200 */       if (dir == 0)
/*     */       {
/* 202 */         func_149676_a(0.0F, f1, 1.0F - width, 1.0F, height, 1.0F);
/*     */       }
/* 204 */       else if (dir == 1)
/*     */       {
/* 206 */         func_149676_a(0.0F, f1, 0.0F, width, height, 1.0F);
/*     */       }
/* 208 */       else if (dir == 2)
/*     */       {
/* 210 */         func_149676_a(0.0F, f1, 0.0F, 1.0F, height, width);
/*     */       }
/* 212 */       else if (dir == 3)
/*     */       {
/* 214 */         func_149676_a(1.0F - width, f1, 0.0F, 1.0F, height, 1.0F);
/*     */       }
/*     */     
/* 217 */     } else if (part == Part.SIDE) {
/*     */       
/* 219 */       func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, f * 17.0F, 1.0F);
/*     */     }
/*     */     else {
/*     */       
/* 223 */       func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, f * 14.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149656_h() {
/* 230 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149740_M() {
/* 236 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149736_g(World world, int x, int y, int z, int side) {
/* 242 */     return Container.func_94526_b((IInventory)world.func_147438_o(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int metadata) {
/* 248 */     return (TileEntity)new TileEntityDisassemblyStation();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTileEntity(int metadata) {
/* 254 */     return isBasePart(metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149651_a(IIconRegister iconRegister) {
/* 261 */     this.field_149761_L = iconRegister.func_94245_a("iron_block");
/*     */   }
/*     */ 
/*     */   
/*     */   public static int serialize(int rotation, Part part) {
/* 266 */     return part.serialize(rotation & 0x3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getRotation(int metadata) {
/* 271 */     return metadata & 0x3;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBasePart(int metadata) {
/* 276 */     return (Part.get(metadata) == Part.BASE);
/*     */   }
/*     */ 
/*     */   
/*     */   public static TileEntity getBase(World world, int x, int y, int z) {
/* 281 */     int metadata = world.func_72805_g(x, y, z);
/* 282 */     int dir = getRotation(metadata);
/* 283 */     Part part = Part.get(metadata);
/*     */     
/* 285 */     if (part == Part.BASE)
/*     */     {
/* 287 */       return world.func_147438_o(x, y, z);
/*     */     }
/* 289 */     if (part == Part.TOP)
/*     */     {
/* 291 */       return getBase(world, x, y - 1, z);
/*     */     }
/*     */     
/* 294 */     return getBase(world, x - DIRECTIONS[dir][0], y, z - DIRECTIONS[dir][1]);
/*     */   }
/*     */   
/*     */   public enum Part
/*     */   {
/* 299 */     BASE,
/* 300 */     SIDE,
/* 301 */     TOP;
/*     */ 
/*     */     
/*     */     public int serialize(int rotation) {
/* 305 */       return rotation | (ordinal() & 0x3) << 2;
/*     */     }
/*     */ 
/*     */     
/*     */     public static Part get(int metadata) {
/* 310 */       return values()[metadata >> 2 & 0x3];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockDisassemblyStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */