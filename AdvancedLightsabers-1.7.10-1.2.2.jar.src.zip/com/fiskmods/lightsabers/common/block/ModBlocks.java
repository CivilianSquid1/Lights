/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*    */ import com.fiskmods.lightsabers.common.item.ItemDisassemblyTable;
/*    */ import com.fiskmods.lightsabers.common.item.ItemForcestone;
/*    */ import com.fiskmods.lightsabers.common.item.ItemHolocron;
/*    */ import com.fiskmods.lightsabers.common.item.ItemLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.item.ItemSithCoffin;
/*    */ import com.fiskmods.lightsabers.common.item.ItemSithStoneCoffin;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityCrystal;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityHolocron;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberForge;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntityLightsaberStand;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithCoffin;
/*    */ import com.fiskmods.lightsabers.common.tileentity.TileEntitySithStoneCoffin;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockSlab;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemSlab;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModBlocks
/*    */ {
/*    */   public static Block lightsaberCrystal;
/*    */   public static Block lightsaberForgeLight;
/*    */   public static Block lightsaberForgeDark;
/*    */   public static Block lightsaberStand;
/*    */   public static Block disassemblyStation;
/*    */   public static Block sithCoffin;
/*    */   public static Block sithStoneCoffin;
/*    */   public static Block holocron;
/*    */   public static Block lightForcestone;
/*    */   public static Block lightActivatedForcestone;
/*    */   public static Block lightForcestoneStairs;
/*    */   public static Block darkForcestone;
/*    */   public static Block darkActivatedForcestone;
/*    */   public static Block darkForcestoneStairs;
/*    */   public static BlockSlab forcestoneDoubleSlab;
/*    */   public static BlockSlab forcestoneSlab;
/*    */   
/*    */   public static void register() {
/* 47 */     lightsaberCrystal = new BlockCrystal();
/*    */     
/* 49 */     lightsaberStand = (Block)new BlockLightsaberStand();
/* 50 */     disassemblyStation = (Block)new BlockDisassemblyStation();
/* 51 */     sithCoffin = (Block)new BlockSithCoffin();
/* 52 */     sithStoneCoffin = (Block)new BlockSithStoneCoffin();
/* 53 */     holocron = (Block)new BlockHolocron();
/*    */     
/* 55 */     lightForcestone = (new BlockForcestone()).func_149711_c(3.0F).func_149752_b(100.0F);
/* 56 */     lightActivatedForcestone = (new BlockPillar()).func_149715_a(1.0F).func_149711_c(3.0F).func_149752_b(100.0F);
/* 57 */     lightForcestoneStairs = (Block)new BlockModStairs(lightForcestone, 0);
/* 58 */     darkForcestone = (new BlockForcestone()).func_149711_c(3.0F).func_149752_b(100.0F);
/* 59 */     darkActivatedForcestone = (new BlockPillar()).func_149715_a(1.0F).func_149711_c(3.0F).func_149752_b(100.0F);
/* 60 */     darkForcestoneStairs = (Block)new BlockModStairs(darkForcestone, 0);
/* 61 */     forcestoneDoubleSlab = (BlockSlab)(new BlockModSlab(true)).func_149711_c(3.0F).func_149752_b(100.0F);
/* 62 */     forcestoneSlab = (BlockSlab)(new BlockModSlab(false)).func_149711_c(3.0F).func_149752_b(100.0F);
/*    */     
/* 64 */     lightsaberForgeLight = new BlockLightsaberForge(lightForcestone);
/* 65 */     lightsaberForgeDark = new BlockLightsaberForge(darkForcestone);
/*    */ 
/*    */     
/* 68 */     BlockRegistry.registerItemBlockAsTileEntity(lightsaberCrystal, "Lightsaber Crystal", TileEntityCrystal.class, ItemCrystal.class);
/* 69 */     BlockRegistry.registerItemBlockAsTileEntity(lightsaberForgeLight, "Lightsaber Forge Light", TileEntityLightsaberForge.class, ItemLightsaberForge.class);
/* 70 */     BlockRegistry.registerItemBlockAsTileEntity(lightsaberForgeDark, "Lightsaber Forge Dark", TileEntityLightsaberForge.class, ItemLightsaberForge.class);
/* 71 */     BlockRegistry.registerTileEntity(lightsaberStand, "Lightsaber Stand", TileEntityLightsaberStand.class);
/* 72 */     BlockRegistry.registerItemBlockAsTileEntity(disassemblyStation, "Disassembly Station", TileEntityDisassemblyStation.class, ItemDisassemblyTable.class);
/* 73 */     BlockRegistry.registerItemBlockAsTileEntity(sithCoffin, "Sith Coffin", TileEntitySithCoffin.class, ItemSithCoffin.class);
/* 74 */     BlockRegistry.registerItemBlockAsTileEntity(sithStoneCoffin, "Sith Stone Coffin", TileEntitySithStoneCoffin.class, ItemSithStoneCoffin.class);
/* 75 */     BlockRegistry.registerItemBlockAsTileEntity(holocron, "Holocron", TileEntityHolocron.class, ItemHolocron.class);
/*    */     
/* 77 */     BlockRegistry.registerItemBlock(lightForcestone, "Light Forcestone", (ItemBlock)new ItemForcestone(lightForcestone));
/* 78 */     BlockRegistry.registerBlock(lightActivatedForcestone, "Light Activated Forcestone Pillar");
/* 79 */     BlockRegistry.registerBlock(lightForcestoneStairs, "Light Forcestone Stairs");
/* 80 */     BlockRegistry.registerItemBlock(darkForcestone, "Dark Forcestone", (ItemBlock)new ItemForcestone(darkForcestone));
/* 81 */     BlockRegistry.registerBlock(darkActivatedForcestone, "Dark Activated Forcestone Pillar");
/* 82 */     BlockRegistry.registerBlock(darkForcestoneStairs, "Dark Forcestone Stairs");
/* 83 */     BlockRegistry.registerItemBlock((Block)forcestoneDoubleSlab, "Forcestone Double Slab", (ItemBlock)new ItemSlab((Block)forcestoneDoubleSlab, forcestoneSlab, forcestoneDoubleSlab, true));
/* 84 */     BlockRegistry.registerItemBlock((Block)forcestoneSlab, "Forcestone Slab", (ItemBlock)new ItemSlab((Block)forcestoneSlab, forcestoneSlab, forcestoneDoubleSlab, false));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\ModBlocks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */