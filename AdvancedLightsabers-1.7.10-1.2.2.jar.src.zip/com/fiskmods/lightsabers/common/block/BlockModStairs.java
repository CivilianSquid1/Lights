/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockStairs;
/*    */ 
/*    */ public class BlockModStairs
/*    */   extends BlockStairs
/*    */ {
/*    */   public BlockModStairs(Block p_i45428_1_, int p_i45428_2_) {
/* 10 */     super(p_i45428_1_, p_i45428_2_);
/* 11 */     this.field_149783_u = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockModStairs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */