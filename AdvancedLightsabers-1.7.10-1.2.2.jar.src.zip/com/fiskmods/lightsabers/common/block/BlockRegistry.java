/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.fiskmods.lightsabers.common.item.ItemBlockWithMetadata;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import java.util.Iterator;
/*    */ import java.util.Locale;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraftforge.oredict.OreDictionary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockRegistry
/*    */ {
/*    */   public static void registerBlock(Block block, String name) {
/* 19 */     String unlocalizedName = name.toLowerCase(Locale.ROOT).replaceAll(" ", "_").replaceAll("'", "");
/*    */     
/* 21 */     block.func_149663_c(unlocalizedName);
/* 22 */     block.func_149658_d("lightsabers:" + unlocalizedName);
/* 23 */     block.func_149647_a(Lightsabers.CREATIVE_TAB);
/*    */     
/* 25 */     GameRegistry.registerBlock(block, unlocalizedName);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemBlock(Block block, String name, Class clazz) {
/* 30 */     String unlocalizedName = name.toLowerCase(Locale.ROOT).replaceAll(" ", "_").replaceAll("'", "");
/*    */     
/* 32 */     block.func_149663_c(unlocalizedName);
/* 33 */     block.func_149658_d("lightsabers:" + unlocalizedName);
/* 34 */     block.func_149647_a(Lightsabers.CREATIVE_TAB);
/*    */     
/* 36 */     GameRegistry.registerBlock(block, clazz, unlocalizedName);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemBlock(Block block, String name, ItemBlock item) {
/* 41 */     String unlocalizedName = name.toLowerCase(Locale.ROOT).replaceAll(" ", "_").replaceAll("'", "");
/* 42 */     registerItemBlock(block, name, (Class)null);
/*    */     
/* 44 */     Iterator<String> iterator = Block.field_149771_c.func_148742_b().iterator();
/*    */     
/* 46 */     while (iterator.hasNext()) {
/*    */       
/* 48 */       String s = iterator.next();
/* 49 */       Block block1 = (Block)Block.field_149771_c.func_82594_a(s);
/*    */       
/* 51 */       if (block == block1) {
/*    */         
/* 53 */         Item.field_150901_e.func_148756_a(Block.func_149682_b(block), s, item.func_77655_b(unlocalizedName));
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemBlock(Block block, String name) {
/* 61 */     registerItemBlock(block, name, ItemBlockWithMetadata.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerOre(Block block, String name, String oreDictName) {
/* 66 */     registerBlock(block, name);
/* 67 */     OreDictionary.registerOre(oreDictName, block);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerOreAsTileEntity(Block block, String name, String oreDictName, Class clazz) {
/* 72 */     registerOre(block, name, oreDictName);
/* 73 */     GameRegistry.registerTileEntity(clazz, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerTileEntity(Block block, String name, Class clazz) {
/* 78 */     registerBlock(block, name);
/* 79 */     GameRegistry.registerTileEntity(clazz, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemBlockAsTileEntity(Block block, String name, Class clazz, Class clazz1) {
/* 84 */     registerItemBlock(block, name, clazz1);
/* 85 */     GameRegistry.registerTileEntity(clazz, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerItemBlockAsTileEntity(Block block, String name, Class clazz) {
/* 90 */     registerItemBlock(block, name, ItemBlockWithMetadata.class);
/* 91 */     GameRegistry.registerTileEntity(clazz, name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */