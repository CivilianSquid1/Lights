/*    */ package com.fiskmods.lightsabers.common.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockBasic
/*    */   extends Block
/*    */ {
/*    */   public BlockBasic(Material material) {
/* 13 */     super(material);
/*    */   }
/*    */ 
/*    */   
/*    */   public Block setHarvestLvl(String tool, int level) {
/* 18 */     setHarvestLevel(tool, level);
/* 19 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_149651_a(IIconRegister par1IIconRegister) {
/* 25 */     this.field_149761_L = par1IIconRegister.func_94245_a("lightsabers:" + func_149739_a().substring(5));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\block\BlockBasic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */