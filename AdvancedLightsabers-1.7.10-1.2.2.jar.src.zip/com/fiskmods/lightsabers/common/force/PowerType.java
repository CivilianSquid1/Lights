/*   */ package com.fiskmods.lightsabers.common.force;
/*   */ 
/*   */ public enum PowerType
/*   */ {
/* 5 */   PER_USE,
/* 6 */   PER_SECOND,
/* 7 */   PASSIVE;
/*   */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\PowerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */