/*     */ package com.fiskmods.lightsabers.common.force;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import java.util.Locale;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.StatCollector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerDesc
/*     */ {
/*     */   public static String create(String action, Object arg1, Object arg2) {
/*  16 */     String gray = EnumChatFormatting.GRAY.toString();
/*  17 */     String yellow = EnumChatFormatting.YELLOW.toString();
/*  18 */     return gray + I18n.func_135052_a("forcepower.stat." + action, new Object[] { yellow + formatObj(arg1) + gray, yellow + formatObj(arg2) + gray });
/*     */   }
/*     */ 
/*     */   
/*     */   public static String translateFormatted(String key, Object... args) {
/*  23 */     Object[] args1 = new Object[args.length];
/*     */     
/*  25 */     for (int i = 0; i < args.length; i++)
/*     */     {
/*  27 */       args1[i] = formatObj(args[i]);
/*     */     }
/*     */     
/*  30 */     return StatCollector.func_74837_a(key, args1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String format(String key, Object... args) {
/*  35 */     Object[] args1 = new Object[args.length];
/*     */     
/*  37 */     for (int i = 0; i < args.length; i++)
/*     */     {
/*  39 */       args1[i] = formatObj(args[i]);
/*     */     }
/*     */     
/*  42 */     return String.format(key, args1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatObj(Object obj) {
/*  47 */     if (obj instanceof Float || obj instanceof Double)
/*     */     {
/*  49 */       return String.valueOf(ItemStack.field_111284_a.format(obj));
/*     */     }
/*  51 */     if (obj instanceof Effect)
/*     */     {
/*  53 */       return ((Effect)obj).getLocalizedName();
/*     */     }
/*  55 */     if (obj instanceof Target)
/*     */     {
/*  57 */       return ((Target)obj).getLocalizedName();
/*     */     }
/*  59 */     if (obj instanceof Unit)
/*     */     {
/*  61 */       return ((Unit)obj).getLocalizedName();
/*     */     }
/*     */     
/*  64 */     return String.valueOf(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String list(Object... args) {
/*  69 */     String s = "";
/*     */     
/*  71 */     for (int i = 0; i < args.length; i++) {
/*     */       
/*  73 */       if (i > 0)
/*     */       {
/*  75 */         if (i == args.length - 1) {
/*     */           
/*  77 */           s = s + " " + StatCollector.func_74838_a("forcepower.list") + " ";
/*     */         }
/*  79 */         else if (i > 0) {
/*     */           
/*  81 */           s = s + ", ";
/*     */         } 
/*     */       }
/*     */       
/*  85 */       s = s + formatObj(args[i]);
/*     */     } 
/*     */     
/*  88 */     return s;
/*     */   }
/*     */   
/*     */   public enum Unit
/*     */   {
/*  93 */     HEALTH,
/*  94 */     DAMAGE,
/*  95 */     ATTACK_DAMAGE,
/*  96 */     FORCE_DAMAGE,
/*  97 */     ENERGY_DAMAGE,
/*  98 */     ABSORPTION,
/*  99 */     SPEED,
/* 100 */     INVISIBILITY,
/* 101 */     IMPACT_RADIUS,
/* 102 */     KNOCKBACK,
/* 103 */     FALL_RESISTANCE;
/*     */ 
/*     */     
/*     */     public String getUnlocalizedName() {
/* 107 */       return "forcepower.stat.unit." + name().toLowerCase(Locale.ROOT);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocalizedName() {
/* 112 */       return StatCollector.func_74837_a(getUnlocalizedName(), new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Target
/*     */   {
/* 118 */     CASTER,
/* 119 */     TARGET,
/* 120 */     ALLIES,
/* 121 */     ENEMIES,
/* 122 */     MOBS,
/* 123 */     PLAYERS,
/* 124 */     INVISIBLE;
/*     */ 
/*     */     
/*     */     public String getUnlocalizedName() {
/* 128 */       return "forcepower.stat.target." + name().toLowerCase(Locale.ROOT);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocalizedName() {
/* 133 */       return StatCollector.func_74837_a(getUnlocalizedName(), new Object[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\PowerDesc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */