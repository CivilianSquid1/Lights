/*     */ package com.fiskmods.lightsabers.common.force;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffect;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectBladeThrow;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectChoke;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectDrain;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectFortify;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectGaze;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectHeal;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectLightning;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectMeditation;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectPush;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectRebound;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectResist;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectSpeed;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectStealth;
/*     */ import com.fiskmods.lightsabers.common.force.effect.PowerEffectStun;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import fiskfille.utils.helper.NBTHelper;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.event.HoverEvent;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.StatCollector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Power
/*     */   implements Comparable<Power>, NBTHelper.ISerializableObject<Power>
/*     */ {
/*  45 */   public static final List<Power> POWERS = Lists.newArrayList();
/*     */   
/*  47 */   public static final Power FORCE_SENSITIVITY = (new Power("forceSensitivity", 0, 0, null, (new PowerStats(160)).setBaseBonus(2).setForceBonus(50).setRegen(5))).setIconIndex(14, 0);
/*  48 */   public static final Power LIGHT_SIDE = (new Power("lightSide", 2, 0, FORCE_SENSITIVITY)).setIconIndex(13, 1);
/*  49 */   public static final Power DARK_SIDE = (new Power("darkSide", -2, 0, FORCE_SENSITIVITY)).setIconIndex(13, 2);
/*  50 */   public static final Power NEUTRAL = (new Power("neutral", 0, 2, FORCE_SENSITIVITY)).setIconIndex(14, 1);
/*  51 */   public static final Power FORCE_LEVEL1 = (new Power("level1", 0, -2, FORCE_SENSITIVITY, (new PowerStats(160)).setBaseBonus(1).setForceBonus(50).setRegen(10, 1))).setIconIndex(11, 1);
/*  52 */   public static final Power FORCE_LEVEL2 = (new Power("level2", 0, -1, FORCE_LEVEL1, (new PowerStats(247)).setBaseBonus(1).setForceBonus(50).setRegen(15, 1))).setIconIndex(12, 1);
/*  53 */   public static final Power FORCE_LEVEL3 = (new Power("level3", 0, -1, FORCE_LEVEL2, (new PowerStats(394)).setBaseBonus(1).setForceBonus(50).setRegen(15, 1))).setIconIndex(10, 2);
/*  54 */   public static final Power FORCE_LEVEL4 = (new Power("level4", 0, -1, FORCE_LEVEL3, (new PowerStats(679)).setBaseBonus(2).setForceBonus(75).setRegen(25, 1))).setIconIndex(11, 2);
/*  55 */   public static final Power FORCE_LEVEL5 = (new Power("level5", 0, -1, FORCE_LEVEL4, (new PowerStats(1186)).setBaseBonus(2).setForceBonus(100).setRegen(30, 1))).setIconIndex(12, 2);
/*     */   
/*  57 */   public static final Power HEAL1 = (new Power("heal1", 0, -4, LIGHT_SIDE, (new PowerStats(320)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(0, 0).setEffect((PowerEffect)new PowerEffectHeal(4.0F, 0.0F));
/*  58 */   public static final Power HEAL2 = (new Power("heal2", 0, -1, HEAL1, (new PowerStats(966)).setUseCost(125.0F))).setIconIndex(0, 1).setEffect((PowerEffect)new PowerEffectHeal(7.0F, 0.0F));
/*  59 */   public static final Power HEAL3 = (new Power("heal3", 0, -1, HEAL2, (new PowerStats(1440)).setUseCost(175.0F))).setIconIndex(0, 2).setEffect((PowerEffect)new PowerEffectHeal(13.0F, 7.0F));
/*  60 */   public static final Power FORTIFY1 = (new Power("fortify1", 2, -4, LIGHT_SIDE, (new PowerStats(320)).setBaseReq(1).setUseCost(2.5F).setType(PowerType.PER_SECOND))).setIconIndex(1, 0).setEffect((PowerEffect)new PowerEffectFortify(0));
/*  61 */   public static final Power FORTIFY2 = (new Power("fortify2", 0, -1, FORTIFY1, (new PowerStats(788)).setUseCost(2.5F).setType(PowerType.PER_SECOND))).setIconIndex(1, 1).setEffect((PowerEffect)new PowerEffectFortify(1));
/*  62 */   public static final Power FORTIFY3 = (new Power("fortify3", 0, -1, FORTIFY2, (new PowerStats(1100)).setUseCost(2.5F).setType(PowerType.PER_SECOND))).setIconIndex(1, 2).setEffect((PowerEffect)new PowerEffectFortify(2));
/*  63 */   public static final Power STUN1 = (new Power("stun1", 2, 0, LIGHT_SIDE, (new PowerStats(320)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(2, 0).setEffect((PowerEffect)new PowerEffectStun(0, 2.0F, false));
/*  64 */   public static final Power STUN2 = (new Power("stun2", 0, -1, STUN1, (new PowerStats(788)).setUseCost(100.0F))).setIconIndex(2, 1).setEffect((PowerEffect)new PowerEffectStun(1, 3.5F, false));
/*  65 */   public static final Power STUN3 = (new Power("stun3", 0, -1, STUN2, (new PowerStats(1100)).setUseCost(150.0F))).setIconIndex(2, 2).setEffect((PowerEffect)new PowerEffectStun(2, 4.0F, true));
/*     */   
/*  67 */   public static final Power DRAIN1 = (new Power("drain1", 0, -4, DARK_SIDE, (new PowerStats(460)).setBaseReq(1).setUseCost(100.0F))).setIconIndex(3, 0).setEffect((PowerEffect)new PowerEffectDrain(0));
/*  68 */   public static final Power DRAIN2 = (new Power("drain2", 0, -1, DRAIN1, (new PowerStats(1180)).setUseCost(150.0F))).setIconIndex(3, 1).setEffect((PowerEffect)new PowerEffectDrain(1));
/*  69 */   public static final Power DRAIN3 = (new Power("drain3", 0, -1, DRAIN2, (new PowerStats(1670)).setUseCost(200.0F))).setIconIndex(3, 2).setEffect((PowerEffect)new PowerEffectDrain(2));
/*  70 */   public static final Power LIGHTNING1 = (new Power("lightning1", -2, -4, DARK_SIDE, (new PowerStats(320)).setBaseReq(1).setUseCost(5.0F).setType(PowerType.PER_SECOND))).setIconIndex(4, 0).setEffect((PowerEffect)new PowerEffectLightning(0));
/*  71 */   public static final Power LIGHTNING2 = (new Power("lightning2", 0, -1, LIGHTNING1, (new PowerStats(788)).setUseCost(10.0F).setType(PowerType.PER_SECOND))).setIconIndex(4, 1).setEffect((PowerEffect)new PowerEffectLightning(1));
/*  72 */   public static final Power LIGHTNING3 = (new Power("lightning3", 0, -1, LIGHTNING2, (new PowerStats(1277)).setUseCost(20.0F).setType(PowerType.PER_SECOND))).setIconIndex(4, 2).setEffect((PowerEffect)new PowerEffectLightning(2));
/*  73 */   public static final Power WOUND1 = (new Power("wound1", -2, 0, DARK_SIDE, (new PowerStats(320)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(5, 0).setEffect((PowerEffect)new PowerEffectChoke(0));
/*  74 */   public static final Power WOUND2 = (new Power("wound2", 0, -1, WOUND1, (new PowerStats(788)).setUseCost(115.0F))).setIconIndex(5, 1).setEffect((PowerEffect)new PowerEffectChoke(1));
/*  75 */   public static final Power WOUND3 = (new Power("wound3", 0, -1, WOUND2, (new PowerStats(1110)).setUseCost(170.0F))).setIconIndex(5, 2).setEffect((PowerEffect)new PowerEffectChoke(2));
/*     */   
/*  77 */   public static final Power STEALTH = (new Power("stealth", -3, 0, NEUTRAL, (new PowerStats(160)).setBaseReq(1).setUseCost(5.0F).setType(PowerType.PER_SECOND))).setIconIndex(11, 0).setEffect((PowerEffect)new PowerEffectStealth());
/*  78 */   public static final Power SPEED = (new Power("speed", 3, 0, NEUTRAL, (new PowerStats(160)).setBaseReq(1).setUseCost(30.0F))).setIconIndex(12, 0).setEffect((PowerEffect)new PowerEffectSpeed(5.0F, 0));
/*  79 */   public static final Power REBOUND = (new Power("rebound", 3, 1, NEUTRAL, (new PowerStats(320)).setBaseReq(1).setUseCost(3.0F).setType(PowerType.PASSIVE))).setIconIndex(13, 0).setEffect((PowerEffect)new PowerEffectRebound());
/*  80 */   public static final Power SIGHT1 = (new Power("sight1", -2, 2, NEUTRAL, (new PowerStats(160)).setBaseReq(1).setUseCost(25.0F))).setIconIndex(6, 0).setEffect((PowerEffect)new PowerEffectGaze(10.0F, 0));
/*  81 */   public static final Power SIGHT2 = (new Power("sight2", 0, 1, SIGHT1, (new PowerStats(394)).setUseCost(25.0F))).setIconIndex(6, 1).setEffect((PowerEffect)new PowerEffectGaze(15.0F, 1));
/*  82 */   public static final Power SIGHT3 = (new Power("sight3", 0, 1, SIGHT2, (new PowerStats(550)).setUseCost(25.0F))).setIconIndex(6, 2).setEffect((PowerEffect)new PowerEffectGaze(25.0F, 2));
/*  83 */   public static final Power MEDITATION1 = (new Power("meditation1", -1, 2, NEUTRAL, (new PowerStats(320)).setBaseReq(1).setUseCost(75.0F))).setIconIndex(7, 0).setEffect((PowerEffect)new PowerEffectMeditation(0));
/*  84 */   public static final Power MEDITATION2 = (new Power("meditation2", 0, 1, MEDITATION1, (new PowerStats(788)).setUseCost(100.0F))).setIconIndex(7, 1).setEffect((PowerEffect)new PowerEffectMeditation(1));
/*  85 */   public static final Power MEDITATION3 = (new Power("meditation3", 0, 1, MEDITATION2, (new PowerStats(1100)).setUseCost(150.0F))).setIconIndex(7, 2).setEffect((PowerEffect)new PowerEffectMeditation(2));
/*  86 */   public static final Power THROW1 = (new Power("throw1", 0, 2, NEUTRAL, (new PowerStats(160)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(10, 0).setEffect((PowerEffect)new PowerEffectBladeThrow(0));
/*  87 */   public static final Power THROW2 = (new Power("throw2", 0, 1, THROW1, (new PowerStats(394)).setUseCost(50.0F))).setIconIndex(10, 1).setEffect((PowerEffect)new PowerEffectBladeThrow(1));
/*  88 */   public static final Power RESIST1 = (new Power("resist1", 1, 2, NEUTRAL, (new PowerStats(160)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(8, 0).setEffect((PowerEffect)new PowerEffectResist(7.0F, 0));
/*  89 */   public static final Power RESIST2 = (new Power("resist2", 0, 1, RESIST1, (new PowerStats(394)).setUseCost(60.0F))).setIconIndex(8, 1).setEffect((PowerEffect)new PowerEffectResist(9.0F, 1));
/*  90 */   public static final Power RESIST3 = (new Power("resist3", 0, 1, RESIST2, (new PowerStats(550)).setUseCost(70.0F))).setIconIndex(8, 2).setEffect((PowerEffect)new PowerEffectResist(14.0F, 2));
/*  91 */   public static final Power PUSH1 = (new Power("push1", 2, 2, NEUTRAL, (new PowerStats(320)).setBaseReq(1).setUseCost(50.0F))).setIconIndex(9, 0).setEffect((PowerEffect)new PowerEffectPush(0));
/*  92 */   public static final Power PUSH2 = (new Power("push2", 0, 1, PUSH1, (new PowerStats(788)).setUseCost(85.0F))).setIconIndex(9, 1).setEffect((PowerEffect)new PowerEffectPush(1));
/*  93 */   public static final Power PUSH3 = (new Power("push3", 0, 1, PUSH2, (new PowerStats(1100)).setUseCost(120.0F))).setIconIndex(9, 2).setEffect((PowerEffect)new PowerEffectPush(2));
/*     */   
/*     */   private final String name;
/*     */   
/*     */   public final Power parent;
/*  98 */   private ForceSide forceSide = ForceSide.NONE;
/*  99 */   private int iconIndex = -1;
/*     */   
/*     */   private int xOffset;
/*     */   private int yOffset;
/* 103 */   public PowerStats powerStats = new PowerStats(0);
/*     */   
/*     */   public PowerEffect powerEffect;
/* 106 */   public Set<Power> children = new HashSet<>();
/*     */ 
/*     */   
/*     */   public Power(String s, int offsetX, int offsetY, Power power) {
/* 110 */     this.name = s;
/* 111 */     this.parent = power;
/*     */     
/* 113 */     if (this.parent != null) {
/*     */       
/* 115 */       this.parent.children.add(this);
/*     */       
/* 117 */       for (ForceSide side : ForceSide.values()) {
/*     */         
/* 119 */         if (side != ForceSide.NONE && isDescendant(side.getPower())) {
/*     */           
/* 121 */           this.forceSide = side;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 126 */       this.forceSide.powers.add(this);
/* 127 */       this.parent.xOffset += offsetX;
/* 128 */       this.parent.yOffset += offsetY;
/*     */     } 
/*     */     
/* 131 */     POWERS.add(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Power(String s, int offsetX, int offsetY, Power power, PowerStats stats) {
/* 136 */     this(s, offsetX, offsetY, power);
/* 137 */     this.powerStats = stats;
/*     */   }
/*     */ 
/*     */   
/*     */   public Power setIconIndex(int x, int y) {
/* 142 */     this.iconIndex = x + y * 16;
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Power setEffect(PowerEffect effect) {
/* 148 */     this.powerEffect = effect;
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasIcon() {
/* 154 */     return (this.iconIndex >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconX() {
/* 159 */     return this.iconIndex % 16;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconY() {
/* 164 */     return this.iconIndex / 16;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getXOffset() {
/* 169 */     return this.xOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getYOffset() {
/* 174 */     return this.yOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public ForceSide getSide() {
/* 179 */     return this.forceSide;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 184 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName() {
/* 189 */     return "forcepower.name." + this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalizedName() {
/* 194 */     return I18n.func_135052_a(getUnlocalizedName(), new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IChatComponent getFormattedName() {
/* 199 */     ChatComponentTranslation chatComponentTranslation = new ChatComponentTranslation(getUnlocalizedName(), new Object[0]);
/* 200 */     chatComponentTranslation.func_150256_b().func_150238_a(this.forceSide.theme);
/*     */     
/* 202 */     IChatComponent desc = chatComponentTranslation.func_150259_f();
/* 203 */     List<String> list = Lists.newArrayList();
/*     */     
/* 205 */     if (this.powerStats.useCost > 0.0F)
/*     */     {
/* 207 */       desc.func_150258_a("\n" + EnumChatFormatting.GRAY + StatCollector.func_74837_a((this.powerStats.powerType == PowerType.PER_USE) ? "forcepower.perUse" : "forcepower.perSecond", new Object[] { ItemStack.field_111284_a.format(this.powerStats.useCost) }) + "\n");
/*     */     }
/*     */     
/* 210 */     if (this.powerEffect != null)
/*     */     {
/* 212 */       for (String s : this.powerEffect.getDesc())
/*     */       {
/* 214 */         desc.func_150258_a("\n" + EnumChatFormatting.GRAY + s);
/*     */       }
/*     */     }
/*     */     
/* 218 */     chatComponentTranslation.func_150256_b().func_150209_a(new HoverEvent(HoverEvent.Action.SHOW_TEXT, desc));
/*     */     
/* 220 */     return (IChatComponent)chatComponentTranslation;
/*     */   }
/*     */ 
/*     */   
/*     */   public IChatComponent getChatFormattedName() {
/* 225 */     IChatComponent title = getFormattedName().func_150259_f();
/* 226 */     IChatComponent text = (new ChatComponentText("[")).func_150257_a(title).func_150258_a("]");
/* 227 */     text.func_150255_a(title.func_150256_b());
/*     */     
/* 229 */     return text;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getActualXpCost(EntityPlayer player) {
/* 234 */     int cost = this.powerStats.xpCost;
/*     */     
/* 236 */     if (this.forceSide.isPolar())
/*     */     {
/* 238 */       cost = (int)(cost + cost * ALHelper.getCompletion(player, this.forceSide.getOpposite()));
/*     */     }
/*     */     
/* 241 */     return cost;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUsable() {
/* 246 */     return (this.powerEffect != null && this.powerStats.powerType != PowerType.PASSIVE);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getUseCost(EntityPlayer player) {
/* 251 */     return this.powerEffect.getUseCost(player, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSided() {
/* 256 */     return (this.forceSide != ForceSide.NONE && this != this.forceSide.getPower());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDescendant(Power of) {
/* 261 */     return isDescendant(this, of);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDescendant(Power power, Power of) {
/* 266 */     if (power == of)
/*     */     {
/* 268 */       return true;
/*     */     }
/*     */     
/* 271 */     if (power.parent != null)
/*     */     {
/* 273 */       return isDescendant(power.parent, of);
/*     */     }
/*     */     
/* 276 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 282 */     return String.format("Power[\"%s\"]", new Object[] { getName() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Power o) {
/* 288 */     int result = this.forceSide.compareTo(o.forceSide);
/* 289 */     return (result == 0) ? this.name.compareTo(o.name) : result;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 294 */     Effect.FORTIFY.powers.add(FORTIFY1);
/* 295 */     Effect.FORTIFY.powers.add(FORTIFY2);
/* 296 */     Effect.FORTIFY.powers.add(FORTIFY3);
/* 297 */     Effect.STUN.powers.add(STUN1);
/* 298 */     Effect.STUN.powers.add(STUN2);
/* 299 */     Effect.STUN.powers.add(STUN3);
/*     */     
/* 301 */     Effect.DRAIN.powers.add(DRAIN1);
/* 302 */     Effect.DRAIN.powers.add(DRAIN2);
/* 303 */     Effect.DRAIN.powers.add(DRAIN3);
/* 304 */     Effect.LIGHTNING.powers.add(LIGHTNING1);
/* 305 */     Effect.LIGHTNING.powers.add(LIGHTNING2);
/* 306 */     Effect.LIGHTNING.powers.add(LIGHTNING3);
/* 307 */     Effect.CHOKE.powers.add(WOUND1);
/* 308 */     Effect.CHOKE.powers.add(WOUND2);
/* 309 */     Effect.CHOKE.powers.add(WOUND3);
/*     */     
/* 311 */     Effect.STEALTH.powers.add(STEALTH);
/* 312 */     Effect.SPEED.powers.add(SPEED);
/* 313 */     Effect.GAZE.powers.add(SIGHT1);
/* 314 */     Effect.GAZE.powers.add(SIGHT2);
/* 315 */     Effect.GAZE.powers.add(SIGHT3);
/* 316 */     Effect.MEDITATION.powers.add(MEDITATION1);
/* 317 */     Effect.MEDITATION.powers.add(MEDITATION2);
/* 318 */     Effect.MEDITATION.powers.add(MEDITATION3);
/* 319 */     Effect.RESIST.powers.add(RESIST1);
/* 320 */     Effect.RESIST.powers.add(RESIST2);
/* 321 */     Effect.RESIST.powers.add(RESIST3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ALData.DataFactory<List<Power>> factory() {
/* 326 */     return new ALData.DataFactory<List<Power>>()
/*     */       {
/*     */         
/*     */         public List<Power> construct()
/*     */         {
/* 331 */           return Lists.newArrayList((Object[])new Power[3]);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Power getPowerFromName(String s) {
/* 338 */     for (Power power : POWERS) {
/*     */       
/* 340 */       if (power.name.equals(s))
/*     */       {
/* 342 */         return power;
/*     */       }
/*     */     } 
/*     */     
/* 346 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTBase writeToNBT() {
/* 352 */     return (NBTBase)new NBTTagString(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/* 358 */     ByteBufUtils.writeUTF8String(buf, getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Adapter
/*     */     implements NBTHelper.ISaveAdapter<Power>
/*     */   {
/*     */     public Power readFromNBT(NBTBase tag) {
/* 366 */       if (tag instanceof NBTTagString)
/*     */       {
/* 368 */         return Power.getPowerFromName(((NBTTagString)tag).func_150285_a_());
/*     */       }
/*     */       
/* 371 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Power fromBytes(ByteBuf buf) {
/* 377 */       return Power.getPowerFromName(ByteBufUtils.readUTF8String(buf));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\Power.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */