/*     */ package com.fiskmods.lightsabers.common.force;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import fiskfille.utils.helper.NBTHelper;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerData
/*     */   implements Comparable<PowerData>, NBTHelper.ISerializableObject<PowerData>
/*     */ {
/*     */   public final Power power;
/*     */   public int xpInvested;
/*     */   private boolean unlocked;
/*     */   
/*     */   public PowerData(Power p) {
/*  30 */     this.power = p;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnlocked() {
/*  35 */     return this.unlocked;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnlocked(Entity entity, boolean b) {
/*  40 */     if (b != this.unlocked) {
/*     */       
/*  42 */       this.unlocked = b;
/*  43 */       ((Container)ALData.POWERS.get(entity)).markDirty(entity);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  50 */     int hashCode = this.power.hashCode();
/*  51 */     hashCode = hashCode * 31 + (this.unlocked ? 1 : 0);
/*  52 */     hashCode = hashCode * 31 + this.xpInvested;
/*     */     
/*  54 */     return hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  60 */     if (obj instanceof PowerData) {
/*     */       
/*  62 */       PowerData data = (PowerData)obj;
/*     */       
/*  64 */       return (this.power == data.power && this.unlocked == data.unlocked && this.xpInvested == data.xpInvested);
/*     */     } 
/*     */     
/*  67 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  73 */     return String.format("PowerData[\"%s\",x=%s,xp=%s]", new Object[] { this.power.getName(), Boolean.valueOf(this.unlocked), Integer.valueOf(this.xpInvested) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(PowerData o) {
/*  79 */     return (this.unlocked && !o.unlocked) ? 1 : this.power.compareTo(o.power);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTBase writeToNBT() {
/*  85 */     NBTTagCompound nbt = new NBTTagCompound();
/*  86 */     nbt.func_74778_a("Id", this.power.getName());
/*  87 */     nbt.func_74757_a("Unlocked", this.unlocked);
/*  88 */     nbt.func_74768_a("XpInvested", this.xpInvested);
/*     */     
/*  90 */     return (NBTBase)nbt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/*  96 */     ByteBufUtils.writeUTF8String(buf, this.power.getName());
/*  97 */     buf.writeBoolean(this.unlocked);
/*  98 */     buf.writeInt(this.xpInvested);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Adapter
/*     */     implements NBTHelper.ISaveAdapter<PowerData>
/*     */   {
/*     */     public PowerData readFromNBT(NBTBase tag) {
/* 106 */       if (tag instanceof NBTTagCompound) {
/*     */         
/* 108 */         NBTTagCompound nbt = (NBTTagCompound)tag;
/* 109 */         PowerData data = new PowerData(Power.getPowerFromName(nbt.func_74779_i("Id")));
/* 110 */         data.unlocked = nbt.func_74767_n("Unlocked");
/* 111 */         data.xpInvested = nbt.func_74762_e("XpInvested");
/*     */         
/* 113 */         return data;
/*     */       } 
/*     */       
/* 116 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PowerData fromBytes(ByteBuf buf) {
/* 122 */       PowerData data = new PowerData(Power.getPowerFromName(ByteBufUtils.readUTF8String(buf)));
/* 123 */       data.unlocked = buf.readBoolean();
/* 124 */       data.xpInvested = buf.readInt();
/*     */       
/* 126 */       return data;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Container
/*     */     extends HashMap<Power, PowerData>
/*     */     implements NBTHelper.ISerializableObject<Container>, Iterable<PowerData>
/*     */   {
/*     */     private int forceMax;
/*     */     private byte basePower;
/*     */     private float regen;
/*     */     private boolean dirty = true;
/*     */     
/*     */     private Container(Map<? extends Power, ? extends PowerData> map) {
/* 140 */       super(map);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getForceMax() {
/* 149 */       return this.forceMax;
/*     */     }
/*     */ 
/*     */     
/*     */     public byte getBasePower() {
/* 154 */       return this.basePower;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getRegen() {
/* 159 */       return this.regen;
/*     */     }
/*     */ 
/*     */     
/*     */     public void update(Entity entity) {
/* 164 */       if (this.dirty) {
/*     */         
/* 166 */         markDirty(entity);
/* 167 */         this.dirty = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void markDirty(Entity entity) {
/* 173 */       this.forceMax = 0;
/* 174 */       this.basePower = 0;
/* 175 */       this.regen = 0.0F;
/*     */       
/* 177 */       for (PowerData data : this) {
/*     */         
/* 179 */         if (data.unlocked) {
/*     */           
/* 181 */           PowerStats stats = data.power.powerStats;
/*     */           
/* 183 */           if (stats.regenOperation == 0) {
/*     */             
/* 185 */             this.regen += stats.regen;
/*     */           }
/*     */           else {
/*     */             
/* 189 */             this.regen += stats.regen / 100.0F * this.regen;
/*     */           } 
/*     */           
/* 192 */           this.forceMax += stats.forceBonus;
/* 193 */           this.basePower = (byte)(this.basePower + stats.baseBonus);
/* 194 */           this.basePower = (byte)(this.basePower - stats.baseRequirement);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public PowerData add(PowerData value) {
/* 201 */       return put(value.power, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Container validate() {
/* 206 */       for (Power power : Power.POWERS) {
/*     */         
/* 208 */         if (!containsKey(power))
/*     */         {
/* 210 */           add(new PowerData(power));
/*     */         }
/*     */       } 
/*     */       
/* 214 */       this.dirty = true;
/*     */       
/* 216 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<PowerData> iterator() {
/* 222 */       return values().iterator();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public NBTBase writeToNBT() {
/* 228 */       NBTTagList list = new NBTTagList();
/*     */       
/* 230 */       for (PowerData data : this)
/*     */       {
/* 232 */         list.func_74742_a(NBTHelper.writeToNBT(data));
/*     */       }
/*     */       
/* 235 */       return (NBTBase)list;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void toBytes(ByteBuf buf) {
/* 241 */       buf.writeInt(size());
/*     */       
/* 243 */       for (PowerData data : this)
/*     */       {
/* 245 */         NBTHelper.toBytes(buf, data);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public static class Adapter
/*     */       implements NBTHelper.ISaveAdapter<Container>
/*     */     {
/*     */       public PowerData.Container readFromNBT(NBTBase tag) {
/* 254 */         if (tag instanceof NBTTagList) {
/*     */           
/* 256 */           PowerData.Container container = new PowerData.Container(new HashMap<>());
/* 257 */           List<NBTBase> tags = NBTHelper.getTags((NBTTagList)tag);
/*     */           
/* 259 */           for (int i = 0; i < tags.size(); i++) {
/*     */             
/* 261 */             PowerData data = (PowerData)NBTHelper.readFromNBT(tags.get(i), PowerData.class);
/*     */             
/* 263 */             if (data != null)
/*     */             {
/* 265 */               container.add(data);
/*     */             }
/*     */           } 
/*     */           
/* 269 */           return container.validate();
/*     */         } 
/*     */         
/* 272 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public PowerData.Container fromBytes(ByteBuf buf) {
/* 278 */         PowerData.Container container = new PowerData.Container(new HashMap<>());
/* 279 */         int length = buf.readInt();
/*     */         
/* 281 */         for (int i = 0; i < length; i++)
/*     */         {
/* 283 */           container.add((PowerData)NBTHelper.fromBytes(buf, PowerData.class));
/*     */         }
/*     */         
/* 286 */         return container.validate();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public static ALData.DataFactory<Container> factory() {
/* 292 */       return new ALData.DataFactory<Container>()
/*     */         {
/*     */           
/*     */           public PowerData.Container construct()
/*     */           {
/* 297 */             return (new PowerData.Container()).validate();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public boolean canEqual() {
/* 303 */             return false;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     private Container() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\PowerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */