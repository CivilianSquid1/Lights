/*    */ package com.fiskmods.lightsabers.common.force;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerStats
/*    */ {
/*    */   public final int xpCost;
/*    */   public int baseRequirement;
/*    */   public int baseBonus;
/*    */   public int forceBonus;
/*    */   public int regen;
/*    */   public int regenOperation;
/*    */   public float useCost;
/* 14 */   public PowerType powerType = PowerType.PER_USE;
/*    */ 
/*    */   
/*    */   public PowerStats(int cost) {
/* 18 */     this.xpCost = cost;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setBaseReq(int amount) {
/* 23 */     this.baseRequirement = amount;
/* 24 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setBaseBonus(int amount) {
/* 29 */     this.baseBonus = amount;
/* 30 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setForceBonus(int amount) {
/* 35 */     this.forceBonus = amount;
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setRegen(int amount) {
/* 41 */     this.regen = amount;
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setRegen(int amount, int operation) {
/* 47 */     this.regen = amount;
/* 48 */     this.regenOperation = operation;
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setUseCost(float cost) {
/* 54 */     this.useCost = cost;
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PowerStats setType(PowerType type) {
/* 60 */     this.powerType = type;
/* 61 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\PowerStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */