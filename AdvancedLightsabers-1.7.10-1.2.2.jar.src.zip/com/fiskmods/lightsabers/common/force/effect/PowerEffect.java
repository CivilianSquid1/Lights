/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*    */ import com.fiskmods.lightsabers.common.force.ForceSide;
/*    */ import com.fiskmods.lightsabers.common.force.Power;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffect
/*    */ {
/* 14 */   public final Random rand = new Random();
/*    */   
/*    */   public final int amplifier;
/*    */   
/*    */   public PowerEffect(int amplifier) {
/* 19 */     this.amplifier = amplifier;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 24 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getUseCost(EntityPlayer player, Power power) {
/* 29 */     return power.powerStats.useCost;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCastSound(ForceSide side) {
/* 34 */     return (side == ForceSide.DARK) ? ALSounds.player_force_dark : ALSounds.player_force_cast;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getCastSoundVolume(ForceSide side) {
/* 39 */     return 1.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getCastSoundPitch(ForceSide side) {
/* 44 */     return (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 49 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */