/*     */ package com.fiskmods.lightsabers.common.force.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.IEntitySelector;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerEffectStun
/*     */   extends PowerEffect
/*     */ {
/*     */   public final float duration;
/*     */   public final int durationInt;
/*     */   public final boolean aoe;
/*     */   
/*     */   public PowerEffectStun(int amplifier, float duration, boolean aoe) {
/*  32 */     super(amplifier);
/*  33 */     this.duration = duration;
/*  34 */     this.durationInt = (int)duration * 20;
/*  35 */     this.aoe = aoe;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute(EntityPlayer player, Side side) {
/*  41 */     World world = player.field_70170_p;
/*  42 */     double range = 16.0D;
/*     */     
/*  44 */     if (this.aoe) {
/*     */       
/*  46 */       AxisAlignedBB aabb = player.field_70121_D.func_72329_c().func_72314_b(10.0D, 10.0D, 10.0D);
/*  47 */       List<EntityLivingBase> list = player.field_70170_p.func_82733_a(EntityLivingBase.class, aabb, IEntitySelector.field_94557_a);
/*     */       
/*  49 */       for (EntityLivingBase entity : list) {
/*     */         
/*  51 */         if (!ALHelper.isAlly((EntityLivingBase)player, entity))
/*     */         {
/*  53 */           if (entity != player)
/*     */           {
/*  55 */             StatusEffect.add(entity, Effect.STUN, this.durationInt, this.amplifier);
/*     */           }
/*     */         }
/*     */       } 
/*     */       
/*  60 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  64 */     Vec3 src = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, 0.0D);
/*  65 */     Vec3 dest = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, range);
/*  66 */     Vec3 hitVec = null;
/*  67 */     MovingObjectPosition rayTrace = world.func_72933_a(VectorHelper.copy(src), VectorHelper.copy(dest));
/*     */     
/*  69 */     if (rayTrace == null) {
/*     */       
/*  71 */       hitVec = dest;
/*     */     }
/*     */     else {
/*     */       
/*  75 */       hitVec = rayTrace.field_72307_f;
/*     */     } 
/*     */     
/*  78 */     double distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */     double point;
/*  80 */     for (point = 0.0D; point <= distance; point += 0.15D) {
/*     */       
/*  82 */       Vec3 particleVec = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, point);
/*     */       
/*  84 */       for (EntityLivingBase entity : VectorHelper.getEntitiesNear(EntityLivingBase.class, world, particleVec, 0.5D)) {
/*     */         
/*  86 */         if (entity != null && entity != player && player.field_70154_o != entity) {
/*     */           
/*  88 */           hitVec.field_72450_a = entity.field_70165_t;
/*  89 */           hitVec.field_72448_b = entity.field_70163_u;
/*  90 */           hitVec.field_72449_c = entity.field_70161_v;
/*  91 */           rayTrace = new MovingObjectPosition((Entity)entity, hitVec);
/*  92 */           distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     if (rayTrace != null)
/*     */     {
/* 100 */       if (rayTrace.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && rayTrace.field_72308_g instanceof EntityLivingBase) {
/*     */         
/* 102 */         EntityLivingBase entity = (EntityLivingBase)rayTrace.field_72308_g;
/* 103 */         StatusEffect.add(entity, Effect.STUN, this.durationInt, this.amplifier);
/*     */         
/* 105 */         return true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDesc() {
/* 116 */     return new String[] { PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { Effect.STUN, EnumChatFormatting.GRAY, Float.valueOf(this.duration) }), this.aoe ? PowerDesc.Target.ENEMIES : PowerDesc.Target.TARGET) };
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectStun.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */