/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectRebound
/*    */   extends PowerEffect
/*    */ {
/*    */   public PowerEffectRebound() {
/* 11 */     super(0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 17 */     return new String[] { PowerDesc.create("effect2", PowerDesc.Unit.FALL_RESISTANCE, PowerDesc.Target.CASTER) };
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectRebound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */