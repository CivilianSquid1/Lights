/*     */ package com.fiskmods.lightsabers.common.force.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.ALEntityData;
/*     */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerEffectPush
/*     */   extends PowerEffect
/*     */ {
/*     */   public PowerEffectPush(int amplifier) {
/*  23 */     super(amplifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute(EntityPlayer player, Side side) {
/*  29 */     World world = player.field_70170_p;
/*  30 */     double range = 16.0D;
/*     */     
/*  32 */     Vec3 src = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, 0.0D);
/*  33 */     Vec3 dest = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, range);
/*  34 */     Vec3 hitVec = null;
/*  35 */     MovingObjectPosition rayTrace = world.func_72933_a(VectorHelper.copy(src), VectorHelper.copy(dest));
/*     */     
/*  37 */     if (rayTrace == null) {
/*     */       
/*  39 */       hitVec = dest;
/*     */     }
/*     */     else {
/*     */       
/*  43 */       hitVec = rayTrace.field_72307_f;
/*     */     } 
/*     */     
/*  46 */     double distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */     double point;
/*  48 */     for (point = 0.0D; point <= distance; point += 0.15D) {
/*     */       
/*  50 */       Vec3 particleVec = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, point);
/*     */       
/*  52 */       for (EntityLivingBase entity : VectorHelper.getEntitiesNear(EntityLivingBase.class, world, particleVec, 0.5D)) {
/*     */         
/*  54 */         if (entity != null && entity != player && player.field_70154_o != entity) {
/*     */           
/*  56 */           hitVec.field_72450_a = entity.field_70165_t;
/*  57 */           hitVec.field_72448_b = entity.field_70163_u;
/*  58 */           hitVec.field_72449_c = entity.field_70161_v;
/*  59 */           rayTrace = new MovingObjectPosition((Entity)entity, hitVec);
/*  60 */           distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*  66 */     if (rayTrace != null)
/*     */     {
/*  68 */       if (rayTrace.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && rayTrace.field_72308_g instanceof EntityLivingBase) {
/*     */         
/*  70 */         EntityLivingBase entity = (EntityLivingBase)rayTrace.field_72308_g;
/*     */         
/*  72 */         if (!entity.field_70170_p.field_72995_K) {
/*     */           
/*  74 */           entity.func_70097_a(ALDamageSources.causeForceDamage((Entity)player), getDamage(this.amplifier));
/*  75 */           (ALEntityData.getData(entity)).forcePushed = true;
/*     */         } 
/*     */         
/*  78 */         Vec3 vec3 = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, (0.5F * getKnockback(this.amplifier)));
/*  79 */         entity.field_70159_w += vec3.field_72450_a - src.field_72450_a;
/*  80 */         entity.field_70181_x += vec3.field_72448_b - src.field_72448_b;
/*  81 */         entity.field_70179_y += vec3.field_72449_c - src.field_72449_c;
/*  82 */         ALData.FORCE_PUSHING_TIMER.setWithoutNotify((Entity)player, Float.valueOf(1.0F));
/*     */         
/*  84 */         return true;
/*     */       } 
/*     */     }
/*     */     
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDesc() {
/*  94 */     return new String[] {
/*     */         
/*  96 */         PowerDesc.create("effect2", PowerDesc.format("+%s %s", new Object[] { Float.valueOf(getKnockback(this.amplifier)), PowerDesc.Unit.KNOCKBACK }), PowerDesc.Target.TARGET), 
/*  97 */         PowerDesc.create("effect2", PowerDesc.format("%s %s", new Object[] { Float.valueOf(getDamage(this.amplifier)), PowerDesc.Unit.DAMAGE }), PowerDesc.Target.TARGET)
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getKnockback(int amplifier) {
/* 103 */     int i = 1;
/*     */     
/* 105 */     for (int j = 0; j < amplifier; j++)
/*     */     {
/* 107 */       i *= 2;
/*     */     }
/*     */     
/* 110 */     return (3 + i);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getDamage(int amplifier) {
/* 115 */     float f = 1.0F;
/*     */     
/* 117 */     for (int j = 0; j < amplifier; j++)
/*     */     {
/* 119 */       f *= f + 0.5F;
/*     */     }
/*     */     
/* 122 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectPush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */