/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.helper.VectorHelper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectChoke
/*    */   extends PowerEffect
/*    */ {
/*    */   public PowerEffectChoke(int amplifier) {
/* 23 */     super(amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 29 */     World world = player.field_70170_p;
/* 30 */     double range = 16.0D;
/*    */     
/* 32 */     Vec3 src = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, 0.0D);
/* 33 */     Vec3 dest = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, range);
/* 34 */     Vec3 hitVec = null;
/* 35 */     MovingObjectPosition rayTrace = world.func_72933_a(VectorHelper.copy(src), VectorHelper.copy(dest));
/*    */     
/* 37 */     if (rayTrace == null) {
/*    */       
/* 39 */       hitVec = dest;
/*    */     }
/*    */     else {
/*    */       
/* 43 */       hitVec = rayTrace.field_72307_f;
/*    */     } 
/*    */     
/* 46 */     double distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*    */     double point;
/* 48 */     for (point = 0.0D; point <= distance; point += 0.15D) {
/*    */       
/* 50 */       Vec3 particleVec = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, point);
/*    */       
/* 52 */       for (EntityLivingBase entity : VectorHelper.getEntitiesNear(EntityLivingBase.class, world, particleVec, 0.5D)) {
/*    */         
/* 54 */         if (entity != null && entity != player && player.field_70154_o != entity) {
/*    */           
/* 56 */           hitVec.field_72450_a = entity.field_70165_t;
/* 57 */           hitVec.field_72448_b = entity.field_70163_u;
/* 58 */           hitVec.field_72449_c = entity.field_70161_v;
/* 59 */           rayTrace = new MovingObjectPosition((Entity)entity, hitVec);
/* 60 */           distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     } 
/* 66 */     if (rayTrace != null && rayTrace.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && rayTrace.field_72308_g instanceof EntityLivingBase) {
/*    */       
/* 68 */       StatusEffect.add((EntityLivingBase)rayTrace.field_72308_g, (EntityLivingBase)player, Effect.CHOKE, 60, this.amplifier);
/* 69 */       return true;
/*    */     } 
/*    */     
/* 72 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 78 */     return new String[] { PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { Integer.valueOf(2 + this.amplifier * 2), PowerDesc.Unit.DAMAGE, EnumChatFormatting.GRAY + "/" }), PowerDesc.Target.TARGET), PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { Effect.STUN, EnumChatFormatting.GRAY, Float.valueOf(getStunDuration(this.amplifier)) }), PowerDesc.Target.TARGET) };
/*    */   }
/*    */ 
/*    */   
/*    */   public static float getStunDuration(int amplifier) {
/* 83 */     float f = 1.5F;
/*    */     
/* 85 */     if (amplifier > 0)
/*    */     {
/* 87 */       f += 1.0F + (amplifier - 1) * 0.5F;
/*    */     }
/*    */     
/* 90 */     return f;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectChoke.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */