/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*    */ import com.fiskmods.lightsabers.client.sound.MovingSoundStatusEffect;
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.potion.Potion;
/*    */ 
/*    */ 
/*    */ public class PowerEffectStealth
/*    */   extends PowerEffectStatus
/*    */ {
/*    */   public PowerEffectStealth() {
/* 21 */     super(Effect.STEALTH, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 27 */     return new String[] { PowerDesc.create("effect2", PowerDesc.Unit.INVISIBILITY, PowerDesc.Target.CASTER) };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void start(EntityPlayer player, Side side) {
/* 33 */     if (side.isClient() && Lightsabers.proxy.isClientPlayer((EntityLivingBase)player))
/*    */     {
/* 35 */       playSound(player);
/*    */     }
/*    */     
/* 38 */     player.func_82142_c(true);
/*    */     
/* 40 */     if (Lightsabers.proxy.isClientPlayer((EntityLivingBase)player))
/*    */     {
/* 42 */       player.func_85030_a(ALSounds.player_force_stealth_on, 1.0F, 1.0F);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop(EntityPlayer player, Side side) {
/* 49 */     super.stop(player, side);
/*    */     
/* 51 */     if (!player.func_70644_a(Potion.field_76441_p))
/*    */     {
/* 53 */       player.func_82142_c(false);
/*    */     }
/*    */     
/* 56 */     if (Lightsabers.proxy.isClientPlayer((EntityLivingBase)player))
/*    */     {
/* 58 */       player.func_85030_a(ALSounds.player_force_stealth_off, 1.0F, 1.0F);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void playSound(EntityPlayer player) {
/* 65 */     Minecraft.func_71410_x().func_147118_V().func_147682_a((ISound)new MovingSoundStatusEffect((EntityLivingBase)player, Effect.STEALTH, ALSounds.ambient_stealth));
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectStealth.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */