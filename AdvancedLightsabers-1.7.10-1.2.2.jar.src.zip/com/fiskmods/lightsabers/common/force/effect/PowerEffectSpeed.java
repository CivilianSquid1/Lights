/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectSpeed
/*    */   extends PowerEffectInstant
/*    */ {
/*    */   public PowerEffectSpeed(float duration, int amplifier) {
/* 14 */     super(Effect.SPEED, duration, amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 20 */     return new String[] { PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { PowerDesc.translateFormatted("forcepower.stat.multiply", new Object[] { PowerDesc.Unit.SPEED, Integer.valueOf(2) }), EnumChatFormatting.GRAY, Float.valueOf(this.duration) }), PowerDesc.Target.CASTER) };
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectSpeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */