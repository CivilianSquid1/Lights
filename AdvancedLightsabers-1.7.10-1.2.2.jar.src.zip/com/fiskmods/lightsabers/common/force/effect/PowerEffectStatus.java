/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.ALData;
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PowerEffectStatus
/*    */   extends PowerEffectActive {
/*    */   public final Effect effect;
/*    */   
/*    */   public PowerEffectStatus(Effect effect, int amplifier) {
/* 16 */     super(amplifier);
/* 17 */     this.effect = effect;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 23 */     float force = ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue();
/*    */     
/* 25 */     if (this.effect.getPower(this.amplifier) != null)
/*    */     {
/* 27 */       StatusEffect.add((EntityLivingBase)player, this.effect, (int)(force / this.effect.getPower(this.amplifier).getUseCost(player) / 20.0F), this.amplifier);
/*    */     }
/*    */     
/* 30 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop(EntityPlayer player, Side side) {
/* 36 */     super.stop(player, side);
/* 37 */     StatusEffect.clear((EntityLivingBase)player, this.effect);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */