/*     */ package com.fiskmods.lightsabers.common.force.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.client.particle.ALParticleType;
/*     */ import com.fiskmods.lightsabers.client.particle.ALParticles;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.force.ForceSide;
/*     */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.IEntitySelector;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerEffectHeal
/*     */   extends PowerEffect
/*     */ {
/*     */   public final float heal;
/*     */   public final float aoeHeal;
/*     */   
/*     */   public PowerEffectHeal(float heal, float aoeHeal) {
/*  29 */     super(0);
/*  30 */     this.heal = heal;
/*  31 */     this.aoeHeal = aoeHeal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute(EntityPlayer player, Side side) {
/*  37 */     player.func_70691_i(this.amplifier);
/*     */     
/*  39 */     if (this.aoeHeal > 0.0F) {
/*     */       
/*  41 */       AxisAlignedBB aabb = player.field_70121_D.func_72329_c().func_72314_b(6.0D, 6.0D, 6.0D);
/*  42 */       List<EntityLivingBase> list = player.field_70170_p.func_82733_a(EntityLivingBase.class, aabb, IEntitySelector.field_94557_a);
/*     */       
/*  44 */       for (EntityLivingBase entity : list)
/*     */       {
/*  46 */         if (ALHelper.isAlly((EntityLivingBase)player, entity) || entity == player)
/*     */         {
/*  48 */           if (entity != player)
/*     */           {
/*  50 */             entity.func_70691_i(this.aoeHeal);
/*     */           }
/*     */           
/*  53 */           if (side.isClient())
/*     */           {
/*  55 */             doParticles(entity);
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  62 */     else if (side.isClient()) {
/*     */       
/*  64 */       doParticles((EntityLivingBase)player);
/*     */     } 
/*     */ 
/*     */     
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDesc() {
/*  74 */     List<String> list = Lists.newArrayList();
/*  75 */     list.add(PowerDesc.create("to", PowerDesc.format("+%s %s", new Object[] { Float.valueOf(this.heal), PowerDesc.Unit.HEALTH }), PowerDesc.Target.CASTER));
/*     */     
/*  77 */     if (this.aoeHeal > 0.0F)
/*     */     {
/*  79 */       list.add(PowerDesc.create("to", PowerDesc.format("+%s %s", new Object[] { Float.valueOf(this.aoeHeal), PowerDesc.Unit.HEALTH }), PowerDesc.Target.ALLIES));
/*     */     }
/*     */     
/*  82 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCastSound(ForceSide side) {
/*  88 */     return ALSounds.player_force_heal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getCastSoundPitch(ForceSide side) {
/*  94 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void doParticles(EntityLivingBase entity) {
/* 100 */     for (int i = 0; i < 16; i++)
/*     */     {
/* 102 */       ALParticles.spawnParticle(ALParticleType.FORCE_HEAL, entity.field_70165_t + ((this.rand.nextFloat() * 2.0F - 1.0F) * entity.field_70130_N), entity.field_70121_D.field_72338_b + (entity.field_70131_O / 3.0F) + (entity.field_70131_O / 3.0F * 2.0F * this.rand.nextFloat()), entity.field_70161_v + ((this.rand.nextFloat() * 2.0F - 1.0F) * entity.field_70130_N), 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectHeal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */