/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.sound.MovingSoundLightning;
/*    */ import com.fiskmods.lightsabers.common.damage.ALDamageSources;
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import com.fiskmods.lightsabers.helper.ALHelper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class PowerEffectLightning
/*    */   extends PowerEffectStatus
/*    */ {
/*    */   public PowerEffectLightning(int amplifier) {
/* 23 */     super(Effect.LIGHTNING, amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 29 */     return new String[] { PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { Integer.valueOf(4 + this.amplifier * 2), PowerDesc.Unit.DAMAGE, EnumChatFormatting.GRAY + "/" }), PowerDesc.Target.TARGET) };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void start(EntityPlayer player, Side side) {
/* 35 */     if (side.isClient())
/*    */     {
/* 37 */       playSound(player);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void playSound(EntityPlayer player) {
/* 44 */     Minecraft.func_71410_x().func_147118_V().func_147682_a((ISound)new MovingSoundLightning((EntityLivingBase)player));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 50 */     World world = player.field_70170_p;
/* 51 */     boolean flag = super.execute(player, side);
/*    */     
/* 53 */     if (flag) {
/*    */       
/* 55 */       EntityLivingBase entity = ALHelper.getForceLightningTarget((EntityLivingBase)player);
/*    */       
/* 57 */       if (entity != null) {
/*    */         
/* 59 */         entity.func_70097_a(ALDamageSources.causeForceLightningDamage((Entity)player), (4 + this.amplifier * 2));
/* 60 */         entity.field_70159_w = 0.0D;
/* 61 */         entity.field_70181_x = Math.min(entity.field_70181_x, 0.0D);
/* 62 */         entity.field_70179_y = 0.0D;
/*    */       } 
/*    */     } 
/*    */     
/* 66 */     return flag;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectLightning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */