/*     */ package com.fiskmods.lightsabers.common.force.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.client.sound.MovingSoundStatusEffect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class PowerEffectFortify
/*     */   extends PowerEffectStatus
/*     */ {
/*     */   public PowerEffectFortify(int amplifier) {
/*  26 */     super(Effect.FORTIFY, amplifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDesc() {
/*  32 */     return new String[] { PowerDesc.create("divide", PowerDesc.Unit.FORCE_DAMAGE, Float.valueOf(getModifierAmount(this.amplifier))) };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(EntityPlayer player, Side side) {
/*  38 */     if (side.isClient() && Lightsabers.proxy.isClientPlayer((EntityLivingBase)player))
/*     */     {
/*  40 */       playSound(player);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void playSound(EntityPlayer player) {
/*  47 */     Minecraft.func_71410_x().func_147118_V().func_147682_a((ISound)new MovingSoundStatusEffect((EntityLivingBase)player, Effect.FORTIFY, ALSounds.ambient_fortify));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void render(EntityPlayer player, float partialTicks) {
/*  54 */     Minecraft.func_71410_x().func_110434_K().func_110577_a(new ResourceLocation("lightsabers", "textures/misc/force_shield.png"));
/*     */     
/*  56 */     GL11.glPushMatrix();
/*  57 */     Tessellator tessellator = Tessellator.field_78398_a;
/*  58 */     boolean prevLighting = GL11.glGetBoolean(2896);
/*  59 */     float prevWidth = GL11.glGetFloat(2849);
/*     */     
/*  61 */     ALRenderHelper.setLighting(61680);
/*  62 */     GL11.glLineWidth(5.0F);
/*  63 */     GL11.glDepthMask(false);
/*  64 */     GL11.glDisable(2896);
/*  65 */     GL11.glEnable(3042);
/*  66 */     GL11.glAlphaFunc(516, 0.99F);
/*  67 */     GL11.glDisable(3008);
/*  68 */     GL11.glBlendFunc(770, 32772);
/*     */     
/*  70 */     float f = 0.25F * this.amplifier;
/*  71 */     float f1 = player.field_70173_aa + partialTicks;
/*  72 */     float range = Math.max(player.field_70130_N, player.field_70131_O) * 0.75F;
/*  73 */     float angleIncr = 1.0F;
/*  74 */     float coverage = 45.0F;
/*  75 */     int amount = 360;
/*  76 */     float spread = 360.0F / amount;
/*     */     
/*  78 */     GL11.glTranslatef(0.0F, 0.0F, -range * 0.75F + range * MathHelper.func_76134_b(f1 / 10.0F) * 0.05F);
/*  79 */     GL11.glRotatef(MathHelper.func_76126_a(f1 / 10.0F) * 5.0F, 1.0F, 0.0F, 0.0F);
/*  80 */     GL11.glRotatef(MathHelper.func_76126_a(f1 / 10.0F + 10.0F) * 5.0F, 0.0F, 1.0F, 0.0F);
/*  81 */     GL11.glRotatef(MathHelper.func_76126_a(f1 / 10.0F + 20.0F) * 5.0F, 0.0F, 0.0F, 1.0F);
/*  82 */     GL11.glTranslatef(0.0F, 0.0F, range);
/*     */     
/*  84 */     for (int i = 0; i < amount; i++) {
/*     */       
/*  86 */       GL11.glPushMatrix();
/*  87 */       tessellator.func_78371_b(3);
/*  88 */       tessellator.func_78370_a(54 + (int)(146.0F * f), 84 + (int)(-84.0F * f), 181 + (int)(19.0F * f), 50);
/*     */       
/*  90 */       for (int j = 0; j < coverage / angleIncr; j++) {
/*     */         
/*  92 */         Vec3 vec3 = Vec3.func_72443_a(0.0D, range, 0.0D);
/*  93 */         float pitch = 90.0F + j * angleIncr;
/*  94 */         float yaw = 180.0F;
/*  95 */         float roll = i * spread;
/*  96 */         vec3.func_72440_a(-pitch * 3.1415927F / 180.0F);
/*  97 */         vec3.func_72442_b(-yaw * 3.1415927F / 180.0F);
/*  98 */         vec3.func_72446_c(-roll * 3.1415927F / 180.0F);
/*  99 */         tessellator.func_78374_a(vec3.field_72450_a, vec3.field_72448_b, vec3.field_72449_c, 0.0D, (j / coverage / angleIncr));
/*     */       } 
/*     */       
/* 102 */       tessellator.func_78381_a();
/* 103 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 106 */     GL11.glLineWidth(prevWidth);
/* 107 */     GL11.glDisable(3042);
/* 108 */     GL11.glAlphaFunc(516, 0.1F);
/* 109 */     GL11.glEnable(3008);
/* 110 */     GL11.glBlendFunc(770, 771);
/* 111 */     GL11.glDepthMask(true);
/*     */     
/* 113 */     if (prevLighting)
/*     */     {
/* 115 */       GL11.glEnable(2896);
/*     */     }
/*     */     
/* 118 */     ALRenderHelper.resetLighting();
/* 119 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getModifierAmount(int amplifier) {
/* 124 */     float f = 0.25F;
/*     */     
/* 126 */     for (int i = 0; i < amplifier; i++)
/*     */     {
/* 128 */       f *= 2.0F;
/*     */     }
/*     */     
/* 131 */     return 1.0F + f;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectFortify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */