/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectMeditation
/*    */   extends PowerEffectInstant
/*    */ {
/*    */   public PowerEffectMeditation(int amplifier) {
/* 25 */     super(Effect.MEDITATION, 90.0F, amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 31 */     player.func_110149_m(getAbsorption(this.amplifier));
/* 32 */     return super.execute(player, side);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 38 */     return new String[] {
/*    */         
/* 40 */         PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { PowerDesc.translateFormatted("forcepower.stat.multiply", new Object[] { PowerDesc.Unit.ATTACK_DAMAGE, Float.valueOf(getModifierAmount(this.amplifier)) }), EnumChatFormatting.GRAY, Integer.valueOf(90) }), PowerDesc.Target.CASTER), 
/* 41 */         PowerDesc.create("to", PowerDesc.format("+%s %s", new Object[] { Float.valueOf(getAbsorption(this.amplifier)), PowerDesc.Unit.ABSORPTION }), PowerDesc.Target.CASTER)
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public static float getModifierAmount(int amplifier) {
/* 47 */     float f = 0.25F;
/*    */     
/* 49 */     for (int i = 0; i < amplifier; i++)
/*    */     {
/* 51 */       f *= 2.0F;
/*    */     }
/*    */     
/* 54 */     return 1.0F + f;
/*    */   }
/*    */ 
/*    */   
/*    */   public static float getAbsorption(int amplifier) {
/* 59 */     return (4 + amplifier * 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectMeditation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */