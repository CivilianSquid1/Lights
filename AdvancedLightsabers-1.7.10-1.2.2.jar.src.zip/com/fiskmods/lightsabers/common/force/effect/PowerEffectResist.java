/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectResist
/*    */   extends PowerEffectInstant
/*    */ {
/*    */   public PowerEffectResist(float duration, int amplifier) {
/* 14 */     super(Effect.RESIST, duration, amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 20 */     return new String[] { PowerDesc.create("effect", PowerDesc.format("%s %s%s", new Object[] { PowerDesc.translateFormatted("forcepower.stat.divide", new Object[] { PowerDesc.Unit.ENERGY_DAMAGE, Float.valueOf(getModifierAmount(this.amplifier)) }), EnumChatFormatting.GRAY, Float.valueOf(this.duration) }), PowerDesc.Target.CASTER) };
/*    */   }
/*    */ 
/*    */   
/*    */   public static float getModifierAmount(int amplifier) {
/* 25 */     float f = 0.25F;
/*    */     
/* 27 */     for (int i = 0; i < amplifier; i++)
/*    */     {
/* 29 */       f *= 2.0F;
/*    */     }
/*    */     
/* 32 */     return 1.0F + f;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectResist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */