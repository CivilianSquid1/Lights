/*     */ package com.fiskmods.lightsabers.common.force.effect;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*     */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*     */ import com.fiskmods.lightsabers.common.force.Power;
/*     */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*     */ import com.fiskmods.lightsabers.helper.ALHelper;
/*     */ import com.google.common.collect.Lists;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fiskfille.utils.helper.VectorHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.IEntitySelector;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerEffectDrain
/*     */   extends PowerEffect
/*     */ {
/*     */   public PowerEffectDrain(int amplifier) {
/*  30 */     super(amplifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute(EntityPlayer player, Side side) {
/*  36 */     World world = player.field_70170_p;
/*  37 */     List<EntityLivingBase> list = getTargets(player);
/*     */     
/*  39 */     for (EntityLivingBase entity : list)
/*     */     {
/*  41 */       StatusEffect.add(entity, (EntityLivingBase)player, Effect.DRAIN, 30, this.amplifier);
/*     */     }
/*     */     
/*  44 */     if (list.size() > 0) {
/*     */       
/*  46 */       ALData.DRAIN_LIFE_TIMER.setWithoutNotify((Entity)player, Float.valueOf(1.0F));
/*  47 */       return true;
/*     */     } 
/*     */     
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDesc() {
/*  56 */     return new String[] { PowerDesc.create("absorb", PowerDesc.format("%s %s", new Object[] { Integer.valueOf(4 + this.amplifier * 2), PowerDesc.Unit.HEALTH }), (this.amplifier < 2) ? PowerDesc.Target.TARGET : PowerDesc.Target.ENEMIES) };
/*     */   }
/*     */ 
/*     */   
/*     */   public List<EntityLivingBase> getTargets(EntityPlayer player) {
/*  61 */     List<EntityLivingBase> list = Lists.newArrayList();
/*  62 */     World world = player.field_70170_p;
/*  63 */     double range = (this.amplifier < 2) ? 5.0D : 7.0D;
/*     */     
/*  65 */     if (this.amplifier < 2) {
/*     */       
/*  67 */       Vec3 src = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, 0.0D);
/*  68 */       Vec3 dest = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, range);
/*  69 */       Vec3 hitVec = null;
/*  70 */       MovingObjectPosition rayTrace = world.func_72933_a(VectorHelper.copy(src), VectorHelper.copy(dest));
/*     */       
/*  72 */       if (rayTrace == null) {
/*     */         
/*  74 */         hitVec = dest;
/*     */       }
/*     */       else {
/*     */         
/*  78 */         hitVec = rayTrace.field_72307_f;
/*     */       } 
/*     */       
/*  81 */       double distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */       double point;
/*  83 */       for (point = 0.0D; point <= distance; point += 0.15D) {
/*     */         
/*  85 */         Vec3 particleVec = VectorHelper.getOffsetCoords((EntityLivingBase)player, 0.0D, 0.0D, point);
/*     */         
/*  87 */         for (EntityLivingBase entity : VectorHelper.getEntitiesNear(EntityLivingBase.class, world, particleVec, 0.5D)) {
/*     */           
/*  89 */           if (entity != null && entity != player && player.field_70154_o != entity) {
/*     */             
/*  91 */             hitVec.field_72450_a = entity.field_70165_t;
/*  92 */             hitVec.field_72448_b = entity.field_70163_u;
/*  93 */             hitVec.field_72449_c = entity.field_70161_v;
/*  94 */             rayTrace = new MovingObjectPosition((Entity)entity, hitVec);
/*  95 */             distance = player.func_70011_f(hitVec.field_72450_a, hitVec.field_72448_b, hitVec.field_72449_c);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 101 */       if (rayTrace != null)
/*     */       {
/* 103 */         if (rayTrace.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && rayTrace.field_72308_g instanceof EntityLivingBase)
/*     */         {
/* 105 */           EntityLivingBase entity = (EntityLivingBase)rayTrace.field_72308_g;
/* 106 */           list.add(entity);
/*     */         }
/*     */       
/*     */       }
/*     */     } else {
/*     */       
/* 112 */       AxisAlignedBB aabb = player.field_70121_D.func_72329_c().func_72314_b(range, range, range);
/* 113 */       List<EntityLivingBase> list1 = world.func_82733_a(EntityLivingBase.class, aabb, IEntitySelector.field_94557_a);
/*     */       
/* 115 */       float force = ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue() + 15.0F;
/* 116 */       float cost = super.getUseCost(player, Effect.DRAIN.getPower(this.amplifier));
/*     */       
/* 118 */       for (EntityLivingBase entity : list1) {
/*     */         
/* 120 */         if (!ALHelper.isAlly((EntityLivingBase)player, entity) && entity != player) {
/*     */           
/* 122 */           if (force >= cost + (list.size() * 15) + 15.0F) {
/*     */             
/* 124 */             list.add(entity);
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getUseCost(EntityPlayer player, Power power) {
/* 140 */     float cost = super.getUseCost(player, power);
/*     */     
/* 142 */     if (this.amplifier >= 2) {
/*     */       
/* 144 */       float force = ((Float)ALData.FORCE_POWER.get((Entity)player)).floatValue();
/*     */       
/* 146 */       if (force >= cost)
/*     */       {
/* 148 */         cost += ((getTargets(player).size() - 1) * 15);
/*     */       }
/*     */     } 
/*     */     
/* 152 */     return cost;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectDrain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */