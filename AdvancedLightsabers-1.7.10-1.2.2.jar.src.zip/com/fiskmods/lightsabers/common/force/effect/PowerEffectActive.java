/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PowerEffectActive
/*    */   extends PowerEffect
/*    */ {
/*    */   public PowerEffectActive(int amplifier) {
/* 11 */     super(amplifier);
/*    */   }
/*    */   
/*    */   public void start(EntityPlayer player, Side side) {}
/*    */   
/*    */   public void stop(EntityPlayer player, Side side) {}
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void render(EntityPlayer player, float partialTicks) {}
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectActive.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */