/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PowerEffectGaze
/*    */   extends PowerEffectInstant
/*    */ {
/*    */   public PowerEffectGaze(float duration, int amplifier) {
/* 13 */     super(Effect.GAZE, duration, amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 19 */     Object[][] args = { { PowerDesc.Target.MOBS }, { PowerDesc.Target.MOBS, PowerDesc.Target.PLAYERS }, { PowerDesc.Target.MOBS, PowerDesc.Target.PLAYERS, PowerDesc.Target.INVISIBLE } };
/*    */     
/* 21 */     return new String[] { PowerDesc.create("highlight", PowerDesc.list(args[this.amplifier]), PowerDesc.format("%s%s", new Object[] { EnumChatFormatting.GRAY, Float.valueOf(this.duration) })) };
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectGaze.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */