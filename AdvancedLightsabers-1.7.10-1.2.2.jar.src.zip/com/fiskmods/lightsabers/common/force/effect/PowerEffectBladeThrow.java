/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*    */ import com.fiskmods.lightsabers.common.force.ForceSide;
/*    */ import com.fiskmods.lightsabers.common.force.PowerDesc;
/*    */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ public class PowerEffectBladeThrow
/*    */   extends PowerEffect
/*    */ {
/*    */   public PowerEffectBladeThrow(int amplifier) {
/* 18 */     super(amplifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 24 */     ItemStack heldItem = player.func_70694_bm();
/*    */     
/* 26 */     if (heldItem != null && heldItem.func_77973_b() instanceof ItemLightsaberBase && ItemLightsaberBase.isActive(heldItem)) {
/*    */       
/* 28 */       if (side.isServer()) {
/*    */         
/* 30 */         ItemLightsaberBase.throwLightsaber((EntityLivingBase)player, heldItem, this.amplifier);
/* 31 */         player.func_71038_i();
/*    */       } 
/*    */       
/* 34 */       return true;
/*    */     } 
/*    */     
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getDesc() {
/* 43 */     (new String[2][])[0] = new String[0]; (new String[1])[0] = PowerDesc.create("multiply", PowerDesc.Unit.IMPACT_RADIUS, PowerDesc.format("%s%s", new Object[] { EnumChatFormatting.GRAY, Integer.valueOf(2) })); (new String[2][])[1] = new String[1]; return (new String[2][])[this.amplifier];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCastSound(ForceSide side) {
/* 49 */     return ALSounds.player_lightsaber_swing;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public float getCastSoundPitch(ForceSide side) {
/* 55 */     return 1.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectBladeThrow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */