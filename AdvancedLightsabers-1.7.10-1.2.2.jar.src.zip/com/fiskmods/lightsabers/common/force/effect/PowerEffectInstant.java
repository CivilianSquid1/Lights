/*    */ package com.fiskmods.lightsabers.common.force.effect;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.data.effect.Effect;
/*    */ import com.fiskmods.lightsabers.common.data.effect.StatusEffect;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PowerEffectInstant
/*    */   extends PowerEffect
/*    */ {
/*    */   public final Effect effect;
/*    */   public final float duration;
/*    */   public final int durationInt;
/*    */   
/*    */   public PowerEffectInstant(Effect effect, float duration, int amplifier) {
/* 17 */     super(amplifier);
/* 18 */     this.effect = effect;
/* 19 */     this.duration = duration;
/* 20 */     this.durationInt = (int)(duration * 20.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean execute(EntityPlayer player, Side side) {
/* 26 */     StatusEffect.add((EntityLivingBase)player, this.effect, this.durationInt, this.amplifier);
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\effect\PowerEffectInstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */