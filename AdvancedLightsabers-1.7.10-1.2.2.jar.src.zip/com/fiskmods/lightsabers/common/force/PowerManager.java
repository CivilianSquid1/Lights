/*     */ package com.fiskmods.lightsabers.common.force;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PowerManager
/*     */ {
/*     */   private final EntityPlayer thePlayer;
/*     */   
/*     */   public PowerManager(EntityPlayer player) {
/*  15 */     this.thePlayer = player;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHierarchy(Power power) {
/*  20 */     if (hasPowerUnlocked(power))
/*     */     {
/*  22 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*  26 */     int i = 0;
/*     */     
/*  28 */     for (Power parent = power.parent; parent != null && !hasPowerUnlocked(parent); i++)
/*     */     {
/*  30 */       parent = parent.parent;
/*     */     }
/*     */     
/*  33 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPowerUnlocked(Power power) {
/*  39 */     return hasPowerUnlocked(this.thePlayer, power);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUnlockPower(Power power) {
/*  44 */     return canUnlockPower(this.thePlayer, power);
/*     */   }
/*     */ 
/*     */   
/*     */   public PowerData getPowerData(Power power) {
/*  49 */     return getPowerData(this.thePlayer, power);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean unlockPower(EntityPlayer player, Power power) {
/*  54 */     if (!hasPowerUnlocked(player, power)) {
/*     */       
/*  56 */       PowerData data = getPowerData(player, power);
/*     */       
/*  58 */       if (data != null) {
/*     */         
/*  60 */         data.setUnlocked((Entity)player, true);
/*  61 */         data.xpInvested = power.getActualXpCost(player);
/*     */         
/*  63 */         ALData.BASE_POWER.incrWithoutNotify((Entity)player, Byte.valueOf((byte)(power.powerStats.baseBonus - power.powerStats.baseRequirement)));
/*     */         
/*  65 */         if (power == Power.FORCE_SENSITIVITY)
/*     */         {
/*  67 */           for (ForceSide side : ForceSide.values())
/*     */           {
/*  69 */             unlockPower(player, side.getPower());
/*     */           }
/*     */         }
/*     */         
/*  73 */         unlockPower(player, power.parent);
/*     */         
/*  75 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean removePower(EntityPlayer player, Power power) {
/*  84 */     if (hasPowerUnlocked(player, power)) {
/*     */       
/*  86 */       PowerData data = getPowerData(player, power);
/*     */       
/*  88 */       if (data != null) {
/*     */         
/*  90 */         data.setUnlocked((Entity)player, false);
/*  91 */         data.xpInvested = 0;
/*     */         
/*  93 */         ALData.BASE_POWER.incrWithoutNotify((Entity)player, Byte.valueOf((byte)(power.powerStats.baseRequirement - power.powerStats.baseBonus)));
/*     */         
/*  95 */         for (Power child : power.children)
/*     */         {
/*  97 */           removePower(player, child);
/*     */         }
/*     */         
/* 100 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean hasPowerUnlocked(EntityPlayer player, Power power) {
/* 109 */     PowerData data = getPowerData(player, power);
/* 110 */     return (data != null && data.isUnlocked());
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canUnlockPower(EntityPlayer player, Power power) {
/* 115 */     return (power.parent == null || hasPowerUnlocked(player, power.parent));
/*     */   }
/*     */ 
/*     */   
/*     */   public static PowerData getPowerData(EntityPlayer player, Power power) {
/* 120 */     return ((PowerData.Container)ALData.POWERS.get((Entity)player)).get(power);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Power getSelectedPower(EntityPlayer player) {
/* 125 */     List<Power> selectedPowers = (List<Power>)ALData.SELECTED_POWERS.get((Entity)player);
/*     */     
/* 127 */     if (!selectedPowers.isEmpty()) {
/*     */       
/* 129 */       int index = ((Byte)ALData.SELECTED_POWER.get((Entity)player)).byteValue();
/*     */       
/* 131 */       if (index >= 0 && index < selectedPowers.size())
/*     */       {
/* 133 */         return selectedPowers.get(index);
/*     */       }
/*     */     } 
/*     */     
/* 137 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\PowerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */