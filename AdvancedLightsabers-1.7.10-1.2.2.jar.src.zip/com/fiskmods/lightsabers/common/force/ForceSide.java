/*    */ package com.fiskmods.lightsabers.common.force;
/*    */ 
/*    */ import com.google.common.collect.Sets;
/*    */ import java.util.Set;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ForceSide
/*    */ {
/* 12 */   NONE(EnumChatFormatting.WHITE),
/* 13 */   LIGHT(EnumChatFormatting.AQUA),
/* 14 */   DARK(EnumChatFormatting.RED),
/* 15 */   NEUTRAL(EnumChatFormatting.YELLOW);
/*    */ 
/*    */   
/* 18 */   public final Set<Power> powers = Sets.newHashSet();
/*    */   public final EnumChatFormatting theme;
/*    */   
/*    */   ForceSide(EnumChatFormatting formatting) {
/* 22 */     this.theme = formatting;
/*    */   }
/*    */ 
/*    */   
/*    */   public Power getPower() {
/* 27 */     switch (this) {
/*    */       
/*    */       case LIGHT:
/* 30 */         return Power.LIGHT_SIDE;
/*    */       case DARK:
/* 32 */         return Power.DARK_SIDE;
/*    */       case NEUTRAL:
/* 34 */         return Power.NEUTRAL;
/*    */     } 
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ForceSide getOpposite() {
/* 42 */     switch (this) {
/*    */       
/*    */       case LIGHT:
/* 45 */         return DARK;
/*    */       case DARK:
/* 47 */         return LIGHT;
/*    */     } 
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPolar() {
/* 55 */     return (this == LIGHT || this == DARK);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\common\force\ForceSide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */