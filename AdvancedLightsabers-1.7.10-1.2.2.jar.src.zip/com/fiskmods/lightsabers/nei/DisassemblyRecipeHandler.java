/*     */ package com.fiskmods.lightsabers.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.GuiRecipe;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import com.fiskmods.lightsabers.client.gui.GuiDisassemblyStation;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*     */ import com.fiskmods.lightsabers.common.item.ItemFocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.tileentity.TileEntityDisassemblyStation;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisassemblyRecipeHandler
/*     */   extends TemplateRecipeHandler
/*     */ {
/*  37 */   private Minecraft mc = Minecraft.func_71410_x();
/*     */   public static ArrayList<FuelPair> afuels;
/*     */   
/*     */   private class ItemEntry
/*     */     implements Comparable<ItemEntry> {
/*     */     private final Map.Entry<ItemStack, Float> e;
/*     */     
/*     */     public ItemEntry(Map.Entry<ItemStack, Float> e) {
/*  45 */       this.e = e;
/*     */     }
/*     */ 
/*     */     
/*     */     public ItemStack getKey() {
/*  50 */       return this.e.getKey();
/*     */     }
/*     */ 
/*     */     
/*     */     public float getValue() {
/*  55 */       return ((Float)this.e.getValue()).floatValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  61 */       int result = 1;
/*  62 */       result = 31 * result + getKey().func_77960_j();
/*  63 */       result = 31 * result + ((getKey().func_77973_b() == null) ? 0 : getKey().func_77973_b().hashCode());
/*  64 */       result = 31 * result + ((getKey().func_77978_p() == null) ? 0 : getKey().func_77978_p().hashCode());
/*  65 */       result = 31 * result + Float.floatToIntBits(getValue());
/*  66 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  72 */       if (this == obj)
/*     */       {
/*  74 */         return true;
/*     */       }
/*  76 */       if (obj == null)
/*     */       {
/*  78 */         return false;
/*     */       }
/*     */       
/*  81 */       ItemEntry other = (ItemEntry)obj;
/*     */       
/*  83 */       if (getKey().func_77960_j() != other.getKey().func_77960_j())
/*     */       {
/*  85 */         return false;
/*     */       }
/*     */       
/*  88 */       if (Float.floatToIntBits(getValue()) != Float.floatToIntBits(other.getValue()))
/*     */       {
/*  90 */         return false;
/*     */       }
/*     */       
/*  93 */       if (getKey().func_77973_b() == null) {
/*     */         
/*  95 */         if (other.getKey().func_77973_b() != null)
/*     */         {
/*  97 */           return false;
/*     */         }
/*     */       }
/* 100 */       else if (!getKey().func_77973_b().equals(other.getKey().func_77973_b())) {
/*     */         
/* 102 */         return false;
/*     */       } 
/*     */       
/* 105 */       if (getKey().func_77978_p() == null) {
/*     */         
/* 107 */         if (other.getKey().func_77978_p() != null)
/*     */         {
/* 109 */           return false;
/*     */         }
/*     */       }
/* 112 */       else if (!getKey().func_77978_p().equals(other.getKey().func_77978_p())) {
/*     */         
/* 114 */         return false;
/*     */       } 
/*     */       
/* 117 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(ItemEntry o) {
/* 123 */       return Float.compare(o.getValue(), getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public class CachedDisassemblyRecipe
/*     */     extends TemplateRecipeHandler.CachedRecipe {
/*     */     public Map<PositionedStack, Float> results;
/*     */     public PositionedStack ingredient;
/*     */     
/*     */     public CachedDisassemblyRecipe(ItemStack input, Map<ItemStack, Float> outputs) {
/* 133 */       super(DisassemblyRecipeHandler.this);
/* 134 */       input.field_77994_a = 1;
/* 135 */       this.ingredient = new PositionedStack(input, 11, 7);
/* 136 */       this.results = new HashMap<>();
/*     */       
/* 138 */       List<DisassemblyRecipeHandler.ItemEntry> list = new ArrayList<>();
/*     */       
/* 140 */       for (Map.Entry<ItemStack, Float> e : outputs.entrySet()) {
/*     */         
/* 142 */         DisassemblyRecipeHandler.ItemEntry entry = new DisassemblyRecipeHandler.ItemEntry(e);
/*     */         
/* 144 */         if (list.contains(entry)) {
/*     */           
/* 146 */           (((DisassemblyRecipeHandler.ItemEntry)list.get(list.indexOf(entry))).getKey()).field_77994_a += ((ItemStack)e.getKey()).field_77994_a;
/*     */           
/*     */           continue;
/*     */         } 
/* 150 */         list.add(entry);
/*     */       } 
/*     */ 
/*     */       
/* 154 */       list.sort(Comparator.naturalOrder());
/*     */       
/* 156 */       for (int i = 0; i < list.size(); i++)
/*     */       {
/* 158 */         addOutput(72 + 18 * i % 5, 18 + 18 * i / 5, list.get(i));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void addOutput(int x, int y, DisassemblyRecipeHandler.ItemEntry e) {
/* 164 */       this.results.put(new PositionedStack(e.getKey(), x - 5, y - 11, false), Float.valueOf(e.getValue()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PositionedStack getIngredient() {
/* 170 */       return this.ingredient;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PositionedStack getResult() {
/* 176 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<PositionedStack> getOtherStacks() {
/* 182 */       List<PositionedStack> stacks = new ArrayList<>(this.results.keySet());
/* 183 */       PositionedStack stack = getOtherStack();
/*     */       
/* 185 */       if (stack != null)
/*     */       {
/* 187 */         stacks.add(stack);
/*     */       }
/*     */       
/* 190 */       return stacks;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PositionedStack getOtherStack() {
/* 196 */       return ((DisassemblyRecipeHandler.FuelPair)DisassemblyRecipeHandler.afuels.get(DisassemblyRecipeHandler.this.cycleticks / 48 % DisassemblyRecipeHandler.afuels.size())).stack;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadTransferRects() {
/* 203 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(34, 25, 24, 17), getOverlayIdentifier(), new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends GuiContainer> getGuiClass() {
/* 209 */     return (Class)GuiDisassemblyStation.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRecipeName() {
/* 215 */     return StatCollector.func_74838_a("recipe.disassembly_station");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateRecipeHandler newInstance() {
/* 221 */     if (afuels == null || afuels.isEmpty())
/*     */     {
/* 223 */       findFuels();
/*     */     }
/*     */     
/* 226 */     return super.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int recipiesPerPage() {
/* 232 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results) {
/* 238 */     if (outputId.equals(getOverlayIdentifier())) {
/*     */       
/* 240 */       loadCraftingRecipes(new ItemStack(ModItems.circuitry));
/*     */     }
/*     */     else {
/*     */       
/* 244 */       super.loadCraftingRecipes(outputId, results);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result) {
/*     */     try {
/* 253 */       Item item = result.func_77973_b();
/*     */       
/* 255 */       if (item == ModItems.circuitry)
/*     */       {
/* 257 */         for (Hilt hilt : Hilt.REGISTRY)
/*     */         {
/* 259 */           addRecipe(hilt.createDefault().create());
/*     */         }
/*     */       }
/* 262 */       else if (item instanceof ItemLightsaberPart)
/*     */       {
/* 264 */         addRecipe(ItemLightsaberPart.get(result).createDefault().create());
/*     */       }
/* 266 */       else if (item instanceof ItemFocusingCrystal)
/*     */       {
/* 268 */         addRecipe((new LightsaberData()).set(new FocusingCrystal[] { ItemFocusingCrystal.get(result) }).create());
/*     */       }
/* 270 */       else if (item instanceof ItemCrystal)
/*     */       {
/* 272 */         addRecipe((new LightsaberData()).set(ItemCrystal.get(result)).create());
/*     */       }
/*     */     
/* 275 */     } catch (Exception e) {
/*     */       
/* 277 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addRecipe(ItemStack stack) {
/* 283 */     this.arecipes.add(new CachedDisassemblyRecipe(stack, TileEntityDisassemblyStation.getOutput(stack)));
/* 284 */     this.arecipes.add(new CachedDisassemblyRecipe(stack = ItemDoubleLightsaber.create(stack, stack), TileEntityDisassemblyStation.getOutput(stack)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient) {
/*     */     try {
/* 292 */       if (ingredient.func_77973_b() instanceof com.fiskmods.lightsabers.common.item.ItemLightsaberBase)
/*     */       {
/* 294 */         this.arecipes.add(new CachedDisassemblyRecipe(ingredient, TileEntityDisassemblyStation.getOutput(ingredient)));
/*     */       }
/*     */     }
/* 297 */     catch (Exception e) {
/*     */       
/* 299 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGuiTexture() {
/* 306 */     return "lightsabers:textures/gui/container/disassembly_station.png";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOverlayIdentifier() {
/* 312 */     return "disassembly_station";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawExtras(int recipe) {
/* 318 */     drawProgressBar(12, 26, 176, 0, 14, 14, 48, 7);
/* 319 */     drawProgressBar(34, 25, 176, 14, 24, 16, 48, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawBackground(int recipe) {
/* 325 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 326 */     GuiDraw.changeTexture(getGuiTexture());
/* 327 */     GuiDraw.drawTexturedModalRect(0, 0, 5, 11, 166, 66);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> handleItemTooltip(GuiRecipe gui, ItemStack stack, List<String> currenttip, int recipe) {
/* 333 */     CachedDisassemblyRecipe crecipe = this.arecipes.get(recipe);
/*     */     
/* 335 */     for (Map.Entry<PositionedStack, Float> e : crecipe.results.entrySet()) {
/*     */       
/* 337 */       if (gui.isMouseOver(e.getKey(), recipe)) {
/*     */         
/* 339 */         currenttip.add(String.format("%s%%", new Object[] { ItemStack.field_111284_a.format((((Float)e.getValue()).floatValue() * 100.0F)) }));
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 344 */     return currenttip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void findFuels() {
/* 351 */     afuels = new ArrayList<>();
/*     */     
/* 353 */     for (UnmodifiableIterator<Map.Entry<ItemStack, Integer>> unmodifiableIterator = TileEntityDisassemblyStation.getFuels().entrySet().iterator(); unmodifiableIterator.hasNext(); ) { Map.Entry<ItemStack, Integer> e = unmodifiableIterator.next();
/*     */       
/* 355 */       afuels.add(new FuelPair(((ItemStack)e.getKey()).func_77946_l(), ((Integer)e.getValue()).intValue())); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FuelPair
/*     */   {
/*     */     public PositionedStack stack;
/*     */     public int burnTime;
/*     */     
/*     */     public FuelPair(ItemStack ingred, int burnTime) {
/* 366 */       this.stack = new PositionedStack(ingred, 11, 43, false);
/* 367 */       this.burnTime = burnTime;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\nei\DisassemblyRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */