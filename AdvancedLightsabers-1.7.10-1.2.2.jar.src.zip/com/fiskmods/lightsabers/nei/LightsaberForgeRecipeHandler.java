/*     */ package com.fiskmods.lightsabers.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import com.fiskmods.lightsabers.client.gui.GuiLightsaberForge;
/*     */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*     */ import com.fiskmods.lightsabers.common.block.ModBlocks;
/*     */ import com.fiskmods.lightsabers.common.event.ClientEventHandler;
/*     */ import com.fiskmods.lightsabers.common.hilt.Hilt;
/*     */ import com.fiskmods.lightsabers.common.item.ItemCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemFocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberBase;
/*     */ import com.fiskmods.lightsabers.common.item.ItemLightsaberPart;
/*     */ import com.fiskmods.lightsabers.common.item.ModItems;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.CrystalColor;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.FocusingCrystal;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*     */ import com.fiskmods.lightsabers.common.lightsaber.PartType;
/*     */ import com.fiskmods.lightsabers.helper.ALRenderHelper;
/*     */ import com.google.common.collect.Iterables;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightsaberForgeRecipeHandler
/*     */   extends TemplateRecipeHandler
/*     */ {
/*  44 */   private Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public class CachedLightsaberForgeRecipe
/*     */     extends TemplateRecipeHandler.CachedRecipe
/*     */   {
/*     */     public ArrayList<PositionedStack> ingredients;
/*     */     public PositionedStack result;
/*     */     public final LightsaberData data;
/*     */     
/*     */     public CachedLightsaberForgeRecipe(LightsaberData output, Object[] inputs) {
/*  54 */       super(LightsaberForgeRecipeHandler.this);
/*  55 */       this.result = new PositionedStack(ItemLightsaberBase.setActive(output.create(), true), 131, 76);
/*  56 */       this.ingredients = new ArrayList<>();
/*  57 */       this.data = output;
/*     */       
/*  59 */       addSlotToContainer(0, 20, 17, inputs);
/*  60 */       addSlotToContainer(1, 20, 35, inputs);
/*  61 */       addSlotToContainer(2, 20, 53, inputs);
/*  62 */       addSlotToContainer(3, 20, 71, inputs);
/*  63 */       addSlotToContainer(4, 43, 71, inputs);
/*  64 */       addSlotToContainer(5, 66, 71, inputs);
/*  65 */       addSlotToContainer(6, 89, 71, inputs);
/*  66 */       addSlotToContainer(7, 107, 71, inputs);
/*     */     }
/*     */ 
/*     */     
/*     */     private void addSlotToContainer(int id, int x, int y, Object[] inputs) {
/*  71 */       if (inputs[id] != null) {
/*     */         
/*  73 */         PositionedStack stack = new PositionedStack(inputs[id], x - 5, y - 11, false);
/*  74 */         this.ingredients.add(stack);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<PositionedStack> getIngredients() {
/*  81 */       return getCycledIngredients(LightsaberForgeRecipeHandler.this.cycleticks / 20, this.ingredients);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PositionedStack getResult() {
/*  87 */       return this.result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void computeVisuals() {
/*  92 */       for (PositionedStack p : this.ingredients)
/*     */       {
/*  94 */         p.generatePermutations();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadTransferRects() {
/* 102 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(126, 54, 26, 17), getOverlayIdentifier(), new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends GuiContainer> getGuiClass() {
/* 108 */     return (Class)GuiLightsaberForge.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRecipeName() {
/* 114 */     return StatCollector.func_74838_a("recipe.lightsaber_forge");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int recipiesPerPage() {
/* 120 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results) {
/* 126 */     if (outputId.equals(getOverlayIdentifier())) {
/*     */       
/* 128 */       loadUsageRecipes(new ItemStack(ModItems.circuitry));
/*     */     }
/*     */     else {
/*     */       
/* 132 */       super.loadCraftingRecipes(outputId, results);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result) {
/*     */     try {
/* 141 */       if (result.func_77973_b() == ModItems.lightsaber)
/*     */       {
/* 143 */         if (result.func_82833_r().equalsIgnoreCase("sweet dreams"))
/*     */         {
/* 145 */           this.mc.field_71439_g.func_85030_a(ALSounds.player_lightsaber_sweet_dreams, 1.0F, 1.0F);
/*     */         }
/*     */         
/* 148 */         LightsaberData data = LightsaberData.get(result);
/* 149 */         Object[] inputs = new Object[8];
/* 150 */         inputs[4] = new ItemStack(ModItems.circuitry);
/* 151 */         inputs[5] = ItemCrystal.create(data.getColor());
/*     */         
/* 153 */         FocusingCrystal[] crystals = data.getFocusingCrystals();
/* 154 */         Hilt[] hilt = data.getHilt();
/*     */         
/* 156 */         for (PartType type : PartType.values())
/*     */         {
/* 158 */           inputs[type.ordinal()] = ItemLightsaberPart.create(type, hilt[type.ordinal()]);
/*     */         }
/*     */         
/* 161 */         for (int i = 0; i < Math.min(crystals.length, 2); i++)
/*     */         {
/* 163 */           inputs[i + 6] = ItemFocusingCrystal.create(crystals[i]);
/*     */         }
/*     */         
/* 166 */         CachedLightsaberForgeRecipe recipe = new CachedLightsaberForgeRecipe(LightsaberData.get(result), inputs);
/* 167 */         recipe.computeVisuals();
/* 168 */         this.arecipes.add(recipe);
/*     */       }
/*     */     
/* 171 */     } catch (Exception e) {
/*     */       
/* 173 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient) {
/*     */     try {
/* 182 */       Item item = ingredient.func_77973_b();
/* 183 */       ingredient = ingredient.func_77946_l();
/* 184 */       ingredient.field_77994_a = 1;
/*     */       
/* 186 */       if (item instanceof ItemLightsaberPart) {
/*     */         
/* 188 */         Hilt hilt = ItemLightsaberPart.get(ingredient);
/* 189 */         Object[] inputs = new Object[8];
/*     */         
/* 191 */         for (PartType type : PartType.values())
/*     */         {
/* 193 */           inputs[type.ordinal()] = ItemLightsaberPart.create(type, hilt);
/*     */         }
/*     */         
/* 196 */         inputs[4] = new ItemStack(ModItems.circuitry);
/*     */         
/* 198 */         for (CrystalColor color : CrystalColor.values())
/*     */         {
/* 200 */           inputs[5] = ItemCrystal.create(color);
/*     */           
/* 202 */           CachedLightsaberForgeRecipe recipe = new CachedLightsaberForgeRecipe((new LightsaberData()).set(hilt).set(color), inputs);
/* 203 */           recipe.computeVisuals();
/* 204 */           this.arecipes.add(recipe);
/*     */         }
/*     */       
/* 207 */       } else if (item == Item.func_150898_a(ModBlocks.lightsaberCrystal)) {
/*     */         
/* 209 */         CrystalColor color = ItemCrystal.get(ingredient);
/* 210 */         Object[] inputs = new Object[8];
/*     */         
/* 212 */         inputs[4] = new ItemStack(ModItems.circuitry);
/* 213 */         inputs[5] = ingredient;
/*     */         
/* 215 */         for (Hilt hilt : Hilt.REGISTRY)
/*     */         {
/* 217 */           for (PartType type : PartType.values())
/*     */           {
/* 219 */             inputs[type.ordinal()] = ItemLightsaberPart.create(type, hilt);
/*     */           }
/*     */           
/* 222 */           CachedLightsaberForgeRecipe recipe = new CachedLightsaberForgeRecipe((new LightsaberData()).set(hilt).set(color), inputs);
/* 223 */           recipe.computeVisuals();
/* 224 */           this.arecipes.add(recipe);
/*     */         }
/*     */       
/* 227 */       } else if (item == ModItems.focusingCrystal) {
/*     */         
/* 229 */         FocusingCrystal crystal = ItemFocusingCrystal.get(ingredient);
/* 230 */         Object[] inputs = new Object[8];
/*     */         
/* 232 */         inputs[4] = new ItemStack(ModItems.circuitry);
/* 233 */         inputs[5] = ItemCrystal.create(CrystalColor.get(0));
/* 234 */         inputs[6] = ingredient;
/*     */         
/* 236 */         for (Hilt hilt : Hilt.REGISTRY)
/*     */         {
/* 238 */           for (PartType type : PartType.values())
/*     */           {
/* 240 */             inputs[type.ordinal()] = ItemLightsaberPart.create(type, hilt);
/*     */           }
/*     */           
/* 243 */           CachedLightsaberForgeRecipe recipe = new CachedLightsaberForgeRecipe((new LightsaberData()).set(hilt).add(crystal), inputs);
/* 244 */           recipe.computeVisuals();
/* 245 */           this.arecipes.add(recipe);
/*     */         }
/*     */       
/* 248 */       } else if (item == ModItems.circuitry) {
/*     */         
/* 250 */         for (Hilt hilt : Hilt.REGISTRY)
/*     */         {
/* 252 */           Object[] inputs = new Object[8];
/* 253 */           inputs[4] = ingredient;
/*     */           
/* 255 */           for (PartType type : PartType.values())
/*     */           {
/* 257 */             inputs[type.ordinal()] = ItemLightsaberPart.create(type, hilt);
/*     */           }
/*     */           
/* 260 */           LightsaberData data = (new LightsaberData()).set(hilt).set(hilt.getColor());
/* 261 */           Collection<FocusingCrystal> crystals = hilt.getFocusingCrystals();
/*     */           
/* 263 */           for (int i = 0; i < Math.min(crystals.size(), 2); i++) {
/*     */             
/* 265 */             FocusingCrystal crystal = (FocusingCrystal)Iterables.get(crystals, i);
/* 266 */             inputs[i + 6] = ItemFocusingCrystal.create(crystal);
/* 267 */             data.add(crystal);
/*     */           } 
/*     */           
/* 270 */           inputs[5] = ItemCrystal.create(hilt.getColor());
/*     */           
/* 272 */           CachedLightsaberForgeRecipe recipe = new CachedLightsaberForgeRecipe(data, inputs);
/* 273 */           recipe.computeVisuals();
/* 274 */           this.arecipes.add(recipe);
/*     */         }
/*     */       
/*     */       } 
/* 278 */     } catch (Exception e) {
/*     */       
/* 280 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGuiTexture() {
/* 287 */     return "lightsabers:textures/gui/container/lightsaber_forge.png";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOverlayIdentifier() {
/* 293 */     return "lightsaber_forge";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawExtras(int recipe) {
/* 299 */     CachedLightsaberForgeRecipe recipe1 = this.arecipes.get(recipe);
/* 300 */     GuiDraw.drawString(StatCollector.func_74837_a("%s cm", new Object[] { ItemStack.field_111284_a.format(recipe1.data.getHeightCm()) }), 40, 54 - GuiDraw.fontRenderer.field_78288_b, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawBackground(int recipe) {
/* 306 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 307 */     GuiDraw.changeTexture(getGuiTexture());
/* 308 */     GuiDraw.drawTexturedModalRect(0, 0, 5, 11, 166, 102);
/*     */     
/* 310 */     int guiLeft = (this.mc.field_71462_r.field_146294_l - 176) / 2;
/* 311 */     int guiTop = (this.mc.field_71462_r.field_146295_m - 166) / 2;
/* 312 */     float spin = this.mc.field_71439_g.field_70173_aa + ClientEventHandler.renderTick;
/* 313 */     CachedLightsaberForgeRecipe recipe1 = this.arecipes.get(recipe);
/*     */     
/* 315 */     GL11.glEnable(32826);
/* 316 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0F, 240.0F);
/* 317 */     GL11.glEnable(2903);
/* 318 */     GL11.glPushMatrix();
/* 319 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 320 */     GL11.glTranslatef(105.0F, 29.0F, 20.0F);
/* 321 */     GL11.glRotatef((float)Math.sin((spin / 20.0F)) * 2.5F, 0.0F, 1.0F, 0.0F);
/* 322 */     GL11.glRotatef((float)Math.sin((spin / 20.0F + 2.0F)) * 2.5F, 0.0F, 0.0F, 1.0F);
/* 323 */     GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/* 324 */     GL11.glRotatef(90.0F + spin, 0.0F, 1.0F, 0.0F);
/* 325 */     GL11.glScalef(-20.0F, 20.0F, 20.0F);
/* 326 */     RenderHelper.func_74520_c();
/* 327 */     ALRenderHelper.startGlScissor(guiLeft + 43, guiTop + 22, 113, 47);
/* 328 */     ALRenderHelper.renderLightsaber(recipe1.data, recipe1.result.item, false);
/* 329 */     ALRenderHelper.endGlScissor();
/* 330 */     RenderHelper.func_74518_a();
/* 331 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\nei\LightsaberForgeRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */