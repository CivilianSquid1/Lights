/*    */ package com.fiskmods.lightsabers.nei;
/*    */ 
/*    */ import codechicken.nei.api.API;
/*    */ import codechicken.nei.api.IConfigureNEI;
/*    */ import codechicken.nei.recipe.ICraftingHandler;
/*    */ import codechicken.nei.recipe.IUsageHandler;
/*    */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*    */ 
/*    */ 
/*    */ public class NEILightsabersConfig
/*    */   implements IConfigureNEI
/*    */ {
/*    */   public void loadConfig() {
/* 14 */     register(new LightsaberForgeRecipeHandler());
/* 15 */     register((TemplateRecipeHandler)new DoubleLightsaberRecipeHandler());
/* 16 */     register(new DisassemblyRecipeHandler());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void register(TemplateRecipeHandler handler) {
/* 23 */     API.registerRecipeHandler((ICraftingHandler)handler);
/* 24 */     API.registerUsageHandler((IUsageHandler)handler);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 30 */     return "Advanced Lightsabers NEI Plugin";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getVersion() {
/* 36 */     return "1.2.2";
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\nei\NEILightsabersConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */