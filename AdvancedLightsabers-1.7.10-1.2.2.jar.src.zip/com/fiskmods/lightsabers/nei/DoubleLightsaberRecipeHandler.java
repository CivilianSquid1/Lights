/*    */ package com.fiskmods.lightsabers.nei;
/*    */ 
/*    */ import codechicken.nei.recipe.ShapedRecipeHandler;
/*    */ import com.fiskmods.lightsabers.client.sound.ALSounds;
/*    */ import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
/*    */ import com.fiskmods.lightsabers.common.item.ModItems;
/*    */ import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleLightsaberRecipeHandler
/*    */   extends ShapedRecipeHandler
/*    */ {
/*    */   public void loadCraftingRecipes(ItemStack result) {
/* 17 */     if (result.func_77973_b() == ModItems.doubleLightsaber) {
/*    */       
/* 19 */       if (result.func_82833_r().equalsIgnoreCase("sweet dreams"))
/*    */       {
/* 21 */         (Minecraft.func_71410_x()).field_71439_g.func_85030_a(ALSounds.player_lightsaber_sweet_dreams, 1.0F, 1.0F);
/*    */       }
/*    */       
/* 24 */       LightsaberData[] array = ItemDoubleLightsaber.get(result);
/* 25 */       Object[] inputs = new Object[10];
/* 26 */       inputs[0] = array[0].create();
/* 27 */       inputs[3] = array[1].create();
/*    */       
/* 29 */       ShapedRecipeHandler.CachedShapedRecipe recipe = new ShapedRecipeHandler.CachedShapedRecipe(this, 3, 3, inputs, result);
/* 30 */       recipe.computeVisuals();
/* 31 */       this.arecipes.add(recipe);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadUsageRecipes(ItemStack ingredient) {
/* 38 */     if (ingredient.func_77973_b() == ModItems.lightsaber) {
/*    */       
/* 40 */       Object[] inputs = new Object[10];
/* 41 */       inputs[0] = ingredient;
/* 42 */       inputs[3] = ingredient;
/*    */       
/* 44 */       ShapedRecipeHandler.CachedShapedRecipe recipe = new ShapedRecipeHandler.CachedShapedRecipe(this, 3, 3, inputs, ItemDoubleLightsaber.create(ingredient, ingredient));
/* 45 */       recipe.computeVisuals();
/* 46 */       this.arecipes.add(recipe);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\com\fiskmods\lightsabers\nei\DoubleLightsaberRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */