/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FiskMath
/*     */ {
/*     */   public static final double KMPH = 0.0049467960817423D;
/*     */   
/*     */   public static <T> T getWeightedD(Random rand, Map<T, Double> map) {
/*  17 */     double totalWeight = 0.0D;
/*     */     
/*  19 */     for (Map.Entry<T, Double> e : map.entrySet())
/*     */     {
/*  21 */       totalWeight += ((Double)e.getValue()).doubleValue();
/*     */     }
/*     */     
/*  24 */     double random = rand.nextDouble() * totalWeight;
/*     */     
/*  26 */     for (Map.Entry<T, Double> e : map.entrySet()) {
/*     */       
/*  28 */       random -= ((Double)e.getValue()).doubleValue();
/*     */       
/*  30 */       if (random <= 0.0D)
/*     */       {
/*  32 */         return e.getKey();
/*     */       }
/*     */     } 
/*     */     
/*  36 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T getWeightedF(Random rand, Map<T, Float> map) {
/*  41 */     float totalWeight = 0.0F;
/*     */     
/*  43 */     for (Map.Entry<T, Float> e : map.entrySet())
/*     */     {
/*  45 */       totalWeight += ((Float)e.getValue()).floatValue();
/*     */     }
/*     */     
/*  48 */     float random = rand.nextFloat() * totalWeight;
/*     */     
/*  50 */     for (Map.Entry<T, Float> e : map.entrySet()) {
/*     */       
/*  52 */       random -= ((Float)e.getValue()).floatValue();
/*     */       
/*  54 */       if (random <= 0.0F)
/*     */       {
/*  56 */         return e.getKey();
/*     */       }
/*     */     } 
/*     */     
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T getWeightedI(Random rand, Map<T, Integer> map) {
/*  65 */     int totalWeight = 1;
/*     */     
/*  67 */     for (Map.Entry<T, Integer> e : map.entrySet())
/*     */     {
/*  69 */       totalWeight += ((Integer)e.getValue()).intValue();
/*     */     }
/*     */     
/*  72 */     int random = rand.nextInt(totalWeight);
/*     */     
/*  74 */     for (Map.Entry<T, Integer> e : map.entrySet()) {
/*     */       
/*  76 */       random -= ((Integer)e.getValue()).intValue();
/*     */       
/*  78 */       if (random <= 0)
/*     */       {
/*  80 */         return e.getKey();
/*     */       }
/*     */     } 
/*     */     
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean containsAABB(AxisAlignedBB within, AxisAlignedBB aabb) {
/*  89 */     return (aabb.field_72340_a > within.field_72340_a && aabb.field_72338_b > within.field_72338_b && aabb.field_72339_c > within.field_72339_c && aabb.field_72336_d < within.field_72336_d && aabb.field_72337_e < within.field_72337_e && aabb.field_72334_f < within.field_72334_f);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getScaledDistance(Vec3 src, Vec3 dst, double radius) {
/*  94 */     return (radius - Math.min(src.func_72438_d(dst), radius)) / radius;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getScaledDistance(Vec3 src, Vec3 dst, float radius) {
/*  99 */     return (float)getScaledDistance(src, dst, radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float animate(float frame, float duration, float frameStart) {
/* 104 */     return (frame >= frameStart && frame <= frameStart + duration) ? ((frame - frameStart) / duration) : 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float animate(float frame, float duration, float frameStart, float fadeIn, float fadeOut) {
/* 109 */     fadeIn = MathHelper.func_76131_a(fadeIn, 0.0F, duration);
/* 110 */     fadeOut = MathHelper.func_76131_a(fadeOut, 0.0F, duration - fadeIn);
/*     */     
/* 112 */     if (frame >= frameStart && frame <= frameStart + duration) {
/*     */       
/* 114 */       float pos = frame - frameStart;
/*     */       
/* 116 */       if (pos > fadeIn && frame < duration - fadeOut)
/*     */       {
/* 118 */         return 1.0F;
/*     */       }
/* 120 */       if (pos > fadeIn) {
/*     */         
/* 122 */         frame = frameStart + duration - pos;
/* 123 */         fadeIn = fadeOut;
/*     */       } 
/*     */       
/* 126 */       return animate(frame, duration, frameStart) * duration / fadeIn;
/*     */     } 
/*     */     
/* 129 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float curveCrests(float f) {
/* 134 */     return MathHelper.func_76126_a((float)(f * Math.PI / 2.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float curve(float f) {
/* 139 */     return (curveCrests(f * 2.0F - 1.0F) + 1.0F) / 2.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FiskMath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */