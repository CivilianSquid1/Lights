/*    */ package fiskfille.utils.helper;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ public class FiskComparators
/*    */ {
/*    */   public static <T> Comparator<T> random(final Random rand) {
/* 10 */     return new Comparator<T>()
/*    */       {
/*    */         
/*    */         public int compare(Object arg0, Object arg1)
/*    */         {
/* 15 */           return rand.nextBoolean() ? 1 : -1;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FiskComparators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */