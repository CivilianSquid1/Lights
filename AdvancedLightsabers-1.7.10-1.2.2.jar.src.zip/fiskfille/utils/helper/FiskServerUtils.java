/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import cpw.mods.fml.common.Loader;
/*     */ import cpw.mods.fml.common.ModContainer;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class FiskServerUtils
/*     */ {
/*  25 */   private static final Random rand = new Random();
/*     */ 
/*     */   
/*     */   public static String getActiveModId() {
/*  29 */     ModContainer container = Loader.instance().activeModContainer();
/*     */     
/*  31 */     if (container != null)
/*     */     {
/*  33 */       return container.getModId();
/*     */     }
/*     */     
/*  36 */     return "minecraft";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getActiveModName() {
/*  41 */     ModContainer container = Loader.instance().activeModContainer();
/*     */     
/*  43 */     if (container != null)
/*     */     {
/*  45 */       return container.getName();
/*     */     }
/*     */     
/*  48 */     return "Minecraft";
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack getStackFrom(Object obj) {
/*  53 */     if (obj instanceof Item)
/*     */     {
/*  55 */       return new ItemStack((Item)obj);
/*     */     }
/*  57 */     if (obj instanceof Block)
/*     */     {
/*  59 */       return new ItemStack((Block)obj);
/*     */     }
/*  61 */     if (obj instanceof ItemStack)
/*     */     {
/*  63 */       return (ItemStack)obj;
/*     */     }
/*     */     
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack getStackInSlot(EntityPlayer player, int slot) {
/*  71 */     if (slot >= 0 && slot < player.field_71071_by.func_70302_i_())
/*     */     {
/*  73 */       return player.field_71071_by.func_70301_a(slot);
/*     */     }
/*     */     
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean cure(EntityLivingBase entity, Potion potion) {
/*  81 */     if (entity.func_70644_a(potion)) {
/*     */       
/*  83 */       entity.func_82170_o(potion.field_76415_H);
/*  84 */       return true;
/*     */     } 
/*     */     
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canEntityEdit(Entity entity, int x, int y, int z, int side, ItemStack heldItem) {
/*  92 */     if (entity instanceof EntityPlayer)
/*     */     {
/*  94 */       return ((EntityPlayer)entity).func_82247_a(x, y, z, side, heldItem);
/*     */     }
/*  96 */     if (entity instanceof EntityLivingBase)
/*     */     {
/*  98 */       return entity.field_70170_p.func_82736_K().func_82766_b("mobGriefing");
/*     */     }
/*     */     
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canEntityEdit(Entity entity, MovingObjectPosition mop, ItemStack heldItem) {
/* 106 */     return canEntityEdit(entity, mop.field_72311_b, mop.field_72312_c, mop.field_72309_d, mop.field_72310_e, heldItem);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isMeleeDamage(DamageSource source) {
/* 111 */     return (source.func_76346_g() != null && !source.func_82725_o() && !source.func_94541_c() && !source.func_76352_a() && !source.func_76347_k());
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isEntityLookingAt(EntityLivingBase observer, Entity entity, double accuracy) {
/* 116 */     Vec3 vec3 = observer.func_70040_Z().func_72432_b();
/* 117 */     Vec3 vec31 = Vec3.func_72443_a(entity.field_70165_t - observer.field_70165_t, entity.field_70121_D.field_72338_b + (entity.field_70131_O / 2.0F) - observer.field_70163_u + observer.func_70047_e(), entity.field_70161_v - observer.field_70161_v);
/* 118 */     double d0 = vec31.func_72433_c();
/* 119 */     double d1 = vec3.func_72430_b(vec31.func_72432_b());
/*     */     
/* 121 */     return (d1 > 1.0D - accuracy / d0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isEntityLookingAt(EntityLivingBase observer, Entity entity) {
/* 126 */     return (isEntityLookingAt(observer, entity, 0.5D) && observer.func_70685_l(entity));
/*     */   }
/*     */ 
/*     */   
/*     */   public static double interpolate(double a, double b, double progress) {
/* 131 */     return a + (b - a) * progress;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float interpolate(float a, float b, float progress) {
/* 136 */     return (float)interpolate(a, b, progress);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T nonNull(T[] iter) {
/* 141 */     for (T t : iter) {
/*     */       
/* 143 */       if (t != null)
/*     */       {
/* 145 */         return t;
/*     */       }
/*     */     } 
/*     */     
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T nonNull(Iterable<T> iter) {
/* 154 */     for (T t : iter) {
/*     */       
/* 156 */       if (t != null)
/*     */       {
/* 158 */         return t;
/*     */       }
/*     */     } 
/*     */     
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T nonNull(Iterable iter, Class<T> filter) {
/* 167 */     for (Object obj : iter) {
/*     */       
/* 169 */       if (obj != null && filter.isInstance(obj))
/*     */       {
/* 171 */         return (T)obj;
/*     */       }
/*     */     } 
/*     */     
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dropItems(World world, int x, int y, int z) {
/* 180 */     TileEntity tile = world.func_147438_o(x, y, z);
/*     */     
/* 182 */     if (tile instanceof IInventory) {
/*     */       
/* 184 */       IInventory inventory = (IInventory)tile;
/*     */       
/* 186 */       for (int i = 0; i < inventory.func_70302_i_(); i++) {
/*     */         
/* 188 */         ItemStack itemstack = inventory.func_70301_a(i);
/*     */         
/* 190 */         if (itemstack != null) {
/*     */           
/* 192 */           float f = rand.nextFloat() * 0.8F + 0.1F;
/* 193 */           float f1 = rand.nextFloat() * 0.8F + 0.1F;
/* 194 */           float f2 = rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/* 196 */           while (itemstack.field_77994_a > 0) {
/*     */             
/* 198 */             int j = rand.nextInt(21) + 10;
/*     */             
/* 200 */             if (j > itemstack.field_77994_a)
/*     */             {
/* 202 */               j = itemstack.field_77994_a;
/*     */             }
/*     */             
/* 205 */             itemstack.field_77994_a -= j;
/* 206 */             EntityItem entityitem = new EntityItem(world, (x + f), (y + f1), (z + f2), new ItemStack(itemstack.func_77973_b(), j, itemstack.func_77960_j()));
/*     */             
/* 208 */             if (itemstack.func_77942_o())
/*     */             {
/* 210 */               entityitem.func_92059_d().func_77982_d((NBTTagCompound)itemstack.func_77978_p().func_74737_b());
/*     */             }
/*     */             
/* 213 */             float f3 = 0.05F;
/* 214 */             entityitem.field_70159_w = rand.nextGaussian() * f3;
/* 215 */             entityitem.field_70181_x = rand.nextGaussian() * f3 + 0.2D;
/* 216 */             entityitem.field_70179_y = rand.nextGaussian() * f3;
/* 217 */             world.func_72838_d((Entity)entityitem);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FiskServerUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */