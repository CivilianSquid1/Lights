/*    */ package fiskfille.utils.helper;
/*    */ 
/*    */ import fiskfille.utils.common.damage.IExtendedDamage;
/*    */ import net.minecraftforge.common.util.EnumHelper;
/*    */ 
/*    */ public class FiskEnumHelper
/*    */   extends EnumHelper
/*    */ {
/*  9 */   private static Class[][] commonTypes = new Class[][] { { IExtendedDamage.DamageType.class, IExtendedDamage.DamageTypeCallback.class } };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IExtendedDamage.DamageType addDamageType(String name, IExtendedDamage.DamageTypeCallback callback) {
/* 16 */     return addEnum(IExtendedDamage.DamageType.class, name, new Object[] { callback });
/*    */   }
/*    */ 
/*    */   
/*    */   public static IExtendedDamage.DamageType addDamageType(String name) {
/* 21 */     return addDamageType(name, (IExtendedDamage.DamageTypeCallback)new IExtendedDamage.DamageTypeCallback.Impl());
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends Enum<?>> T addEnum(Class<T> enumType, String enumName, Object... paramValues) {
/* 26 */     return (T)addEnum(commonTypes, enumType, enumName, paramValues);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FiskEnumHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */