/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.google.common.base.Predicates;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import cpw.mods.fml.common.Loader;
/*     */ import cpw.mods.fml.common.ModContainer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FiskPredicates
/*     */ {
/*  20 */   public static final Map<Class, Map<String, Predicate>> METHODS = Maps.newHashMap();
/*     */   
/*  22 */   public static final Predicate<Entity> ON_GROUND = new Predicate<Entity>()
/*     */     {
/*     */       
/*     */       public boolean apply(Entity input)
/*     */       {
/*  27 */         return input.field_70122_E;
/*     */       }
/*     */     };
/*     */   
/*  31 */   public static final Predicate<Entity> ALIVE = new Predicate<Entity>()
/*     */     {
/*     */       
/*     */       public boolean apply(Entity input)
/*     */       {
/*  36 */         return input.func_70089_S();
/*     */       }
/*     */     };
/*     */   
/*  40 */   public static final Predicate<Entity> IS_FLYING = new Predicate<Entity>()
/*     */     {
/*     */       
/*     */       public boolean apply(Entity input)
/*     */       {
/*  45 */         return (input instanceof EntityPlayer && ((EntityPlayer)input).field_71075_bZ.field_75100_b);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public static <T> Predicate<T> forInput(Class<T> clazz, String input) {
/*  51 */     List<Predicate<T>> list = Lists.newArrayList();
/*  52 */     String[] astring = input.split(" && ");
/*     */     
/*  54 */     for (String s : astring) {
/*     */       
/*  56 */       boolean inverted = false;
/*     */       
/*  58 */       while (s.startsWith("!")) {
/*     */         
/*  60 */         s = s.substring(1);
/*  61 */         inverted = !inverted;
/*     */       } 
/*     */       
/*  64 */       Predicate<T> p = getHook(clazz, s);
/*     */       
/*  66 */       if (p != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  71 */         if (inverted)
/*     */         {
/*  73 */           p = Predicates.not(p);
/*     */         }
/*     */         
/*  76 */         list.add(p);
/*     */       } 
/*     */     } 
/*  79 */     return Predicates.and(list);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> void addHook(String key, Class<T> clazz, Predicate<T> p) {
/*  84 */     getHooks(clazz).put(key, p);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<String, Predicate> getHooks(Class clazz) {
/*  89 */     Map<String, Predicate> map = METHODS.get(clazz);
/*     */     
/*  91 */     if (map == null)
/*     */     {
/*  93 */       METHODS.put(clazz, map = Maps.newHashMap());
/*     */     }
/*     */     
/*  96 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Predicate getHook(Class clazz, String key) {
/* 101 */     Predicate p = getHooks(clazz).get(key);
/*     */     
/* 103 */     return (p == null) ? Predicates.alwaysFalse() : p;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <K, V> Predicate<Map.Entry<K, V>> filterKeys(final Predicate<K> p) {
/* 108 */     return new Predicate<Map.Entry<K, V>>()
/*     */       {
/*     */         
/*     */         public boolean apply(Map.Entry<K, V> input)
/*     */         {
/* 113 */           return p.apply(input.getKey());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static <K, V> Predicate<Map.Entry<K, V>> filterValues(final Predicate<V> p) {
/* 120 */     return new Predicate<Map.Entry<K, V>>()
/*     */       {
/*     */         
/*     */         public boolean apply(Map.Entry<K, V> input)
/*     */         {
/* 125 */           return p.apply(input.getValue());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Predicate<Object> ofType(final Class<?> type) {
/* 149 */     return new Predicate<Object>()
/*     */       {
/*     */         
/*     */         public boolean apply(Object input)
/*     */         {
/* 154 */           return type.isInstance(input);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 161 */     addHook("hasTab", Item.class, new Predicate<Item>()
/*     */         {
/*     */           
/*     */           public boolean apply(Item input)
/*     */           {
/* 166 */             return (input.func_77640_w() != null);
/*     */           }
/*     */         });
/*     */     
/* 170 */     for (ModContainer mod : Loader.instance().getModList()) {
/*     */       
/* 172 */       addHook("fromMod_" + mod.getModId(), Item.class, new Predicate<Item>()
/*     */           {
/*     */             
/*     */             public boolean apply(Item input)
/*     */             {
/* 177 */               return input.delegate.name().startsWith(mod.getModId() + ":");
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FiskPredicates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */