/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.ALReflection;
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import fiskfille.utils.DimensionalCoords;
/*     */ import fiskfille.utils.registry.FiskRegistryEntry;
/*     */ import fiskfille.utils.registry.FiskSimpleRegistry;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagByte;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagDouble;
/*     */ import net.minecraft.nbt.NBTTagFloat;
/*     */ import net.minecraft.nbt.NBTTagInt;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagLong;
/*     */ import net.minecraft.nbt.NBTTagShort;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTHelper
/*     */ {
/*  34 */   private static final Map<Class<? extends ISerializableObject>, ISaveAdapter> ADAPTERS = Maps.newHashMap();
/*     */ 
/*     */   
/*     */   public static List<NBTBase> getTags(NBTTagList nbttaglist) {
/*  38 */     return (List<NBTBase>)ALReflection.tagList.get(nbttaglist);
/*     */   }
/*     */ 
/*     */   
/*     */   public static NBTBase writeToNBT(Object obj) {
/*  43 */     if (obj instanceof ISerializableObject)
/*     */     {
/*  45 */       return ((ISerializableObject)obj).writeToNBT();
/*     */     }
/*  47 */     if (obj instanceof Byte)
/*     */     {
/*  49 */       return (NBTBase)new NBTTagByte(((Byte)obj).byteValue());
/*     */     }
/*  51 */     if (obj instanceof Short)
/*     */     {
/*  53 */       return (NBTBase)new NBTTagShort(((Short)obj).shortValue());
/*     */     }
/*  55 */     if (obj instanceof Integer)
/*     */     {
/*  57 */       return (NBTBase)new NBTTagInt(((Integer)obj).intValue());
/*     */     }
/*  59 */     if (obj instanceof Long)
/*     */     {
/*  61 */       return (NBTBase)new NBTTagLong(((Long)obj).longValue());
/*     */     }
/*  63 */     if (obj instanceof Float)
/*     */     {
/*  65 */       return (NBTBase)new NBTTagFloat(((Float)obj).floatValue());
/*     */     }
/*  67 */     if (obj instanceof Double)
/*     */     {
/*  69 */       return (NBTBase)new NBTTagDouble(((Double)obj).doubleValue());
/*     */     }
/*  71 */     if (obj instanceof Boolean)
/*     */     {
/*  73 */       return (NBTBase)new NBTTagByte((byte)(((Boolean)obj).booleanValue() ? 1 : 0));
/*     */     }
/*  75 */     if (obj instanceof String) {
/*     */       
/*  77 */       String s = (String)obj;
/*     */       
/*  79 */       if (s != null)
/*     */       {
/*  81 */         return (NBTBase)new NBTTagString(s);
/*     */       }
/*     */     } else {
/*  84 */       if (obj instanceof List) {
/*     */         
/*  86 */         List list = (List)obj;
/*  87 */         NBTTagList nbttaglist = new NBTTagList();
/*     */         
/*  89 */         for (int i = 0; i < list.size(); i++) {
/*     */           
/*  91 */           NBTBase tag = writeToNBT(list.get(i));
/*     */           
/*  93 */           if (tag != null)
/*     */           {
/*  95 */             nbttaglist.func_74742_a(tag);
/*     */           }
/*     */         } 
/*     */         
/*  99 */         return (NBTBase)nbttaglist;
/*     */       } 
/* 101 */       if (obj instanceof ItemStack)
/*     */       {
/* 103 */         return (NBTBase)((ItemStack)obj).func_77955_b(new NBTTagCompound());
/*     */       }
/* 105 */       if (obj instanceof DimensionalCoords) {
/*     */         
/* 107 */         DimensionalCoords coords = (DimensionalCoords)obj;
/* 108 */         NBTTagCompound nbt = new NBTTagCompound();
/* 109 */         nbt.func_74768_a("x", coords.field_71574_a);
/* 110 */         nbt.func_74768_a("y", coords.field_71572_b);
/* 111 */         nbt.func_74768_a("z", coords.field_71573_c);
/* 112 */         nbt.func_74768_a("dim", coords.dimension);
/*     */         
/* 114 */         return (NBTBase)nbt;
/*     */       } 
/*     */     } 
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readFromNBT(NBTBase tag, Class<T> type) {
/* 122 */     return readFromNBT(tag, new ALData.ClassType(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readFromNBT(NBTBase tag, ALData.ClassType<T> typeClass) {
/* 127 */     if (ISerializableObject.class.isAssignableFrom(typeClass.getType())) {
/*     */       
/* 129 */       if (ADAPTERS.containsKey(typeClass.getType()))
/*     */       {
/* 131 */         return (T)((ISaveAdapter)ADAPTERS.get(typeClass.getType())).readFromNBT(tag);
/*     */       }
/*     */       
/* 134 */       return null;
/*     */     } 
/* 136 */     if (tag instanceof NBTBase.NBTPrimitive) {
/*     */       
/* 138 */       NBTBase.NBTPrimitive nbt = (NBTBase.NBTPrimitive)tag;
/*     */       
/* 140 */       if (typeClass.getType() == Byte.class)
/*     */       {
/* 142 */         return (T)Byte.valueOf(nbt.func_150290_f());
/*     */       }
/* 144 */       if (typeClass.getType() == Short.class)
/*     */       {
/* 146 */         return (T)Short.valueOf(nbt.func_150289_e());
/*     */       }
/* 148 */       if (typeClass.getType() == Integer.class)
/*     */       {
/* 150 */         return (T)Integer.valueOf(nbt.func_150287_d());
/*     */       }
/* 152 */       if (typeClass.getType() == Long.class)
/*     */       {
/* 154 */         return (T)Long.valueOf(nbt.func_150291_c());
/*     */       }
/* 156 */       if (typeClass.getType() == Float.class)
/*     */       {
/* 158 */         return (T)Float.valueOf(nbt.func_150288_h());
/*     */       }
/* 160 */       if (typeClass.getType() == Double.class)
/*     */       {
/* 162 */         return (T)Double.valueOf(nbt.func_150286_g());
/*     */       }
/* 164 */       if (typeClass.getType() == Boolean.class)
/*     */       {
/* 166 */         return (T)Boolean.valueOf((nbt.func_150290_f() != 0));
/*     */       }
/*     */     } else {
/* 169 */       if (typeClass.getType() == String.class && tag instanceof NBTTagString)
/*     */       {
/* 171 */         return (T)((NBTTagString)tag).func_150285_a_();
/*     */       }
/* 173 */       if (typeClass.getType() == List.class && tag instanceof NBTTagList) {
/*     */         
/* 175 */         List<NBTBase> tags = getTags((NBTTagList)tag);
/* 176 */         List<Object> list = Lists.newArrayList();
/*     */         
/* 178 */         for (int i = 0; i < tags.size(); i++) {
/*     */           
/* 180 */           Object entry = readFromNBT(tags.get(i), typeClass.getParamSafe());
/*     */           
/* 182 */           if (entry != null)
/*     */           {
/* 184 */             list.add(entry);
/*     */           }
/*     */         } 
/*     */         
/* 188 */         return (T)list;
/*     */       } 
/* 190 */       if (tag instanceof NBTTagCompound) {
/*     */         
/* 192 */         NBTTagCompound nbt = (NBTTagCompound)tag;
/*     */         
/* 194 */         if (typeClass.getType() == ItemStack.class)
/*     */         {
/* 196 */           return (T)ItemStack.func_77949_a(nbt);
/*     */         }
/* 198 */         if (typeClass.getType() == DimensionalCoords.class)
/*     */         {
/* 200 */           return (T)new DimensionalCoords(nbt.func_74762_e("x"), nbt.func_74762_e("y"), nbt.func_74762_e("z"), nbt.func_74762_e("dim"));
/*     */         }
/*     */       } 
/*     */     } 
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void toBytes(ByteBuf buf, Object obj) {
/* 209 */     if (obj instanceof Byte) {
/*     */       
/* 211 */       buf.writeByte(((Byte)obj).byteValue());
/*     */     }
/* 213 */     else if (obj instanceof Short) {
/*     */       
/* 215 */       buf.writeShort(((Short)obj).shortValue());
/*     */     }
/* 217 */     else if (obj instanceof Integer) {
/*     */       
/* 219 */       buf.writeInt(((Integer)obj).intValue());
/*     */     }
/* 221 */     else if (obj instanceof Long) {
/*     */       
/* 223 */       buf.writeLong(((Long)obj).longValue());
/*     */     }
/* 225 */     else if (obj instanceof Float) {
/*     */       
/* 227 */       buf.writeFloat(((Float)obj).floatValue());
/*     */     }
/* 229 */     else if (obj instanceof Double) {
/*     */       
/* 231 */       buf.writeDouble(((Double)obj).doubleValue());
/*     */     }
/* 233 */     else if (obj instanceof Boolean) {
/*     */       
/* 235 */       buf.writeBoolean(((Boolean)obj).booleanValue());
/*     */     }
/*     */     else {
/*     */       
/* 239 */       buf.writeBoolean((obj != null));
/*     */       
/* 241 */       if (obj instanceof ISerializableObject) {
/*     */         
/* 243 */         ((ISerializableObject)obj).toBytes(buf);
/*     */       }
/* 245 */       else if (obj instanceof String) {
/*     */         
/* 247 */         ByteBufUtils.writeUTF8String(buf, (String)obj);
/*     */       }
/* 249 */       else if (obj instanceof List) {
/*     */         
/* 251 */         List list = (List)obj;
/* 252 */         buf.writeInt(list.size());
/*     */         
/* 254 */         for (int i = 0; i < list.size(); i++)
/*     */         {
/* 256 */           toBytes(buf, list.get(i));
/*     */         }
/*     */       }
/* 259 */       else if (obj instanceof ItemStack) {
/*     */         
/* 261 */         ByteBufUtils.writeItemStack(buf, (ItemStack)obj);
/*     */       }
/* 263 */       else if (obj instanceof DimensionalCoords) {
/*     */         
/* 265 */         DimensionalCoords coords = (DimensionalCoords)obj;
/* 266 */         buf.writeInt(coords.field_71574_a);
/* 267 */         buf.writeInt(coords.field_71572_b);
/* 268 */         buf.writeInt(coords.field_71573_c);
/* 269 */         buf.writeInt(coords.dimension);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T fromBytes(ByteBuf buf, Class<T> type) {
/* 276 */     return fromBytes(buf, new ALData.ClassType(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T fromBytes(ByteBuf buf, ALData.ClassType<T> typeClass) {
/* 281 */     if (typeClass.getType() == Byte.class)
/*     */     {
/* 283 */       return (T)Byte.valueOf(buf.readByte());
/*     */     }
/* 285 */     if (typeClass.getType() == Short.class)
/*     */     {
/* 287 */       return (T)Short.valueOf(buf.readShort());
/*     */     }
/* 289 */     if (typeClass.getType() == Integer.class)
/*     */     {
/* 291 */       return (T)Integer.valueOf(buf.readInt());
/*     */     }
/* 293 */     if (typeClass.getType() == Long.class)
/*     */     {
/* 295 */       return (T)Long.valueOf(buf.readLong());
/*     */     }
/* 297 */     if (typeClass.getType() == Float.class)
/*     */     {
/* 299 */       return (T)Float.valueOf(buf.readFloat());
/*     */     }
/* 301 */     if (typeClass.getType() == Double.class)
/*     */     {
/* 303 */       return (T)Double.valueOf(buf.readDouble());
/*     */     }
/* 305 */     if (typeClass.getType() == Boolean.class)
/*     */     {
/* 307 */       return (T)Boolean.valueOf(buf.readBoolean());
/*     */     }
/* 309 */     if (buf.readBoolean())
/*     */     {
/* 311 */       if (ISerializableObject.class.isAssignableFrom(typeClass.getType())) {
/*     */         
/* 313 */         if (ADAPTERS.containsKey(typeClass.getType()))
/*     */         {
/* 315 */           return (T)((ISaveAdapter)ADAPTERS.get(typeClass.getType())).fromBytes(buf);
/*     */         }
/*     */       } else {
/* 318 */         if (typeClass.getType() == String.class)
/*     */         {
/* 320 */           return (T)ByteBufUtils.readUTF8String(buf);
/*     */         }
/* 322 */         if (typeClass.getType() == List.class) {
/*     */           
/* 324 */           List<Object> list = Lists.newArrayList();
/* 325 */           int size = buf.readInt();
/*     */           
/* 327 */           for (int i = 0; i < size; i++) {
/*     */             
/* 329 */             Object entry = fromBytes(buf, typeClass.getParamSafe());
/*     */             
/* 331 */             if (entry != null)
/*     */             {
/* 333 */               list.add(entry);
/*     */             }
/*     */           } 
/*     */           
/* 337 */           return (T)list;
/*     */         } 
/* 339 */         if (typeClass.getType() == ItemStack.class)
/*     */         {
/* 341 */           return (T)ByteBufUtils.readItemStack(buf);
/*     */         }
/* 343 */         if (typeClass.getType() == DimensionalCoords.class)
/*     */         {
/* 345 */           return (T)new DimensionalCoords(buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt());
/*     */         }
/*     */       } 
/*     */     }
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends FiskRegistryEntry<T>> List<T> readNBTList(NBTTagCompound compound, String name, FiskSimpleRegistry<T> registry) {
/* 354 */     List<T> list = null;
/*     */     
/* 356 */     if (compound.func_150297_b(name, 9)) {
/*     */       
/* 358 */       NBTTagList tagList = compound.func_150295_c(name, 8);
/* 359 */       list = Lists.newArrayList();
/*     */       
/* 361 */       for (int i = 0; i < tagList.func_74745_c(); i++) {
/*     */         
/* 363 */         FiskRegistryEntry fiskRegistryEntry = registry.getObject(tagList.func_150307_f(i));
/*     */         
/* 365 */         if (fiskRegistryEntry != null)
/*     */         {
/* 367 */           list.add((T)fiskRegistryEntry);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 372 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NBTTagCompound getCompound(String s) {
/*     */     try {
/* 379 */       NBTBase tag = JsonToNBT.func_150315_a(s);
/*     */       
/* 381 */       if (tag instanceof NBTTagCompound)
/*     */       {
/* 383 */         return (NBTTagCompound)tag;
/*     */       }
/*     */     }
/* 386 */     catch (NBTException nBTException) {}
/*     */ 
/*     */ 
/*     */     
/* 390 */     return new NBTTagCompound();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends ISerializableObject<T>> void registerAdapter(Class<? extends T> type, Class<? extends ISaveAdapter<T>> adapter) {
/*     */     try {
/* 397 */       ADAPTERS.put(type, adapter.newInstance());
/*     */     }
/* 399 */     catch (Exception e) {
/*     */       
/* 401 */       throw new RuntimeException("An unexpected error occurred while registering save adapter:", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface ISaveAdapter<T extends ISerializableObject<T>> {
/*     */     T readFromNBT(NBTBase param1NBTBase);
/*     */     
/*     */     T fromBytes(ByteBuf param1ByteBuf);
/*     */   }
/*     */   
/*     */   public static interface ISerializableObject<T extends ISerializableObject<T>> {
/*     */     NBTBase writeToNBT();
/*     */     
/*     */     void toBytes(ByteBuf param1ByteBuf);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\NBTHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */