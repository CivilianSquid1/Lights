/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectorHelper
/*     */ {
/*     */   public static Vec3 getOffsetCoords(EntityLivingBase entity, double xOffset, double yOffset, double zOffset, float partialTicks) {
/*  19 */     Vec3 vec3 = Vec3.func_72443_a(xOffset, yOffset, zOffset);
/*  20 */     vec3.func_72440_a(-(entity.field_70125_A + (entity.field_70125_A - entity.field_70127_C) * partialTicks) * 3.1415927F / 180.0F);
/*  21 */     vec3.func_72442_b(-(entity.field_70177_z + (entity.field_70177_z - entity.field_70126_B) * partialTicks) * 3.1415927F / 180.0F);
/*     */     
/*  23 */     return Vec3.func_72443_a(entity.field_70165_t + vec3.field_72450_a, entity.field_70163_u + getOffset(entity) + vec3.field_72448_b, entity.field_70161_v + vec3.field_72449_c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getOffsetCoords(EntityLivingBase entity, double xOffset, double yOffset, double zOffset) {
/*  28 */     return getOffsetCoords(entity, xOffset, yOffset, zOffset, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 copy(Vec3 vec3) {
/*  33 */     return Vec3.func_72443_a(vec3.field_72450_a, vec3.field_72448_b, vec3.field_72449_c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 add(Vec3 vec3, Vec3 vec31) {
/*  38 */     return Vec3.func_72443_a(vec3.field_72450_a + vec31.field_72450_a, vec3.field_72448_b + vec31.field_72448_b, vec3.field_72449_c + vec31.field_72449_c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 multiply(Vec3 vec3, Vec3 vec31) {
/*  43 */     return Vec3.func_72443_a(vec3.field_72450_a * vec31.field_72450_a, vec3.field_72448_b * vec31.field_72448_b, vec3.field_72449_c * vec31.field_72449_c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 multiply(Vec3 vec3, double factor) {
/*  48 */     return multiply(vec3, Vec3.func_72443_a(factor, factor, factor));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 interpolate(Vec3 vec3, Vec3 vec31, double distance) {
/*  53 */     double d = distance / vec3.func_72438_d(vec31);
/*  54 */     return add(multiply(vec3, d), multiply(vec31, 1.0D - d));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 centerOf(Entity entity) {
/*  59 */     return Vec3.func_72443_a(entity.field_70165_t, entity.field_70121_D.field_72338_b + (entity.field_70131_O / 2.0F), entity.field_70161_v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getPosition(Entity entity, float partialTicks) {
/*  64 */     if (partialTicks == 1.0F)
/*     */     {
/*  66 */       return Vec3.func_72443_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
/*     */     }
/*     */ 
/*     */     
/*  70 */     double d0 = entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * partialTicks;
/*  71 */     double d1 = entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * partialTicks;
/*  72 */     double d2 = entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * partialTicks;
/*  73 */     return Vec3.func_72443_a(d0, d1, d2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double getOffset(EntityLivingBase entity) {
/*  79 */     double yOffset = entity.func_70047_e();
/*     */     
/*  81 */     if (entity instanceof EntityPlayer && entity.field_70170_p.field_72995_K) {
/*     */       
/*  83 */       yOffset -= ((EntityPlayer)entity).getDefaultEyeHeight();
/*     */       
/*  85 */       if (!Lightsabers.proxy.isClientPlayer(entity))
/*     */       {
/*  87 */         yOffset += 1.6200000047683716D;
/*     */       }
/*     */     } 
/*     */     
/*  91 */     return yOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getBackSideCoordsRenderYawOffset(EntityLivingBase entity, double amount, boolean side, double backAmount, boolean pitch) {
/*  96 */     Vec3 front = getFrontCoordsRenderYawOffset(entity, backAmount, pitch).func_72441_c(-entity.field_70165_t, -(entity.field_70163_u + getOffset(entity)), -entity.field_70161_v);
/*  97 */     return getSideCoordsRenderYawOffset(entity, amount, side).func_72441_c(front.field_72450_a, front.field_72448_b, front.field_72449_c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getSideCoordsRenderYawOffset(EntityLivingBase entity, double amount, boolean side) {
/* 102 */     return getSideCoordsRenderYawOffset(entity, amount, side ? -90 : 90);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getSideCoordsRenderYawOffset(EntityLivingBase entity, double amount, int side) {
/* 107 */     float pitch = 0.0F;
/* 108 */     float yaw = entity.field_70761_aq + side;
/* 109 */     float f3 = MathHelper.func_76134_b(-yaw * 0.017453292F - 3.1415927F);
/* 110 */     float f4 = MathHelper.func_76126_a(-yaw * 0.017453292F - 3.1415927F);
/* 111 */     float f5 = -MathHelper.func_76134_b(-pitch * 0.017453292F);
/* 112 */     float yScale = MathHelper.func_76126_a(-pitch * 0.017453292F);
/* 113 */     float xScale = f4 * f5;
/* 114 */     float zScale = f3 * f5;
/* 115 */     return Vec3.func_72443_a(entity.field_70165_t, entity.field_70163_u + getOffset(entity), entity.field_70161_v).func_72441_c(xScale * amount, yScale * amount, zScale * amount);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 getFrontCoordsRenderYawOffset(EntityLivingBase entity, double amount, boolean applyPitch) {
/* 120 */     float pitch = applyPitch ? entity.field_70125_A : 0.0F;
/* 121 */     float yaw = entity.field_70761_aq;
/*     */     
/* 123 */     float f3 = MathHelper.func_76134_b(-yaw * 0.017453292F - 3.1415927F);
/* 124 */     float f4 = MathHelper.func_76126_a(-yaw * 0.017453292F - 3.1415927F);
/* 125 */     float f5 = -MathHelper.func_76134_b(-pitch * 0.017453292F);
/* 126 */     float yScale = MathHelper.func_76126_a(-pitch * 0.017453292F);
/* 127 */     float xScale = f4 * f5;
/* 128 */     float zScale = f3 * f5;
/* 129 */     return Vec3.func_72443_a(entity.field_70165_t, entity.field_70163_u + getOffset(entity), entity.field_70161_v).func_72441_c(xScale * amount, yScale * amount, zScale * amount);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends Entity> List<T> getEntitiesNear(Class<T> type, World world, double x, double y, double z, double radius) {
/* 134 */     return world.func_72872_a(type, AxisAlignedBB.func_72330_a(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends Entity> List<T> getEntitiesNear(Class<T> type, World world, Vec3 vec3, double radius) {
/* 139 */     return getEntitiesNear(type, world, vec3.field_72450_a, vec3.field_72448_b, vec3.field_72449_c, radius);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\VectorHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */