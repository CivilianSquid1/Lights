/*     */ package fiskfille.utils.helper;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.gson.Gson;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileHelper
/*     */ {
/*     */   public static URLConnection createConnection(String url) throws MalformedURLException, IOException {
/*  24 */     URLConnection connection = (new URL(url)).openConnection();
/*  25 */     connection.setRequestProperty("User-Agent", "Mozilla/5.0");
/*     */     
/*  27 */     return connection;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isURL(String path) {
/*  32 */     return (path.startsWith("http://") || path.startsWith("https://") || path.startsWith("www."));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> read(String path) throws IOException {
/*  37 */     return IOUtils.readLines(Lightsabers.class.getResourceAsStream(path));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> read(File file) throws IOException {
/*  42 */     return read(new FileReader(file));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> read(URL url) throws IOException {
/*  47 */     return read(new InputStreamReader(url.openStream()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> read(URLConnection connection) throws IOException {
/*  52 */     return read(new InputStreamReader(connection.getInputStream()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> read(Reader reader) throws IOException {
/*  57 */     BufferedReader in = new BufferedReader(reader);
/*  58 */     List<String> list = Lists.newArrayList();
/*     */     
/*     */     String currentLine;
/*  61 */     while ((currentLine = in.readLine()) != null)
/*     */     {
/*  63 */       list.add(currentLine);
/*     */     }
/*     */     
/*  66 */     in.close();
/*     */     
/*  68 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readJson(Gson gson, Class<T> type, String path) throws IOException {
/*  73 */     return (T)gson.fromJson(flatten(read(path)), type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readJson(Gson gson, Class<T> type, File file) throws IOException {
/*  78 */     if (!file.isFile() || !file.getName().endsWith(".json"))
/*     */     {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     return readJson(gson, type, new FileReader(file));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readJson(Gson gson, Class<T> type, URL url) throws IOException {
/*  88 */     return readJson(gson, type, new InputStreamReader(url.openStream()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readJson(Gson gson, Class<T> type, URLConnection connection) throws IOException {
/*  93 */     return readJson(gson, type, new InputStreamReader(connection.getInputStream()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T readJson(Gson gson, Class<T> type, Reader reader) throws IOException {
/*  98 */     return (T)gson.fromJson(flatten(read(reader)), type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String flatten(List<String> list) {
/* 103 */     String s = "";
/*     */     
/* 105 */     for (String s1 : list)
/*     */     {
/* 107 */       s = s + s1 + "\n";
/*     */     }
/*     */     
/* 110 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\helper\FileHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */