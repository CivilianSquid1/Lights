/*     */ package fiskfille.utils;
/*     */ 
/*     */ import com.fiskmods.lightsabers.common.data.ALData;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DimensionalCoords
/*     */   extends ChunkCoordinates
/*     */ {
/*     */   public int dimension;
/*     */   
/*     */   public DimensionalCoords() {}
/*     */   
/*     */   public DimensionalCoords(int x, int y, int z, int dim) {
/*  18 */     super(x, y, z);
/*  19 */     this.dimension = dim;
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords(ChunkCoordinates coords, int dim) {
/*  24 */     super(coords);
/*  25 */     this.dimension = dim;
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords(TileEntity tile) {
/*  30 */     set(tile);
/*     */   }
/*     */ 
/*     */   
/*     */   public static DimensionalCoords copy(DimensionalCoords coords) {
/*  35 */     if (coords != null)
/*     */     {
/*  37 */       return (new DimensionalCoords()).set(coords);
/*     */     }
/*     */     
/*  40 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords set(int x, int y, int z, int dim) {
/*  45 */     this.field_71574_a = x;
/*  46 */     this.field_71572_b = y;
/*  47 */     this.field_71573_c = z;
/*  48 */     this.dimension = dim;
/*     */     
/*  50 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords set(TileEntity tile) {
/*  55 */     if (tile.func_145831_w() != null)
/*     */     {
/*  57 */       return set(tile.field_145851_c, tile.field_145848_d, tile.field_145849_e, (tile.func_145831_w()).field_73011_w.field_76574_g);
/*     */     }
/*     */     
/*  60 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords set(DimensionalCoords coords) {
/*  65 */     return set(coords.toArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public DimensionalCoords set(int... args) {
/*  70 */     int[] aint = toArray();
/*     */     
/*  72 */     for (int i = 0; i < Math.min(args.length, aint.length); i++)
/*     */     {
/*  74 */       aint[i] = args[i];
/*     */     }
/*     */     
/*  77 */     return set(aint[0], aint[1], aint[2], aint[3]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] toArray() {
/*  82 */     return new int[] { this.field_71574_a, this.field_71572_b, this.field_71573_c, this.dimension };
/*     */   }
/*     */ 
/*     */   
/*     */   public static DimensionalCoords fromArray(int[] aint) {
/*  87 */     int[] aint1 = new int[4];
/*     */     
/*  89 */     for (int i = 0; i < Math.min(aint.length, aint1.length); i++)
/*     */     {
/*  91 */       aint1[i] = aint[i];
/*     */     }
/*     */     
/*  94 */     return new DimensionalCoords(aint1[0], aint1[1], aint1[2], aint1[3]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ALData.DataFactory<DimensionalCoords> factory() {
/*  99 */     return new ALData.DataFactory<DimensionalCoords>()
/*     */       {
/*     */         
/*     */         public DimensionalCoords construct()
/*     */         {
/* 104 */           return new DimensionalCoords();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 112 */     if (!(obj instanceof DimensionalCoords))
/*     */     {
/* 114 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 118 */     DimensionalCoords coords = (DimensionalCoords)obj;
/* 119 */     return (this.field_71574_a == coords.field_71574_a && this.field_71572_b == coords.field_71572_b && this.field_71573_c == coords.field_71573_c && this.dimension == coords.dimension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 126 */     return this.field_71574_a + this.field_71573_c << 8 + this.field_71572_b << 16 + this.dimension << 32;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "Pos{x=" + this.field_71574_a + ", y=" + this.field_71572_b + ", z=" + this.field_71573_c + ", dim=" + this.dimension + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object obj) {
/* 138 */     return compareTo((DimensionalCoords)obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(DimensionalCoords coords) {
/* 143 */     return (this.dimension == coords.dimension) ? ((this.field_71572_b == coords.field_71572_b) ? ((this.field_71573_c == coords.field_71573_c) ? (this.field_71574_a - coords.field_71574_a) : (this.field_71573_c - coords.field_71573_c)) : (this.field_71572_b - coords.field_71572_b)) : (this.dimension - coords.dimension);
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\DimensionalCoords.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */