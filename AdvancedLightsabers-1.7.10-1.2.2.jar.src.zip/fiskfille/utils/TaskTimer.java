/*    */ package fiskfille.utils;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public class TaskTimer
/*    */ {
/*  9 */   private static Map<String, TaskTimer> timers = Maps.newHashMap();
/*    */   
/*    */   private final String task;
/*    */   
/*    */   private long startTime;
/*    */   
/*    */   private TaskTimer(String s) {
/* 16 */     this.task = s;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void start(String task) {
/* 21 */     (get(task)).startTime = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void stop(String task) {
/* 26 */     Log.info2("Tasks", "Finished task %s in %s ms", new Object[] { task, Long.valueOf(System.currentTimeMillis() - (get(task)).startTime) });
/*    */   }
/*    */ 
/*    */   
/*    */   private static TaskTimer get(String task) {
/* 31 */     TaskTimer timer = timers.get(task);
/*    */     
/* 33 */     if (timer == null)
/*    */     {
/* 35 */       timers.put(task, timer = new TaskTimer(task));
/*    */     }
/*    */     
/* 38 */     return timer;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\TaskTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */