/*    */ package fiskfille.utils;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ import java.util.Map;
/*    */ import net.minecraft.util.StringUtils;
/*    */ import org.apache.logging.log4j.Level;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log
/*    */ {
/* 16 */   private static Map<String, Logger> loggers = Maps.newHashMap();
/*    */ 
/*    */   
/*    */   private static Logger fetchLogger(String key) {
/* 20 */     Logger logger = loggers.get(key);
/*    */     
/* 22 */     if (logger == null)
/*    */     {
/* 24 */       loggers.put(key, logger = LogManager.getLogger(key));
/*    */     }
/*    */     
/* 27 */     return logger;
/*    */   }
/*    */ 
/*    */   
/*    */   private static Logger getLogger(String prefix) {
/* 32 */     String name = FiskServerUtils.getActiveModName();
/*    */     
/* 34 */     if (!StringUtils.func_151246_b(prefix))
/*    */     {
/* 36 */       name = String.format("%s/%s", new Object[] { name, prefix });
/*    */     }
/*    */     
/* 39 */     return fetchLogger(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean warn2(String prefix, String message, Object... args) {
/* 44 */     return log(Level.WARN, prefix, message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean error2(String prefix, String message, Object... args) {
/* 49 */     return log(Level.ERROR, prefix, message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean info2(String prefix, String message, Object... args) {
/* 54 */     return log(Level.INFO, prefix, message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean debug2(String prefix, String message, Object... args) {
/* 59 */     return log(Level.DEBUG, prefix, message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean warn(String message, Object... args) {
/* 64 */     return warn2("", message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean error(String message, Object... args) {
/* 69 */     return error2("", message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean info(String message, Object... args) {
/* 74 */     return info2("", message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean debug(String message, Object... args) {
/* 79 */     return debug2("", message, args);
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean log(Level level, String prefix, String message, Object... args) {
/* 84 */     Logger logger = getLogger(prefix);
/*    */     
/* 86 */     if (args.length > 0)
/*    */     {
/* 88 */       message = String.format(message, args);
/*    */     }
/*    */     
/* 91 */     logger.log(level, message);
/*    */     
/* 93 */     return logger.isEnabled(level);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\Log.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */