/*    */ package fiskfille.utils.common.interaction;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.common.network.FiskNetworkManager;
/*    */ import fiskfille.utils.common.network.MessageInteraction;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*    */ 
/*    */ public enum InteractionHandler
/*    */ {
/* 15 */   INSTANCE;
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 20 */     EntityPlayer player = event.entityPlayer;
/* 21 */     PlayerInteractEvent.Action action = event.action;
/* 22 */     int x = event.x;
/* 23 */     int y = event.y;
/* 24 */     int z = event.z;
/*    */     
/* 26 */     if (action == PlayerInteractEvent.Action.RIGHT_CLICK_AIR) {
/*    */       
/* 28 */       x = MathHelper.func_76128_c(player.field_70165_t);
/* 29 */       y = MathHelper.func_76128_c(player.field_70121_D.field_72338_b);
/* 30 */       z = MathHelper.func_76128_c(player.field_70161_v);
/*    */     } 
/*    */     
/* 33 */     if (interact(player, InteractionType.get(action), x, y, z)) {
/*    */       
/* 35 */       event.setCanceled(true);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean interact(EntityPlayer player, InteractionType type, int x, int y, int z) {
/* 42 */     if (player.field_70170_p.field_72995_K)
/*    */     {
/* 44 */       for (Interaction interaction : Interaction.REGISTRY) {
/*    */         
/* 46 */         if (interaction.listen(player, player, type, Side.CLIENT, x, y, z)) {
/*    */           
/* 48 */           if (interaction.syncWithServer())
/*    */           {
/* 50 */             FiskNetworkManager.wrapper.sendToServer((IMessage)new MessageInteraction(player, interaction, type, x, y, z));
/*    */           }
/*    */           
/* 53 */           return true;
/*    */         } 
/*    */       } 
/*    */     }
/*    */     
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void register() {
/* 63 */     MinecraftForge.EVENT_BUS.register(INSTANCE);
/*    */   }
/*    */   
/*    */   public enum InteractionType
/*    */   {
/* 68 */     KEY_PRESS,
/* 69 */     KEY_HOLD,
/* 70 */     RIGHT_CLICK_AIR,
/* 71 */     RIGHT_CLICK_BLOCK,
/* 72 */     LEFT_CLICK_BLOCK;
/*    */ 
/*    */     
/*    */     public static InteractionType get(PlayerInteractEvent.Action action) {
/* 76 */       switch (action) {
/*    */         
/*    */         case RIGHT_CLICK_AIR:
/* 79 */           return RIGHT_CLICK_AIR;
/*    */         case RIGHT_CLICK_BLOCK:
/* 81 */           return RIGHT_CLICK_BLOCK;
/*    */         case LEFT_CLICK_BLOCK:
/* 83 */           return LEFT_CLICK_BLOCK;
/*    */       } 
/*    */       
/* 86 */       return KEY_PRESS;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\interaction\InteractionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */