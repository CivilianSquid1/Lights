/*    */ package fiskfille.utils.common.interaction;
/*    */ 
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.registry.FiskRegistryEntry;
/*    */ import fiskfille.utils.registry.FiskRegistryNamespaced;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Interaction
/*    */   extends FiskRegistryEntry<Interaction>
/*    */ {
/*    */   public static final int MAX_ID = 255;
/* 17 */   public static final FiskRegistryNamespaced<Interaction> REGISTRY = (new FiskRegistryNamespaced("fiskutils", null)).setMaxId(255);
/*    */ 
/*    */   
/*    */   public static void register(String key, Interaction value) {
/* 21 */     REGISTRY.putObject(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Interaction getFromName(String key) {
/* 26 */     return (Interaction)REGISTRY.getObject(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getNameFor(Interaction value) {
/* 31 */     return REGISTRY.getNameForObject(value);
/*    */   }
/*    */   
/* 34 */   public static final NetworkRegistry.TargetPoint TARGET_NONE = new NetworkRegistry.TargetPoint(0, 0.0D, 0.0D, 0.0D, 0.0D);
/* 35 */   public static final NetworkRegistry.TargetPoint TARGET_ALL = null;
/*    */ 
/*    */   
/*    */   public abstract boolean listen(EntityPlayer paramEntityPlayer1, EntityPlayer paramEntityPlayer2, InteractionHandler.InteractionType paramInteractionType, Side paramSide, int paramInt1, int paramInt2, int paramInt3, List<Integer> paramList);
/*    */   
/*    */   public abstract void receive(EntityPlayer paramEntityPlayer1, EntityPlayer paramEntityPlayer2, InteractionHandler.InteractionType paramInteractionType, Side paramSide, int paramInt1, int paramInt2, int paramInt3, Integer[] paramArrayOfInteger);
/*    */   
/*    */   public boolean listen(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z) {
/* 43 */     List<Integer> args = new ArrayList<>();
/*    */     
/* 45 */     if (listen(sender, clientPlayer, type, side, x, y, z, args)) {
/*    */       
/* 47 */       receive(sender, clientPlayer, type, side, x, y, z, args.<Integer>toArray(new Integer[args.size()]));
/*    */       
/* 49 */       return true;
/*    */     } 
/*    */     
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean syncWithServer() {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public NetworkRegistry.TargetPoint getTargetPoint(EntityPlayer player, int x, int y, int z) {
/* 62 */     return new NetworkRegistry.TargetPoint(player.field_71093_bK, x, y, z, 32.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\interaction\Interaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */