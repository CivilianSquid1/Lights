/*    */ package fiskfille.utils.common.interaction.key;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fiskfille.utils.common.interaction.InteractionBase;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyBinding;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public abstract class KeyPressBase
/*    */   extends InteractionBase
/*    */ {
/*    */   public KeyPressBase(InteractionHandler.InteractionType... types) {
/* 14 */     super(types);
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyPressBase() {
/* 19 */     super(new InteractionHandler.InteractionType[] { InteractionHandler.InteractionType.KEY_PRESS });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean syncWithServer() {
/* 25 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean serverRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean clientRequirements(EntityPlayer player, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 37 */     return getKey(player).func_151470_d();
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract FiskKeyBinding getKey(EntityPlayer paramEntityPlayer);
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\interaction\key\KeyPressBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */