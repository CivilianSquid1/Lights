/*    */ package fiskfille.utils.common.interaction;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class InteractionBase
/*    */   extends Interaction
/*    */ {
/*    */   protected final ImmutableList<InteractionHandler.InteractionType> reqTypes;
/*    */   
/*    */   public InteractionBase(InteractionHandler.InteractionType... types) {
/* 17 */     this.reqTypes = ImmutableList.builder().add((Object[])types).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public InteractionBase() {
/* 22 */     this(new InteractionHandler.InteractionType[] { InteractionHandler.InteractionType.RIGHT_CLICK_AIR });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean listen(EntityPlayer sender, EntityPlayer clientPlayer, InteractionHandler.InteractionType type, Side side, int x, int y, int z, List<Integer> args) {
/* 28 */     if (!this.reqTypes.contains(type))
/*    */     {
/* 30 */       return false;
/*    */     }
/*    */     
/* 33 */     if (side.isClient() && sender == clientPlayer)
/*    */     {
/* 35 */       if (!clientRequirements(sender, type, x, y, z))
/*    */       {
/* 37 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 41 */     return serverRequirements(sender, type, x, y, z);
/*    */   }
/*    */   
/*    */   public abstract boolean serverRequirements(EntityPlayer paramEntityPlayer, InteractionHandler.InteractionType paramInteractionType, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   public abstract boolean clientRequirements(EntityPlayer paramEntityPlayer, InteractionHandler.InteractionType paramInteractionType, int paramInt1, int paramInt2, int paramInt3);
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\interaction\InteractionBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */