/*    */ package fiskfille.utils.common.entity.attribute;
/*    */ 
/*    */ 
/*    */ public class AttributePair
/*    */ {
/*    */   public final Double amount;
/*    */   public final Integer operation;
/*    */   
/*    */   public AttributePair(double amount, int operation) {
/* 10 */     this.amount = Double.valueOf(amount);
/* 11 */     this.operation = Integer.valueOf(operation);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 17 */     return String.format("AttributePair[amt=%s,op=%s]", new Object[] { this.amount, this.operation });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 23 */     return this.amount.hashCode() ^ this.operation.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 29 */     if (obj instanceof AttributePair) {
/*    */       
/* 31 */       AttributePair pair = (AttributePair)obj;
/*    */       
/* 33 */       return (pair.amount.equals(this.amount) && pair.operation.equals(this.operation));
/*    */     } 
/*    */     
/* 36 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\entity\attribute\AttributePair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */