/*    */ package fiskfille.utils.common.entity.attribute;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.ai.attributes.IAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeWrapper
/*    */ {
/* 13 */   private final List<AttributePair> modifiers = Lists.newArrayList();
/*    */   
/*    */   public final IAttribute attribute;
/*    */   
/*    */   public AttributeWrapper(IAttribute attribute) {
/* 18 */     this.attribute = attribute;
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<Double> getModifiers(int operation) {
/* 23 */     List<Double> list = Lists.newArrayList();
/*    */     
/* 25 */     for (AttributePair pair : this.modifiers) {
/*    */       
/* 27 */       if (operation == pair.operation.intValue())
/*    */       {
/* 29 */         list.add(pair.amount);
/*    */       }
/*    */     } 
/*    */     
/* 33 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   public ImmutableList<AttributePair> getModifiers() {
/* 38 */     return ImmutableList.copyOf(this.modifiers);
/*    */   }
/*    */ 
/*    */   
/*    */   public void apply(double amount, int operation) {
/* 43 */     this.modifiers.add(new AttributePair(amount, operation));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 48 */     return this.modifiers.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getValue(double baseValue) {
/* 53 */     List<Double> list = Lists.newArrayList(getModifiers(1));
/* 54 */     list.addAll(getModifiers(2));
/*    */     
/*    */     Iterator<Double> iter;
/*    */     
/* 58 */     for (iter = list.iterator(); iter.hasNext(); baseValue *= 1.0D + amount)
/*    */     {
/* 60 */       double amount = ((Double)iter.next()).doubleValue();
/*    */     }
/*    */     
/* 63 */     for (iter = getModifiers(0).iterator(); iter.hasNext(); baseValue += amount)
/*    */     {
/* 65 */       double amount = ((Double)iter.next()).doubleValue();
/*    */     }
/*    */     
/* 68 */     return this.attribute.func_111109_a(baseValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public float getValue(float baseValue) {
/* 73 */     return (float)getValue(baseValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\entity\attribute\AttributeWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */