/*    */ package fiskfille.utils.common.keybinds;
/*    */ 
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ 
/*    */ public class FiskKeyBinding
/*    */   extends KeyBinding
/*    */ {
/*    */   public final String defaultKeyDescription;
/*    */   public String field_74515_c;
/*    */   
/*    */   public FiskKeyBinding(String name, int key) {
/* 13 */     super(name = "key." + FiskServerUtils.getActiveModId() + "." + name, key, FiskServerUtils.getActiveModName());
/* 14 */     this.defaultKeyDescription = name;
/* 15 */     this.field_74515_c = name;
/*    */     
/* 17 */     FiskKeyHandler.KEYS.add(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_151464_g() {
/* 23 */     return this.field_74515_c;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return this.defaultKeyDescription;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\keybinds\FiskKeyBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */