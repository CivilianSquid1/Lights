/*    */ package fiskfille.utils.common.keybinds;
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.common.gameevent.InputEvent;
/*    */ import cpw.mods.fml.common.gameevent.TickEvent;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.MathHelper;
/*    */ 
/*    */ public enum FiskKeyHandler {
/*    */   private int[] timePressed;
/*    */   private int pressed;
/*    */   private Minecraft mc;
/*    */   public static final List<FiskKeyBinding> KEYS;
/* 19 */   INSTANCE;
/*    */   
/*    */   FiskKeyHandler() {
/* 22 */     this.mc = Minecraft.func_71410_x();
/*    */   }
/*    */   static {
/*    */     KEYS = new ArrayList<>();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 30 */     EntityClientPlayerMP entityClientPlayerMP = this.mc.field_71439_g;
/*    */     
/* 32 */     if (this.mc.field_71462_r == null) {
/*    */       
/* 34 */       int prevPressed = this.pressed;
/* 35 */       this.pressed = 0;
/*    */       
/* 37 */       for (int i = 0; i < KEYS.size(); i++) {
/*    */         
/* 39 */         if (((FiskKeyBinding)KEYS.get(i)).func_151470_d())
/*    */         {
/* 41 */           this.pressed |= 1 << i;
/*    */         }
/*    */       } 
/*    */       
/* 45 */       if (this.pressed != prevPressed)
/*    */       {
/* 47 */         InteractionHandler.interact((EntityPlayer)this.mc.field_71439_g, InteractionHandler.InteractionType.KEY_PRESS, MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70165_t), MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70121_D.field_72338_b), MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70161_v));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onClientTick(TickEvent.ClientTickEvent event) {
/* 55 */     EntityClientPlayerMP entityClientPlayerMP = this.mc.field_71439_g;
/*    */     
/* 57 */     if (this.mc.field_71462_r == null && event.phase == TickEvent.Phase.END) {
/*    */       
/* 59 */       if (this.timePressed == null)
/*    */       {
/* 61 */         this.timePressed = new int[KEYS.size()];
/*    */       }
/*    */       
/* 64 */       for (int i = 0; i < KEYS.size(); i++) {
/*    */         
/* 66 */         if (((FiskKeyBinding)KEYS.get(i)).func_151470_d()) {
/*    */           
/* 68 */           this.timePressed[i] = this.timePressed[i] + 1; if (this.timePressed[i] + 1 == 5)
/*    */           {
/* 70 */             InteractionHandler.interact((EntityPlayer)this.mc.field_71439_g, InteractionHandler.InteractionType.KEY_HOLD, MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70165_t), MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70121_D.field_72338_b), MathHelper.func_76128_c(((EntityPlayer)entityClientPlayerMP).field_70161_v));
/*    */           }
/*    */         }
/*    */         else {
/*    */           
/* 75 */           this.timePressed[i] = 0;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void register() {
/* 83 */     FMLCommonHandler.instance().bus().register(INSTANCE);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\keybinds\FiskKeyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */