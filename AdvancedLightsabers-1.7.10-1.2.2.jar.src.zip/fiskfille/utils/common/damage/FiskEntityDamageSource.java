/*    */ package fiskfille.utils.common.damage;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.EntityDamageSource;
/*    */ 
/*    */ public class FiskEntityDamageSource
/*    */   extends EntityDamageSource
/*    */   implements IExtendedDamage {
/*    */   private int flags;
/*    */   
/*    */   public FiskEntityDamageSource(String domain, String name, Entity entity) {
/* 12 */     super(domain + "." + name, entity);
/*    */   }
/*    */ 
/*    */   
/*    */   public FiskEntityDamageSource with(IExtendedDamage.DamageType... types) {
/* 17 */     this.flags = IExtendedDamage.DamageType.with(this.flags, types);
/* 18 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFlags() {
/* 24 */     return this.flags;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\damage\FiskEntityDamageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */