/*    */ package fiskfille.utils.common.damage;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.EntityDamageSourceIndirect;
/*    */ 
/*    */ public class FiskEntityDamageSourceIndirect
/*    */   extends EntityDamageSourceIndirect
/*    */   implements IExtendedDamage {
/*    */   private int flags;
/*    */   
/*    */   public FiskEntityDamageSourceIndirect(String domain, String name, Entity entity, Entity indirectEntity) {
/* 12 */     super(domain + "." + name, entity, indirectEntity);
/*    */   }
/*    */ 
/*    */   
/*    */   public FiskEntityDamageSourceIndirect with(IExtendedDamage.DamageType... types) {
/* 17 */     this.flags = IExtendedDamage.DamageType.with(this.flags, types);
/* 18 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFlags() {
/* 24 */     return this.flags;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\damage\FiskEntityDamageSourceIndirect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */