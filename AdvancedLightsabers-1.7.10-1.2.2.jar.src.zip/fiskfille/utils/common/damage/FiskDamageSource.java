/*    */ package fiskfille.utils.common.damage;
/*    */ 
/*    */ import net.minecraft.util.DamageSource;
/*    */ 
/*    */ public class FiskDamageSource
/*    */   extends DamageSource
/*    */   implements IExtendedDamage {
/*    */   private int flags;
/*    */   
/*    */   public FiskDamageSource(String domain, String name) {
/* 11 */     super(domain + "." + name);
/*    */   }
/*    */ 
/*    */   
/*    */   public FiskDamageSource with(IExtendedDamage.DamageType... types) {
/* 16 */     this.flags = IExtendedDamage.DamageType.with(this.flags, types);
/* 17 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFlags() {
/* 23 */     return this.flags;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\damage\FiskDamageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */