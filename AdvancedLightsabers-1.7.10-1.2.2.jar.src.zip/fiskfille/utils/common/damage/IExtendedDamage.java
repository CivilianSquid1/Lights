/*    */ package fiskfille.utils.common.damage;
/*    */ 
/*    */ import net.minecraft.util.DamageSource;
/*    */ 
/*    */ public interface IExtendedDamage
/*    */ {
/*    */   int getFlags();
/*    */   
/*    */   public enum DamageType
/*    */   {
/* 11 */     KINETIC((String)new IExtendedDamage.DamageTypeCallback.Impl()
/*    */       {
/*    */         
/*    */         public boolean isPresent(IExtendedDamage.DamageType type, DamageSource source)
/*    */         {
/* 16 */           return (source == DamageSource.field_76379_h || super.isPresent(type, source));
/*    */         }
/*    */       }),
/* 19 */     INTERNAL((String)new IExtendedDamage.DamageTypeCallback.Impl()
/*    */       {
/*    */         
/*    */         public boolean isPresent(IExtendedDamage.DamageType type, DamageSource source)
/*    */         {
/* 24 */           return (source == DamageSource.field_76369_e || source == DamageSource.field_76366_f || super.isPresent(type, source));
/*    */         }
/*    */       }),
/* 27 */     COLD,
/* 28 */     ENERGY,
/* 29 */     SOUND,
/* 30 */     LIGHTNING;
/*    */ 
/*    */     
/*    */     private final IExtendedDamage.DamageTypeCallback hook;
/*    */     
/*    */     DamageType(IExtendedDamage.DamageTypeCallback callback) {
/* 36 */       this.hook = callback;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public int getFlag() {
/* 46 */       return 1 << ordinal();
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isPresent(DamageSource source) {
/* 51 */       return this.hook.isPresent(this, source);
/*    */     }
/*    */ 
/*    */     
/*    */     public static int with(int flags, DamageType... types) {
/* 56 */       for (DamageType type : types)
/*    */       {
/* 58 */         flags |= type.getFlag();
/*    */       }
/*    */       
/* 61 */       return flags;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static interface DamageTypeCallback
/*    */   {
/*    */     boolean isPresent(IExtendedDamage.DamageType param1DamageType, DamageSource param1DamageSource);
/*    */     
/*    */     public static class Impl
/*    */       implements DamageTypeCallback
/*    */     {
/*    */       public boolean isPresent(IExtendedDamage.DamageType type, DamageSource source) {
/* 74 */         return (source instanceof IExtendedDamage && (((IExtendedDamage)source).getFlags() & type.getFlag()) == type.getFlag());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\damage\IExtendedDamage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */