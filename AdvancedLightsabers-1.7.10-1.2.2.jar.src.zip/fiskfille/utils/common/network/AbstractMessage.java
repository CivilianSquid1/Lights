/*     */ package fiskfille.utils.common.network;
/*     */ 
/*     */ import com.fiskmods.lightsabers.Lightsabers;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import cpw.mods.fml.common.network.simpleimpl.MessageContext;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessage<REQ extends AbstractMessage>
/*     */   implements IMessage, IMessageHandler<REQ, IMessage>
/*     */ {
/*     */   protected MessageContext context;
/*     */   
/*     */   public final IMessage onMessage(REQ message, MessageContext ctx) {
/*  20 */     ((AbstractMessage)message).context = ctx;
/*     */ 
/*     */     
/*     */     try {
/*  24 */       message.receive();
/*     */     }
/*  26 */     catch (MessageException messageException) {}
/*     */ 
/*     */ 
/*     */     
/*  30 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityPlayer getPlayer() throws MessageException {
/*  37 */     EntityPlayer player = this.context.side.isClient() ? Lightsabers.proxy.getPlayer() : (EntityPlayer)(this.context.getServerHandler()).field_147369_b;
/*     */     
/*  39 */     if (player != null)
/*     */     {
/*  41 */       return player;
/*     */     }
/*     */     
/*  44 */     throw new EntityCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Entity> T getEntity(World world, Class<? extends T> type, int id) throws MessageException {
/*  49 */     Entity entity = world.func_73045_a(id);
/*     */     
/*  51 */     if (entity != null && type.isInstance(entity))
/*     */     {
/*  53 */       return (T)entity;
/*     */     }
/*     */     
/*  56 */     throw new EntityCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Entity> T getEntity(Class<? extends T> type, int id) throws MessageException {
/*  61 */     return getEntity(getWorld(), type, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityPlayer getPlayer(World world, int id) throws MessageException {
/*  66 */     return getEntity(world, EntityPlayer.class, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityPlayer getPlayer(int id) throws MessageException {
/*  71 */     return getPlayer(getWorld(), id);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityPlayer getSender(World world, int id) throws MessageException {
/*  76 */     return this.context.side.isServer() ? getPlayer() : getPlayer(world, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityPlayer getSender(int id) throws MessageException {
/*  81 */     return getSender(getWorld(), id);
/*     */   }
/*     */ 
/*     */   
/*     */   public World getWorld() throws MessageException {
/*  86 */     return (getPlayer()).field_70170_p;
/*     */   }
/*     */ 
/*     */   
/*     */   public World getWorld(int dimension) throws MessageException {
/*  91 */     if (dimension == (getWorld()).field_73011_w.field_76574_g)
/*     */     {
/*  93 */       return getWorld();
/*     */     }
/*  95 */     if (this.context.side.isServer())
/*     */     {
/*  97 */       return (World)MinecraftServer.func_71276_C().func_71218_a(dimension);
/*     */     }
/*     */     
/* 100 */     throw new InvalidSideException();
/*     */   }
/*     */   
/*     */   public abstract void receive() throws MessageException;
/*     */   
/*     */   protected static class MessageException extends Exception {}
/*     */   
/*     */   protected static class EntityCastException extends MessageException {}
/*     */   
/*     */   protected static class InvalidSideException extends MessageException {}
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\network\AbstractMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */