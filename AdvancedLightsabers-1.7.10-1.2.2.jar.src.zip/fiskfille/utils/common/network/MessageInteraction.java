/*    */ package fiskfille.utils.common.network;
/*    */ 
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.common.interaction.Interaction;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.registry.FiskRegistryEntry;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class MessageInteraction extends AbstractMessage<MessageInteraction> {
/*    */   private int id;
/*    */   private int x;
/*    */   private int y;
/*    */   private int z;
/*    */   private Interaction interaction;
/*    */   private InteractionHandler.InteractionType type;
/*    */   
/*    */   public MessageInteraction() {}
/*    */   
/*    */   public MessageInteraction(EntityPlayer player, Interaction interaction, InteractionHandler.InteractionType type, int x, int y, int z) {
/* 22 */     this.id = player.func_145782_y();
/* 23 */     this.interaction = interaction;
/* 24 */     this.type = type;
/* 25 */     this.x = x;
/* 26 */     this.y = y;
/* 27 */     this.z = z;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 33 */     this.id = buf.readInt();
/* 34 */     this.interaction = (Interaction)Interaction.REGISTRY.getObjectById(buf.readByte());
/* 35 */     this.type = InteractionHandler.InteractionType.values()[Math.abs(buf.readByte()) % (InteractionHandler.InteractionType.values()).length];
/* 36 */     this.x = buf.readInt();
/* 37 */     this.y = buf.readInt();
/* 38 */     this.z = buf.readInt();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 44 */     buf.writeInt(this.id);
/* 45 */     buf.writeByte(Interaction.REGISTRY.getIDForObject((FiskRegistryEntry)this.interaction));
/* 46 */     buf.writeByte(this.type.ordinal());
/* 47 */     buf.writeInt(this.x);
/* 48 */     buf.writeInt(this.y);
/* 49 */     buf.writeInt(this.z);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 55 */     EntityPlayer sender = getSender(this.id);
/* 56 */     EntityPlayer clientPlayer = getPlayer();
/*    */     
/* 58 */     if (this.context.side.isClient()) {
/*    */       
/* 60 */       if (sender != clientPlayer)
/*    */       {
/* 62 */         this.interaction.listen(sender, clientPlayer, this.type, Side.CLIENT, this.x, this.y, this.z);
/*    */       }
/*    */     }
/* 65 */     else if (this.interaction.listen(sender, clientPlayer, this.type, Side.SERVER, this.x, this.y, this.z)) {
/*    */       
/* 67 */       NetworkRegistry.TargetPoint target = this.interaction.getTargetPoint(sender, this.x, this.y, this.z);
/*    */       
/* 69 */       if (target == null) {
/*    */         
/* 71 */         FiskNetworkManager.wrapper.sendToDimension(this, sender.field_71093_bK);
/*    */       }
/* 73 */       else if (target.range > 0.0D) {
/*    */         
/* 75 */         FiskNetworkManager.wrapper.sendToAllAround(this, target);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\network\MessageInteraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */