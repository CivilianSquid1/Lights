/*    */ package fiskfille.utils.common.network;
/*    */ 
/*    */ import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ 
/*    */ public class FiskNetworkManager
/*    */   extends FiskNetworkHelper
/*    */ {
/*    */   public static SimpleNetworkWrapper wrapper;
/*    */   
/*    */   public static void register() {
/* 12 */     wrapper = getWrapper(FiskServerUtils.getActiveModId());
/*    */     
/* 14 */     registerMessage(MessageInteraction.class);
/* 15 */     registerMessage(MessageTileTrigger.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\network\FiskNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */