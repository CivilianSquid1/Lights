/*    */ package fiskfille.utils.common.network;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FiskNetworkHelper
/*    */ {
/* 15 */   private static Map<String, SimpleNetworkWrapper> wrappers = Maps.newHashMap();
/* 16 */   private static Map<String, Integer> ids = Maps.newHashMap();
/*    */ 
/*    */ 
/*    */   
/*    */   public static <REQ extends cpw.mods.fml.common.network.simpleimpl.IMessage & cpw.mods.fml.common.network.simpleimpl.IMessageHandler<REQ, cpw.mods.fml.common.network.simpleimpl.IMessage>> void registerMessage(Class<REQ> msg) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: getstatic cpw/mods/fml/relauncher/Side.CLIENT : Lcpw/mods/fml/relauncher/Side;
/*    */     //   4: invokestatic registerMessage : (Ljava/lang/Class;Lcpw/mods/fml/relauncher/Side;)V
/*    */     //   7: aload_0
/*    */     //   8: getstatic cpw/mods/fml/relauncher/Side.SERVER : Lcpw/mods/fml/relauncher/Side;
/*    */     //   11: invokestatic registerMessage : (Ljava/lang/Class;Lcpw/mods/fml/relauncher/Side;)V
/*    */     //   14: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #20	-> 0
/*    */     //   #21	-> 7
/*    */     //   #22	-> 14
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	15	0	msg	Ljava/lang/Class;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	15	0	msg	Ljava/lang/Class<TREQ;>;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <REQ extends cpw.mods.fml.common.network.simpleimpl.IMessage & cpw.mods.fml.common.network.simpleimpl.IMessageHandler<REQ, cpw.mods.fml.common.network.simpleimpl.IMessage>> void registerMessage(Class<REQ> msg, Side side) {
/* 26 */     String modid = FiskServerUtils.getActiveModId();
/* 27 */     getWrapper(modid).registerMessage(msg, msg, getNextId(modid), side);
/*    */   }
/*    */ 
/*    */   
/*    */   public static SimpleNetworkWrapper getWrapper(String modid) {
/* 32 */     SimpleNetworkWrapper wrapper = wrappers.get(modid);
/*    */     
/* 34 */     if (wrapper == null)
/*    */     {
/* 36 */       wrappers.put(modid, wrapper = new SimpleNetworkWrapper(modid));
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 81 */     return wrapper;
/*    */   }
/*    */ 
/*    */   
/*    */   protected static int getNextId(String modid) {
/* 86 */     Integer id = (ids.get(modid) != null) ? ids.get(modid) : Integer.valueOf(0);
/* 87 */     ids.put(modid, Integer.valueOf(id.intValue() + 1));
/*    */     
/* 89 */     return id.intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\network\FiskNetworkHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */