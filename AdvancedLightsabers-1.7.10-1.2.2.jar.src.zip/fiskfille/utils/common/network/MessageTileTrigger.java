/*    */ package fiskfille.utils.common.network;
/*    */ 
/*    */ import com.fiskmods.lightsabers.common.network.ALNetworkManager;
/*    */ import fiskfille.utils.DimensionalCoords;
/*    */ import fiskfille.utils.helper.NBTHelper;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageTileTrigger
/*    */   extends AbstractMessage<MessageTileTrigger>
/*    */ {
/*    */   private DimensionalCoords coords;
/*    */   private int id;
/*    */   private int action;
/*    */   private int playerDim;
/*    */   
/*    */   public MessageTileTrigger() {}
/*    */   
/*    */   public MessageTileTrigger(DimensionalCoords coords, EntityPlayer player, int action) {
/* 24 */     this.coords = coords;
/* 25 */     this.action = action;
/*    */     
/* 27 */     if (player != null) {
/*    */       
/* 29 */       this.id = player.func_145782_y();
/* 30 */       this.playerDim = player.field_70170_p.field_73011_w.field_76574_g;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buf) {
/* 37 */     this.id = buf.readInt();
/* 38 */     this.action = buf.readInt();
/* 39 */     this.playerDim = buf.readInt();
/* 40 */     this.coords = (DimensionalCoords)NBTHelper.fromBytes(buf, DimensionalCoords.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buf) {
/* 46 */     buf.writeInt(this.id);
/* 47 */     buf.writeInt(this.action);
/* 48 */     buf.writeInt(this.playerDim);
/* 49 */     NBTHelper.toBytes(buf, this.coords);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void receive() throws AbstractMessage.MessageException {
/* 55 */     EntityPlayer player = getSender(getWorld(this.playerDim), this.id);
/* 56 */     TileEntity tile = getWorld(this.coords.dimension).func_147438_o(this.coords.field_71574_a, this.coords.field_71572_b, this.coords.field_71573_c);
/*    */     
/* 58 */     if (tile instanceof ITileDataCallback) {
/*    */       
/* 60 */       ((ITileDataCallback)tile).receive(player, this.action);
/*    */       
/* 62 */       if (this.context.side.isServer())
/*    */       {
/* 64 */         ALNetworkManager.wrapper.sendToDimension(new MessageTileTrigger(this.coords, player, this.action), this.coords.dimension);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public static interface ITileDataCallback {
/*    */     void receive(EntityPlayer param1EntityPlayer, int param1Int);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\common\network\MessageTileTrigger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */