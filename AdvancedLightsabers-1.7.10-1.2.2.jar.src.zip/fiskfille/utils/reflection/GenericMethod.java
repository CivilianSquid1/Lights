/*    */ package fiskfille.utils.reflection;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ public class GenericMethod<C, T>
/*    */ {
/*    */   private final Method theMethod;
/*    */   
/*    */   public GenericMethod(Method method) {
/* 12 */     this.theMethod = method;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T invoke(C instance, Object... args) {
/*    */     try {
/* 19 */       return (T)this.theMethod.invoke(instance, args);
/*    */     }
/* 21 */     catch (Exception e) {
/*    */       
/* 23 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public T invokeStatic(Object... args) {
/* 29 */     return invoke(null, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public static class Builder<C, T>
/*    */   {
/*    */     private final Class<C> parentClass;
/*    */     
/*    */     private final Class<T> returnType;
/*    */     private Class[] parameters;
/*    */     
/*    */     private Builder(Class<C> parent, Class<T> type) {
/* 41 */       this.parentClass = parent;
/* 42 */       this.returnType = type;
/*    */     }
/*    */ 
/*    */     
/*    */     public static <C, T> Builder in(Class<C> parent, Class<T> type) {
/* 47 */       return new Builder<>(parent, type);
/*    */     }
/*    */ 
/*    */     
/*    */     public Builder with(Class... params) {
/* 52 */       this.parameters = params;
/* 53 */       return this;
/*    */     }
/*    */ 
/*    */     
/*    */     public GenericMethod find(String... names) {
/* 58 */       for (String name : names) {
/*    */         
/* 60 */         for (Method method : this.parentClass.getDeclaredMethods()) {
/*    */           
/* 62 */           if (method.getName().equals(name) && method.getReturnType() == this.returnType) {
/*    */             
/* 64 */             if (this.parameters != null) {
/*    */               
/* 66 */               if ((method.getParameters()).length != this.parameters.length) {
/*    */                 continue;
/*    */               }
/*    */ 
/*    */               
/* 71 */               for (int i = 0; i < this.parameters.length; i++) {
/*    */                 
/* 73 */                 if (method.getParameterTypes()[i] != this.parameters[i]);
/*    */               } 
/*    */             } 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 80 */             method.setAccessible(true);
/* 81 */             return new GenericMethod<>(method);
/*    */           } 
/*    */           continue;
/*    */         } 
/*    */       } 
/* 86 */       throw new RuntimeException(String.format("Unable to locate method of type %s in %s: %s", new Object[] { this.returnType.getName(), this.parentClass.getName(), Arrays.asList(names) }));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\reflection\GenericMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */