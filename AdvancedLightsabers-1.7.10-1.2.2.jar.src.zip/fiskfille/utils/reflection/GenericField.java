/*    */ package fiskfille.utils.reflection;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ public class GenericField<C, T>
/*    */ {
/*    */   private final Field theField;
/*    */   
/*    */   public GenericField(Class<C> parent, Class<T> type, String... names) {
/* 12 */     for (String name : names) {
/*    */       
/* 14 */       for (Field field : parent.getDeclaredFields()) {
/*    */         
/* 16 */         if (field.getName().equals(name) && field.getType() == type) {
/*    */           
/* 18 */           field.setAccessible(true);
/* 19 */           this.theField = field;
/*    */           
/*    */           return;
/*    */         } 
/*    */       } 
/*    */     } 
/* 25 */     throw new RuntimeException(String.format("Unable to locate field of type %s in %s: %s", new Object[] { type.getName(), parent.getName(), Arrays.asList(names) }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T get(C instance) {
/*    */     try {
/* 32 */       return (T)this.theField.get(instance);
/*    */     }
/* 34 */     catch (Exception e) {
/*    */       
/* 36 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public T getStatic() {
/* 42 */     return get(null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(C instance, T value) {
/*    */     try {
/* 49 */       this.theField.set(instance, value);
/*    */     }
/* 51 */     catch (Exception e) {
/*    */       
/* 53 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStatic(T value) {
/* 59 */     set(null, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\reflection\GenericField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */