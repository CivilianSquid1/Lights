/*    */ package fiskfille.utils.asm;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.FMLLaunchHandler;
/*    */ import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLoadingPlugin
/*    */   implements IFMLLoadingPlugin
/*    */ {
/*    */   public static boolean obfuscatedEnv;
/*    */   
/*    */   public abstract void setupTransformers(Side paramSide, List<Class> paramList);
/*    */   
/*    */   public String[] getASMTransformerClass() {
/* 20 */     List<Class<?>> classes = new ArrayList<>();
/* 21 */     setupTransformers(FMLLaunchHandler.side(), classes);
/*    */     
/* 23 */     String[] astring = new String[classes.size()];
/*    */     
/* 25 */     for (int i = 0; i < astring.length; i++)
/*    */     {
/* 27 */       astring[i] = ((Class)classes.get(i)).getName();
/*    */     }
/*    */     
/* 30 */     return astring;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void injectData(Map<String, Object> data) {
/* 36 */     obfuscatedEnv = ((Boolean)Boolean.class.cast(data.get("runtimeDeobfuscationEnabled"))).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\asm\AbstractLoadingPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */