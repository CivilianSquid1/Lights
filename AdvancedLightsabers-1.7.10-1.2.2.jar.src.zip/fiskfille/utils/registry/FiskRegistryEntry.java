/*    */ package fiskfille.utils.registry;
/*    */ 
/*    */ import com.google.common.reflect.TypeToken;
/*    */ import cpw.mods.fml.common.FMLLog;
/*    */ import cpw.mods.fml.common.InjectedModContainer;
/*    */ import cpw.mods.fml.common.Loader;
/*    */ import cpw.mods.fml.common.ModContainer;
/*    */ import java.util.Locale;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FiskRegistryEntry<T>
/*    */ {
/* 16 */   public final FiskDelegate<T> delegate = new FiskDelegate<>((T)this, (Class)getClass());
/*    */   
/* 18 */   private TypeToken<T> token = new TypeToken<T>(getClass())
/*    */     {
/*    */     
/*    */     };
/* 22 */   private ResourceLocation registryName = null;
/*    */ 
/*    */   
/*    */   public final T setRegistryName(String name) {
/* 26 */     if (getRegistryName() != null)
/*    */     {
/* 28 */       throw new IllegalStateException("Attempted to set registry name with existing registry name! New: " + name + " Old: " + getRegistryName());
/*    */     }
/*    */     
/* 31 */     this.delegate.setName(name);
/*    */     
/* 33 */     int index = name.lastIndexOf(':');
/* 34 */     String oldPrefix = (index == -1) ? "" : name.substring(0, index);
/* 35 */     name = (index == -1) ? name : name.substring(index + 1);
/*    */     
/* 37 */     ModContainer mc = Loader.instance().activeModContainer();
/* 38 */     String prefix = (mc == null || (mc instanceof InjectedModContainer && ((InjectedModContainer)mc).wrappedContainer instanceof cpw.mods.fml.common.FMLContainer)) ? "minecraft" : mc.getModId().toLowerCase(Locale.ROOT);
/*    */     
/* 40 */     if (!oldPrefix.equals(prefix) && oldPrefix.length() > 0) {
/*    */       
/* 42 */       FMLLog.bigWarning("Dangerous alternative prefix '%s' for name '%s', expected '%s' invalid registry invocation/invalid name?", new Object[] { oldPrefix, name, prefix });
/* 43 */       prefix = oldPrefix;
/*    */     } 
/*    */     
/* 46 */     this.registryName = new ResourceLocation(prefix, name);
/*    */     
/* 48 */     return (T)this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final T setRegistryName(ResourceLocation name) {
/* 53 */     return setRegistryName(name.toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public final T setRegistryName(String domain, String name) {
/* 58 */     return setRegistryName(domain + ":" + name);
/*    */   }
/*    */ 
/*    */   
/*    */   public final ResourceLocation getRegistryName() {
/* 63 */     return this.registryName;
/*    */   }
/*    */ 
/*    */   
/*    */   public final String getDomain() {
/* 68 */     return this.registryName.func_110624_b();
/*    */   }
/*    */ 
/*    */   
/*    */   public final Class<T> getRegistryType() {
/* 73 */     return this.token.getRawType();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return this.delegate.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\registry\FiskRegistryEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */