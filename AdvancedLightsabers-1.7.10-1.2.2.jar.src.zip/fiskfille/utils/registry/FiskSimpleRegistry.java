/*     */ package fiskfille.utils.registry;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.google.common.collect.BiMap;
/*     */ import com.google.common.collect.HashBiMap;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.collect.Maps;
/*     */ import fiskfille.utils.helper.FiskPredicates;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.util.RegistrySimple;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FiskSimpleRegistry<T extends FiskRegistryEntry<T>>
/*     */   extends RegistrySimple
/*     */   implements Iterable<T>
/*     */ {
/*     */   protected final Map nameLookup;
/*     */   private final String defaultDomain;
/*     */   private final String defaultKey;
/*     */   private T defaultValue;
/*     */   
/*     */   public FiskSimpleRegistry(String domain, String key) {
/*  27 */     this.nameLookup = (Map)((BiMap)this.field_82596_a).inverse();
/*  28 */     this.defaultDomain = domain;
/*  29 */     this.defaultKey = namespace(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getDefaultValue() {
/*  34 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putObject(String key, T value) {
/*  39 */     key = namespace(key);
/*     */     
/*  41 */     if (containsKey(key))
/*     */     {
/*  43 */       throw new IllegalArgumentException(String.format("Duplicate key '%s'", new Object[] { key }));
/*     */     }
/*     */     
/*  46 */     if (this.defaultKey != null && key.equals(this.defaultKey))
/*     */     {
/*  48 */       this.defaultValue = value;
/*     */     }
/*     */     
/*  51 */     value.setRegistryName(key);
/*  52 */     super.func_82595_a(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_82595_a(Object key, Object value) {
/*  58 */     putObject((String)key, (T)value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map func_148740_a() {
/*  64 */     return (Map)HashBiMap.create();
/*     */   }
/*     */ 
/*     */   
/*     */   public T getObject(String key) {
/*  69 */     return castDefault((T)super.func_82594_a(namespace(key)));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNameForObject(T value) {
/*  74 */     return (String)this.nameLookup.get(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/*  79 */     return super.func_148741_d(namespace(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/*  85 */     return this.field_82596_a.values().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String namespace(String key) {
/*  90 */     return (key != null && key.indexOf(':') == -1) ? (this.defaultDomain + ":" + key) : key;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_148741_d(Object key) {
/*  96 */     return containsKey((String)key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(T value) {
/* 101 */     return this.field_82596_a.values().contains(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getObject(Object key) {
/* 107 */     return getObject((String)key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> func_148742_b() {
/* 113 */     return super.func_148742_b();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getKeys(Predicate<T> p) {
/* 118 */     return Maps.filterEntries(this.field_82596_a, FiskPredicates.filterValues(p)).keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public T castDefault(T value) {
/* 123 */     if (value == null)
/*     */     {
/* 125 */       return getDefaultValue();
/*     */     }
/*     */     
/* 128 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getRandom(Random rand) {
/* 133 */     return (T)Iterables.get(this, rand.nextInt(func_148742_b().size()));
/*     */   }
/*     */ 
/*     */   
/*     */   public T getRandom() {
/* 138 */     return getRandom(new Random());
/*     */   }
/*     */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\registry\FiskSimpleRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */