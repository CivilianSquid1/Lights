/*    */ package fiskfille.utils.registry;
/*    */ 
/*    */ import com.google.common.base.Objects;
/*    */ import cpw.mods.fml.common.registry.RegistryDelegate;
/*    */ 
/*    */ 
/*    */ public class FiskDelegate<T>
/*    */   implements RegistryDelegate<T>
/*    */ {
/*    */   private T referant;
/*    */   private String name;
/*    */   private final Class<T> type;
/*    */   
/*    */   public FiskDelegate(T referant, Class<T> type) {
/* 15 */     this.referant = referant;
/* 16 */     this.type = type;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T get() {
/* 22 */     return this.referant;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String name() {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<T> type() {
/* 34 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   void changeReference(T newTarget) {
/* 39 */     this.referant = newTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   void setName(String name) {
/* 44 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (obj instanceof RegistryDelegate.Delegate) {
/*    */       
/* 52 */       RegistryDelegate.Delegate<?> other = (RegistryDelegate.Delegate)obj;
/*    */       
/* 54 */       return Objects.equal(other.name(), this.name);
/*    */     } 
/*    */     
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 63 */     return Objects.hashCode(new Object[] { this.name });
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\registry\FiskDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */