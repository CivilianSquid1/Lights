/*    */ package fiskfille.utils.registry;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import net.minecraft.util.ObjectIntIdentityMap;
/*    */ 
/*    */ public class FiskRegistryNamespaced<T extends FiskRegistryEntry<T>>
/*    */   extends FiskSimpleRegistry<T>
/*    */ {
/*  9 */   protected ObjectIntIdentityMap underlyingIntegerMap = new ObjectIntIdentityMap();
/* 10 */   private int maxId = 0;
/* 11 */   private int nextId = 0;
/*    */ 
/*    */   
/*    */   public FiskRegistryNamespaced(String domain, String key) {
/* 15 */     super(domain, key);
/*    */   }
/*    */ 
/*    */   
/*    */   public FiskRegistryNamespaced<T> setMaxId(int max) {
/* 20 */     this.maxId = max;
/* 21 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void putObject(String key, T value) {
/* 27 */     addObject(this.nextId, key, value);
/* 28 */     this.nextId++;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addObject(int id, String key, T value) {
/* 33 */     if (id < 0 || (this.maxId > 0 && id > this.maxId))
/*    */     {
/* 35 */       throw new IndexOutOfBoundsException(String.format("Index: %s, Max: %s", new Object[] { Integer.valueOf(id), Integer.valueOf(this.maxId) }));
/*    */     }
/*    */     
/* 38 */     super.putObject(key, value);
/* 39 */     this.underlyingIntegerMap.func_148746_a(value, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIDForObject(T value) {
/* 44 */     return this.underlyingIntegerMap.func_148747_b(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public T getObjectById(int id) {
/* 49 */     return castDefault((T)this.underlyingIntegerMap.func_148745_a(id));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsId(int id) {
/* 54 */     return this.underlyingIntegerMap.func_148744_b(id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator iterator() {
/* 60 */     return this.underlyingIntegerMap.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public T lookup(String key) {
/* 65 */     if (containsKey(key))
/*    */     {
/* 67 */       return getObject(key);
/*    */     }
/*    */ 
/*    */     
/*    */     try {
/* 72 */       int id = Integer.parseInt(key);
/*    */       
/* 74 */       if (containsId(id))
/*    */       {
/* 76 */         return getObjectById(id);
/*    */       }
/*    */     }
/* 79 */     catch (NumberFormatException numberFormatException) {}
/*    */ 
/*    */ 
/*    */     
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\registry\FiskRegistryNamespaced.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */