/*    */ package fiskfille.utils;
/*    */ 
/*    */ import com.fiskmods.lightsabers.Lightsabers;
/*    */ import com.google.common.collect.Maps;
/*    */ import fiskfille.utils.common.interaction.InteractionHandler;
/*    */ import fiskfille.utils.common.keybinds.FiskKeyHandler;
/*    */ import fiskfille.utils.common.network.FiskNetworkManager;
/*    */ import fiskfille.utils.helper.FiskServerUtils;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FiskUtils
/*    */ {
/*    */   public static final String MODID = "fiskutils";
/* 17 */   private static final Map<Hook, String> HOOK_OWNERS = Maps.newHashMap();
/*    */ 
/*    */   
/*    */   public static void hook(Hook hook) {
/* 21 */     if (HOOK_OWNERS.containsKey(hook)) {
/*    */       
/* 23 */       Log.debug("%s hook ignored, already handled by %s", new Object[] { hook, HOOK_OWNERS.get(hook) });
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 28 */     Log.debug("Adding hook %s", new Object[] { hook });
/* 29 */     HOOK_OWNERS.put(hook, FiskServerUtils.getActiveModId());
/*    */ 
/*    */     
/* 32 */     switch (hook) {
/*    */ 
/*    */       
/*    */       case PREINIT:
/* 36 */         if (Lightsabers.proxy.getSide().isClient())
/*    */         {
/* 38 */           FiskKeyHandler.register();
/*    */         }
/*    */         
/* 41 */         FiskNetworkManager.register();
/* 42 */         InteractionHandler.register();
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Hook
/*    */   {
/* 51 */     PREINIT,
/* 52 */     INIT,
/* 53 */     POSTINIT;
/*    */   }
/*    */ }


/* Location:              C:\Users\Augustus\Desktop\AdvancedLightsabers-1.7.10-1.2.2.jar!\fiskfill\\utils\FiskUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */